--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8 (Ubuntu 14.8-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.8 (Ubuntu 14.8-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: kfz; Type: TABLE; Schema: public; Owner: jensen
--

CREATE TABLE public.kfz (
    code character varying,
    ort character varying
);


ALTER TABLE public.kfz OWNER TO jensen;

--
-- Name: plz; Type: TABLE; Schema: public; Owner: jensen
--

CREATE TABLE public.plz (
    id integer,
    stadt character varying,
    land character varying,
    abk character(2),
    landkreis character varying
);


ALTER TABLE public.plz OWNER TO jensen;

--
-- Name: plz_kfz; Type: VIEW; Schema: public; Owner: jensen
--

CREATE VIEW public.plz_kfz AS
 SELECT "substring"(to_char(plz.id, '00000'::text), 2) AS "substring",
    kfz.code,
    kfz.ort
   FROM (public.plz
     JOIN public.kfz ON (((POSITION(((lower((plz.landkreis)::text) || ' '::text)) IN (lower((kfz.ort)::text))) = 1) OR (POSITION(((lower((plz.stadt)::text) || ' '::text)) IN (lower((kfz.ort)::text))) = 1))))
  ORDER BY plz.id;


ALTER TABLE public.plz_kfz OWNER TO jensen;

--
-- Data for Name: kfz; Type: TABLE DATA; Schema: public; Owner: jensen
--

COPY public.kfz (code, ort) FROM stdin;
A	Augsburg         
AA	Ostalbkreis         
AB	Aschaffenburg         
ABG	Altenburger Land        
ABI	Anhalt-Bitterfeld         
AC	Aachen         
AE	Vogtlandkreis         
AH	Borken         
AIB	München Rosenheim        
AIC	Aichach-Friedberg         
AK	Altenkirchen (Westerwald)        
ALF	Hildesheim         
ALZ	Aschaffenburg         
AM	Amberg Stadt        
AN	Ansbach         
ANA	Erzgebirgskreis         
ANG	Uckermark         
ANK	Vorpommern-Greifswald         
AÖ	Altötting         
AP	Weimarer Land        
APD	Weimarer Land        
ARN	Ilm-Kreis         
ART	Kyffhäuserkreis         
AS	Amberg-Sulzbach         
ASL	Salzlandkreis         
ASZ	Erzgebirgskreis         
AT	Mecklenburgische Seenplatte        
AU	Erzgebirgskreis         
AUR	Aurich         
AW	Ahrweiler         
AZ	Alzey-Worms         
AZE	Anhalt-Bitterfeld         
B	Berlin         
BA	Bamberg         
BAD	Baden-Baden Stadt        
BAR	Barnim         
BB	Böblingen         
BBG	Salzlandkreis         
BC	Biberach         
BCH	Neckar-Odenwald-Kreis         
BE	Warendorf         
BED	Mittelsachsen         
BER	Barnim         
BF	Steinfurt         
BGD	Berchtesgadener Land        
BGL	Berchtesgadener Land        
BH	Ortenaukreis Raststatt        
BI	Bielefeld         
BID	Marburg-Biedenkopf         
BIN	Mainz-Bingen         
BIR	Birkenfeld         
BIT	Eifelkreis Bitburg-Prüm        
BIW	Bautzen         
BK	Börde Rems-Murr-Kreis        
BKS	Bernkastel-Wittlich         
BL	Zollernalbkreis         
BLB	Siegen-Wittgenstein         
BLK	Burgenlandkreis         
BM	Rhein-Erft-Kreis         
BN	Bonn Stadt        
BNA	Leipzig         
BO	Bochum Stadt        
BÖ	Börde         
BOH	Borken         
BOR	Borken         
BOT	Bottrop Stadt        
BRA	Wesermarsch         
BRB	Brandenburg Stadt        
BRG	Jerichower Land        
BRK	Bad Kissingen        
BRL	Goslar         
BRV	Rotenburg (Wümme)        
BS	Braunschweig Stadt        
BT	Bayreuth         
BTF	Anhalt-Bitterfeld         
BÜD	Wetteraukreis         
BÜR	Paderborn         
BUL	Amberg-Sulzbach Schwandorf        
BÜS	Konstanz Gemeinde Büsingen am Hochrhein     
BÜZ	Rostock Landkreis        
BZ	Bautzen         
C	Chemnitz Stadt        
CA	Oberspreewald-Lausitz         
CAS	Recklinghausen         
CB	Cottbus         
CE	Celle         
CHA	Cham         
CLP	Cloppenburg         
CLZ	Goslar         
CO	Zulassungsstelle Coburg        
COC	Cochem-Zell         
COE	Coesfeld         
CR	Schwäbisch Hall        
CW	Calw         
CUX	Cuxhaven         
D	Düsseldorf Stadt        
DA	Darmstadt         
DAH	Dachau         
DAN	Lüchow-Dannenberg         
DAU	Vulkaneifel         
DBR	Rostock Landkreis        
DD	Dresden Stadt        
DE	Dessau-Roßlau Stadt        
DEG	Deggendorf         
DEL	Delmenhorst Stadt        
DGF	Dingol ng-Landau        
DH	Diepholz         
DI	Darmstadt-Dieburg         
DIL	Lahn-Dill-Kreis         
DIN	Wesel         
DIZ	Rhein-Lahn-Kreis         
DKB	Dinkelsbühl         
DL	Mittelsachsen         
DLG	Dillingen an der Donau      
DM	Mecklenburgische Seenplatte        
DN	Düren         
DO	Dortmund Stadt        
DON	Donau-Ries in Donauwörth       
DU	Duisburg Stadt        
DUD	Göttingen         
DÜW	Bad Dürkheim        
DW	Sächsische Schweiz-Osterzgebirge        
DZ	Nordsachsen         
E	Essen Stadt        
EA	Eisenach Stadt        
EB	Nordsachsen         
EBE	Ebersberg         
EBN	Haßberge         
EBS	Bayreuth Forchheim Kulmbach       
ECK	Rendsburg-Eckernförde         
ED	Erding         
EE	Elbe-Elster         
EF	Erfurt Stadt        
EG	Rottal-Inn         
EI	Eichstätt         
EIC	Eichsfeld         
EIL	Mansfeld-Südharz         
EIN	Northeim         
EIS	Saale-Holzland-Kreis         
EL	Emsland         
EM	Emmendingen         
EMD	Emden Stadt        
EMS	Rhein-Lahn-Kreis         
EN	Ennepe-Ruhr-Kreis         
ER	Erlangen Stadt        
ERB	Odenwaldkreis         
ERH	Erlangen-Höchstadt         
ERK	Heinsberg         
ERZ	Erzgebirgskreis         
ES	Esslingen         
ESB	Amberg-Sulzbach Bayreuth Neustadt a. d. Waldnaab Nürnberger Land  
ESW	Werra-Meißner-Kreis         
EU	Euskirchen         
EW	Barnim         
F	Frankfurt/Main Stadt        
FB	Wetteraukreis in Friedberg Hessen      
FD	Fulda         
FDB	Aichach-Friedberg         
FDS	Freudenstadt         
FEU	Ansbach         
FF	Frankfurt (Oder) Stadt       
FFB	Fürstenfeldbruck         
FG	Mittelsachsen         
FI	Elbe-Elster         
FKB	Waldeck-Frankenberg         
FL	Flensburg         
FLÖ	Mittelsachsen         
FN	Bodenseekreis         
FO	Forchheim         
FOR	Spree-Neiße         
FR	Freiburg im Breisgau Breisgau-Hochschwarzwald      
FRG	Freyung-Grafenau         
FRI	Friesland         
FRW	Märkisch-Oderland         
FS	Freising Moosburg        
FT	Frankenthal (Pfalz) Zulassungsbehörde Bad Dürkheim und Rhein-Pfalz-Kreis   
FTL	Sächsische Schweiz-Osterzgebirge        
FÜ	Fürth Zirndorf in Bayern      
FÜS	Ostallgäu         
FZ	Schwalm-Eder-Kreis         
GA	Gardelegen / Altmarkkreis Salzwedel – Sachsen-Anhalt   
GAN	Bad Gandersheim / Landkreis Northeim – Niedersachsen  
GAP	Garmisch-Partenkirchen – Bayern      
GC	Glauchau / Landkreis Zwickau – Sachsen   
GD	Schwäbisch Gmünd / Ostalbkreis – Baden-Württemberg   
GDB	Gadebusch / Landkreis Nordwestmecklenburg – Mecklenburg-Vorpommern   
GE	Gelsenkirchen – Nordrhein-Westfalen      
GEL	Geldern / Kreis Kleve – Nordrhein-Westfalen   
GEO	Gerolzhofen / Landkreise Haßberge und Schweinfurt – Bayern 
GER	Germersheim – Rheinland-Pfalz      
GF	Gifhorn – Niedersachsen      
GG	Groß-Gerau – Hessen      
GHA	Geithain / Landkreis Leipzig – Sachsen   
GHC	Gräfenhainichen / Landkreis Wittenberg – Sachsen-Anhalt   
GI	Gießen – Hessen      
GK	Geilenkirchen / Kreis Heinsberg – Nordhrein-Westfalen   
GL	Bergisch Gladbach / Rheinisch-Bergischer Kreis – Nordrhein-Westfalen  
GM	Gummersbach / Oberbergischer Kreis – Nordrhein-Westfalen   
GMN	Grimmen / Landkreis Vorpommern-Rügen – Mecklenburg-Vorpommern   
GN	Main-Kinzig-Kreis
GNT	Genthin / Landkreis Jerichower Land – Sachsen-Anhalt  
GÖ	Göttingen – Niedersachsen      
GOA	Sankt Goar / Rhein-Hunsrück-Kreis – Rheinland-Pfalz   
GOH	Sankt Goarshausen / Rhein-Lahn-Kreis – Rheinland-Pfalz   
GP	Göppingen – Baden-Württemberg      
GR	Görlitz – Sachsen      
GRA	Görlitz – Sachsen      
GRH	Grafenau / Landkreis Freyung-Grafenau – Bayern   
GRI	Bad Griesbach im Rottal / Landkreis Rottal-Inn – Bayern
GRM	Grimma / Landkreis Leipzig – Sachsen   
GRZ	Greiz – Thüringen      
GS	Goslar – Niedersachsen      
GT	Gütersloh in Rheda-Wiedenbrück – Nordrhein-Westfalen    
GTH	Gotha – Thüringen      
GÜ	Güstrow / Landkreis Rostock – Mecklenburg-Vorpommern   
GUB	Guben / Landkreis Spree-Neiße – Brandenburg   
GUN	Gunzenhausen / Landkreis Weißenburg-Gunzenhausen – Bayern   
GVM	Grevesmühlen / Landkreis Nordwestmecklenburg – Mecklenburg-Vorpommern   
GW	Greifswald / Landkreis Vorpommern-Greifswald – Mecklenburg-Vorpommern   
GZ	Günzburg – Bayern      
H	Hannover – Niedersachsen      
HA	Hagen / Westfalen – Nordrhein-Westfalen    
HAB	Hammelburg / Landkreis Bad Kissingen – Bayern  
HAL	Halle a.d. Saale – Sachsen-Anhalt    
HAM	Hamm – Nordrhein-Westfalen      
HAS	Haßfurt / Landkreis Haßberge – Bayern   
HB	Hansestadt Bremen und Bremerhaven – Bremen   
HBN	Hildburghausen – Thüringen      
HBS	Halberstadt / Landkreis Harz – Sachsen-Anhalt   
HC	Hainichen / Landkreis Mittelsachsen – Sachsen   
HCH	Hechingen / Zollernalbkreis – Baden-Württemberg    
HD	Heidelberg / Rhein-Neckar-Kreis – Baden-Württemberg    
HDH	Heidenheim a.d. Brenz – Baden-Württemberg    
HDL	Haldensleben / Landkreis Börde – Sachsen-Anhalt   
HE	Helmstedt – Niedersachsen      
HEB	Hersbruck / Landkreis Nürnberger Land – Bayern  
HEF	Bad Hersfeld / Landkreis Bad Hersfeld-Rotenburg – Hessen 
HEI	Heide in Holstein / Landkreis Dithmarschen in – Schleswig-Holstein
HEL	Hessen Landesregierung und Landtag     
HER	Herne – Nordrhein-Westfalen      
HET	Hettstedt / Landkreis Mansfeld-Südharz – Sachsen-Anhalt   
HF	Herford – Nordrhein-Westfalen      
HG	Bad Homburg vor der Höhe / Landkreis Hochtaunuskreis –
HGN	Hagenow / Landkreis Ludwigslust-Parchim – Mecklenburg-Vorpommern   
HGW	Hansestadt Greifswald / Landkreis Vorpommern-Greifswald – Mecklenburg-Vorpommern  
HH	Hansestadt Hamburg – Hamburg     
HHM	Hohenmölsen / Burgenlandkreis – Sachsen-Anhalt    
HI	Hildesheim – Niedersachsen      
HIG	Heiligenstadt / Landkreis Eichsfeld – Thüringen   
HIP	Hilpoltstein / Landkreis Roth – Bayern   
HK	Heidekreis – Niedersachsen      
HL	Hansestadt Lübeck – Schleswig-Holstein     
HM	Hameln / Landkreis Hameln-Pyrmont – Niedersachsen   
HMÜ	Hannoversch Münden / Landkreis Göttingen – Niedersachsen  
HN	Heilbronn am Neckar – Baden-Württemberg    
HO	Hof a.d. Saale – Bayern    
HOG	Hofgeismar / Landkreis Kassel – Hessen   
HOH	Hofheim in Unterfranken / Landkreis Haßberge – Bayern 
HOL	Holzminden – Niedersachsen      
HOM	Homburg / Saarland-Pfalz-Kreis – Saarland    
HOR	Horb / Landkreis Freudenstadt – Baden-Württemberg   
HOT	Hohenstein-Ernstthal / Landkreis Zwickau – Sachsen   
HP	Heppenheim / Landkreis Bergstraße – Hessen   
HR	Homberg – Efze / Schwalm-Eder-Kreis – Hessen  
HRO	Hansestadt Rostock – Mecklenburg-Vorpommern     
HS	Heinsberg – Nordrhein-Westfalen      
HSK	Hochsauerlandkreis – Nordrhein-Westfalen      
HST	Hansestadt Stralsund / Landkreis Vorpommern-Rügen – Mecklenburg-Vorpommern  
HU	Hanau / Main-Kinzig-Kreis – Hessen    
HV	Havelberg / Landkreis Stendal – Sachsen-Anhalt   
HVL	Havelland – Brandenburg      
HWI	Hansestadt Wismar / Landkreis Nordwestmecklenburg – Mecklenburg-Vorpommern  
HX	Höxter – Nordrhein-Westfalen      
HY	Hoyerswerda / Landkreis Bautzen – Sachsen   
HZ	Harz – Sachsen-Anhalt      
IGB	St. Ingbert / Saarpfalz Kreis – Saarland  
IK	Ilm-Kreis – Thüringen      
IL	Ilmenau / Ilm-Kreis – Thüringen    
ILL	Illertissen / Landkreis Neu-Ulm – Bayern   
IN	Ingolstadt a.d. Donau – Bayern    
IZ	Itzehoe / Kreis Steinburg – Schleswig-Holstein   
J	Jena – Thüringen      
JE	Jessen / Landkreis Wittenberg – Sachsen-Anhalt   
JL	Jerichower Land – Sachsen-Anhalt     
JM	Jomrich – Bayern      
JÜL	Jülich / Kreis Düren – Nordrhein-Westfalen   
K	Köln – Nordrhein-Westfalen      
KA	Karlsruhe – Baden-Württemberg      
KB	Korbach / Landkreis Waldeck-Frankenberg – Hessen   
KC	Kronach – Bayern      
KE	Kempten im Allgäu – Bayern    
KEH	Kelheim – Bayern      
KEL	Kehl / Ortenaukreis – Baden-Württemberg    
KEM	Kenath / Landkreise Bayreuth und Tirschenreuth – Bayern 
KF	Kaufbeuren – Bayern      
KG	Bad Kissingen – Bayern     
KH	Bad Kreuznach – Rheinland-Pfalz     
KI	Kiel – Schleswig-Holstein      
KIB	Kirchheimbolanden / Donnersberg-Kreis – Rheinland-Pfalz    
KK	Kempen-Krefeld Kreis Viersen – Nordrhein-Westfalen    
KL	Kaiserslautern – Rheinland-Pfalz      
KLE	Kleve – Nordrhein-Westfalen      
KLZ	Klötze / Altmarkkreis Salzwedel – Sachsen-Anhalt   
KM	Kamenz / Landkreis Bautzen – Sachsen   
KN	Konstanz – Baden-Württemberg      
KO	Koblenz – Rheinland-Pfalz      
KÖN	Bad Königshöfen – Landkreis Rhön / Grabfeld – Bayern Unterfranken
KÖT	Köthen / Landkreis Anhalt-Bitterfeld – Sachsen-Anhalt   
KR	Krefeld – Nordrhein-Westfalen      
KRU	Krumbach in Schwaben – Landkreis Günzburg – Bayern 
KS	Kassel – Hessen      
KT	Kitzingen – Bayern      
KU	Kulmbach – Bayern      
KÜN	Künzelsau / Hohenlohe-Kreis – Baden-Württemberg    
KUS	Kusel – Rheinland-Pfalz      
KY	Kyritz / Landkreis Ostprignitz-Ruppin – Brandenburg   
KYF	Kyffhäuserkreis – Thüringen      
L	Leipzig – Sachsen      
LA	Landshut – Bayern      
LAU	Lauf a.d. Pegnitz / Nürnberger Land – Bayern 
LB	Ludwigsburg – Baden-Württemberg      
LBS	Bad Lobenstein / Saale-Orla-Kreis – Thüringen   
LBZ	Lübz / Landkreis Ludwigslust-Parchim – Mecklenburg-Vorpommern   
LD	Landau in der Pfalz / – Rheinland-Pfalz  
LDK	Lahn-Dill-Kreis – Hessen      
LDS	Landkreis Dahme-Spreewald – Brandenburg     
LEO	Leonberg / Landkreis Böblingen – Niedersachsen   
LER	Leer in Ostfriesland – Niedersachsen    
LEV	Leverkusen – Nordrhein-Westfalen      
LG	Lüneburg – Niedersachsen      
LH	Lüdinghausen / Kreis Coesfeld – Nordrhein-Westfalen   
LI	Lindau am Bodensee – Bayern    
LIB	Bad Liebenwerda / Landkreis Elbe-Elster – Brandenburg  
LIF	Lichtenfels – Bayern      
LIP	Kreis Lippe(Nordrhein-Westfalen       
LL	Landsberg am Lech – Bayern    
LM	Limburg a.d. Lahn / Landkreis Limburg-Weilburg(Hessen   
LÖ	Lörrach – Baden-Württemberg      
LÖB	Löbau / Landkreis Görlitz – Sachsen   
LOS	Landkreis Oder-Spree – Brandenburg     
LP	Lippstadt / Kreis Soest – Nordrhein-Westfalen   
LR	Lahr im Schwarzwald / Ortenaukreis – Baden-Württemberg  
LRO	Landkreis Rostock – Mecklenburg-Vorpommern     
LSA	Sachsen-Anhalt Landesregierung und Landtag     
LSN	Sachsen Landesregierung und Landtag     
LSZ	Bad Langensalza / Unstrut-Hainich-Kreis – Thüringen   
LU	Ludwigshafen am Rhein – Rheinland-Pfalz    
LÜN	Lünen / Kreis Unna – Nordrhein-Westfalen   
LUP	Ludwigslust-Parchim – Mecklenburg-Vorpommern      
LWL	Ludwigslust – Mecklenburg-Vorpommern      
M	München – Bayern      
MA	Mannheim – Baden-Württemberg      
MAB	Marienberg / Erzgebirgskreis – Sachsen    
MAI	Mainburg / Landkreis Kelheim – Bayern   
MAK	Marktredwitz / Landkreis Wunsiedel im Fichtelgebirge – Bayern 
MAL	Landkreis Mallersdorf – Bayern     
MB	Miesbach – Bayern      
MC	Malchin / Landkreis Mecklenburgische Seenplatte – Mecklenburg-Vorpommern  
MD	Magdeburg – Sachsen-Anhalt      
ME	Mettmann – Nordrhein-Westfalen      
MEI	Meißen – Sachsen      
MEK	Mittlerer Erzgebirgskreis – Sachsen     
MER	Merseburg / Saalekreis – Sachsen-Anhalt    
MET	Mellrichstadt / Landkreis Rhön-Grabfeld – Bayern   
MG	Mönchengladbach – Nordrhein-Westfalen      
MGH	Bad Mergentheim / Main-Tauber-Kreis – Baden-Württemberg   
MGN	Meiningen / Landkreis Schmalkalden-Meiningen – Thüringen   
MH	Mülheim/Ruhr – Nordrhein-Westfalen      
MHL	Mühlhausen / Unstrut-Hainich-Kreis – Thüringen    
MI	Minden / Kreis Minden-Lübbecke – Nordrhein-Westfalen   
MIL	Miltenberg – Bayern      
MK	Mark / Märkischer Kreis – Nordrhein-Westfalen   
MKK	Main-Kinzig-Kreis – Hessen      
ML	Mansfelder Land / Landkreis Mansfeld-Südharz – Sachsen-Anhalt  
MM	Memmingen – Bayern      
MN	Mindelheim / Landkreis Unterallgäu – Bayern   
MO	Moers / Kreis Wesel – Nordrhein-Westfalen   
MOD	Marktoberdorf / Landkreis Ostallgäu – Bayern   
MOL	Märkisch-Oderland – Brandenburg      
MON	Monschau / Städteregion Aachen – Nordrhein-Westfalen   
MOS	Mosbach / Neckar-Odenwald-Kreis – Baden-Württemberg    
MQ	Merseburg-Querfurt / Saalekreis – Baden-Württemberg    
MR	Marburg / Landkreis Marburg-Biedenkopf – Hessen   
MS	Münster – Nordrhein-Westfalen      
MSE	Mecklenburgische Seenplatte – Mecklenburg-Vorpommern     
MSH	Mansfeld-Südharz – Sachsen-Anhalt      
MSP	Main-Spessart-Kreis – Bayern      
MST	Mecklenburg-Strelitz / Landkreis Mecklenburgische Seenplatte – Mecklenburg-Vorpommern  
MTL	Muldentalkreis – Sachsen      
MTK	Main-Taunus-Kreis – Hessen      
MÜ	Mühldorf am Inn – Bayern    
MÜB	Münchberg / Landkreis Bayreuth – Bayern   
MÜR	Müritz / Landkreis Mecklenburgische Seenplatte – Mecklenburg-Vorpommern  
MVL	Mecklenburg-Vorpommern Landesregierung und Landtag     
MW	Mittweida / Landkreis Mittelsachsen – Sachsen   
MY	Mayen / Landkreis Mayen-Koblenz – Rheinland-Pfalz   
MYK	Mayen-Koblenz – Rheinland-Pfalz      
MZ	Mainz / Landkreis Mainz-Bingen – Rheinland-Pfalz   
MZG	Merzig / Landkreis Merzig-Wadern – Saarland   
N	Nürnberg – Bayern      
NAB	Nabburg / Landkreise Amberg-sulzbach und Schwandorf – Bayern 
NAI	Naila / Landkreis Hof – Bayern   
NB	Neubrandenburg – Mecklenburg-Vorpommern      
ND	Neuburg a.d. Donau / Landkreise Neuburg-Schrobenhausen – Bayern 
NDH	Nordhausen – Thüringen      
NE	Neuss / Rhein-Kreis Neuss – Nordrhein-Westfalen   
NEA	Neustadt a.d. Aisch / Landkreis Neustadt a.d. Aisch-Bad Windsheim Bayern
NEB	Nebra im Unstruttal / Burgenlandkreis – Sachsen-Anhalt  
NEC	Neustadt bei Coburg / Landkreis Coburg – Bayern 
NEN	Neunburg vorm Wald / Landkreis Schwandorf – Bayern 
NES	Bad Neustadt a.d. Saale / Landkreis Rhön-Grabfeld – Bayern
NEW	Neustadt a.d. Waldnaab – Bayern    
NF	Nordfriesland – Schleswig-Holstein      
NH	Neuhaus am Rennweg / Landkreis Sonneberg – Thüringen 
NI	Nienburg a.d. Weser – Niedersachsen    
NK	Neunkirchen – Saarland      
NL	Niedersächsische Landesregierung und Landtag     
NM	Neumarkt in der Oberpfalz – Bayern   
NMB	Naumburg a.d. Saale / Burgenlandkreis – Sachsen-Anhalt  
NMS	Neumünster – Schleswig-Holstein      
NÖ	Nördlingen / Landkreis Donau-Ries – Bayern   
NOH	Nordhorn / Landkreis Grafschaft Bentheim – Niedersachsen  
NOL	Niederschlesische Oberlausitz / Landkreis Görlitz – Sachsen  
NOM	Northeim – Niedersachsen      
NOR	Norden / Landkreis Aurich – Niedersachsen   
NP	Neuruppin / Landkreis Ostprignitz-Ruppin – Brandenburg   
NR	Neuwied am Rhein – Rheinland-Pfalz    
NRW	Nordrhein-Westfalen Landesregierung Landtag und Polizei    
NU	Neu-Ulm – Bayern      
NVP	Nordvorpommern / Landkreis Vorpommern-Rügen – Mecklenburg-Vorpommern   
NW	Neustadt a.d. Weinstraße – Rheinland-Pfalz    
NWM	Nordwestmecklenburg – Mecklenburg-Vorpommern      
NY	Niesky Landkreis Görlitz – Sachsen    
NZ	Neustrelitz / Landkreis Mecklenburgische Seenplatte – Mecklenburg-Vorpommern  
OA	Oberallgäu – Bayern      
OAL	Ostallgäu – Bayern      
OB	Oberhausen – Nordrhein-Westfalen      
OBG	Osterburg / Landkreis Stendal – Sachsen-Anhalt   
OC	Oschersleben a.d. Bode / Landkreis Börde – Sachsen-Anhalt 
OCH	Ochsenfurt / Landkreis Würzburg – Bayern   
OD	Bad Oldesloe / Kreis Stormarn – Schleswig-Holstein  
OE	Olpe – Nordrhein-Westfalen      
OF	Offenbach am Main – Hessen    
OG	Offenburg / Ortenaukreis – Baden-Württemberg    
OH	Ostholstein – Schleswig-Holstein      
OHA	Osterode am Harz – Niedersachsen    
OHV	Oberhavel – Brandenburg      
OHZ	Osterholz-Scharmbeck / Landkreis Osterholz – Niedersachsen   
OK	Ohrekreis / Landkreis Börde – Sachsen-Anhalt   
OL	Oldenburg – Niedersachsen      
OPR	Ostprignitz-Ruppin – Brandenburg      
OR	Oranienburg – Brandenburg      
OS	Osnabrück – Niedersachsen      
OSL	Oberspreewald-Lausitz – Brandenburg      
OVI	Oberviechtach / Landkreis Schwandorf – Bayern   
OVL	Obervogtland in Klingenthal und Ölsnitz – Sachsen  
OVL	Obervogtland / Vogtlandkreis – Sachsen    
OZ	Oschatz / Landkreis Nordsachsen – Sachsen   
P	Potsdam – Brandenburg      
PA	Passau – Bayern      
PAF	Pfaffenhofen a.d. Ilm – Bayern    
PAN	Pfarrkirchen / Landkreis Rottal-Inn – Bayern   
PAR	Parsberg / Landkreis Neumarkt in der Oberpfalz – Bayern
PB	Paderborn – Nordrhein-Westfalen      
PCH	Parchim / Landkreis Ludwigslust-Parchim – Mecklenburg-Vorpommern   
PE	Peine – Niedersachsen      
PEG	Pegnitz / Landkreise Bayreuth Forchenheim und Nürnberger Land –
PF	Pforzheim / Enzkreis – Baden-Württemberg    
PI	Pinneberg – Schleswig-Holstein      
PIR	Pirna / Landkreis Sächsische Schweiz-Osterzgebirge – Sachsen  
PL	Plauen / Vogtlandkreis – Sachsen    
PLÖ	Plön – Schleswig-Holstein      
PM	Potsdam-Mittelmark – Brandenburg      
PN	Pößneck / Saale-Orla-Kreis – Thüringen    
PR	Prignitz – Brandenburg      
PRÜ	Prüm / Eifelkreis Bitburg-Prüm – Rheinland-Pfalz   
PS	Pirmasens / Landkreis Südwestpfalz – Rheinland-Pfalz   
PW	Pasewalk / Landkreis Vormpommern-Greifswald – Mecklenburg-Vorpommern   
PZ	Prenzlau / Landkreis Uckermark – Brandenburg   
QFT	Querfurt / Saalekreis – Sachsen-Anhalt    
QLB	Quedlinburg / Landkreis Harz – Sachsen-Anhalt   
R	Regensburg – Bayern      
RA	Rastatt – Baden-Württemberg      
RC	Reichenbach / Vogtlandkreis – Sachsen    
RD	Rendsburg / Landkreis Rendsburg-Eckernförde – Schleswig-Holstein   
RDG	Ribnitz-Damgarten / Landkreis Vorpommern-Rügen – Mecklenburg-Vorpommern   
RE	Recklinghausen – Nordrhein-Westfalen      
REG	Regen – Bayern      
REH	Rehau / Landkreis Wunsiedel im Fichtelgebirge – Bayern 
RG	Riesa-Großenhain / Landkreis Meißen – Sachsen   
RH	Roth – Bayern      
RI	Rinteln / Landkreis Schaumburg – Niedersachsen   
RID	Riedenburg / Landkreis Kelheim – Bayern   
RIE	Riesa / Landkreis Meißen – Sachsen   
RL	Rochlitz / Landkreis Mittelsachsen – Sachsen   
RM	Röbel a.d. Müritz / Landkreis Mecklenburgische Seenplatte – Mecklenburg-Vorpommern
RO	Rosenheim – Bayern      
ROD	Roding / Landkreise Cham und Schwandorf – Bayern 
ROF	Rotenburg a.d. Fulda / Landkreis Hersfeld-Rotenburg – Hessen 
ROK	Rockenhausen / Donnersbergkreis – Rheinland-Pfalz    
ROL	Rottenburg a.d. Laaber / Landkreis Kelheim – Bayern 
ROS	Rostock – Mecklenburg-Vorpommern      
ROT	Rothenburg ob der Tauber / Landkreis Ansbach – Bayern
ROW	Rotenburg a.d. Wümme – Niedersachsen    
RP	Rhein-Pfalz-Kreis        
RPL	Rheinland-Pfalz Landesregierung Landtag und Polizei    
RS	Remscheid – Nordrhein-Westfalen      
RSL	Roßlau a.d. Elbe / Stadt Dessau-Roßlau – Sachsen-Anhalt 
RT	Reutlingen – Baden-Württemberg      
RU	Rudolstadt / Landkreis Saalfeld-Rudolfstadt – Thüringen   
RÜD	Rüdesheim / Rheingau-Taunus-Kreis – Hessen    
RÜG	Rügen / Landkreis Vorpommern-Rügen – Mecklenburg-Vorpommern   
RV	Ravensburg – Baden-Württemberg      
RW	Rottweil – Baden-Württemberg      
RZ	Ratzeburg / Kreis Herzogtum Lauenburg – Schleswig-Holstein  
S	Stuttgart – Baden-Württemberg      
SAB	Saarburg / Landkreis Trier-Saarburg – Rheinland-Pfalz   
SAD	Schwandorf – Bayern      
SAL	Saarland Landesregierung Landtag und Polizei – Saarland  
SAN	Stadtsteinach / Landkreise Kronach und Kulmbach – Bayern 
SAW	Salzwedel / Altmarkkreis – Sachsen-Anhalt    
SB	Saarbrücken – Saarland      
SBG	Strasburg / Landkreis Vorpommern-Greifswald – Mecklenburg-Vorpommern   
SBK	Schönebeck a.d. Elbe / Salzlandkreis – Sachsen-Anhalt  
SC	Schwabach – Bayern      
SCZ	Schleiz / Saale-Orla-Kreis – Thüringen    
SDH	Sondershausen / Kyffhäuserkreis – Thüringen    
SDL	Stendal – Sachsen-Anhalt      
SDT	Schwedt a.d. Oder / Landkreis Uckermark – Brandenburg 
SE	Bad Segeberg / Kreis Segeberg – Schleswig-Holstein  
SEB	Sebnitz / Landkreis Sächsische Schweiz-Osterzgebirge – Sachsen  
SEE	Seelow / Landkreis Märkisch-Oderland – Brandenburg   
SEF	Scheinfeld / Landkreis Neustadt an der Aisch-Bad Windsheim –
SEL	Selb / Landkreis Wunsiedel im Fichtelgebirge – Bayern 
SFB	Senftenberg / Landkreis Oberspreewald-Lausitz – Brandenburg   
SFT	Staßfurt / Salzlandkreis – Sachsen-Anhalt    
SG	Solingen – Nordrhein-Westfalen      
SGH	Sangerhausen / Landkreis Mansfeld-Südharz – Sachsen-Anhalt   
SH	Schleswig-Holstein Landesregierung Landtag und Polizei – Schleswig-Holstein  
SHA	Schwäbisch Hall – Baden-Württemberg     
SHG	Schaumburg oder Stadthagen – Niedersachsen    
SHK	Saale-Holzland-Kreis – Thüringen      
SHL	Suhl – Thüringen      
SI	Siegen / Kreis Siegen-Wittgenstein – Nordrhein-Westfalen   
SIG	Sigmaringen – Baden-Württemberg      
SIM	Simmern / Rhein-Hunsrück-Kreis – Rheinland-Pfalz    
SK	Saalkreis – Sachsen-Anhalt      
SL	Schleswig / Kreis Schleswig-Flensburg – Schleswig-Holstein   
SLE	Schleiden / Kreis Euskirchen – Nordrhein-Westfalen   
SLF	Saalfeld a.d. Saale / Landkreis Saalfeld-Rudolstadt – Thüringen 
SLK	Salzlandkreis – Sachsen-Anhalt      
SLN	Schmölln / Landkreis Altenburger Land – Thüringen  
SLS	Saarlouis – Saarland      
SLÜ	Schlüchtern / Main-Kinzig-Kreis – Hessen    
SLZ	Bad Salzungen / Wartburgkreis – Thüringen   
SM	Schmalkalden-Meiningen – Thüringen      
SN	Schwerin – Mecklenburg-Vorpommern      
SO	Soest – Nordrhein-Westfalen      
SOB	Schrobenhausen / Landkreis Neuburg-Schrobenhausen – Bayern   
SOG	Schongau / Landkreis Weilheim-Schongau – Bayern   
SOK	Saale-Orla-Kreis – Thüringen      
SÖM	Sömmerda – Thüringen      
SON	Sonneberg – Thüringen      
SP	Speyer – Rheinland-Pfalz      
SPB	Spremberg / Landkreis Spree-Neiße – Brandenburg   
SPN	Spree-Neiße – Brandenburg      
SR	Straubing / Landkreis Straubing-Bogen – Bayern   
SRB	Strausberg / Landkreis Märkisch-Oderland – Brandenburg   
SRO	Stadtroda / Saale-Holzland-Kreis – Thüringen    
ST	Steinfurt – Nordrhein-Westfalen      
STA	Starnberg – Bayern      
STB	Sternberg / Landkreis Ludwigslust-Parchim – Mecklenburg-Vorpommern   
STD	Stade – Niedersachsen      
STE	Bad Staffelstein / Landkreis Lichtenfels – Bayern  
STL	Stollberg / Erzgebirgskreis – Sachsen    
SU	Siegburg / Rhein-Sieg-Kreis – Nordrhein-Westfalen    
SUL	Sulzbach-Rosenberg / Landkreis Amberg-Sulzbach – Bayern   
SÜW	Südliche Weinstraße – Rheinland-Pfalz     
SW	Schweinfurt – Bayern      
SWA	Bad Schwalbach / Rheingau-Taunus-Kreis – Hessen   
SZ	Salzgitter – Niedersachsen      
SZB	Schwarzenberg / Erzgebirgskreis – Sachsen    
TBB	Tauberbischofsheim / Main-Tauber-Kreis – Baden-Württemberg    
TDO	Torgau Delitzsch Oschatz / Landkreis Nordsachsen – Sachsen 
TE	Tecklenburg / Kreis Steinfurt – Nordrhein-Westfalen   
TET	Teterow / Landkreis Rostock – Mecklenburg-Vorpommern   
TF	Teltow-Fläming – Brandenburg      
TG	Torgau / Landkreis Nordsachsen – Sachsen   
THL	Thüringen Landesregierung und Landtag – Thüringen   
THW	Bundesanstalt Technisches Hilfswerk – bundesweit    
TIR	Tirschenreuth – Bayern      
TO	Torgau-Oschatz / Landkreis Nordsachsen – Sachsen   
TÖL	Bad Tölz / Landkreis Bad Tölz-Wolfratshausen – Bayern 
TP	Templin / Landkreis Uckermark – Brandenburg   
TR	Trier / Landkreis Trier-Saarburg – Rheinland-Pfalz   
TS	Traunstein – Bayern      
TÜ	Tübingen – Baden-Württemberg      
TUT	Tuttlingen – Baden-Württemberg      
UE	Uelzen – Niedersachsen      
UEM	Ueckermünde / Landkreis Vorpommern-Greifswald – Mecklenburg-Vorpommern   
UFF	Uffenheim / Landkreis Neustadt – Mittelfranken / Bayern 
UH	Unstrut-Hainich – Thüringen      
UL	Ulm / Alb-Donau-Kreis – Baden-Württemberg    
UM	Uckermark – Brandenburg      
UN	Unna – Nordrhein-Westfalen      
USI	Usingen / Hochtaunuskreis – Hessen    
V	Vogtland – Sachsen      
VAI	Vaihingen an der Enz / Landkreis Ludwigsburg – Baden-Württemberg
VB	Vogelsbergkreis – Hessen      
VEC	Vechta – Niedersachsen      
VER	Verden a.d. Aller – Niedersachsen    
VG	Landkreis Vorpommern-Greifswald – Mecklenburg-Vorpommern     
VIB	Vilsbiburg / Landkreis Landshut – Bayern   
VIE	Viersen – Nordrhein-Westfalen      
VK	Völklingen / Regionalverband Saarbrücken – Saarland   
VOH	Vohenstrauß / Landkreis Neustadt an der Waldnaab – Bayern
VR	Landkreis Vorpommern-Rügen – Mecklenburg-Vorpommern     
VS	Villingen-Schwenningen / Schwarzwald-Baar-Kreis – Baden-Württemberg    
W	Wuppertal – Nordrhein-Westfalen      
WA	Waldeck / Landkreis Waldeck-Frankenberg – Hessen   
WAF	Warendorf – Nordrhein-Westfalen      
WAK	Wartburgkreis – Thüringen      
WAN	Wanne-Eickel / Stadt Herne – Nordrhein-Westfalen   
WAT	Wattenscheid / Stadt Bochum – Nordrhein-Westfalen   
WB	Wittenberg – Sachsen-Anhalt      
WBS	Worbis / Landkreis Eichsfeld – Thüringen   
WDA	Werdau / Landkreis Zwickau – Sachsen   
WE	Weimar – Thüringen      
WEL	Weilburg / Landkreis Limburg-Weilburg – Hessen   
WEN	Weiden in der Oberpfalz – Bayern   
WER	Wertingen / Landkreis Dillingen a.d. Donau – Bayern 
WES	Wesel – Nordrhein-Westfalen      
WF	Wolfenbüttel – Niedersachsen      
WHV	Wilhelmshaven – Niedersachsen      
WI	Wiesbaden und Hessische Polizei – Hessen   
WIL	Wittlich a.d. Mosel / Landkreis Bernkastel-Wittlich – Rheinland-Pfalz 
WIS	Wismar / Landkreis Nordwestmecklenburg – Mecklenburg-Vorpommern   
WIT	Witten / Ennepe-Ruhr-Kreis – Nordrhein-Westfalen    
WK	Wittstock a.d. Dosse / Landkreis Ostprignitz-Ruppin – Brandenburg 
WL	Winsen a.d. Luhe / Landkreis Harburg – Niedersachsen 
WLG	Wolgast / Landkreis Vorpommern-Greifswald – Mecklenburg-Vorpommern   
WM	Weilheim / Landkreis Weilheim-Schongau – Bayern   
WMS	Wolmirstedt / Landkreis Börde – Sachsen-Anhalt   
WN	Waiblingen / Rems-Murr-Kreis – Baden-Württemberg    
WND	St. Wendel – Saarland     
WO	Worms – Rheinland-Pfalz      
WOB	Wolfsburg – Niedersachsen      
WOH	Wolfhagen / Landkreis Kassel – Hessen   
WOL	Wolfach / Ortenaukreis – Baden-Württemberg    
WOR	Wolfratshausen / Landkreise München Starnberg und Bad-Tölz-Wolfratshausen – Bayern
WOS	Wolfstein / Landkreis Freyung-Grafenau – Bayern   
WR	Wernigerode / Landkreis Harz – Sachsen-Anhalt   
WRN	Waren a.d. Müritz / Landkreis Mecklenburgische Seenplatte – Mecklenburg-Vorpommern
WS	Wasserburg am Inn / Landkreis Rosenheim – Bayern 
WSF	Weißenfels / Burgenlandkreis – Sachsen-Anhalt    
WST	Westerstede / Landkreis Ammerland – Niedersachsen   
WSW	Weißwasser / Landkreis Görlitz – Sachsen   
WT	Waldshut-Tiengen / Landkreis Waldshut – Baden-Württemberg   
WTM	Wittmund – Niedersachsen      
WÜ	Würzburg Polizei Unterfranken – Bayern    
WUG	Weißenburg / Landkreis Weißenburg-Gunzenhausen – Bayern   
WÜM	Waldmünchen / Landkreis Cham – Bayern   
WUN	Wunsiedel im Fichtelgebirge – Bayern    
WUR	Wurzen / Landkreis Leipzig(Sachsen     
WW	Westerwald / Westerwaldkreis – Rheinland-Pfalz    
WZ	Wetzlar / Lahn-Dill-Kreis – Hessen    
WIZ	Witzenhausen / Werra-Meißner-Kreis – Hessen    
WZL	Wanzleben / Landkreis Börde – Sachsen-Anhalt   
Z	Zwickauer Land – Sachsen     
ZE	Zerbst / Landkreis Anhalt-Bitterfeld – Sachsen-Anhalt   
ZEL	Zell a.d. Mosel / Landkreis Cochem-Zell – Rheinland-Pfalz 
ZI	Zittau / Landkreis Görlitz – Sachsen   
ZP	Zschopau / Erzgebirgskreis – Sachsen    
ZR	Zeulenroda / Landkreis Greiz – Thüringen   
ZW	Zweibrücken – Rheinland-Pfalz      
ZZ	Zeitz / Burgenlandkreis – Sachsen-Anhalt    
\.


--
-- Data for Name: plz; Type: TABLE DATA; Schema: public; Owner: jensen
--

COPY public.plz (id, stadt, land, abk, landkreis) FROM stdin;
3058	Frauendorf	Brandenburg	BB	Spree-Neiße
3058	Gallinchen	Brandenburg	BB	Cottbus
3058	Roggosen	Brandenburg	BB	Spree-Neiße
3058	Groß Gaglow	Brandenburg	BB	Cottbus
3058	Laubsdorf	Brandenburg	BB	Spree-Neiße
3058	Komptendorf	Brandenburg	BB	Spree-Neiße
3058	Gablenz	Brandenburg	BB	Spree-Neiße
3058	Kathlow	Brandenburg	BB	Spree-Neiße
3058	Kiekebusch	Brandenburg	BB	Cottbus
3058	Groß Oßnig	Brandenburg	BB	Spree-Neiße
3058	Koppatz	Brandenburg	BB	Spree-Neiße
3096	Briesen	Brandenburg	BB	Spree-Neiße
3096	Guhrow	Brandenburg	BB	Spree-Neiße
3096	Schmogrow-Fehrow	Brandenburg	BB	Spree-Neiße
3096	Burg (Spreewald)	Brandenburg	BB	Spree-Neiße
3096	Dissen-Striesow	Brandenburg	BB	Spree-Neiße
3096	Werben	Brandenburg	BB	Spree-Neiße
3099	Kolkwitz	Brandenburg	BB	Spree-Neiße
3103	Neupetershain	Brandenburg	BB	Oberspreewald-Lausitz
3103	Neu-Seeland	Brandenburg	BB	Oberspreewald-Lausitz
3116	Drebkau	Brandenburg	BB	Spree-Neiße
3119	Welzow	Brandenburg	BB	Spree-Neiße
3130	Haidemühl	Brandenburg	BB	Spree-Neiße
3130	Spremberg	Brandenburg	BB	Spree-Neiße
3130	Türkendorf	Brandenburg	BB	Spree-Neiße
3130	Bagenz	Brandenburg	BB	Spree-Neiße
3130	Felixsee	Brandenburg	BB	Spree-Neiße
3130	Jämlitz-Klein Düben	Brandenburg	BB	Spree-Neiße
3130	Hornow-Wadelsdorf	Brandenburg	BB	Spree-Neiße
3130	Proschim	Brandenburg	BB	Spree-Neiße
3130	Reuthen	Brandenburg	BB	Spree-Neiße
3130	Wolfshain	Brandenburg	BB	Spree-Neiße
3130	Drieschnitz-Kahsel	Brandenburg	BB	Spree-Neiße
3130	Graustein	Brandenburg	BB	Spree-Neiße
3130	Lieskau	Brandenburg	BB	Spree-Neiße
3130	Tschernitz	Brandenburg	BB	Spree-Neiße
3130	Groß Luja	Brandenburg	BB	Spree-Neiße
3139	Terpe	Brandenburg	BB	Spree-Neiße
3149	Wiesengrund	Brandenburg	BB	Spree-Neiße
3149	Forst (Lausitz)	Brandenburg	BB	Spree-Neiße
3149	Groß Schacksdorf-Simmersdorf	Brandenburg	BB	Spree-Neiße
3159	Neiße-Malxetal	Brandenburg	BB	Spree-Neiße
3159	Wiesengrund	Brandenburg	BB	Spree-Neiße
3159	Döbern	Brandenburg	BB	Spree-Neiße
3172	Gastrose-Kerkwitz	Brandenburg	BB	Spree-Neiße
3172	Pinnow-Heideland	Brandenburg	BB	Spree-Neiße
3172	Bärenklau	Brandenburg	BB	Spree-Neiße
3172	Lutzketal	Brandenburg	BB	Spree-Neiße
3172	Guben	Brandenburg	BB	Spree-Neiße
3172	Grießen	Brandenburg	BB	Spree-Neiße
3172	Atterwasch	Brandenburg	BB	Spree-Neiße
3172	Grabko	Brandenburg	BB	Spree-Neiße
3185	Drachhausen	Brandenburg	BB	Spree-Neiße
3185	Peitz	Brandenburg	BB	Spree-Neiße
3185	Heinersbrück	Brandenburg	BB	Spree-Neiße
3185	Teichland	Brandenburg	BB	Spree-Neiße
3185	Turnow-Preilack	Brandenburg	BB	Spree-Neiße
3185	Grötsch	Brandenburg	BB	Spree-Neiße
3185	Drehnow	Brandenburg	BB	Spree-Neiße
3185	Tauer	Brandenburg	BB	Spree-Neiße
3197	Jänschwalde	Brandenburg	BB	Spree-Neiße
3197	Drewitz	Brandenburg	BB	Spree-Neiße
3202	Luckow-Petershagen	Brandenburg	BB	Uckermark
3205	Groß-Mehßow	Brandenburg	BB	Oberspreewald-Lausitz
3205	Ogrosen	Brandenburg	BB	Oberspreewald-Lausitz
3205	Luckaitztal	Brandenburg	BB	Oberspreewald-Lausitz
3205	Werchow	Brandenburg	BB	Oberspreewald-Lausitz
3205	Bolschwitz	Brandenburg	BB	Oberspreewald-Lausitz
3205	Bronkow	Brandenburg	BB	Oberspreewald-Lausitz
3205	Kemmen	Brandenburg	BB	Oberspreewald-Lausitz
3205	Laasow	Brandenburg	BB	Oberspreewald-Lausitz
3205	Saßleben	Brandenburg	BB	Oberspreewald-Lausitz
3205	Mlode	Brandenburg	BB	Oberspreewald-Lausitz
3205	Lug	Brandenburg	BB	Oberspreewald-Lausitz
3205	Lipten	Brandenburg	BB	Oberspreewald-Lausitz
3205	Missen	Brandenburg	BB	Oberspreewald-Lausitz
3205	Calau	Brandenburg	BB	Oberspreewald-Lausitz
3205	Bischdorf	Brandenburg	BB	Oberspreewald-Lausitz
3222	Ragow	Brandenburg	BB	Oberspreewald-Lausitz
3222	Groß-Klessow	Brandenburg	BB	Oberspreewald-Lausitz
3222	Kittlitz	Brandenburg	BB	Oberspreewald-Lausitz
3222	Boblitz	Brandenburg	BB	Oberspreewald-Lausitz
3222	Lübbenau/Spreewald	Brandenburg	BB	Oberspreewald-Lausitz
3222	Groß Beuchow	Brandenburg	BB	Oberspreewald-Lausitz
3222	Klein Radden	Brandenburg	BB	Oberspreewald-Lausitz
3222	Hindenberg	Brandenburg	BB	Oberspreewald-Lausitz
3226	Raddusch	Brandenburg	BB	Oberspreewald-Lausitz
3226	Leipe	Brandenburg	BB	Oberspreewald-Lausitz
3226	Vetschau	Brandenburg	BB	Oberspreewald-Lausitz
3226	Suschow	Brandenburg	BB	Oberspreewald-Lausitz
3226	Koßwig	Brandenburg	BB	Oberspreewald-Lausitz
3229	Altdöbern	Brandenburg	BB	Oberspreewald-Lausitz
3229	Luckaitztal	Brandenburg	BB	Oberspreewald-Lausitz
3238	Betten	Brandenburg	BB	Elbe-Elster
3238	Lichterfeld	Brandenburg	BB	Elbe-Elster
3238	Dollenchen	Brandenburg	BB	Elbe-Elster
3238	Staupitz	Brandenburg	BB	Elbe-Elster
3238	Massen	Brandenburg	BB	Elbe-Elster
3238	Lindthal	Brandenburg	BB	Elbe-Elster
3238	Gorden	Brandenburg	BB	Elbe-Elster
3238	Schacksdorf	Brandenburg	BB	Elbe-Elster
3238	Göllnitz	Brandenburg	BB	Elbe-Elster
3238	Sallgast	Brandenburg	BB	Elbe-Elster
3238	Gröbitz	Brandenburg	BB	Elbe-Elster
3238	Finsterwalde	Brandenburg	BB	Elbe-Elster
3238	Schadewitz	Brandenburg	BB	Elbe-Elster
3238	Eichholz-Drößig	Brandenburg	BB	Elbe-Elster
3238	Lindena	Brandenburg	BB	Elbe-Elster
3238	Rückersdorf	Brandenburg	BB	Elbe-Elster
3238	Lugau	Brandenburg	BB	Elbe-Elster
3238	Fischwasser	Brandenburg	BB	Elbe-Elster
3238	Oppelhain	Brandenburg	BB	Elbe-Elster
3238	Lieskau	Brandenburg	BB	Elbe-Elster
3238	Münchhausen	Brandenburg	BB	Elbe-Elster
3238	Gruhno	Brandenburg	BB	Elbe-Elster
3238	Ponnsdorf	Brandenburg	BB	Elbe-Elster
3246	Gahro	Brandenburg	BB	Elbe-Elster
3246	Crinitz	Brandenburg	BB	Elbe-Elster
3246	Babben	Brandenburg	BB	Elbe-Elster
3249	Breitenau	Brandenburg	BB	Elbe-Elster
3249	Sonnewalde	Brandenburg	BB	Elbe-Elster
3249	Bahren	Brandenburg	BB	Elbe-Elster
3249	Goßmar	Brandenburg	BB	Elbe-Elster
3249	Zeckerin	Brandenburg	BB	Elbe-Elster
3249	Pahlsdorf	Brandenburg	BB	Elbe-Elster
3249	Kleinkrausnik	Brandenburg	BB	Elbe-Elster
3249	Großkrausnik	Brandenburg	BB	Elbe-Elster
3253	Werenzhain	Brandenburg	BB	Elbe-Elster
3253	Tröbitz	Brandenburg	BB	Elbe-Elster
3253	Trebbus	Brandenburg	BB	Elbe-Elster
3253	Hennersdorf	Brandenburg	BB	Elbe-Elster
3253	Dübrichen	Brandenburg	BB	Elbe-Elster
3253	Frankena	Brandenburg	BB	Elbe-Elster
3253	Doberlug-Kirchhain	Brandenburg	BB	Elbe-Elster
3253	Friedersdorf	Brandenburg	BB	Elbe-Elster
3253	Schilda	Brandenburg	BB	Elbe-Elster
3253	Schönborn	Brandenburg	BB	Elbe-Elster
3253	Arenzhain	Brandenburg	BB	Elbe-Elster
3253	Prießen	Brandenburg	BB	Elbe-Elster
3253	Nexdorf	Brandenburg	BB	Elbe-Elster
3253	Schönewalde	Brandenburg	BB	Elbe-Elster
3253	Brenitz	Brandenburg	BB	Elbe-Elster
3253	Buchhain	Brandenburg	BB	Elbe-Elster
4895	Falkenberg/Elster	Brandenburg	BB	Elbe-Elster
4910	Haida	Brandenburg	BB	Elbe-Elster
4910	Elsterwerda	Brandenburg	BB	Elbe-Elster
4916	Stolzenhain	Brandenburg	BB	Elbe-Elster
4916	Herzberg (Elster)	Brandenburg	BB	Elbe-Elster
4916	Werchau	Brandenburg	BB	Elbe-Elster
4916	Wildberg	Brandenburg	BB	Elbe-Elster
4916	Themesgrund	Brandenburg	BB	Elbe-Elster
4916	Heideeck	Brandenburg	BB	Elbe-Elster
4924	Uebigau-Wahrenbrück	Brandenburg	BB	Elbe-Elster
4924	Bad Liebenwerda	Brandenburg	BB	Elbe-Elster
4928	Plessa	Brandenburg	BB	Elbe-Elster
4928	Döllingen	Brandenburg	BB	Elbe-Elster
4928	Schraden	Brandenburg	BB	Elbe-Elster
4928	Kahla	Brandenburg	BB	Elbe-Elster
4931	Mühlberg (Elbe)	Brandenburg	BB	Elbe-Elster
4932	Wainsdorf	Brandenburg	BB	Elbe-Elster
4932	Prösen	Brandenburg	BB	Elbe-Elster
4932	Gröden	Brandenburg	BB	Elbe-Elster
4932	Großthiemig	Brandenburg	BB	Elbe-Elster
4932	Reichenhain	Brandenburg	BB	Elbe-Elster
4932	Saathain	Brandenburg	BB	Elbe-Elster
4932	Merzdorf	Brandenburg	BB	Elbe-Elster
4932	Hirschfeld	Brandenburg	BB	Elbe-Elster
4934	Dreska	Brandenburg	BB	Elbe-Elster
4934	Hohenleipisch	Brandenburg	BB	Elbe-Elster
4936	Wehrhain	Brandenburg	BB	Elbe-Elster
4936	Malitschkendorf	Brandenburg	BB	Elbe-Elster
4936	Kolochau	Brandenburg	BB	Elbe-Elster
4936	Frankenhain	Brandenburg	BB	Elbe-Elster
4936	Körba	Brandenburg	BB	Elbe-Elster
4936	Naundorf	Brandenburg	BB	Elbe-Elster
4936	Jagsal	Brandenburg	BB	Elbe-Elster
4936	Hohenbucko	Brandenburg	BB	Elbe-Elster
4936	Ölsig	Brandenburg	BB	Elbe-Elster
4936	Hillmersdorf	Brandenburg	BB	Elbe-Elster
4936	Schöna-Kolpien	Brandenburg	BB	Elbe-Elster
4936	Freileben	Brandenburg	BB	Elbe-Elster
4936	Lebusa	Brandenburg	BB	Elbe-Elster
4936	Schlieben	Brandenburg	BB	Elbe-Elster
4936	Proßmarke	Brandenburg	BB	Elbe-Elster
4936	Stechau	Brandenburg	BB	Elbe-Elster
4938	Uebigau-Wahrenbrück	Brandenburg	BB	Elbe-Elster
12529	Schönefeld	Brandenburg	BB	Dahme-Spreewald
14461	Potsdam	Brandenburg	BB	Potsdam
14467	Potsdam	Brandenburg	BB	Potsdam
14469	Potsdam	Brandenburg	BB	Potsdam
14471	Potsdam	Brandenburg	BB	Potsdam
14473	Potsdam	Brandenburg	BB	Potsdam
14476	Seeburg	Brandenburg	BB	Havelland
14476	Groß Glienicke	Brandenburg	BB	Potsdam
14476	Marquardt	Brandenburg	BB	Potsdam
14476	Uetz-Paaren	Brandenburg	BB	Potsdam
14476	Töplitz	Brandenburg	BB	Potsdam-Mittelmark
14476	Fahrland	Brandenburg	BB	Potsdam
14476	Golm	Brandenburg	BB	Potsdam
14476	Neu Fahrland	Brandenburg	BB	Potsdam
14476	Satzkorn	Brandenburg	BB	Potsdam
14478	Potsdam	Brandenburg	BB	Potsdam
14480	Potsdam	Brandenburg	BB	Potsdam
14482	Potsdam	Brandenburg	BB	Potsdam
14513	Teltow	Brandenburg	BB	Potsdam-Mittelmark
14532	Nudow	Brandenburg	BB	Potsdam-Mittelmark
14532	Kleinmachnow	Brandenburg	BB	Potsdam-Mittelmark
14532	Philippsthal	Brandenburg	BB	Potsdam-Mittelmark
14532	Fahlhorst	Brandenburg	BB	Potsdam-Mittelmark
14532	Stahnsdorf	Brandenburg	BB	Potsdam-Mittelmark
14542	Werder (Havel)	Brandenburg	BB	Potsdam-Mittelmark
14542	Schwielowsee	Brandenburg	BB	Potsdam-Mittelmark
14542	Kloster Lehnin	Brandenburg	BB	Potsdam-Mittelmark
14547	Stücken	Brandenburg	BB	Potsdam-Mittelmark
14547	Beelitz	Brandenburg	BB	Potsdam-Mittelmark
14548	Schwielowsee	Brandenburg	BB	Potsdam-Mittelmark
14550	Groß Kreutz	Brandenburg	BB	Potsdam-Mittelmark
14550	Derwitz	Brandenburg	BB	Potsdam-Mittelmark
14550	Bochow	Brandenburg	BB	Potsdam-Mittelmark
14550	Deetz	Brandenburg	BB	Potsdam-Mittelmark
14550	Krielow	Brandenburg	BB	Potsdam-Mittelmark
14550	Schmergow	Brandenburg	BB	Potsdam-Mittelmark
14552	Fresdorf	Brandenburg	BB	Potsdam-Mittelmark
14552	Saarmund	Brandenburg	BB	Potsdam-Mittelmark
14552	Tremsdorf	Brandenburg	BB	Potsdam-Mittelmark
14552	Michendorf	Brandenburg	BB	Potsdam-Mittelmark
14552	Wildenbruch	Brandenburg	BB	Potsdam-Mittelmark
14554	Seddiner See	Brandenburg	BB	Potsdam-Mittelmark
14557	Langerwisch	Brandenburg	BB	Potsdam-Mittelmark
14557	Wilhelmshorst	Brandenburg	BB	Potsdam-Mittelmark
14558	Bergholz-Rehbrücke	Brandenburg	BB	Potsdam-Mittelmark
14612	Falkensee	Brandenburg	BB	Havelland
14621	Schönwalde	Brandenburg	BB	Havelland
14624	Dallgow-Döberitz	Brandenburg	BB	Havelland
14627	Elstal	Brandenburg	BB	Havelland
14641	Etzin	Brandenburg	BB	Havelland
14641	Perwenitz	Brandenburg	BB	Havelland
14641	Nauen	Brandenburg	BB	Havelland
14641	Bredow	Brandenburg	BB	Havelland
14641	Pessin	Brandenburg	BB	Havelland
14641	Berge	Brandenburg	BB	Havelland
14641	Zeestow	Brandenburg	BB	Havelland
14641	Tremmen	Brandenburg	BB	Havelland
14641	Klein Behnitz	Brandenburg	BB	Havelland
14641	Wustermark	Brandenburg	BB	Havelland
14641	Börnicke	Brandenburg	BB	Havelland
14641	Grünefeld	Brandenburg	BB	Havelland
14641	Paulinenaue	Brandenburg	BB	Havelland
14641	Wachow	Brandenburg	BB	Havelland
14641	Bergerdamm	Brandenburg	BB	Havelland
14641	Wansdorf	Brandenburg	BB	Havelland
14641	Lietzow	Brandenburg	BB	Havelland
14641	Ribbeck	Brandenburg	BB	Havelland
14641	Paaren im Glien	Brandenburg	BB	Havelland
14641	Tietzow	Brandenburg	BB	Havelland
14641	Selbelang	Brandenburg	BB	Havelland
14641	Mühlenberge	Brandenburg	BB	Havelland
14641	Pausin	Brandenburg	BB	Havelland
14641	Kienberg	Brandenburg	BB	Havelland
14641	Groß Behnitz	Brandenburg	BB	Havelland
14641	Retzow	Brandenburg	BB	Havelland
14641	Falkenrehde	Brandenburg	BB	Havelland
14641	Brädikow	Brandenburg	BB	Havelland
14641	Markee	Brandenburg	BB	Havelland
14656	Brieselang	Brandenburg	BB	Havelland
14662	Mühlenberge	Brandenburg	BB	Havelland
14662	Friesack	Brandenburg	BB	Havelland
14662	Warsow	Brandenburg	BB	Havelland
14662	Vietznitz	Brandenburg	BB	Havelland
14669	Ketzin	Brandenburg	BB	Havelland
14669	Zachow	Brandenburg	BB	Havelland
14712	Rathenow	Brandenburg	BB	Havelland
14715	Märkisch Luch Möthlow	Brandenburg	BB	Havelland
14715	Kriele	Brandenburg	BB	Havelland
14715	Gräningen	Brandenburg	BB	Havelland
14715	Nennhausen	Brandenburg	BB	Havelland
14715	Märkisch Luch Buschow	Brandenburg	BB	Havelland
14715	Liepe	Brandenburg	BB	Havelland
14715	Zollchow	Brandenburg	BB	Havelland
14715	Bützer	Brandenburg	BB	Havelland
14715	Großwudicke	Brandenburg	BB	Havelland
14715	Märkisch Luch Barnewitz	Brandenburg	BB	Havelland
14715	Bamme	Brandenburg	BB	Havelland
14715	Kotzen	Brandenburg	BB	Havelland
14715	Märkisch Luch Garlitz	Brandenburg	BB	Havelland
14715	Mützlitz	Brandenburg	BB	Havelland
14715	Nitzahn	Brandenburg	BB	Havelland
14715	Jerchel	Brandenburg	BB	Havelland
14715	Märkisch Luch	Brandenburg	BB	Havelland
14715	Vieritz	Brandenburg	BB	Havelland
14715	Milow	Brandenburg	BB	Havelland
14715	Stechow-Ferchesar	Brandenburg	BB	Havelland
14715	Möthlitz	Brandenburg	BB	Havelland
14715	Havelaue	Brandenburg	BB	Havelland
14715	Seeblick	Brandenburg	BB	Havelland
14715	Landin	Brandenburg	BB	Havelland
14727	Premnitz	Brandenburg	BB	Havelland
14727	Döberitz	Brandenburg	BB	Havelland
14728	Rhinow	Brandenburg	BB	Havelland
14728	Kleßen-Görne	Brandenburg	BB	Havelland
14728	Havelaue	Brandenburg	BB	Havelland
14728	Gollenberg	Brandenburg	BB	Havelland
14770	Brandenburg an der Havel	Brandenburg	BB	Brandenburg an der Havel
14772	Brandenburg an der Havel	Brandenburg	BB	Brandenburg an der Havel
14774	Brandenburg an der Havel	Brandenburg	BB	Brandenburg an der Havel
14776	Brandenburg an der Havel	Brandenburg	BB	Brandenburg an der Havel
14778	Wenzlow	Brandenburg	BB	Potsdam-Mittelmark
14778	Schenkenberg	Brandenburg	BB	Potsdam-Mittelmark
14778	Götz	Brandenburg	BB	Potsdam-Mittelmark
14778	Wollin	Brandenburg	BB	Potsdam-Mittelmark
14778	Beetzseeheide	Brandenburg	BB	Potsdam-Mittelmark
14778	Golzow	Brandenburg	BB	Potsdam-Mittelmark
14778	Trechwitz	Brandenburg	BB	Potsdam-Mittelmark
14778	Kloster Lehnin	Brandenburg	BB	Potsdam-Mittelmark
14778	Planetal	Brandenburg	BB	Potsdam-Mittelmark
14778	Planebruch	Brandenburg	BB	Potsdam-Mittelmark
14778	Päwesin	Brandenburg	BB	Potsdam-Mittelmark
14778	Havelsee	Brandenburg	BB	Potsdam-Mittelmark
14778	Beetzsee	Brandenburg	BB	Potsdam-Mittelmark
14778	Jeserig	Brandenburg	BB	Potsdam-Mittelmark
14778	Wust	Brandenburg	BB	Brandenburg an der Havel
14778	Gollwitz	Brandenburg	BB	Brandenburg an der Havel
14778	Roskow	Brandenburg	BB	Potsdam-Mittelmark
14789	Bensdorf	Brandenburg	BB	Potsdam-Mittelmark
14789	Wusterwitz	Brandenburg	BB	Potsdam-Mittelmark
14789	Rosenau	Brandenburg	BB	Potsdam-Mittelmark
14793	Rottstock	Brandenburg	BB	Potsdam-Mittelmark
14793	Ziesar	Brandenburg	BB	Potsdam-Mittelmark
14793	Buckautal	Brandenburg	BB	Potsdam-Mittelmark
14793	Gräben	Brandenburg	BB	Potsdam-Mittelmark
14797	Kloster Lehnin	Brandenburg	BB	Potsdam-Mittelmark
14798	Havelsee	Brandenburg	BB	Potsdam-Mittelmark
14806	Schwanebeck	Brandenburg	BB	Potsdam-Mittelmark
14806	Belzig	Brandenburg	BB	Potsdam-Mittelmark
14806	Planetal	Brandenburg	BB	Potsdam-Mittelmark
14806	Hagelberg	Brandenburg	BB	Potsdam-Mittelmark
14822	Borkwalde	Brandenburg	BB	Potsdam-Mittelmark
14822	Planebruch	Brandenburg	BB	Potsdam-Mittelmark
14822	Brück	Brandenburg	BB	Potsdam-Mittelmark
14822	Borkheide	Brandenburg	BB	Potsdam-Mittelmark
14822	Mühlenfließ	Brandenburg	BB	Potsdam-Mittelmark
14822	Linthe	Brandenburg	BB	Potsdam-Mittelmark
14823	Niemegk	Brandenburg	BB	Potsdam-Mittelmark
14823	Mühlenfließ	Brandenburg	BB	Potsdam-Mittelmark
14823	Rabenstein/Fläming	Brandenburg	BB	Potsdam-Mittelmark
14827	Wiesenburg	Brandenburg	BB	Potsdam-Mittelmark
14828	Görzke	Brandenburg	BB	Potsdam-Mittelmark
14913	Wahlsdorf	Brandenburg	BB	Teltow-Fläming
14913	Jüterbog	Brandenburg	BB	Teltow-Fläming
14913	Herbersdorf	Brandenburg	BB	Teltow-Fläming
14913	Niederer Fläming	Brandenburg	BB	Teltow-Fläming
14913	Ihlow	Brandenburg	BB	Teltow-Fläming
14913	Hohenseefeld	Brandenburg	BB	Teltow-Fläming
14913	Niedergörsdorf	Brandenburg	BB	Teltow-Fläming
14913	Niebendorf-Heinsdorf	Brandenburg	BB	Teltow-Fläming
14913	Nuthe-Urstromtal	Brandenburg	BB	Teltow-Fläming
14929	Treuenbrietzen	Brandenburg	BB	Potsdam-Mittelmark
14943	Luckenwalde	Brandenburg	BB	Teltow-Fläming
14943	Lüdersdorf	Brandenburg	BB	Teltow-Fläming
14943	Lühsdorf	Brandenburg	BB	Potsdam-Mittelmark
14947	Nuthe-Urstromtal	Brandenburg	BB	Teltow-Fläming
14959	Trebbin	Brandenburg	BB	Teltow-Fläming
14959	Schönhagen	Brandenburg	BB	Teltow-Fläming
14974	Thyrow	Brandenburg	BB	Teltow-Fläming
14974	Ludwigsfelde	Brandenburg	BB	Teltow-Fläming
14979	Großbeeren	Brandenburg	BB	Teltow-Fläming
15230	Frankfurt (Oder)	Brandenburg	BB	Frankfurt (Oder)
15232	Frankfurt (Oder)	Brandenburg	BB	Frankfurt (Oder)
15234	Frankfurt (Oder)	Brandenburg	BB	Frankfurt (Oder)
15236	Jacobsdorf Pillgram	Brandenburg	BB	Oder-Spree
15236	Jacobsdorf Sieversdorf	Brandenburg	BB	Oder-Spree
15236	Frankfurt (Oder)	Brandenburg	BB	Frankfurt (Oder)
15236	Jacobsdorf Jacobsdorf	Brandenburg	BB	Oder-Spree
15236	Jacobsdorf Petersdorf bei Briesen	Brandenburg	BB	Oder-Spree
15236	Jacobsdorf	Brandenburg	BB	Oder-Spree
15236	Treplin	Brandenburg	BB	Märkisch-Oderland
15295	Groß Lindow	Brandenburg	BB	Oder-Spree
15295	Wiesenau	Brandenburg	BB	Oder-Spree
15295	Ziltendorf	Brandenburg	BB	Oder-Spree
15295	Ziltendorf Ernst-Thälmann-Siedlung	Brandenburg	BB	Oder-Spree
15295	Groß Lindow Weißenspring	Brandenburg	BB	Oder-Spree
15295	Groß Lindow Schlaubehammer	Brandenburg	BB	Oder-Spree
15295	Ziltendorf Aurith	Brandenburg	BB	Oder-Spree
15295	Brieskow-Finkenheerd	Brandenburg	BB	Oder-Spree
15299	Grunow-Dammendorf Grunow	Brandenburg	BB	Oder-Spree
15299	Mixdorf	Brandenburg	BB	Oder-Spree
15299	Müllrose	Brandenburg	BB	Oder-Spree
15299	Grunow-Dammendorf	Brandenburg	BB	Oder-Spree
15299	Dammendorf	Brandenburg	BB	Oder-Spree
15306	Vierlinden Alt Rosenthal	Brandenburg	BB	Märkisch-Oderland
15306	Fichtenhöhe	Brandenburg	BB	Märkisch-Oderland
15306	Lietzen	Brandenburg	BB	Märkisch-Oderland
15306	Lindendorf Libbenichen	Brandenburg	BB	Märkisch-Oderland
15306	Gusow-Platkow Platkow	Brandenburg	BB	Märkisch-Oderland
15306	Gusow-Platkow Gusow	Brandenburg	BB	Märkisch-Oderland
15306	Werbig	Brandenburg	BB	Märkisch-Oderland
15306	Fichtenhöhe Alt Mahlisch	Brandenburg	BB	Märkisch-Oderland
15306	Lindendorf	Brandenburg	BB	Märkisch-Oderland
15306	Lindendorf Neu Mahlisch	Brandenburg	BB	Märkisch-Oderland
15306	Lindendorf Dolgelin	Brandenburg	BB	Märkisch-Oderland
15306	Gusow-Platkow	Brandenburg	BB	Märkisch-Oderland
15306	Lindendorf Sachsendorf	Brandenburg	BB	Märkisch-Oderland
15306	Fichtenhöhe Niederjesar	Brandenburg	BB	Märkisch-Oderland
15306	Vierlinden Görlsdorf	Brandenburg	BB	Märkisch-Oderland
15306	Vierlinden	Brandenburg	BB	Märkisch-Oderland
15306	Seelow	Brandenburg	BB	Märkisch-Oderland
15306	Vierlinden Diedersdorf	Brandenburg	BB	Märkisch-Oderland
15306	Vierlinden Friedersdorf	Brandenburg	BB	Märkisch-Oderland
15306	Vierlinden Marxdorf	Brandenburg	BB	Märkisch-Oderland
15306	Vierlinden Neuentempel	Brandenburg	BB	Märkisch-Oderland
15306	Falkenhagen	Brandenburg	BB	Märkisch-Oderland
15306	Vierlinden Worin	Brandenburg	BB	Märkisch-Oderland
15320	Neutrebbin Altbarnim	Brandenburg	BB	Märkisch-Oderland
15320	Sietzing	Brandenburg	BB	Märkisch-Oderland
15320	Neuhardenberg Quappendorf	Brandenburg	BB	Märkisch-Oderland
15320	Neutrebbin Neutrebbin	Brandenburg	BB	Märkisch-Oderland
15320	Neutrebbin	Brandenburg	BB	Märkisch-Oderland
15320	Neuhardenberg Neuhardenberg	Brandenburg	BB	Märkisch-Oderland
15320	Neuhardenberg Wulkow bei Trebnitz	Brandenburg	BB	Märkisch-Oderland
15320	Neuhardenberg Altfriedland	Brandenburg	BB	Märkisch-Oderland
15320	Neutrebbin Alttrebbin	Brandenburg	BB	Märkisch-Oderland
15320	Neuhardenberg	Brandenburg	BB	Märkisch-Oderland
15324	Letschin	Brandenburg	BB	Märkisch-Oderland
15324	Gieshof-Zelliner Loose	Brandenburg	BB	Märkisch-Oderland
15324	Kienitz	Brandenburg	BB	Märkisch-Oderland
15324	Groß Neuendorf	Brandenburg	BB	Märkisch-Oderland
15324	Ortwig	Brandenburg	BB	Märkisch-Oderland
15324	Neubarnim	Brandenburg	BB	Märkisch-Oderland
15324	Kiehnwerder	Brandenburg	BB	Märkisch-Oderland
15326	Zeschdorf Petershagen	Brandenburg	BB	Märkisch-Oderland
15326	Lebus Lebus	Brandenburg	BB	Märkisch-Oderland
15326	Zeschdorf	Brandenburg	BB	Märkisch-Oderland
15326	Lebus Schönfließ	Brandenburg	BB	Märkisch-Oderland
15326	Lebus Mallnow	Brandenburg	BB	Märkisch-Oderland
15326	Zeschdorf Döbberin	Brandenburg	BB	Märkisch-Oderland
15326	Fichtenhöhe Carzig	Brandenburg	BB	Märkisch-Oderland
15326	Fichtenhöhe	Brandenburg	BB	Märkisch-Oderland
15326	Lebus Wulkow	Brandenburg	BB	Märkisch-Oderland
15326	Zeschdorf Alt Zeschdorf	Brandenburg	BB	Märkisch-Oderland
15326	Lebus	Brandenburg	BB	Märkisch-Oderland
15326	Podelzig	Brandenburg	BB	Märkisch-Oderland
15328	Zechin Friedrichsaue	Brandenburg	BB	Märkisch-Oderland
15328	Reitwein	Brandenburg	BB	Märkisch-Oderland
15328	Golzow	Brandenburg	BB	Märkisch-Oderland
15328	Zechin Zechin	Brandenburg	BB	Märkisch-Oderland
15328	Alt Tucheband	Brandenburg	BB	Märkisch-Oderland
15328	Zechin Buschdorf	Brandenburg	BB	Märkisch-Oderland
15328	Küstriner Vorland	Brandenburg	BB	Märkisch-Oderland
15328	Bleyen-Genschmar Bleyen	Brandenburg	BB	Märkisch-Oderland
15328	Küstriner Vorland Manschnow	Brandenburg	BB	Märkisch-Oderland
15328	Zechin	Brandenburg	BB	Märkisch-Oderland
15328	Küstriner Vorland Küstrin-Kietz	Brandenburg	BB	Märkisch-Oderland
15328	Bleyen-Genschmar Genschmar	Brandenburg	BB	Märkisch-Oderland
15328	Alt Tucheband Hathenow	Brandenburg	BB	Märkisch-Oderland
15328	Alt Tucheband Alt Tucheband	Brandenburg	BB	Märkisch-Oderland
15328	Bleyen-Genschmar	Brandenburg	BB	Märkisch-Oderland
15328	Küstriner Vorland Gorgast	Brandenburg	BB	Märkisch-Oderland
15328	Alt Tucheband Ratstock	Brandenburg	BB	Märkisch-Oderland
15344	Strausberg	Brandenburg	BB	Märkisch-Oderland
15345	Reichenow-Möglin Möglin	Brandenburg	BB	Märkisch-Oderland
15345	Rehfelde Rehfelde	Brandenburg	BB	Märkisch-Oderland
15345	Garzau-Garzin Garzin	Brandenburg	BB	Märkisch-Oderland
15345	Oberbarnim	Brandenburg	BB	Märkisch-Oderland
15345	Garzau-Garzin Garzau	Brandenburg	BB	Märkisch-Oderland
15345	Prötzel Prädikow	Brandenburg	BB	Märkisch-Oderland
15345	Prötzel Harnekop	Brandenburg	BB	Märkisch-Oderland
15345	Oberbarnim Klosterdorf	Brandenburg	BB	Märkisch-Oderland
15345	Lichtenow	Brandenburg	BB	Märkisch-Oderland
15345	Prötzel Sternebeck	Brandenburg	BB	Märkisch-Oderland
15345	Garzau-Garzin	Brandenburg	BB	Märkisch-Oderland
15345	Reichenow-Möglin	Brandenburg	BB	Märkisch-Oderland
15345	Prötzel	Brandenburg	BB	Märkisch-Oderland
15345	Reichenow-Möglin Reichenow	Brandenburg	BB	Märkisch-Oderland
15345	Petershagen-Eggersdorf	Brandenburg	BB	Märkisch-Oderland
15345	Prötzel Prötzel	Brandenburg	BB	Märkisch-Oderland
15345	Zinndorf	Brandenburg	BB	Märkisch-Oderland
15345	Rehfelde Werder	Brandenburg	BB	Märkisch-Oderland
15345	Rehfelde	Brandenburg	BB	Märkisch-Oderland
15345	Werder	Brandenburg	BB	Märkisch-Oderland
15345	Rehfelde Zinndorf	Brandenburg	BB	Märkisch-Oderland
15345	Altlandsberg	Brandenburg	BB	Märkisch-Oderland
15366	Neuenhagen bei Berlin	Brandenburg	BB	Märkisch-Oderland
15366	Münchehofe	Brandenburg	BB	Märkisch-Oderland
15366	Dahlwitz-Hoppegarten	Brandenburg	BB	Märkisch-Oderland
15366	Hönow	Brandenburg	BB	Märkisch-Oderland
15370	Petershagen-Eggersdorf	Brandenburg	BB	Märkisch-Oderland
15370	Fredersdorf-Vogelsdorf	Brandenburg	BB	Märkisch-Oderland
15372	Müncheberg	Brandenburg	BB	Märkisch-Oderland
15374	Müncheberg	Brandenburg	BB	Märkisch-Oderland
15377	Oberbarnim	Brandenburg	BB	Märkisch-Oderland
15377	Ihlow	Brandenburg	BB	Märkisch-Oderland
15377	Buckow	Brandenburg	BB	Märkisch-Oderland
15377	Waldsieversdorf	Brandenburg	BB	Märkisch-Oderland
15377	Oberbarnim Grunow	Brandenburg	BB	Märkisch-Oderland
15377	Märkische Höhe	Brandenburg	BB	Märkisch-Oderland
15377	Märkische Höhe Ringenwalde	Brandenburg	BB	Märkisch-Oderland
15377	Oberbarnim Grunow; Grunow	Brandenburg	BB	Märkisch-Oderland
15377	Märkische Höhe Batzlow	Brandenburg	BB	Märkisch-Oderland
15377	Oberbarnim Bollersdorf	Brandenburg	BB	Märkisch-Oderland
15377	Oberbarnim Grunow; Ernsthof	Brandenburg	BB	Märkisch-Oderland
15377	Oberbarnim Bollersdorf; Bollersdorf	Brandenburg	BB	Märkisch-Oderland
15377	Oberbarnim Bollersdorf; Pritzhagen	Brandenburg	BB	Märkisch-Oderland
15377	Märkische Höhe Reichenberg	Brandenburg	BB	Märkisch-Oderland
15378	Hennickendorf	Brandenburg	BB	Märkisch-Oderland
15378	Herzfelde	Brandenburg	BB	Märkisch-Oderland
15517	Fürstenwalde/Spree	Brandenburg	BB	Oder-Spree
15517	Fürstenwalde/Spree Trebus	Brandenburg	BB	Oder-Spree
15517	Fürstenwalde/Spree Fürstenwalde	Brandenburg	BB	Oder-Spree
15518	Grünheide (Mark)	Brandenburg	BB	Oder-Spree
15518	Steinhöfel Buchholz	Brandenburg	BB	Oder-Spree
15518	Langewahl	Brandenburg	BB	Oder-Spree
15518	Madlitz-Wilmersdorf Alt Madlitz	Brandenburg	BB	Oder-Spree
15518	Madlitz-Wilmersdorf Falkenberg	Brandenburg	BB	Oder-Spree
15518	Briesen (Mark) Biegen	Brandenburg	BB	Oder-Spree
15518	Briesen (Mark) Briesen (Mark)	Brandenburg	BB	Oder-Spree
15518	Madlitz-Wilmersdorf	Brandenburg	BB	Oder-Spree
15518	Briesen (Mark)	Brandenburg	BB	Oder-Spree
15518	Grünheide (Mark) Hangelsberg	Brandenburg	BB	Oder-Spree
15518	Steinhöfel Neuendorf im Sande	Brandenburg	BB	Oder-Spree
15518	Madlitz-Wilmersdorf Wilmersdorf	Brandenburg	BB	Oder-Spree
15518	Falkenberg	Brandenburg	BB	Oder-Spree
15518	Steinhöfel Hasenfelde	Brandenburg	BB	Oder-Spree
15518	Steinhöfel Gölsdorf	Brandenburg	BB	Oder-Spree
15518	Steinhöfel Beerfelde	Brandenburg	BB	Oder-Spree
15518	Steinhöfel	Brandenburg	BB	Oder-Spree
15518	Steinhöfel Demnitz	Brandenburg	BB	Oder-Spree
15518	Steinhöfel Steinhöfel	Brandenburg	BB	Oder-Spree
15518	Steinhöfel Tempelberg	Brandenburg	BB	Oder-Spree
15518	Steinhöfel Arensdorf	Brandenburg	BB	Oder-Spree
15518	Steinhöfel Jänickendorf	Brandenburg	BB	Oder-Spree
15518	Steinhöfel Schönfelde	Brandenburg	BB	Oder-Spree
15518	Rauen	Brandenburg	BB	Oder-Spree
15518	Steinhöfel Heinersdorf	Brandenburg	BB	Oder-Spree
15518	Berkenbrück	Brandenburg	BB	Oder-Spree
15526	Reichenwalde Kolpin	Brandenburg	BB	Oder-Spree
15526	Rietz-Neuendorf	Brandenburg	BB	Oder-Spree
15526	Reichenwalde Dahmsdorf	Brandenburg	BB	Oder-Spree
15526	Rietz-Neuendorf Alt Golm	Brandenburg	BB	Oder-Spree
15526	Bad Saarow Petersdorf	Brandenburg	BB	Oder-Spree
15526	Bad Saarow Bad Saarow	Brandenburg	BB	Oder-Spree
15526	Bad Saarow Neu Golm	Brandenburg	BB	Oder-Spree
15526	Bad Saarow	Brandenburg	BB	Oder-Spree
15526	Reichenwalde Reichenwalde	Brandenburg	BB	Oder-Spree
15526	Reichenwalde	Brandenburg	BB	Oder-Spree
15528	Spreenhagen Hartmannsdorf	Brandenburg	BB	Oder-Spree
15528	Spreenhagen Spreenhagen	Brandenburg	BB	Oder-Spree
15528	Spreenhagen Braunsdorf	Brandenburg	BB	Oder-Spree
15528	Spreenhagen	Brandenburg	BB	Oder-Spree
15528	Grünheide (Mark) Spreeau	Brandenburg	BB	Oder-Spree
15528	Spreenhagen Markgrafpieske	Brandenburg	BB	Oder-Spree
15528	Grünheide (Mark)	Brandenburg	BB	Oder-Spree
15528	Grünheide (Mark) Mönchwinkel	Brandenburg	BB	Oder-Spree
15537	Grünheide (Mark) Grünheide	Brandenburg	BB	Oder-Spree
15537	Gosen Neu Zittau	Brandenburg	BB	Oder-Spree
15537	Gosen	Brandenburg	BB	Oder-Spree
15537	Grünheide (Mark)	Brandenburg	BB	Oder-Spree
15537	Erkner	Brandenburg	BB	Oder-Spree
15537	Grünheide (Mark) Kienbaum	Brandenburg	BB	Oder-Spree
15537	Grünheide (Mark) Kagel	Brandenburg	BB	Oder-Spree
15562	Rüdersdorf bei Berlin	Brandenburg	BB	Märkisch-Oderland
15566	Schöneiche bei Berlin	Brandenburg	BB	Oder-Spree
15569	Woltersdorf	Brandenburg	BB	Oder-Spree
15711	Königs Wusterhausen	Brandenburg	BB	Dahme-Spreewald
15711	Zeesen	Brandenburg	BB	Dahme-Spreewald
15711	Schenkendorf	Brandenburg	BB	Dahme-Spreewald
15712	Senzig	Brandenburg	BB	Dahme-Spreewald
15712	Kablow	Brandenburg	BB	Dahme-Spreewald
15712	Zernsdorf	Brandenburg	BB	Dahme-Spreewald
15713	Wernsdorf	Brandenburg	BB	Dahme-Spreewald
15713	Niederlehme	Brandenburg	BB	Dahme-Spreewald
15732	Eichwalde	Brandenburg	BB	Dahme-Spreewald
15732	Waltersdorf	Brandenburg	BB	Dahme-Spreewald
15732	Schulzendorf	Brandenburg	BB	Dahme-Spreewald
15738	Zeuthen	Brandenburg	BB	Dahme-Spreewald
15741	Bestensee	Brandenburg	BB	Dahme-Spreewald
15741	Motzen	Brandenburg	BB	Dahme-Spreewald
15741	Pätz	Brandenburg	BB	Dahme-Spreewald
15741	Gräbendorf	Brandenburg	BB	Dahme-Spreewald
15745	Wildau	Brandenburg	BB	Dahme-Spreewald
15746	Groß Köris	Brandenburg	BB	Dahme-Spreewald
15748	Märkisch Buchholz	Brandenburg	BB	Dahme-Spreewald
15748	Münchehofe	Brandenburg	BB	Dahme-Spreewald
15749	Ragow	Brandenburg	BB	Dahme-Spreewald
15749	Gallun	Brandenburg	BB	Dahme-Spreewald
15749	Kiekebusch	Brandenburg	BB	Dahme-Spreewald
15749	Brusendorf	Brandenburg	BB	Dahme-Spreewald
15749	Mittenwalde	Brandenburg	BB	Dahme-Spreewald
15752	Streganz	Brandenburg	BB	Dahme-Spreewald
15752	Kolberg	Brandenburg	BB	Dahme-Spreewald
15752	Prieros	Brandenburg	BB	Dahme-Spreewald
15754	Dolgenbrodt	Brandenburg	BB	Dahme-Spreewald
15754	Bindow	Brandenburg	BB	Dahme-Spreewald
15754	Friedersdorf	Brandenburg	BB	Dahme-Spreewald
15754	Dannenreich	Brandenburg	BB	Dahme-Spreewald
15754	Gussow	Brandenburg	BB	Dahme-Spreewald
15754	Wolzig	Brandenburg	BB	Dahme-Spreewald
15754	Blossin	Brandenburg	BB	Dahme-Spreewald
15755	Töpchin	Brandenburg	BB	Dahme-Spreewald
15755	Teupitz	Brandenburg	BB	Dahme-Spreewald
15755	Schwerin	Brandenburg	BB	Dahme-Spreewald
15757	Briesen	Brandenburg	BB	Dahme-Spreewald
15757	Halbe	Brandenburg	BB	Dahme-Spreewald
15757	Löpten	Brandenburg	BB	Dahme-Spreewald
15757	Oderin	Brandenburg	BB	Dahme-Spreewald
15757	Freidorf	Brandenburg	BB	Dahme-Spreewald
15806	Saalow	Brandenburg	BB	Teltow-Fläming
15806	Schöneiche	Brandenburg	BB	Teltow-Fläming
15806	Telz	Brandenburg	BB	Dahme-Spreewald
15806	Mellensee	Brandenburg	BB	Teltow-Fläming
15806	Zossen	Brandenburg	BB	Teltow-Fläming
15806	Kummersdorf-Alexanderdorf	Brandenburg	BB	Teltow-Fläming
15806	Nächst Neuendorf	Brandenburg	BB	Teltow-Fläming
15806	Rehagen	Brandenburg	BB	Teltow-Fläming
15806	Groß Machnow	Brandenburg	BB	Teltow-Fläming
15806	Kallinchen	Brandenburg	BB	Teltow-Fläming
15806	Glienick	Brandenburg	BB	Teltow-Fläming
15806	Nunsdorf	Brandenburg	BB	Teltow-Fläming
15806	Groß Schulzendorf	Brandenburg	BB	Teltow-Fläming
15806	Gadsdorf	Brandenburg	BB	Teltow-Fläming
15827	Dahlewitz	Brandenburg	BB	Teltow-Fläming
15827	Blankenfelde	Brandenburg	BB	Teltow-Fläming
15831	Jühnsdorf	Brandenburg	BB	Teltow-Fläming
15831	Diepensee	Brandenburg	BB	Teltow-Fläming
15831	Selchow	Brandenburg	BB	Dahme-Spreewald
15831	Waßmannsdorf	Brandenburg	BB	Teltow-Fläming
15831	Groß Kienitz	Brandenburg	BB	Teltow-Fläming
15831	Großziethen	Brandenburg	BB	Dahme-Spreewald
15831	Mahlow	Brandenburg	BB	Teltow-Fläming
15834	Rangsdorf	Brandenburg	BB	Teltow-Fläming
15837	Baruth/Mark	Brandenburg	BB	Teltow-Fläming
15838	Wünsdorf	Brandenburg	BB	Teltow-Fläming
15838	Sperenberg	Brandenburg	BB	Teltow-Fläming
15838	Klausdorf	Brandenburg	BB	Teltow-Fläming
15838	Kummersdorf-Gut	Brandenburg	BB	Teltow-Fläming
15848	Beeskow	Brandenburg	BB	Oder-Spree
15848	Tauche	Brandenburg	BB	Oder-Spree
15848	Speichrow	Brandenburg	BB	Dahme-Spreewald
15848	Tauche Tauche	Brandenburg	BB	Oder-Spree
15848	Tauche Briescht	Brandenburg	BB	Oder-Spree
15848	Tauche Giesensdorf	Brandenburg	BB	Oder-Spree
15848	Tauche Ranzig	Brandenburg	BB	Oder-Spree
15848	Tauche Falkenberg	Brandenburg	BB	Oder-Spree
15848	Beeskow Oegeln	Brandenburg	BB	Oder-Spree
15848	Rietz-Neuendorf Pfaffendorf	Brandenburg	BB	Oder-Spree
15848	Beeskow Radinkendorf	Brandenburg	BB	Oder-Spree
15848	Beeskow Neuendorf	Brandenburg	BB	Oder-Spree
15848	Rietz-Neuendorf Wilmersdorf	Brandenburg	BB	Oder-Spree
15848	Friedland Chossewitz	Brandenburg	BB	Oder-Spree
15848	Friedland Weichensdorf	Brandenburg	BB	Oder-Spree
15848	Friedland Leißnitz	Brandenburg	BB	Oder-Spree
15848	Friedland	Brandenburg	BB	Oder-Spree
15848	Friedland Schadow	Brandenburg	BB	Oder-Spree
15848	Friedland Klein Muckrow	Brandenburg	BB	Oder-Spree
15848	Beeskow Krügersdorf	Brandenburg	BB	Oder-Spree
15848	Tauche Görsdorf bei Beeskow	Brandenburg	BB	Oder-Spree
15848	Rietz-Neuendorf	Brandenburg	BB	Oder-Spree
15848	Rietz-Neuendorf Sauen	Brandenburg	BB	Oder-Spree
15848	Rietz-Neuendorf Behrensdorf	Brandenburg	BB	Oder-Spree
15848	Beeskow Kohlsdorf	Brandenburg	BB	Oder-Spree
15848	Tauche Trebatsch	Brandenburg	BB	Oder-Spree
15848	Ragow-Merz	Brandenburg	BB	Oder-Spree
15848	Rietz-Neuendorf Drahendorf	Brandenburg	BB	Oder-Spree
15848	Tauche Lindenberg	Brandenburg	BB	Oder-Spree
15848	Friedland Pieskow	Brandenburg	BB	Oder-Spree
15848	Friedland Groß Briesen	Brandenburg	BB	Oder-Spree
15848	Ragow-Merz Ragow	Brandenburg	BB	Oder-Spree
15848	Tauche Werder	Brandenburg	BB	Oder-Spree
15848	Rietz-Neuendorf Görzig	Brandenburg	BB	Oder-Spree
15848	Plattkow	Brandenburg	BB	Dahme-Spreewald
15848	Rietz-Neuendorf Ahrensdorf	Brandenburg	BB	Oder-Spree
15848	Rietz-Neuendorf Birkholz	Brandenburg	BB	Oder-Spree
15848	Beeskow Schneeberg	Brandenburg	BB	Oder-Spree
15848	Friedland Karras	Brandenburg	BB	Oder-Spree
15848	Friedland Niewisch	Brandenburg	BB	Oder-Spree
15848	Beeskow Bornow	Brandenburg	BB	Oder-Spree
15848	Rietz-Neuendorf Buckow	Brandenburg	BB	Oder-Spree
15848	Tauche Mittweide	Brandenburg	BB	Oder-Spree
15848	Friedland Günthersdorf	Brandenburg	BB	Oder-Spree
15848	Friedland Reudnitz	Brandenburg	BB	Oder-Spree
15848	Friedland Friedland	Brandenburg	BB	Oder-Spree
15848	Friedland Zeust	Brandenburg	BB	Oder-Spree
15848	Rietz-Neuendorf Neubrück (Spree)	Brandenburg	BB	Oder-Spree
15848	Rietz-Neuendorf Herzberg	Brandenburg	BB	Oder-Spree
15848	Friedland Lindow	Brandenburg	BB	Oder-Spree
15848	Ragow-Merz Merz	Brandenburg	BB	Oder-Spree
15848	Rietz-Neuendorf Groß Rietz	Brandenburg	BB	Oder-Spree
15848	Friedland Kummerow	Brandenburg	BB	Oder-Spree
15848	Tauche Kossenblatt	Brandenburg	BB	Oder-Spree
15848	Tauche Stremmen	Brandenburg	BB	Oder-Spree
15859	Philadelphia	Brandenburg	BB	Oder-Spree
15859	Rieplos	Brandenburg	BB	Oder-Spree
15859	Kummersdorf	Brandenburg	BB	Oder-Spree
15859	Storkow (Mark) Schwerin	Brandenburg	BB	Oder-Spree
15859	Storkow (Mark) Groß Schauen	Brandenburg	BB	Oder-Spree
15859	Storkow (Mark) Limsdorf	Brandenburg	BB	Oder-Spree
15859	Storkow (Mark) Storkow	Brandenburg	BB	Oder-Spree
15859	Storkow (Mark) Kummersdorf	Brandenburg	BB	Oder-Spree
15859	Storkow (Mark) Görsdorf bei Storkow	Brandenburg	BB	Oder-Spree
15859	Storkow (Mark) Groß Eichholz	Brandenburg	BB	Oder-Spree
15859	Storkow (Mark)	Brandenburg	BB	Oder-Spree
15859	Storkow (Mark) Bugk	Brandenburg	BB	Oder-Spree
15859	Kehrigk	Brandenburg	BB	Oder-Spree
15859	Storkow (Mark) Alt Stahnsdorf	Brandenburg	BB	Oder-Spree
15859	Storkow (Mark) Selchow	Brandenburg	BB	Oder-Spree
15859	Storkow (Mark) Wochowsee	Brandenburg	BB	Oder-Spree
15864	Diensdorf-Radlow	Brandenburg	BB	Oder-Spree
15864	Rietz-Neuendorf Glienicke	Brandenburg	BB	Oder-Spree
15864	Rietz-Neuendorf	Brandenburg	BB	Oder-Spree
15864	Wendisch Rietz	Brandenburg	BB	Oder-Spree
15868	Lieberose	Brandenburg	BB	Dahme-Spreewald
15868	Jamlitz	Brandenburg	BB	Dahme-Spreewald
15868	Friedland Groß Muckrow	Brandenburg	BB	Dahme-Spreewald
15868	Ullersdorf	Brandenburg	BB	Dahme-Spreewald
15868	Leeskow	Brandenburg	BB	Dahme-Spreewald
15868	Friedland	Brandenburg	BB	Dahme-Spreewald
15868	Doberburg	Brandenburg	BB	Dahme-Spreewald
15890	Siehdichum Pohlitz	Brandenburg	BB	Oder-Spree
15890	Siehdichum Schernsdorf	Brandenburg	BB	Oder-Spree
15890	Vogelsang	Brandenburg	BB	Oder-Spree
15890	Schlaubetal Fünfeichen	Brandenburg	BB	Oder-Spree
15890	Siehdichum Rießen	Brandenburg	BB	Oder-Spree
15890	Siehdichum	Brandenburg	BB	Oder-Spree
15890	Eisenhüttenstadt	Brandenburg	BB	Oder-Spree
15890	Schlaubetal Kieselwitz	Brandenburg	BB	Oder-Spree
15890	Eisenhüttenstadt Schönfließ	Brandenburg	BB	Oder-Spree
15890	Eisenhüttenstadt Fürstenberg	Brandenburg	BB	Oder-Spree
15890	Schlaubetal	Brandenburg	BB	Oder-Spree
15890	Schlaubetal Bremsdorf	Brandenburg	BB	Oder-Spree
15890	Eisenhüttenstadt Diehlo	Brandenburg	BB	Oder-Spree
15898	Neißemünde Breslack	Brandenburg	BB	Oder-Spree
15898	Neuzelle Ossendorf	Brandenburg	BB	Oder-Spree
15898	Neißemünde Coschen	Brandenburg	BB	Oder-Spree
15898	Neuzelle Neuzelle	Brandenburg	BB	Oder-Spree
15898	Neißemünde	Brandenburg	BB	Oder-Spree
15898	Neuzelle Göhlen	Brandenburg	BB	Oder-Spree
15898	Neißemünde Ratzdorf	Brandenburg	BB	Oder-Spree
15898	Neißemünde Wellmitz	Brandenburg	BB	Oder-Spree
15898	Neuzelle Kobbeln	Brandenburg	BB	Oder-Spree
15898	Neuzelle Henzendorf	Brandenburg	BB	Oder-Spree
15898	Neuzelle	Brandenburg	BB	Oder-Spree
15898	Neuzelle Bomsdorf	Brandenburg	BB	Oder-Spree
15898	Neuzelle Treppeln	Brandenburg	BB	Oder-Spree
15898	Lawitz	Brandenburg	BB	Oder-Spree
15898	Neuzelle Bahro	Brandenburg	BB	Oder-Spree
15898	Neuzelle Streichwitz	Brandenburg	BB	Oder-Spree
15898	Neuzelle Möbiskruge	Brandenburg	BB	Oder-Spree
15898	Neuzelle Schwerzko	Brandenburg	BB	Oder-Spree
15898	Neuzelle Steinsdorf	Brandenburg	BB	Oder-Spree
15907	Lübben (Spreewald)	Brandenburg	BB	Dahme-Spreewald
15910	Pretschen	Brandenburg	BB	Dahme-Spreewald
15910	Kuschkow	Brandenburg	BB	Dahme-Spreewald
15910	Rietzneuendorf-Staakow	Brandenburg	BB	Dahme-Spreewald
15910	Dürrenhofe	Brandenburg	BB	Dahme-Spreewald
15910	Alt-Schadow	Brandenburg	BB	Dahme-Spreewald
15910	Hohenbrück-Neu Schadow	Brandenburg	BB	Dahme-Spreewald
15910	Gröditsch	Brandenburg	BB	Dahme-Spreewald
15910	Schuhlen-Wiese	Brandenburg	BB	Dahme-Spreewald
15910	Wittmannsdorf-Bückchen	Brandenburg	BB	Dahme-Spreewald
15910	Schönwald	Brandenburg	BB	Dahme-Spreewald
15910	Krausnick-Groß Wasserburg	Brandenburg	BB	Dahme-Spreewald
15910	Unterspreewald	Brandenburg	BB	Dahme-Spreewald
15910	Schlepzig	Brandenburg	BB	Dahme-Spreewald
15913	Dollgen	Brandenburg	BB	Dahme-Spreewald
15913	Byhleguhre	Brandenburg	BB	Dahme-Spreewald
15913	Mochow	Brandenburg	BB	Dahme-Spreewald
15913	Byhlen	Brandenburg	BB	Dahme-Spreewald
15913	Alt Zauche	Brandenburg	BB	Dahme-Spreewald
15913	Briesensee	Brandenburg	BB	Dahme-Spreewald
15913	Butzen	Brandenburg	BB	Dahme-Spreewald
15913	Laasow	Brandenburg	BB	Dahme-Spreewald
15913	Glietz	Brandenburg	BB	Dahme-Spreewald
15913	Wußwerk	Brandenburg	BB	Dahme-Spreewald
15913	Biebersdorf	Brandenburg	BB	Dahme-Spreewald
15913	Krugau	Brandenburg	BB	Dahme-Spreewald
15913	Klein Leine	Brandenburg	BB	Dahme-Spreewald
15913	Jessern	Brandenburg	BB	Dahme-Spreewald
15913	Caminchen	Brandenburg	BB	Dahme-Spreewald
15913	Lamsfeld-Groß Liebitz	Brandenburg	BB	Dahme-Spreewald
15913	Neu Zauche	Brandenburg	BB	Dahme-Spreewald
15913	Groß Leuthen	Brandenburg	BB	Dahme-Spreewald
15913	Leibchel	Brandenburg	BB	Dahme-Spreewald
15913	Ressen-Zaue	Brandenburg	BB	Dahme-Spreewald
15913	Groß Leine	Brandenburg	BB	Dahme-Spreewald
15913	Goyatz	Brandenburg	BB	Dahme-Spreewald
15913	Straupitz	Brandenburg	BB	Dahme-Spreewald
15913	Sacrow-Waldow	Brandenburg	BB	Dahme-Spreewald
15926	Heideblick Pitschen-Pickel	Brandenburg	BB	Dahme-Spreewald
15926	Heideblick Falkenberg	Brandenburg	BB	Dahme-Spreewald
15926	Luckau	Brandenburg	BB	Dahme-Spreewald
15926	Bersteland	Brandenburg	BB	Dahme-Spreewald
15926	Heideblick Wüstermarke	Brandenburg	BB	Dahme-Spreewald
15926	Bersteland Freiwalde	Brandenburg	BB	Dahme-Spreewald
15926	Bersteland Niewitz	Brandenburg	BB	Dahme-Spreewald
15926	Bersteland Reichwalde	Brandenburg	BB	Dahme-Spreewald
15926	Heideblick Beesdau	Brandenburg	BB	Dahme-Spreewald
15926	Heideblick Goßmar	Brandenburg	BB	Dahme-Spreewald
15926	Walddrehna	Brandenburg	BB	Dahme-Spreewald
15926	Heideblick Riedebeck	Brandenburg	BB	Dahme-Spreewald
15926	Duben	Brandenburg	BB	Dahme-Spreewald
15926	Heideblick Weißack	Brandenburg	BB	Dahme-Spreewald
15926	Cahnsdorf	Brandenburg	BB	Dahme-Spreewald
15926	Görlsdorf	Brandenburg	BB	Dahme-Spreewald
15926	Heideblick Bornsdorf	Brandenburg	BB	Dahme-Spreewald
15926	Heideblick Gehren	Brandenburg	BB	Dahme-Spreewald
15926	Schlabendorf	Brandenburg	BB	Dahme-Spreewald
15926	Heideblick Langengrassau	Brandenburg	BB	Dahme-Spreewald
15926	Heideblick	Brandenburg	BB	Dahme-Spreewald
15926	Heideblick Waltersdorf	Brandenburg	BB	Dahme-Spreewald
15936	Steinreich	Brandenburg	BB	Teltow-Fläming
15936	Steinreich Glienig	Brandenburg	BB	Teltow-Fläming
15936	Dahmetal	Brandenburg	BB	Teltow-Fläming
15936	Dahme/Mark	Brandenburg	BB	Teltow-Fläming
15938	Kasel-Golzig	Brandenburg	BB	Dahme-Spreewald
15938	Steinreich	Brandenburg	BB	Dahme-Spreewald
15938	Steinreich Sellendorf	Brandenburg	BB	Dahme-Spreewald
15938	Drahnsdorf	Brandenburg	BB	Dahme-Spreewald
15938	Golßen	Brandenburg	BB	Dahme-Spreewald
16225	Eberswalde	Brandenburg	BB	Barnim
16227	Eberswalde	Brandenburg	BB	Barnim
16230	Breydin	Brandenburg	BB	Barnim
16230	Sydower Fließ	Brandenburg	BB	Barnim
16230	Britz	Brandenburg	BB	Barnim
16230	Chorin	Brandenburg	BB	Barnim
16230	Melchow	Brandenburg	BB	Barnim
16244	Finowfurt	Brandenburg	BB	Barnim
16244	Altenhof	Brandenburg	BB	Barnim
16247	Althüttendorf	Brandenburg	BB	Barnim
16247	Friedrichswalde	Brandenburg	BB	Barnim
16247	Ziethen	Brandenburg	BB	Barnim
16247	Neugrimnitz	Brandenburg	BB	Barnim
16247	Joachimsthal	Brandenburg	BB	Barnim
16248	Niederfinow	Brandenburg	BB	Barnim
16248	Parsteinsee	Brandenburg	BB	Barnim
16248	Lunow-Stolzenhagen	Brandenburg	BB	Barnim
16248	Liepe	Brandenburg	BB	Barnim
16248	Oderberg	Brandenburg	BB	Barnim
16248	Hohenfinow	Brandenburg	BB	Barnim
16248	Hohensaaten	Brandenburg	BB	Märkisch-Oderland
16248	Bölkendorf	Brandenburg	BB	Uckermark
16259	Falkenberg	Brandenburg	BB	Märkisch-Oderland
16259	Schiffmühle	Brandenburg	BB	Märkisch-Oderland
16259	Oderaue Wustrow	Brandenburg	BB	Märkisch-Oderland
16259	Höhenland	Brandenburg	BB	Märkisch-Oderland
16259	Oderaue Zäckericker Loose	Brandenburg	BB	Märkisch-Oderland
16259	Oderaue Neurüdnitz	Brandenburg	BB	Märkisch-Oderland
16259	Beiersdorf-Freudenberg Beiersdorf	Brandenburg	BB	Märkisch-Oderland
16259	Falkenberg Kruge/Gersdorf; Gersdorf	Brandenburg	BB	Märkisch-Oderland
16259	Neulewin Neulietzegöricke	Brandenburg	BB	Märkisch-Oderland
16259	Heckelberg-Brunow Heckelberg	Brandenburg	BB	Märkisch-Oderland
16259	Beiersdorf-Freudenberg Freudenberg	Brandenburg	BB	Märkisch-Oderland
16259	Oderaue Mädewitz; Altmädewitz	Brandenburg	BB	Märkisch-Oderland
16259	Falkenberg Falkenberg/Mark	Brandenburg	BB	Märkisch-Oderland
16259	Höhenland Wölsickendorf-Wollenberg	Brandenburg	BB	Märkisch-Oderland
16259	Oderaue Mädewitz; Neumädewitz	Brandenburg	BB	Märkisch-Oderland
16259	Falkenberg Kruge/Gersdorf; Neugersdorf	Brandenburg	BB	Märkisch-Oderland
16259	Falkenberg Kruge/Gersdorf	Brandenburg	BB	Märkisch-Oderland
16259	Falkenberg Kruge/Gersdorf; Kruge	Brandenburg	BB	Märkisch-Oderland
16259	Oderaue Neureetz	Brandenburg	BB	Märkisch-Oderland
16259	Neulewin Güstebieser Loose	Brandenburg	BB	Märkisch-Oderland
16259	Oderaue Mädewitz	Brandenburg	BB	Märkisch-Oderland
16259	Falkenberg Dannenberg/Mark	Brandenburg	BB	Märkisch-Oderland
16259	Oderaue Wustrow; Neu-Wustrow	Brandenburg	BB	Märkisch-Oderland
16259	Oderaue	Brandenburg	BB	Märkisch-Oderland
16259	Höhenland Leuenberg	Brandenburg	BB	Märkisch-Oderland
16259	Höhenland Wölsickendorf-Wollenberg; Wölsickendorf	Brandenburg	BB	Märkisch-Oderland
16259	Oderaue Neuküstrinchen	Brandenburg	BB	Märkisch-Oderland
16259	Neulewin Neulewin	Brandenburg	BB	Märkisch-Oderland
16259	Oderaue Wustrow; Wustrow	Brandenburg	BB	Märkisch-Oderland
16259	Beiersdorf-Freudenberg	Brandenburg	BB	Märkisch-Oderland
16259	Höhenland Wölsickendorf-Wollenberg; Wollenberg	Brandenburg	BB	Märkisch-Oderland
16259	Oderaue Altreetz	Brandenburg	BB	Märkisch-Oderland
16259	Heckelberg-Brunow Brunow	Brandenburg	BB	Märkisch-Oderland
16259	Heckelberg-Brunow	Brandenburg	BB	Märkisch-Oderland
16259	Höhenland Steinbeck	Brandenburg	BB	Märkisch-Oderland
16259	Hohenwutzen	Brandenburg	BB	Märkisch-Oderland
16259	Neulewin	Brandenburg	BB	Märkisch-Oderland
16259	Tiefensee	Brandenburg	BB	Barnim
16259	Bralitz	Brandenburg	BB	Märkisch-Oderland
16259	Neuenhagen	Brandenburg	BB	Märkisch-Oderland
16259	Altglietzen	Brandenburg	BB	Märkisch-Oderland
16259	Bad Freienwalde	Brandenburg	BB	Märkisch-Oderland
16269	Bliesdorf Bliesdorf	Brandenburg	BB	Märkisch-Oderland
16269	Bliesdorf Metzdorf	Brandenburg	BB	Märkisch-Oderland
16269	Bliesdorf Kunersdorf	Brandenburg	BB	Märkisch-Oderland
16269	Bliesdorf	Brandenburg	BB	Märkisch-Oderland
16269	Wriezen	Brandenburg	BB	Märkisch-Oderland
16269	Wriezener Höhe	Brandenburg	BB	Märkisch-Oderland
16278	Mark Landin	Brandenburg	BB	Uckermark
16278	Stolpe/Oder	Brandenburg	BB	Uckermark
16278	Angermünde	Brandenburg	BB	Uckermark
16278	Günterberg	Brandenburg	BB	Uckermark
16278	Görlsdorf	Brandenburg	BB	Uckermark
16278	Crussow	Brandenburg	BB	Uckermark
16278	Mürow	Brandenburg	BB	Uckermark
16278	Pinnow	Brandenburg	BB	Uckermark
16278	Kerkow	Brandenburg	BB	Uckermark
16278	Wolletz	Brandenburg	BB	Uckermark
16278	Greiffenberg	Brandenburg	BB	Uckermark
16278	Schmiedeberg	Brandenburg	BB	Uckermark
16278	Wilmersdorf	Brandenburg	BB	Uckermark
16278	Gellmersdorf	Brandenburg	BB	Uckermark
16278	Biesenbrow	Brandenburg	BB	Uckermark
16278	Steinhöfel	Brandenburg	BB	Uckermark
16278	Schmargendorf	Brandenburg	BB	Uckermark
16278	Bruchhagen	Brandenburg	BB	Uckermark
16278	Frauenhagen	Brandenburg	BB	Uckermark
16278	Welsow	Brandenburg	BB	Uckermark
16278	Neukünkendorf	Brandenburg	BB	Uckermark
16278	Schöneberg	Brandenburg	BB	Uckermark
16278	Herzsprung	Brandenburg	BB	Uckermark
16303	Schwedt/Oder	Brandenburg	BB	Uckermark
16306	Biesendahlshof	Brandenburg	BB	Uckermark
16306	Passow	Brandenburg	BB	Uckermark
16306	Zichow	Brandenburg	BB	Uckermark
16306	Luckow-Petershagen	Brandenburg	BB	Uckermark
16306	Berkholz-Meyenburg	Brandenburg	BB	Uckermark
16306	Vierraden	Brandenburg	BB	Uckermark
16306	Schönow	Brandenburg	BB	Uckermark
16306	Casekow	Brandenburg	BB	Uckermark
16306	Stendell	Brandenburg	BB	Uckermark
16306	Groß Pinnow	Brandenburg	BB	Uckermark
16306	Woltersdorf	Brandenburg	BB	Uckermark
16306	Friedrichsthal	Brandenburg	BB	Uckermark
16306	Hohenselchow	Brandenburg	BB	Uckermark
16306	Blumberg	Brandenburg	BB	Uckermark
16306	Wartin	Brandenburg	BB	Uckermark
16307	Neurochlitz	Brandenburg	BB	Uckermark
16307	Hohenreinkendorf	Brandenburg	BB	Uckermark
16307	Schönfeld	Brandenburg	BB	Uckermark
16307	Gartz (Oder)	Brandenburg	BB	Uckermark
16307	Rosow	Brandenburg	BB	Uckermark
16307	Mescherin	Brandenburg	BB	Uckermark
16307	Geesow	Brandenburg	BB	Uckermark
16307	Radekow	Brandenburg	BB	Uckermark
16307	Tantow	Brandenburg	BB	Uckermark
16321	Lobetal	Brandenburg	BB	Barnim
16321	Rüdnitz	Brandenburg	BB	Barnim
16321	Börnicke	Brandenburg	BB	Barnim
16321	Lindenberg	Brandenburg	BB	Barnim
16321	Bernau	Brandenburg	BB	Barnim
16321	Danewitz	Brandenburg	BB	Barnim
16321	Schönow	Brandenburg	BB	Barnim
16341	Zepernick	Brandenburg	BB	Barnim
16341	Schwanebeck	Brandenburg	BB	Barnim
16348	Klosterfelde	Brandenburg	BB	Barnim
16348	Prenden	Brandenburg	BB	Barnim
16348	Ruhlsdorf	Brandenburg	BB	Barnim
16348	Groß Schönebeck (Schorfheide)	Brandenburg	BB	Barnim
16348	Stolzenhagen	Brandenburg	BB	Barnim
16348	Wandlitz	Brandenburg	BB	Barnim
16348	Marienwerder	Brandenburg	BB	Barnim
16348	Zerpenschleuse	Brandenburg	BB	Barnim
16352	Schönwalde	Brandenburg	BB	Barnim
16352	Basdorf	Brandenburg	BB	Barnim
16352	Schönerlinde	Brandenburg	BB	Barnim
16356	Seefeld	Brandenburg	BB	Barnim
16356	Eiche	Brandenburg	BB	Barnim
16356	Krummensee	Brandenburg	BB	Barnim
16356	Ahrensfelde	Brandenburg	BB	Barnim
16356	Blumberg	Brandenburg	BB	Barnim
16356	Werneuchen	Brandenburg	BB	Barnim
16356	Schönfeld	Brandenburg	BB	Barnim
16356	Mehrow	Brandenburg	BB	Barnim
16356	Hirschfelde	Brandenburg	BB	Barnim
16356	Wilmersdorf	Brandenburg	BB	Barnim
16359	Biesenthal	Brandenburg	BB	Barnim
16359	Lanke	Brandenburg	BB	Barnim
16515	Zühlsdorf	Brandenburg	BB	Oberhavel
16515	Freienhagen	Brandenburg	BB	Oberhavel
16515	Oranienburg	Brandenburg	BB	Oberhavel
16515	Wensickendorf	Brandenburg	BB	Oberhavel
16515	Neuholland	Brandenburg	BB	Oberhavel
16515	Zehlendorf	Brandenburg	BB	Oberhavel
16515	Schmachtenhagen	Brandenburg	BB	Oberhavel
16515	Nassenheide	Brandenburg	BB	Oberhavel
16515	Friedrichsthal	Brandenburg	BB	Oberhavel
16515	Malz	Brandenburg	BB	Oberhavel
16540	Hohen Neuendorf	Brandenburg	BB	Oberhavel
16540	Stolpe	Brandenburg	BB	Oberhavel
16547	Birkenwerder	Brandenburg	BB	Oberhavel
16548	Glienicke/Nordbahn	Brandenburg	BB	Oberhavel
16552	Schildow	Brandenburg	BB	Oberhavel
16556	Borgsdorf	Brandenburg	BB	Oberhavel
16559	Liebenwalde	Brandenburg	BB	Oberhavel
16559	Kreuzbruch	Brandenburg	BB	Oberhavel
16559	Hammer	Brandenburg	BB	Oberhavel
16559	Liebenthal	Brandenburg	BB	Oberhavel
16562	Bergfelde	Brandenburg	BB	Oberhavel
16565	Lehnitz	Brandenburg	BB	Oberhavel
16567	Mühlenbeck	Brandenburg	BB	Oberhavel
16567	Schönfließ	Brandenburg	BB	Oberhavel
16727	Oberkrämer	Brandenburg	BB	Oberhavel
16727	Velten	Brandenburg	BB	Oberhavel
16761	Hennigsdorf	Brandenburg	BB	Oberhavel
16766	Oberkrämer	Brandenburg	BB	Oberhavel
16766	Kremmen	Brandenburg	BB	Oberhavel
16767	Leegebruch	Brandenburg	BB	Oberhavel
16767	Germendorf	Brandenburg	BB	Oberhavel
16775	Sonnenberg	Brandenburg	BB	Oberhavel
16775	Großwoltersdorf	Brandenburg	BB	Oberhavel
16775	Bredereiche	Brandenburg	BB	Oberhavel
16775	Barsdorf	Brandenburg	BB	Oberhavel
16775	Rönnebeck	Brandenburg	BB	Oberhavel
16775	Burgwall	Brandenburg	BB	Oberhavel
16775	Blumenow	Brandenburg	BB	Oberhavel
16775	Krewelin	Brandenburg	BB	Oberhavel
16775	Schulzendorf	Brandenburg	BB	Oberhavel
16775	Marienthal	Brandenburg	BB	Oberhavel
16775	Mildenberg	Brandenburg	BB	Oberhavel
16775	Kappe	Brandenburg	BB	Oberhavel
16775	Gransee	Brandenburg	BB	Oberhavel
16775	Stechlin	Brandenburg	BB	Oberhavel
16775	Klein-Mutz	Brandenburg	BB	Oberhavel
16775	Löwenberger Land	Brandenburg	BB	Oberhavel
16775	Zabelsdorf	Brandenburg	BB	Oberhavel
16775	Schönermark	Brandenburg	BB	Oberhavel
16775	Badingen	Brandenburg	BB	Oberhavel
16775	Tornow	Brandenburg	BB	Oberhavel
16792	Wesendorf	Brandenburg	BB	Oberhavel
16792	Zehdenick	Brandenburg	BB	Oberhavel
16792	Kurtschlag	Brandenburg	BB	Oberhavel
16798	Fürstenberg/Havel	Brandenburg	BB	Oberhavel
16798	Himmelpfort	Brandenburg	BB	Oberhavel
16798	Steinförde	Brandenburg	BB	Oberhavel
16816	Neuruppin	Brandenburg	BB	Ostprignitz-Ruppin
16818	Fehrbellin Wall	Brandenburg	BB	Ostprignitz-Ruppin
16818	Fehrbellin Deutschhof	Brandenburg	BB	Ostprignitz-Ruppin
16818	Fehrbellin Wustrau-Altfriesack	Brandenburg	BB	Ostprignitz-Ruppin
16818	Märkisch Linden	Brandenburg	BB	Ostprignitz-Ruppin
16818	Temnitzquell	Brandenburg	BB	Ostprignitz-Ruppin
16818	Storbeck-Frankendorf	Brandenburg	BB	Ostprignitz-Ruppin
16818	Rheinsberg Braunsberg	Brandenburg	BB	Ostprignitz-Ruppin
16818	Basdorf	Brandenburg	BB	Ostprignitz-Ruppin
16818	Fehrbellin Langen	Brandenburg	BB	Ostprignitz-Ruppin
16818	Walsleben	Brandenburg	BB	Ostprignitz-Ruppin
16818	Dabergotz	Brandenburg	BB	Ostprignitz-Ruppin
16827	Alt Ruppin	Brandenburg	BB	Ostprignitz-Ruppin
16831	Rheinsberg Heinrichsdorf	Brandenburg	BB	Ostprignitz-Ruppin
16831	Rheinsberg Schwanow	Brandenburg	BB	Ostprignitz-Ruppin
16831	Rheinsberg Linow	Brandenburg	BB	Ostprignitz-Ruppin
16831	Rheinsberg Kleinzerlang	Brandenburg	BB	Ostprignitz-Ruppin
16831	Rheinsberg Großzerlang	Brandenburg	BB	Ostprignitz-Ruppin
16831	Rheinsberg Zechlinerhütte	Brandenburg	BB	Ostprignitz-Ruppin
16831	Rheinsberg Zechow	Brandenburg	BB	Ostprignitz-Ruppin
16831	Rheinsberg Zühlen	Brandenburg	BB	Ostprignitz-Ruppin
16831	Rheinsberg	Brandenburg	BB	Ostprignitz-Ruppin
16833	Fehrbellin Walchow	Brandenburg	BB	Ostprignitz-Ruppin
16833	Fehrbellin Dechtow	Brandenburg	BB	Ostprignitz-Ruppin
16833	Fehrbellin Linum	Brandenburg	BB	Ostprignitz-Ruppin
16833	Fehrbellin Königshorst	Brandenburg	BB	Ostprignitz-Ruppin
16833	Fehrbellin Hakenberg	Brandenburg	BB	Ostprignitz-Ruppin
16833	Fehrbellin Betzin	Brandenburg	BB	Ostprignitz-Ruppin
16833	Fehrbellin Tarmow	Brandenburg	BB	Ostprignitz-Ruppin
16833	Fehrbellin Lentzke	Brandenburg	BB	Ostprignitz-Ruppin
16833	Fehrbellin Protzen	Brandenburg	BB	Ostprignitz-Ruppin
16833	Fehrbellin Brunne	Brandenburg	BB	Ostprignitz-Ruppin
16833	Fehrbellin	Brandenburg	BB	Ostprignitz-Ruppin
16833	Fehrbellin Karwesee	Brandenburg	BB	Ostprignitz-Ruppin
16835	Herzberg	Brandenburg	BB	Ostprignitz-Ruppin
16835	Rheinsberg Dierberg	Brandenburg	BB	Ostprignitz-Ruppin
16835	Lindow (Mark) Schönberg (Mark)	Brandenburg	BB	Ostprignitz-Ruppin
16835	Lindow (Mark)	Brandenburg	BB	Ostprignitz-Ruppin
16835	Vielitz	Brandenburg	BB	Ostprignitz-Ruppin
16835	Lindow (Mark) Hindenberg	Brandenburg	BB	Ostprignitz-Ruppin
16835	Rüthnick	Brandenburg	BB	Ostprignitz-Ruppin
16835	Seebeck-Strubensee	Brandenburg	BB	Ostprignitz-Ruppin
16837	Rheinsberg Dorf Zechlin	Brandenburg	BB	Ostprignitz-Ruppin
16837	Rheinsberg Luhme	Brandenburg	BB	Ostprignitz-Ruppin
16837	Rheinsberg Flecken Zechlin	Brandenburg	BB	Ostprignitz-Ruppin
16837	Rheinsberg Wallitz	Brandenburg	BB	Ostprignitz-Ruppin
16837	Wittstock/Dosse Zempow	Brandenburg	BB	Ostprignitz-Ruppin
16837	Rheinsberg Kagar	Brandenburg	BB	Ostprignitz-Ruppin
16845	Stüdenitz-Schönermark	Brandenburg	BB	Ostprignitz-Ruppin
16845	Neustadt (Dosse)	Brandenburg	BB	Ostprignitz-Ruppin
16845	Temnitztal Garz	Brandenburg	BB	Ostprignitz-Ruppin
16845	Sieversdorf-Hohenofen	Brandenburg	BB	Ostprignitz-Ruppin
16845	Fehrbellin Manker	Brandenburg	BB	Ostprignitz-Ruppin
16845	Märkisch Linden	Brandenburg	BB	Ostprignitz-Ruppin
16845	Zernitz-Lohm	Brandenburg	BB	Ostprignitz-Ruppin
16845	Kyritz Holzhausen	Brandenburg	BB	Ostprignitz-Ruppin
16845	Breddin	Brandenburg	BB	Ostprignitz-Ruppin
16845	Großderschau	Brandenburg	BB	Havelland
16845	Temnitztal Wildberg	Brandenburg	BB	Ostprignitz-Ruppin
16845	Dreetz	Brandenburg	BB	Ostprignitz-Ruppin
16845	Temnitztal	Brandenburg	BB	Ostprignitz-Ruppin
16866	Groß Welle	Brandenburg	BB	Prignitz
16866	Kunow	Brandenburg	BB	Prignitz
16866	Demerthin	Brandenburg	BB	Prignitz
16866	Döllen	Brandenburg	BB	Prignitz
16866	Dannenwalde	Brandenburg	BB	Prignitz
16866	Vehlow	Brandenburg	BB	Prignitz
16866	Schönhagen	Brandenburg	BB	Prignitz
16866	Teetz-Ganz	Brandenburg	BB	Ostprignitz-Ruppin
16866	Kyritz Kötzlin	Brandenburg	BB	Ostprignitz-Ruppin
16866	Kyritz Drewen	Brandenburg	BB	Ostprignitz-Ruppin
16866	Granzow	Brandenburg	BB	Prignitz
16866	Bork-Lellichow	Brandenburg	BB	Ostprignitz-Ruppin
16866	Rehfeld-Berlitt	Brandenburg	BB	Ostprignitz-Ruppin
16866	Vehlin	Brandenburg	BB	Prignitz
16866	Barenthin	Brandenburg	BB	Prignitz
16866	Kolrep	Brandenburg	BB	Prignitz
16866	Kyritz	Brandenburg	BB	Ostprignitz-Ruppin
16866	Görike	Brandenburg	BB	Prignitz
16866	Gumtow	Brandenburg	BB	Prignitz
16866	Schrepkow	Brandenburg	BB	Prignitz
16866	Wutike	Brandenburg	BB	Prignitz
16868	Wusterhausen (Dosse)	Brandenburg	BB	Ostprignitz-Ruppin
16909	Heiligengrabe Papenbruch	Brandenburg	BB	Ostprignitz-Ruppin
16909	Heiligengrabe Blandikow	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse Berlinchen	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse Schweinrich	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse Dossow	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse Groß Haßlow	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse Goldbeck	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse Zootzen	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse Herzsprung	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse Dranse	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse Wulfersdorf	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse Fretzdorf	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse Gadow	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse Niemerlang	Brandenburg	BB	Ostprignitz-Ruppin
16909	Heiligengrabe Grabow bei Blumenthal	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse Rossow	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse Christdorf	Brandenburg	BB	Ostprignitz-Ruppin
16909	Heiligengrabe Blesendorf	Brandenburg	BB	Ostprignitz-Ruppin
16909	Heiligengrabe Maulbeerwalde	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse Sewekow	Brandenburg	BB	Ostprignitz-Ruppin
16909	Wittstock/Dosse Königsberg	Brandenburg	BB	Ostprignitz-Ruppin
16909	Heiligengrabe	Brandenburg	BB	Ostprignitz-Ruppin
16909	Heiligengrabe Wernikow	Brandenburg	BB	Ostprignitz-Ruppin
16909	Heiligengrabe Jabel	Brandenburg	BB	Ostprignitz-Ruppin
16909	Heiligengrabe Liebenthal	Brandenburg	BB	Ostprignitz-Ruppin
16909	Heiligengrabe Zaatzke	Brandenburg	BB	Ostprignitz-Ruppin
16918	Wittstock/Dosse Freyenstein	Brandenburg	BB	Ostprignitz-Ruppin
16921	Alt Krüssow	Brandenburg	BB	Prignitz
16928	Tüchen	Brandenburg	BB	Prignitz
16928	Kuhsdorf	Brandenburg	BB	Prignitz
16928	Mesendorf	Brandenburg	BB	Prignitz
16928	Heiligengrabe Blumenthal	Brandenburg	BB	Prignitz
16928	Groß Woltersdorf	Brandenburg	BB	Prignitz
16928	Beveringen	Brandenburg	BB	Prignitz
16928	Groß Pankow	Brandenburg	BB	Prignitz
16928	Klein Woltersdorf	Brandenburg	BB	Prignitz
16928	Heiligengrabe Rosenwinkel	Brandenburg	BB	Prignitz
16928	Boddin-Langnow	Brandenburg	BB	Prignitz
16928	Steffenshagen	Brandenburg	BB	Prignitz
16928	Hoppenrade	Brandenburg	BB	Prignitz
16928	Kehrberg	Brandenburg	BB	Prignitz
16928	Vettin	Brandenburg	BB	Prignitz
16928	Wilmersdorf	Brandenburg	BB	Prignitz
16928	Pritzwalk	Brandenburg	BB	Prignitz
16928	Buchholz	Brandenburg	BB	Prignitz
16928	Lindenberg	Brandenburg	BB	Prignitz
16928	Alt Krüssow	Brandenburg	BB	Prignitz
16928	Falkenhagen	Brandenburg	BB	Prignitz
16928	Sadenbeck	Brandenburg	BB	Prignitz
16928	Kemnitz	Brandenburg	BB	Prignitz
16928	Kuhbier	Brandenburg	BB	Prignitz
16928	Schönebeck	Brandenburg	BB	Prignitz
16928	Gerdshagen	Brandenburg	BB	Prignitz
16928	Helle	Brandenburg	BB	Prignitz
16945	Meyenburg	Brandenburg	BB	Prignitz
16945	Halenbeck-Rohlsdorf	Brandenburg	BB	Prignitz
16945	Kümmernitztal	Brandenburg	BB	Prignitz
16945	Marienfließ	Brandenburg	BB	Prignitz
16949	Putlitz	Brandenburg	BB	Prignitz
16949	Triglitz	Brandenburg	BB	Prignitz
17268	Herzfelde	Brandenburg	BB	Uckermark
17268	Vietmannsdorf	Brandenburg	BB	Uckermark
17268	Gandenitz	Brandenburg	BB	Uckermark
17268	Storkow	Brandenburg	BB	Uckermark
17268	Röddelin	Brandenburg	BB	Uckermark
17268	Mittenwalde	Brandenburg	BB	Uckermark
17268	Milmersdorf	Brandenburg	BB	Uckermark
17268	Beutel	Brandenburg	BB	Uckermark
17268	Klosterwalde	Brandenburg	BB	Uckermark
17268	Petznick	Brandenburg	BB	Uckermark
17268	Gollin	Brandenburg	BB	Uckermark
17268	Flieth-Stegelitz	Brandenburg	BB	Uckermark
17268	Temmen-Ringenwalde	Brandenburg	BB	Uckermark
17268	Groß Dölln	Brandenburg	BB	Uckermark
17268	Densow	Brandenburg	BB	Uckermark
17268	Boitzenburger Land	Brandenburg	BB	Uckermark
17268	Grunewald	Brandenburg	BB	Uckermark
17268	Gerswalde	Brandenburg	BB	Uckermark
17268	Templin	Brandenburg	BB	Uckermark
17268	Hammelspring	Brandenburg	BB	Uckermark
17279	Lychen	Brandenburg	BB	Uckermark
17291	Schönfeld	Brandenburg	BB	Uckermark
17291	Prenzlau	Brandenburg	BB	Uckermark
17291	Gramzow	Brandenburg	BB	Uckermark
17291	Grünow	Brandenburg	BB	Uckermark
17291	Carmzow-Wallmow	Brandenburg	BB	Uckermark
17291	Schenkenberg	Brandenburg	BB	Uckermark
17291	Göritz	Brandenburg	BB	Uckermark
17291	Nordwestuckermark	Brandenburg	BB	Uckermark
17291	Oberuckersee	Brandenburg	BB	Uckermark
17291	Randowtal	Brandenburg	BB	Uckermark
17291	Uckerfelde	Brandenburg	BB	Uckermark
17326	Brüssow	Brandenburg	BB	Uckermark
17337	Uckerland	Brandenburg	BB	Uckermark
19309	Besandten	Brandenburg	BB	Prignitz
19309	Lenzen (Elbe)	Brandenburg	BB	Prignitz
19309	Wootz	Brandenburg	BB	Prignitz
19309	Eldenburg	Brandenburg	BB	Prignitz
19309	Mellen	Brandenburg	BB	Prignitz
19309	Lanz	Brandenburg	BB	Prignitz
19322	Rühstädt	Brandenburg	BB	Prignitz
19322	Weisen	Brandenburg	BB	Prignitz
19322	Breese	Brandenburg	BB	Prignitz
19322	Groß Breese	Brandenburg	BB	Prignitz
19322	Cumlosen	Brandenburg	BB	Prignitz
19322	Wittenberge	Brandenburg	BB	Prignitz
19336	Legde/Quitzöbel	Brandenburg	BB	Prignitz
19336	Kletzke	Brandenburg	BB	Prignitz
19336	Bad Wilsnack	Brandenburg	BB	Prignitz
19336	Viesecke	Brandenburg	BB	Prignitz
19339	Glöwen	Brandenburg	BB	Prignitz
19339	Netzow	Brandenburg	BB	Prignitz
19339	Bendelin	Brandenburg	BB	Prignitz
19348	Krampfer	Brandenburg	BB	Prignitz
19348	Pirow	Brandenburg	BB	Prignitz
19348	Baek	Brandenburg	BB	Prignitz
19348	Retzin	Brandenburg	BB	Prignitz
19348	Perleberg	Brandenburg	BB	Prignitz
19348	Klein Gottschow	Brandenburg	BB	Prignitz
19348	Gülitz-Reetz	Brandenburg	BB	Prignitz
19348	Berge	Brandenburg	BB	Prignitz
19348	Kleinow	Brandenburg	BB	Prignitz
19357	Boberow	Brandenburg	BB	Prignitz
19357	Karstädt	Brandenburg	BB	Prignitz
19357	Mankmuß	Brandenburg	BB	Prignitz
19357	Garlin	Brandenburg	BB	Prignitz
19357	Pröttlin	Brandenburg	BB	Prignitz
10115	Berlin	Berlin	BE	Berlin; Stadt
10117	Berlin	Berlin	BE	Berlin; Stadt
10119	Berlin	Berlin	BE	Berlin; Stadt
10178	Berlin	Berlin	BE	Berlin; Stadt
10179	Berlin	Berlin	BE	Berlin; Stadt
10243	Berlin Friedrichshain	Berlin	BE	Berlin; Stadt
10245	Berlin Friedrichshain	Berlin	BE	Berlin; Stadt
10247	Berlin Friedrichshain	Berlin	BE	Berlin; Stadt
10249	Berlin Friedrichshain	Berlin	BE	Berlin; Stadt
10315	Berlin	Berlin	BE	Berlin; Stadt
10317	Berlin	Berlin	BE	Berlin; Stadt
10318	Berlin	Berlin	BE	Berlin; Stadt
10319	Berlin	Berlin	BE	Berlin; Stadt
10365	Berlin	Berlin	BE	Berlin; Stadt
10367	Berlin	Berlin	BE	Berlin; Stadt
10369	Berlin	Berlin	BE	Berlin; Stadt
10405	Berlin	Berlin	BE	Berlin; Stadt
10407	Berlin	Berlin	BE	Berlin; Stadt
10409	Berlin	Berlin	BE	Berlin; Stadt
10435	Berlin	Berlin	BE	Berlin; Stadt
10437	Berlin	Berlin	BE	Berlin; Stadt
10439	Berlin	Berlin	BE	Berlin; Stadt
10551	Berlin	Berlin	BE	Berlin; Stadt
10553	Berlin	Berlin	BE	Berlin; Stadt
10555	Berlin	Berlin	BE	Berlin; Stadt
10557	Berlin	Berlin	BE	Berlin; Stadt
10559	Berlin	Berlin	BE	Berlin; Stadt
10585	Berlin	Berlin	BE	Berlin; Stadt
10587	Berlin	Berlin	BE	Berlin; Stadt
10589	Berlin	Berlin	BE	Berlin; Stadt
10623	Berlin	Berlin	BE	Berlin; Stadt
10625	Berlin	Berlin	BE	Berlin; Stadt
10627	Berlin	Berlin	BE	Berlin; Stadt
10629	Berlin	Berlin	BE	Berlin; Stadt
10707	Berlin	Berlin	BE	Berlin; Stadt
10709	Berlin	Berlin	BE	Berlin; Stadt
10711	Berlin	Berlin	BE	Berlin; Stadt
10713	Berlin	Berlin	BE	Berlin; Stadt
10715	Berlin	Berlin	BE	Berlin; Stadt
10717	Berlin	Berlin	BE	Berlin; Stadt
10719	Berlin	Berlin	BE	Berlin; Stadt
10777	Berlin	Berlin	BE	Berlin; Stadt
10779	Berlin	Berlin	BE	Berlin; Stadt
10781	Berlin	Berlin	BE	Berlin; Stadt
10783	Berlin	Berlin	BE	Berlin; Stadt
10785	Berlin	Berlin	BE	Berlin; Stadt
10787	Berlin	Berlin	BE	Berlin; Stadt
10789	Berlin	Berlin	BE	Berlin; Stadt
10823	Berlin	Berlin	BE	Berlin; Stadt
10825	Berlin	Berlin	BE	Berlin; Stadt
10827	Berlin	Berlin	BE	Berlin; Stadt
10829	Berlin	Berlin	BE	Berlin; Stadt
10961	Berlin Kreuzberg	Berlin	BE	Berlin; Stadt
10963	Berlin Kreuzberg	Berlin	BE	Berlin; Stadt
10965	Berlin Kreuzberg	Berlin	BE	Berlin; Stadt
10967	Berlin Kreuzberg	Berlin	BE	Berlin; Stadt
10969	Berlin Kreuzberg	Berlin	BE	Berlin; Stadt
10997	Berlin Kreuzberg	Berlin	BE	Berlin; Stadt
10999	Berlin Kreuzberg	Berlin	BE	Berlin; Stadt
11011	Berlin	Berlin	BE	Berlin; Stadt
12043	Berlin	Berlin	BE	Berlin; Stadt
12045	Berlin	Berlin	BE	Berlin; Stadt
12047	Berlin	Berlin	BE	Berlin; Stadt
12049	Berlin	Berlin	BE	Berlin; Stadt
12051	Berlin	Berlin	BE	Berlin; Stadt
12053	Berlin	Berlin	BE	Berlin; Stadt
12055	Berlin	Berlin	BE	Berlin; Stadt
12057	Berlin	Berlin	BE	Berlin; Stadt
12059	Berlin	Berlin	BE	Berlin; Stadt
12099	Berlin	Berlin	BE	Berlin; Stadt
12101	Berlin	Berlin	BE	Berlin; Stadt
12103	Berlin	Berlin	BE	Berlin; Stadt
12105	Berlin	Berlin	BE	Berlin; Stadt
12107	Berlin	Berlin	BE	Berlin; Stadt
12109	Berlin	Berlin	BE	Berlin; Stadt
12157	Berlin	Berlin	BE	Berlin; Stadt
12159	Berlin	Berlin	BE	Berlin; Stadt
12161	Berlin	Berlin	BE	Berlin; Stadt
12163	Berlin	Berlin	BE	Berlin; Stadt
12165	Berlin	Berlin	BE	Berlin; Stadt
12167	Berlin	Berlin	BE	Berlin; Stadt
12169	Berlin	Berlin	BE	Berlin; Stadt
12203	Berlin	Berlin	BE	Berlin; Stadt
12205	Berlin	Berlin	BE	Berlin; Stadt
12207	Berlin	Berlin	BE	Berlin; Stadt
12209	Berlin	Berlin	BE	Berlin; Stadt
12247	Berlin	Berlin	BE	Berlin; Stadt
12249	Berlin	Berlin	BE	Berlin; Stadt
12277	Berlin	Berlin	BE	Berlin; Stadt
12279	Berlin	Berlin	BE	Berlin; Stadt
12305	Berlin	Berlin	BE	Berlin; Stadt
12307	Berlin	Berlin	BE	Berlin; Stadt
12309	Berlin	Berlin	BE	Berlin; Stadt
12347	Berlin	Berlin	BE	Berlin; Stadt
12349	Berlin	Berlin	BE	Berlin; Stadt
12351	Berlin	Berlin	BE	Berlin; Stadt
12353	Berlin	Berlin	BE	Berlin; Stadt
12355	Berlin	Berlin	BE	Berlin; Stadt
12357	Berlin	Berlin	BE	Berlin; Stadt
12359	Berlin	Berlin	BE	Berlin; Stadt
12435	Berlin	Berlin	BE	Berlin; Stadt
12437	Berlin	Berlin	BE	Berlin; Stadt
12439	Berlin	Berlin	BE	Berlin; Stadt
12459	Berlin	Berlin	BE	Berlin; Stadt
12487	Berlin	Berlin	BE	Berlin; Stadt
12489	Berlin	Berlin	BE	Berlin; Stadt
12524	Berlin	Berlin	BE	Berlin; Stadt
12526	Berlin	Berlin	BE	Berlin; Stadt
12527	Berlin	Berlin	BE	Berlin; Stadt
12627	Berlin	Berlin	BE	Berlin; Stadt
12629	Berlin	Berlin	BE	Berlin; Stadt
12679	Berlin	Berlin	BE	Berlin; Stadt
12681	Berlin	Berlin	BE	Berlin; Stadt
12683	Berlin	Berlin	BE	Berlin; Stadt
12685	Berlin	Berlin	BE	Berlin; Stadt
12687	Berlin	Berlin	BE	Berlin; Stadt
12689	Berlin	Berlin	BE	Berlin; Stadt
13047	Reinickendorf	Berlin	BE	Berlin; Stadt
13051	Berlin	Berlin	BE	Berlin; Stadt
13053	Berlin	Berlin	BE	Berlin; Stadt
13055	Berlin	Berlin	BE	Berlin; Stadt
13057	Berlin	Berlin	BE	Berlin; Stadt
13059	Berlin	Berlin	BE	Berlin; Stadt
13086	Berlin	Berlin	BE	Berlin; Stadt
13088	Berlin	Berlin	BE	Berlin; Stadt
13089	Berlin	Berlin	BE	Berlin; Stadt
13125	Berlin	Berlin	BE	Berlin; Stadt
13127	Berlin	Berlin	BE	Berlin; Stadt
13129	Berlin	Berlin	BE	Berlin; Stadt
13156	Berlin	Berlin	BE	Berlin; Stadt
13158	Berlin	Berlin	BE	Berlin; Stadt
13159	Berlin	Berlin	BE	Berlin; Stadt
13187	Berlin	Berlin	BE	Berlin; Stadt
13189	Berlin	Berlin	BE	Berlin; Stadt
13347	Berlin	Berlin	BE	Berlin; Stadt
13349	Berlin	Berlin	BE	Berlin; Stadt
13351	Berlin	Berlin	BE	Berlin; Stadt
13353	Berlin	Berlin	BE	Berlin; Stadt
13355	Berlin	Berlin	BE	Berlin; Stadt
13357	Berlin	Berlin	BE	Berlin; Stadt
13359	Berlin	Berlin	BE	Berlin; Stadt
13403	Berlin	Berlin	BE	Berlin; Stadt
13405	Berlin	Berlin	BE	Berlin; Stadt
13407	Berlin	Berlin	BE	Berlin; Stadt
13409	Berlin	Berlin	BE	Berlin; Stadt
13435	Berlin	Berlin	BE	Berlin; Stadt
13437	Berlin	Berlin	BE	Berlin; Stadt
13439	Berlin	Berlin	BE	Berlin; Stadt
13465	Berlin	Berlin	BE	Berlin; Stadt
13467	Berlin	Berlin	BE	Berlin; Stadt
13469	Berlin	Berlin	BE	Berlin; Stadt
13503	Berlin	Berlin	BE	Berlin; Stadt
13505	Berlin	Berlin	BE	Berlin; Stadt
13507	Berlin	Berlin	BE	Berlin; Stadt
13509	Berlin	Berlin	BE	Berlin; Stadt
13581	Berlin	Berlin	BE	Berlin; Stadt
13583	Berlin	Berlin	BE	Berlin; Stadt
13585	Berlin	Berlin	BE	Berlin; Stadt
13587	Berlin	Berlin	BE	Berlin; Stadt
13589	Berlin	Berlin	BE	Berlin; Stadt
13591	Berlin	Berlin	BE	Berlin; Stadt
13593	Berlin	Berlin	BE	Berlin; Stadt
13595	Berlin	Berlin	BE	Berlin; Stadt
13597	Berlin	Berlin	BE	Berlin; Stadt
13599	Berlin	Berlin	BE	Berlin; Stadt
13627	Berlin	Berlin	BE	Berlin; Stadt
13629	Berlin	Berlin	BE	Berlin; Stadt
14050	Berlin	Berlin	BE	Berlin; Stadt
14052	Berlin	Berlin	BE	Berlin; Stadt
14053	Berlin	Berlin	BE	Berlin; Stadt
14055	Berlin	Berlin	BE	Berlin; Stadt
14057	Berlin	Berlin	BE	Berlin; Stadt
14059	Berlin	Berlin	BE	Berlin; Stadt
14089	Berlin	Berlin	BE	Berlin; Stadt
14109	Berlin	Berlin	BE	Berlin; Stadt
14129	Berlin	Berlin	BE	Berlin; Stadt
14131	Berlin	Berlin	BE	Berlin; Stadt
14163	Berlin	Berlin	BE	Berlin; Stadt
14165	Berlin	Berlin	BE	Berlin; Stadt
14167	Berlin	Berlin	BE	Berlin; Stadt
14169	Berlin	Berlin	BE	Berlin; Stadt
14193	Berlin	Berlin	BE	Berlin; Stadt
14195	Berlin	Berlin	BE	Berlin; Stadt
14197	Berlin	Berlin	BE	Berlin; Stadt
14199	Berlin	Berlin	BE	Berlin; Stadt
70173	Stuttgart Stuttgart-Mitte	Baden-Württemberg	BW	81
70173	Stuttgart	Baden-Württemberg	BW	81
70174	Stuttgart	Baden-Württemberg	BW	81
70174	Stuttgart Stuttgart-Mitte	Baden-Württemberg	BW	81
70174	Stuttgart Stuttgart-Nord	Baden-Württemberg	BW	81
70176	Stuttgart Stuttgart-Mitte	Baden-Württemberg	BW	81
70176	Stuttgart Stuttgart-West	Baden-Württemberg	BW	81
70176	Stuttgart	Baden-Württemberg	BW	81
70178	Stuttgart	Baden-Württemberg	BW	81
70178	Stuttgart Stuttgart-West	Baden-Württemberg	BW	81
70178	Stuttgart Stuttgart-Mitte	Baden-Württemberg	BW	81
70178	Stuttgart Stuttgart-Süd	Baden-Württemberg	BW	81
70180	Stuttgart Stuttgart-Süd	Baden-Württemberg	BW	81
70180	Stuttgart Stuttgart-Mitte	Baden-Württemberg	BW	81
70180	Stuttgart	Baden-Württemberg	BW	81
70182	Stuttgart	Baden-Württemberg	BW	81
70182	Stuttgart Stuttgart-Mitte	Baden-Württemberg	BW	81
70184	Stuttgart Frauenkopf	Baden-Württemberg	BW	81
70184	Stuttgart Stuttgart-Mitte	Baden-Württemberg	BW	81
70184	Stuttgart Stuttgart-Süd	Baden-Württemberg	BW	81
70184	Stuttgart Stuttgart-Ost	Baden-Württemberg	BW	81
70184	Stuttgart	Baden-Württemberg	BW	81
70186	Stuttgart	Baden-Württemberg	BW	81
70186	Stuttgart Stuttgart-Ost	Baden-Württemberg	BW	81
70188	Stuttgart Stuttgart-Ost	Baden-Württemberg	BW	81
70188	Stuttgart Stuttgart-Mitte	Baden-Württemberg	BW	81
70188	Stuttgart	Baden-Württemberg	BW	81
70190	Stuttgart	Baden-Württemberg	BW	81
70190	Stuttgart Stuttgart-Mitte	Baden-Württemberg	BW	81
70190	Stuttgart Stuttgart-Ost	Baden-Württemberg	BW	81
70191	Stuttgart Bad Cannstatt	Baden-Württemberg	BW	81
70191	Stuttgart Stuttgart-Nord	Baden-Württemberg	BW	81
70191	Stuttgart	Baden-Württemberg	BW	81
70192	Stuttgart	Baden-Württemberg	BW	81
70192	Stuttgart Feuerbach	Baden-Württemberg	BW	81
70192	Stuttgart Stuttgart-Nord	Baden-Württemberg	BW	81
70193	Stuttgart Stuttgart-Nord	Baden-Württemberg	BW	81
71106	Magstadt	Baden-Württemberg	BW	81
70193	Stuttgart Stuttgart-West	Baden-Württemberg	BW	81
70193	Stuttgart	Baden-Württemberg	BW	81
70195	Stuttgart	Baden-Württemberg	BW	81
70195	Stuttgart Botnang	Baden-Württemberg	BW	81
70197	Stuttgart Stuttgart-West	Baden-Württemberg	BW	81
70197	Stuttgart	Baden-Württemberg	BW	81
70199	Stuttgart	Baden-Württemberg	BW	81
70199	Stuttgart Stuttgart-West	Baden-Württemberg	BW	81
70199	Stuttgart Stuttgart-Süd	Baden-Württemberg	BW	81
70327	Stuttgart Luginsland	Baden-Württemberg	BW	81
70327	Stuttgart Wangen	Baden-Württemberg	BW	81
70327	Stuttgart Hedelfingen	Baden-Württemberg	BW	81
70327	Stuttgart Untertürkheim	Baden-Württemberg	BW	81
70327	Stuttgart Stuttgart-Ost	Baden-Württemberg	BW	81
70327	Stuttgart Rotenberg	Baden-Württemberg	BW	81
70327	Stuttgart	Baden-Württemberg	BW	81
70329	Stuttgart	Baden-Württemberg	BW	81
70329	Stuttgart Uhlbach	Baden-Württemberg	BW	81
70329	Stuttgart Rohracker	Baden-Württemberg	BW	81
70329	Stuttgart Obertürkheim	Baden-Württemberg	BW	81
70372	Stuttgart Bad Cannstatt	Baden-Württemberg	BW	81
70372	Stuttgart	Baden-Württemberg	BW	81
70374	Stuttgart	Baden-Württemberg	BW	81
70374	Stuttgart Sommerrain	Baden-Württemberg	BW	81
70374	Stuttgart Bad Cannstatt	Baden-Württemberg	BW	81
70376	Stuttgart Münster	Baden-Württemberg	BW	81
70376	Stuttgart Burgholzhof	Baden-Württemberg	BW	81
70376	Stuttgart Bad Cannstatt	Baden-Württemberg	BW	81
70376	Stuttgart	Baden-Württemberg	BW	81
70378	Stuttgart	Baden-Württemberg	BW	81
70435	Stuttgart Zuffenhausen	Baden-Württemberg	BW	81
70435	Stuttgart	Baden-Württemberg	BW	81
70437	Stuttgart	Baden-Württemberg	BW	81
70437	Stuttgart Mönchfeld	Baden-Württemberg	BW	81
70437	Stuttgart Rot	Baden-Württemberg	BW	81
70437	Stuttgart Zazenhausen	Baden-Württemberg	BW	81
70437	Stuttgart Freiberg	Baden-Württemberg	BW	81
70437	Stuttgart Zuffenhausen	Baden-Württemberg	BW	81
70439	Stuttgart Zuffenhausen	Baden-Württemberg	BW	81
70439	Stuttgart Stammheim	Baden-Württemberg	BW	81
70439	Stuttgart Neuwirtshaus	Baden-Württemberg	BW	81
70439	Stuttgart	Baden-Württemberg	BW	81
70469	Stuttgart	Baden-Württemberg	BW	81
70469	Stuttgart Feuerbach	Baden-Württemberg	BW	81
70469	Stuttgart Zuffenhausen	Baden-Württemberg	BW	81
70499	Stuttgart Giebel	Baden-Württemberg	BW	81
70499	Stuttgart Zuffenhausen	Baden-Württemberg	BW	81
70499	Stuttgart Weilimdorf	Baden-Württemberg	BW	81
70499	Stuttgart Wolfbusch	Baden-Württemberg	BW	81
70499	Stuttgart Hausen	Baden-Württemberg	BW	81
70499	Stuttgart Bergheim	Baden-Württemberg	BW	81
70499	Stuttgart	Baden-Württemberg	BW	81
70563	Stuttgart	Baden-Württemberg	BW	81
70563	Stuttgart Vaihingen	Baden-Württemberg	BW	81
70563	Stuttgart Möhringen	Baden-Württemberg	BW	81
70565	Stuttgart Möhringen	Baden-Württemberg	BW	81
70565	Stuttgart Fasanenhof	Baden-Württemberg	BW	81
70565	Stuttgart Dürrlewang	Baden-Württemberg	BW	81
70565	Stuttgart Vaihingen	Baden-Württemberg	BW	81
70565	Stuttgart Rohr	Baden-Württemberg	BW	81
70565	Stuttgart	Baden-Württemberg	BW	81
70567	Stuttgart	Baden-Württemberg	BW	81
70567	Stuttgart Möhringen	Baden-Württemberg	BW	81
70567	Stuttgart Degerloch	Baden-Württemberg	BW	81
70569	Stuttgart Büsnau	Baden-Württemberg	BW	81
70569	Stuttgart Kaltental	Baden-Württemberg	BW	81
70569	Stuttgart Vaihingen	Baden-Württemberg	BW	81
70569	Stuttgart	Baden-Württemberg	BW	81
70597	Stuttgart	Baden-Württemberg	BW	81
70597	Stuttgart Möhringen	Baden-Württemberg	BW	81
70597	Stuttgart Sonnenberg	Baden-Württemberg	BW	81
70597	Stuttgart Kaltental	Baden-Württemberg	BW	81
70597	Stuttgart Hoffeld	Baden-Württemberg	BW	81
70597	Stuttgart Degerloch	Baden-Württemberg	BW	81
70599	Stuttgart Schönberg	Baden-Württemberg	BW	81
70599	Stuttgart Hohenheim	Baden-Württemberg	BW	81
70599	Stuttgart Steckfeld	Baden-Württemberg	BW	81
70599	Stuttgart Asemwald	Baden-Württemberg	BW	81
70599	Stuttgart Plieningen	Baden-Württemberg	BW	81
70599	Stuttgart Birkach	Baden-Württemberg	BW	81
70599	Stuttgart	Baden-Württemberg	BW	81
70619	Stuttgart	Baden-Württemberg	BW	81
70619	Stuttgart Sillenbuch	Baden-Württemberg	BW	81
70619	Stuttgart Heumaden	Baden-Württemberg	BW	81
70619	Stuttgart Riedenberg	Baden-Württemberg	BW	81
70619	Stuttgart Lederberg	Baden-Württemberg	BW	81
70629	Stuttgart Flughafen	Baden-Württemberg	BW	81
70629	Stuttgart	Baden-Württemberg	BW	81
70734	Fellbach	Baden-Württemberg	BW	81
70736	Fellbach	Baden-Württemberg	BW	81
70771	Leinfelden-Echterdingen	Baden-Württemberg	BW	81
70794	Filderstadt	Baden-Württemberg	BW	81
70806	Kornwestheim	Baden-Württemberg	BW	81
70825	Korntal-Münchingen	Baden-Württemberg	BW	81
70839	Gerlingen	Baden-Württemberg	BW	81
71032	Böblingen	Baden-Württemberg	BW	81
71034	Böblingen	Baden-Württemberg	BW	81
71063	Sindelfingen	Baden-Württemberg	BW	81
71065	Sindelfingen	Baden-Württemberg	BW	81
71067	Sindelfingen	Baden-Württemberg	BW	81
71069	Sindelfingen	Baden-Württemberg	BW	81
71083	Herrenberg	Baden-Württemberg	BW	81
71088	Holzgerlingen	Baden-Württemberg	BW	81
71093	Weil im Schönbuch	Baden-Württemberg	BW	81
71101	Schönaich	Baden-Württemberg	BW	81
71111	Waldenbuch	Baden-Württemberg	BW	81
71116	Gärtringen	Baden-Württemberg	BW	81
71120	Grafenau	Baden-Württemberg	BW	81
71126	Gäufelden	Baden-Württemberg	BW	81
71131	Jettingen	Baden-Württemberg	BW	81
71134	Aidlingen	Baden-Württemberg	BW	81
71139	Ehningen	Baden-Württemberg	BW	81
71144	Steinenbronn	Baden-Württemberg	BW	81
71149	Bondorf	Baden-Württemberg	BW	81
71154	Nufringen	Baden-Württemberg	BW	81
71155	Altdorf	Baden-Württemberg	BW	81
71157	Hildrizhausen	Baden-Württemberg	BW	81
71159	Mötzingen	Baden-Württemberg	BW	81
71229	Leonberg	Baden-Württemberg	BW	81
71254	Ditzingen	Baden-Württemberg	BW	81
71263	Weil der Stadt	Baden-Württemberg	BW	81
71272	Renningen	Baden-Württemberg	BW	81
71277	Rutesheim	Baden-Württemberg	BW	81
71282	Hemmingen	Baden-Württemberg	BW	81
71287	Weissach	Baden-Württemberg	BW	81
71332	Waiblingen	Baden-Württemberg	BW	81
71334	Waiblingen	Baden-Württemberg	BW	81
71336	Waiblingen	Baden-Württemberg	BW	81
71364	Winnenden	Baden-Württemberg	BW	81
71384	Weinstadt	Baden-Württemberg	BW	81
71394	Kernen im Remstal	Baden-Württemberg	BW	81
71397	Leutenbach	Baden-Württemberg	BW	81
71404	Korb	Baden-Württemberg	BW	81
71409	Schwaikheim	Baden-Württemberg	BW	81
71522	Backnang	Baden-Württemberg	BW	81
71540	Murrhardt	Baden-Württemberg	BW	81
71543	Wüstenrot	Baden-Württemberg	BW	81
71543	Beilstein	Baden-Württemberg	BW	81
71546	Aspach	Baden-Württemberg	BW	81
71549	Auenwald	Baden-Württemberg	BW	81
71554	Weissach im Tal	Baden-Württemberg	BW	81
71560	Sulzbach an der Murr	Baden-Württemberg	BW	81
71563	Affalterbach	Baden-Württemberg	BW	81
71566	Althütte	Baden-Württemberg	BW	81
71570	Oppenweiler	Baden-Württemberg	BW	81
71573	Allmersbach im Tal	Baden-Württemberg	BW	81
71576	Burgstetten	Baden-Württemberg	BW	81
71577	Großerlach	Baden-Württemberg	BW	81
71579	Spiegelberg	Baden-Württemberg	BW	81
71634	Ludwigsburg	Baden-Württemberg	BW	81
71636	Ludwigsburg	Baden-Württemberg	BW	81
71638	Ludwigsburg	Baden-Württemberg	BW	81
71640	Ludwigsburg	Baden-Württemberg	BW	81
71642	Ludwigsburg	Baden-Württemberg	BW	81
71665	Vaihingen an der Enz	Baden-Württemberg	BW	81
71672	Marbach am Neckar	Baden-Württemberg	BW	81
71679	Asperg	Baden-Württemberg	BW	81
71686	Remseck am Neckar	Baden-Württemberg	BW	81
71691	Freiberg am Neckar	Baden-Württemberg	BW	81
71696	Möglingen	Baden-Württemberg	BW	81
71701	Schwieberdingen	Baden-Württemberg	BW	81
71706	Markgröningen	Baden-Württemberg	BW	81
71711	Murr	Baden-Württemberg	BW	81
71711	Steinheim an der Murr	Baden-Württemberg	BW	81
71717	Beilstein	Baden-Württemberg	BW	81
71718	Billensbach	Baden-Württemberg	BW	81
71720	Oberstenfeld	Baden-Württemberg	BW	81
71723	Großbottwar	Baden-Württemberg	BW	81
71726	Benningen am Neckar	Baden-Württemberg	BW	81
71729	Erdmannhausen	Baden-Württemberg	BW	81
71732	Tamm	Baden-Württemberg	BW	81
71735	Eberdingen	Baden-Württemberg	BW	81
71737	Kirchberg an der Murr	Baden-Württemberg	BW	81
71739	Oberriexingen	Baden-Württemberg	BW	81
72622	Nürtingen	Baden-Württemberg	BW	81
72631	Aichtal	Baden-Württemberg	BW	81
72636	Frickenhausen	Baden-Württemberg	BW	81
72639	Neuffen	Baden-Württemberg	BW	81
72644	Oberboihingen	Baden-Württemberg	BW	81
72649	Wolfschlugen	Baden-Württemberg	BW	81
72654	Neckartenzlingen	Baden-Württemberg	BW	81
72655	Altdorf	Baden-Württemberg	BW	81
72657	Altenriet	Baden-Württemberg	BW	81
72658	Bempflingen	Baden-Württemberg	BW	81
72660	Beuren	Baden-Württemberg	BW	81
72663	Großbettlingen	Baden-Württemberg	BW	81
72664	Kohlberg	Baden-Württemberg	BW	81
72666	Neckartailfingen	Baden-Württemberg	BW	81
72667	Schlaitdorf	Baden-Württemberg	BW	81
72669	Unterensingen	Baden-Württemberg	BW	81
73033	Göppingen	Baden-Württemberg	BW	81
73035	Göppingen	Baden-Württemberg	BW	81
73037	Göppingen	Baden-Württemberg	BW	81
73054	Eislingen/Fils	Baden-Württemberg	BW	81
73061	Ebersbach an der Fils	Baden-Württemberg	BW	81
73066	Uhingen	Baden-Württemberg	BW	81
73072	Donzdorf	Baden-Württemberg	BW	81
73079	Süßen	Baden-Württemberg	BW	81
73084	Salach	Baden-Württemberg	BW	81
73087	Boll	Baden-Württemberg	BW	81
73092	Heiningen	Baden-Württemberg	BW	81
73095	Albershausen	Baden-Württemberg	BW	81
73098	Rechberghausen	Baden-Württemberg	BW	81
73099	Adelberg	Baden-Württemberg	BW	81
73101	Aichelberg	Baden-Württemberg	BW	81
73102	Birenbach	Baden-Württemberg	BW	81
73104	Börtlingen	Baden-Württemberg	BW	81
73105	Dürnau	Baden-Württemberg	BW	81
73107	Eschenbach	Baden-Württemberg	BW	81
73108	Gammelshausen	Baden-Württemberg	BW	81
73110	Hattenhofen	Baden-Württemberg	BW	81
73111	Lauterstein	Baden-Württemberg	BW	81
73113	Ottenbach	Baden-Württemberg	BW	81
73114	Schlat	Baden-Württemberg	BW	81
73116	Wäschenbeuren	Baden-Württemberg	BW	81
73117	Wangen	Baden-Württemberg	BW	81
73119	Zell unter Aichelberg	Baden-Württemberg	BW	81
73207	Plochingen	Baden-Württemberg	BW	81
73230	Kirchheim unter Teck	Baden-Württemberg	BW	81
73235	Weilheim an der Teck	Baden-Württemberg	BW	81
73240	Wendlingen am Neckar	Baden-Württemberg	BW	81
73249	Wernau	Baden-Württemberg	BW	81
73252	Lenningen	Baden-Württemberg	BW	81
73257	Köngen	Baden-Württemberg	BW	81
73262	Reichenbach an der Fils	Baden-Württemberg	BW	81
73265	Dettingen unter Teck	Baden-Württemberg	BW	81
73266	Bissingen an der Teck	Baden-Württemberg	BW	81
73268	Erkenbrechtsweiler	Baden-Württemberg	BW	81
73269	Hochdorf	Baden-Württemberg	BW	81
73271	Holzmaden	Baden-Württemberg	BW	81
73272	Neidlingen	Baden-Württemberg	BW	81
73274	Notzingen	Baden-Württemberg	BW	81
73275	Ohmden	Baden-Württemberg	BW	81
73277	Owen	Baden-Württemberg	BW	81
73278	Schlierbach	Baden-Württemberg	BW	81
73312	Geislingen an der Steige	Baden-Württemberg	BW	81
73312	Geislingen an der Steige Aufhausen	Baden-Württemberg	BW	81
73312	Geislingen an der Steige Türkheim	Baden-Württemberg	BW	81
73326	Deggingen	Baden-Württemberg	BW	81
73329	Kuchen	Baden-Württemberg	BW	81
73333	Gingen an der Fils	Baden-Württemberg	BW	81
73337	Bad Überkingen	Baden-Württemberg	BW	81
73342	Bad Ditzenbach	Baden-Württemberg	BW	81
73344	Gruibingen	Baden-Württemberg	BW	81
73345	Drackenstein	Baden-Württemberg	BW	81
73345	Hohenstadt	Baden-Württemberg	BW	81
73347	Mühlhausen im Täle	Baden-Württemberg	BW	81
73349	Wiesensteig	Baden-Württemberg	BW	81
73430	Aalen	Baden-Württemberg	BW	81
73431	Aalen	Baden-Württemberg	BW	81
73432	Aalen	Baden-Württemberg	BW	81
73433	Aalen	Baden-Württemberg	BW	81
73434	Aalen	Baden-Württemberg	BW	81
73441	Bopfingen	Baden-Württemberg	BW	81
73447	Oberkochen	Baden-Württemberg	BW	81
73450	Neresheim	Baden-Württemberg	BW	81
73453	Abtsgmünd	Baden-Württemberg	BW	81
73457	Essingen	Baden-Württemberg	BW	81
73460	Hüttlingen	Baden-Württemberg	BW	81
73463	Westhausen	Baden-Württemberg	BW	81
73466	Lauchheim	Baden-Württemberg	BW	81
73467	Kirchheim am Ries	Baden-Württemberg	BW	81
73469	Riesbürg	Baden-Württemberg	BW	81
73479	Ellwangen (Jagst)	Baden-Württemberg	BW	81
73485	Unterschneidheim	Baden-Württemberg	BW	81
73486	Adelmannsfelden	Baden-Württemberg	BW	81
73488	Ellenberg	Baden-Württemberg	BW	81
73489	Jagstzell	Baden-Württemberg	BW	81
73491	Neuler	Baden-Württemberg	BW	81
73492	Rainau	Baden-Württemberg	BW	81
73494	Rosenberg	Baden-Württemberg	BW	81
73495	Stödtlen	Baden-Württemberg	BW	81
73497	Tannhausen	Baden-Württemberg	BW	81
73499	Wört	Baden-Württemberg	BW	81
73525	Schwäbisch Gmünd	Baden-Württemberg	BW	81
73527	Schwäbisch Gmünd	Baden-Württemberg	BW	81
73527	Täferrot	Baden-Württemberg	BW	81
73529	Schwäbisch Gmünd	Baden-Württemberg	BW	81
73540	Heubach	Baden-Württemberg	BW	81
73547	Lorch	Baden-Württemberg	BW	81
73550	Waldstetten	Baden-Württemberg	BW	81
73553	Alfdorf	Baden-Württemberg	BW	81
73557	Mutlangen	Baden-Württemberg	BW	81
73560	Böbingen an der Rems	Baden-Württemberg	BW	81
73563	Mögglingen	Baden-Württemberg	BW	81
73565	Spraitbach	Baden-Württemberg	BW	81
73566	Bartholomä	Baden-Württemberg	BW	81
73568	Durlangen	Baden-Württemberg	BW	81
73569	Eschach	Baden-Württemberg	BW	81
73569	Obergröningen	Baden-Württemberg	BW	81
73571	Göggingen	Baden-Württemberg	BW	81
73572	Heuchlingen	Baden-Württemberg	BW	81
73574	Iggingen	Baden-Württemberg	BW	81
73575	Leinzell	Baden-Württemberg	BW	81
73577	Ruppertshofen	Baden-Württemberg	BW	81
73579	Schechingen	Baden-Württemberg	BW	81
73614	Schorndorf	Baden-Württemberg	BW	81
73630	Remshalden	Baden-Württemberg	BW	81
73635	Rudersberg	Baden-Württemberg	BW	81
73642	Welzheim	Baden-Württemberg	BW	81
73650	Winterbach	Baden-Württemberg	BW	81
73655	Plüderhausen	Baden-Württemberg	BW	81
73660	Urbach	Baden-Württemberg	BW	81
73663	Berglen	Baden-Württemberg	BW	81
73666	Baltmannsweiler	Baden-Württemberg	BW	81
73667	Kaisersbach	Baden-Württemberg	BW	81
73669	Lichtenwald	Baden-Württemberg	BW	81
73728	Esslingen am Neckar	Baden-Württemberg	BW	81
73730	Esslingen am Neckar	Baden-Württemberg	BW	81
73732	Esslingen am Neckar	Baden-Württemberg	BW	81
73733	Esslingen am Neckar	Baden-Württemberg	BW	81
73734	Esslingen am Neckar	Baden-Württemberg	BW	81
73760	Ostfildern	Baden-Württemberg	BW	81
73765	Neuhausen auf den Fildern	Baden-Württemberg	BW	81
73770	Denkendorf	Baden-Württemberg	BW	81
73773	Aichwald	Baden-Württemberg	BW	81
73776	Altbach	Baden-Württemberg	BW	81
73779	Deizisau	Baden-Württemberg	BW	81
74072	Heilbronn	Baden-Württemberg	BW	81
74074	Heilbronn	Baden-Württemberg	BW	81
74076	Heilbronn	Baden-Württemberg	BW	81
74078	Heilbronn	Baden-Württemberg	BW	81
74080	Heilbronn	Baden-Württemberg	BW	81
74081	Heilbronn	Baden-Württemberg	BW	81
74172	Neckarsulm	Baden-Württemberg	BW	81
74177	Bad Friedrichshall	Baden-Württemberg	BW	81
74182	Obersulm	Baden-Württemberg	BW	81
74189	Weinsberg	Baden-Württemberg	BW	81
74193	Schwaigern	Baden-Württemberg	BW	81
74196	Neuenstadt am Kocher	Baden-Württemberg	BW	81
74199	Untergruppenbach	Baden-Württemberg	BW	81
74206	Bad Wimpfen	Baden-Württemberg	BW	81
74211	Leingarten	Baden-Württemberg	BW	81
74214	Schöntal	Baden-Württemberg	BW	81
74219	Möckmühl	Baden-Württemberg	BW	81
74223	Flein	Baden-Württemberg	BW	81
74226	Nordheim	Baden-Württemberg	BW	81
74229	Oedheim	Baden-Württemberg	BW	81
74232	Abstatt	Baden-Württemberg	BW	81
74235	Erlenbach	Baden-Württemberg	BW	81
74238	Krautheim	Baden-Württemberg	BW	81
74239	Hardthausen am Kocher	Baden-Württemberg	BW	81
74243	Langenbrettach	Baden-Württemberg	BW	81
74245	Löwenstein	Baden-Württemberg	BW	81
74246	Eberstadt	Baden-Württemberg	BW	81
74248	Ellhofen	Baden-Württemberg	BW	81
74249	Jagsthausen	Baden-Württemberg	BW	81
74251	Lehrensteinsfeld	Baden-Württemberg	BW	81
74252	Massenbachhausen	Baden-Württemberg	BW	81
74254	Offenau	Baden-Württemberg	BW	81
74255	Roigheim	Baden-Württemberg	BW	81
74257	Untereisesheim	Baden-Württemberg	BW	81
74259	Widdern	Baden-Württemberg	BW	81
74321	Bietigheim-Bissingen	Baden-Württemberg	BW	81
74336	Brackenheim	Baden-Württemberg	BW	81
74337	Botenheim	Baden-Württemberg	BW	81
74343	Sachsenheim	Baden-Württemberg	BW	81
74348	Lauffen am Neckar	Baden-Württemberg	BW	81
74354	Besigheim	Baden-Württemberg	BW	81
74357	Bönnigheim	Baden-Württemberg	BW	81
74360	Ilsfeld	Baden-Württemberg	BW	81
74363	Güglingen	Baden-Württemberg	BW	81
74366	Kirchheim am Neckar	Baden-Württemberg	BW	81
74369	Löchgau	Baden-Württemberg	BW	81
74372	Sersheim	Baden-Württemberg	BW	81
74374	Zaberfeld	Baden-Württemberg	BW	81
74376	Gemmrigheim	Baden-Württemberg	BW	81
74379	Ingersheim	Baden-Württemberg	BW	81
74382	Neckarwestheim	Baden-Württemberg	BW	81
74385	Pleidelsheim	Baden-Württemberg	BW	81
74388	Talheim	Baden-Württemberg	BW	81
74389	Cleebronn	Baden-Württemberg	BW	81
74391	Erligheim	Baden-Württemberg	BW	81
74392	Freudental	Baden-Württemberg	BW	81
74394	Hessigheim	Baden-Württemberg	BW	81
74395	Mundelsheim	Baden-Württemberg	BW	81
74397	Pfaffenhofen	Baden-Württemberg	BW	81
74399	Walheim	Baden-Württemberg	BW	81
74405	Gaildorf	Baden-Württemberg	BW	81
74417	Gschwend	Baden-Württemberg	BW	81
74420	Oberrot	Baden-Württemberg	BW	81
74423	Obersontheim	Baden-Württemberg	BW	81
74424	Bühlertann	Baden-Württemberg	BW	81
74426	Bühlerzell	Baden-Württemberg	BW	81
74427	Fichtenberg	Baden-Württemberg	BW	81
74429	Sulzbach-Laufen	Baden-Württemberg	BW	81
74523	Schwäbisch Hall	Baden-Württemberg	BW	81
74532	Ilshofen	Baden-Württemberg	BW	81
74535	Mainhardt	Baden-Württemberg	BW	81
74538	Rosengarten	Baden-Württemberg	BW	81
74541	Vellberg	Baden-Württemberg	BW	81
74542	Braunsbach	Baden-Württemberg	BW	81
74544	Michelbach an der Bilz	Baden-Württemberg	BW	81
74545	Michelfeld	Baden-Württemberg	BW	81
74547	Untermünkheim	Baden-Württemberg	BW	81
74549	Wolpertshausen	Baden-Württemberg	BW	81
74564	Crailsheim	Baden-Württemberg	BW	81
74572	Blaufelden	Baden-Württemberg	BW	81
74575	Schrozberg	Baden-Württemberg	BW	81
74579	Fichtenau	Baden-Württemberg	BW	81
74582	Gerabronn	Baden-Württemberg	BW	81
74585	Rot am See	Baden-Württemberg	BW	81
74586	Frankenhardt	Baden-Württemberg	BW	81
74589	Satteldorf	Baden-Württemberg	BW	81
74592	Kirchberg an der Jagst	Baden-Württemberg	BW	81
74594	Kreßberg	Baden-Württemberg	BW	81
74595	Langenburg	Baden-Württemberg	BW	81
74597	Stimpfach	Baden-Württemberg	BW	81
74599	Wallhausen	Baden-Württemberg	BW	81
74613	Öhringen	Baden-Württemberg	BW	81
74626	Bretzfeld	Baden-Württemberg	BW	81
74629	Pfedelbach	Baden-Württemberg	BW	81
74632	Neuenstein	Baden-Württemberg	BW	81
74635	Kupferzell	Baden-Württemberg	BW	81
74638	Waldenburg	Baden-Württemberg	BW	81
74639	Zweiflingen	Baden-Württemberg	BW	81
74653	Künzelsau	Baden-Württemberg	BW	81
74653	Ingelfingen	Baden-Württemberg	BW	81
74670	Forchtenberg	Baden-Württemberg	BW	81
74673	Mulfingen	Baden-Württemberg	BW	81
74676	Niedernhall	Baden-Württemberg	BW	81
74677	Dörzbach	Baden-Württemberg	BW	81
74679	Weißbach	Baden-Württemberg	BW	81
74744	Ahorn	Baden-Württemberg	BW	81
74831	Gundelsheim	Baden-Württemberg	BW	81
74832	Bachenau	Baden-Württemberg	BW	81
74861	Neudenau	Baden-Württemberg	BW	81
74906	Bad Rappenau	Baden-Württemberg	BW	81
74912	Kirchardt	Baden-Württemberg	BW	81
74930	Ittlingen	Baden-Württemberg	BW	81
74936	Siegelsbach	Baden-Württemberg	BW	81
75031	Eppingen	Baden-Württemberg	BW	81
75050	Gemmingen	Baden-Württemberg	BW	81
75392	Deckenpfronn	Baden-Württemberg	BW	81
89168	Niederstotzingen	Baden-Württemberg	BW	81
89518	Heidenheim an der Brenz	Baden-Württemberg	BW	81
89520	Heidenheim an der Brenz	Baden-Württemberg	BW	81
89522	Heidenheim an der Brenz	Baden-Württemberg	BW	81
89537	Giengen an der Brenz	Baden-Württemberg	BW	81
89542	Herbrechtingen	Baden-Württemberg	BW	81
89547	Gerstetten	Baden-Württemberg	BW	81
89551	Königsbronn	Baden-Württemberg	BW	81
89555	Steinheim am Albuch	Baden-Württemberg	BW	81
89558	Böhmenkirch	Baden-Württemberg	BW	81
89561	Dischingen	Baden-Württemberg	BW	81
89564	Nattheim	Baden-Württemberg	BW	81
89567	Sontheim an der Brenz	Baden-Württemberg	BW	81
89568	Hermaringen	Baden-Württemberg	BW	81
97877	Wertheim	Baden-Württemberg	BW	81
97896	Freudenberg	Baden-Württemberg	BW	81
97900	Külsheim	Baden-Württemberg	BW	81
97922	Lauda-Königshofen	Baden-Württemberg	BW	81
97941	Tauberbischofsheim	Baden-Württemberg	BW	81
97944	Boxberg	Baden-Württemberg	BW	81
97947	Grünsfeld	Baden-Württemberg	BW	81
97950	Großrinderfeld	Baden-Württemberg	BW	81
97953	Königheim	Baden-Württemberg	BW	81
97956	Werbach	Baden-Württemberg	BW	81
97957	Wittighausen	Baden-Württemberg	BW	81
97959	Assamstadt	Baden-Württemberg	BW	81
97980	Bad Mergentheim	Baden-Württemberg	BW	81
97990	Weikersheim	Baden-Württemberg	BW	81
97993	Creglingen	Baden-Württemberg	BW	81
97996	Niederstetten	Baden-Württemberg	BW	81
97999	Igersheim	Baden-Württemberg	BW	81
68159	Mannheim	Baden-Württemberg	BW	82
68161	Mannheim	Baden-Württemberg	BW	82
68163	Mannheim	Baden-Württemberg	BW	82
68165	Mannheim	Baden-Württemberg	BW	82
68167	Mannheim	Baden-Württemberg	BW	82
68169	Mannheim	Baden-Württemberg	BW	82
68199	Mannheim	Baden-Württemberg	BW	82
68219	Mannheim	Baden-Württemberg	BW	82
68229	Mannheim	Baden-Württemberg	BW	82
68239	Mannheim	Baden-Württemberg	BW	82
68259	Mannheim	Baden-Württemberg	BW	82
68305	Mannheim	Baden-Württemberg	BW	82
68307	Mannheim	Baden-Württemberg	BW	82
68309	Mannheim	Baden-Württemberg	BW	82
68526	Ladenburg	Baden-Württemberg	BW	82
68535	Edingen-Neckarhausen	Baden-Württemberg	BW	82
68542	Heddesheim	Baden-Württemberg	BW	82
68549	Ilvesheim	Baden-Württemberg	BW	82
68723	Plankstadt	Baden-Württemberg	BW	82
68723	Schwetzingen	Baden-Württemberg	BW	82
68723	Oftersheim	Baden-Württemberg	BW	82
68753	Waghäusel	Baden-Württemberg	BW	82
68766	Hockenheim	Baden-Württemberg	BW	82
68775	Ketsch	Baden-Württemberg	BW	82
68782	Brühl	Baden-Württemberg	BW	82
68789	Sankt Leon-Rot	Baden-Württemberg	BW	82
68794	Oberhausen-Rheinhausen	Baden-Württemberg	BW	82
68799	Reilingen	Baden-Württemberg	BW	82
68804	Altlußheim	Baden-Württemberg	BW	82
68809	Neulußheim	Baden-Württemberg	BW	82
69115	Heidelberg	Baden-Württemberg	BW	82
69117	Heidelberg	Baden-Württemberg	BW	82
69118	Heidelberg	Baden-Württemberg	BW	82
69120	Heidelberg	Baden-Württemberg	BW	82
69121	Heidelberg	Baden-Württemberg	BW	82
69123	Heidelberg	Baden-Württemberg	BW	82
69124	Heidelberg	Baden-Württemberg	BW	82
69126	Heidelberg	Baden-Württemberg	BW	82
69151	Neckargemünd	Baden-Württemberg	BW	82
69168	Wiesloch	Baden-Württemberg	BW	82
69181	Leimen	Baden-Württemberg	BW	82
69190	Walldorf	Baden-Württemberg	BW	82
69198	Schriesheim	Baden-Württemberg	BW	82
69207	Sandhausen	Baden-Württemberg	BW	82
69214	Eppelheim	Baden-Württemberg	BW	82
69221	Dossenheim	Baden-Württemberg	BW	82
69226	Nußloch	Baden-Württemberg	BW	82
69231	Rauenberg	Baden-Württemberg	BW	82
69234	Dielheim	Baden-Württemberg	BW	82
69242	Mühlhausen	Baden-Württemberg	BW	82
69245	Bammental	Baden-Württemberg	BW	82
69250	Schönau	Baden-Württemberg	BW	82
69251	Gaiberg	Baden-Württemberg	BW	82
69253	Heiligkreuzsteinach	Baden-Württemberg	BW	82
69254	Malsch	Baden-Württemberg	BW	82
69256	Mauer	Baden-Württemberg	BW	82
69257	Wiesenbach	Baden-Württemberg	BW	82
69259	Wilhelmsfeld	Baden-Württemberg	BW	82
69412	Eberbach	Baden-Württemberg	BW	82
69427	Mudau	Baden-Württemberg	BW	82
69429	Waldbrunn	Baden-Württemberg	BW	82
69434	Heddesbach	Baden-Württemberg	BW	82
69436	Schönbrunn	Baden-Württemberg	BW	82
69437	Neckargerach	Baden-Württemberg	BW	82
69439	Zwingenberg	Baden-Württemberg	BW	82
69469	Weinheim	Baden-Württemberg	BW	82
69493	Hirschberg an der Bergstraße	Baden-Württemberg	BW	82
69502	Hemsbach	Baden-Württemberg	BW	82
69514	Laudenbach	Baden-Württemberg	BW	82
71292	Friolzheim	Baden-Württemberg	BW	82
71296	Heimsheim	Baden-Württemberg	BW	82
71297	Mönsheim	Baden-Württemberg	BW	82
71299	Wimsheim	Baden-Württemberg	BW	82
72160	Horb am Neckar	Baden-Württemberg	BW	82
72178	Waldachtal	Baden-Württemberg	BW	82
72184	Eutingen im Gäu	Baden-Württemberg	BW	82
72186	Empfingen	Baden-Württemberg	BW	82
72202	Nagold	Baden-Württemberg	BW	82
72213	Altensteig	Baden-Württemberg	BW	82
72218	Wildberg	Baden-Württemberg	BW	82
72221	Haiterbach	Baden-Württemberg	BW	82
72224	Ebhausen	Baden-Württemberg	BW	82
72226	Simmersfeld	Baden-Württemberg	BW	82
72227	Egenhausen	Baden-Württemberg	BW	82
72229	Rohrdorf	Baden-Württemberg	BW	82
72250	Freudenstadt	Baden-Württemberg	BW	82
72270	Baiersbronn	Baden-Württemberg	BW	82
72275	Alpirsbach	Baden-Württemberg	BW	82
72280	Dornstetten	Baden-Württemberg	BW	82
72285	Pfalzgrafenweiler	Baden-Württemberg	BW	82
72290	Loßburg	Baden-Württemberg	BW	82
72291	Betzweiler-Wälde	Baden-Württemberg	BW	82
72293	Glatten	Baden-Württemberg	BW	82
72294	Grömbach	Baden-Württemberg	BW	82
72296	Schopfloch	Baden-Württemberg	BW	82
72297	Seewald	Baden-Württemberg	BW	82
72299	Wörnersberg	Baden-Württemberg	BW	82
74706	Osterburken	Baden-Württemberg	BW	82
74722	Buchen (Odenwald)	Baden-Württemberg	BW	82
74731	Walldürn	Baden-Württemberg	BW	82
74736	Hardheim	Baden-Württemberg	BW	82
74740	Adelsheim	Baden-Württemberg	BW	82
74743	Seckach	Baden-Württemberg	BW	82
74746	Höpfingen	Baden-Württemberg	BW	82
74747	Ravenstein	Baden-Württemberg	BW	82
74749	Rosenberg	Baden-Württemberg	BW	82
74821	Mosbach	Baden-Württemberg	BW	82
74834	Elztal	Baden-Württemberg	BW	82
74838	Limbach	Baden-Württemberg	BW	82
74842	Billigheim	Baden-Württemberg	BW	82
74847	Obrigheim	Baden-Württemberg	BW	82
74850	Schefflenz	Baden-Württemberg	BW	82
74855	Haßmersheim	Baden-Württemberg	BW	82
74858	Aglasterhausen	Baden-Württemberg	BW	82
74862	Binau	Baden-Württemberg	BW	82
74864	Fahrenbach	Baden-Württemberg	BW	82
74865	Neckarzimmern	Baden-Württemberg	BW	82
74867	Neunkirchen	Baden-Württemberg	BW	82
74869	Schwarzach	Baden-Württemberg	BW	82
74889	Sinsheim	Baden-Württemberg	BW	82
74909	Meckesheim	Baden-Württemberg	BW	82
74915	Waibstadt	Baden-Württemberg	BW	82
74918	Angelbachtal	Baden-Württemberg	BW	82
74921	Helmstadt-Bargen	Baden-Württemberg	BW	82
74924	Neckarbischofsheim	Baden-Württemberg	BW	82
74925	Epfenbach	Baden-Württemberg	BW	82
74927	Eschelbronn	Baden-Württemberg	BW	82
74928	Hüffenhardt	Baden-Württemberg	BW	82
74931	Lobbach	Baden-Württemberg	BW	82
74933	Neidenstein	Baden-Württemberg	BW	82
74934	Reichartshausen	Baden-Württemberg	BW	82
74937	Spechbach	Baden-Württemberg	BW	82
74939	Zuzenhausen	Baden-Württemberg	BW	82
75015	Bretten	Baden-Württemberg	BW	82
75038	Oberderdingen	Baden-Württemberg	BW	82
75045	Walzbachtal	Baden-Württemberg	BW	82
75053	Gondelsheim	Baden-Württemberg	BW	82
75056	Sulzfeld	Baden-Württemberg	BW	82
75057	Kürnbach	Baden-Württemberg	BW	82
75059	Zaisenhausen	Baden-Württemberg	BW	82
75172	Pforzheim	Baden-Württemberg	BW	82
75173	Pforzheim	Baden-Württemberg	BW	82
75175	Pforzheim	Baden-Württemberg	BW	82
75177	Pforzheim	Baden-Württemberg	BW	82
75179	Pforzheim	Baden-Württemberg	BW	82
75180	Pforzheim	Baden-Württemberg	BW	82
75181	Pforzheim	Baden-Württemberg	BW	82
75196	Remchingen	Baden-Württemberg	BW	82
75203	Königsbach-Stein	Baden-Württemberg	BW	82
75210	Keltern	Baden-Württemberg	BW	82
75217	Birkenfeld	Baden-Württemberg	BW	82
75223	Niefern-Öschelbronn	Baden-Württemberg	BW	82
75228	Ispringen	Baden-Württemberg	BW	82
75233	Tiefenbronn	Baden-Württemberg	BW	82
75236	Kämpfelbach	Baden-Württemberg	BW	82
75239	Eisingen	Baden-Württemberg	BW	82
75242	Neuhausen	Baden-Württemberg	BW	82
75245	Neulingen	Baden-Württemberg	BW	82
75248	Ölbronn-Dürrn	Baden-Württemberg	BW	82
75249	Kieselbronn	Baden-Württemberg	BW	82
75305	Neuenbürg	Baden-Württemberg	BW	82
75323	Bad Wildbad im Schwarzwald	Baden-Württemberg	BW	82
75328	Schömberg	Baden-Württemberg	BW	82
75331	Engelsbrand	Baden-Württemberg	BW	82
75334	Straubenhardt	Baden-Württemberg	BW	82
75335	Dobel	Baden-Württemberg	BW	82
75337	Enzklösterle	Baden-Württemberg	BW	82
75339	Höfen an der Enz	Baden-Württemberg	BW	82
75365	Calw	Baden-Württemberg	BW	82
75378	Bad Liebenzell	Baden-Württemberg	BW	82
75382	Althengstett	Baden-Württemberg	BW	82
75385	Bad Teinach-Zavelstein	Baden-Württemberg	BW	82
75387	Neubulach	Baden-Württemberg	BW	82
75389	Neuweiler	Baden-Württemberg	BW	82
75391	Gechingen	Baden-Württemberg	BW	82
75394	Oberreichenbach	Baden-Württemberg	BW	82
75395	Ostelsheim	Baden-Württemberg	BW	82
75397	Simmozheim	Baden-Württemberg	BW	82
75399	Unterreichenbach	Baden-Württemberg	BW	82
75417	Mühlacker	Baden-Württemberg	BW	82
75428	Illingen	Baden-Württemberg	BW	82
75433	Maulbronn	Baden-Württemberg	BW	82
75438	Knittlingen	Baden-Württemberg	BW	82
75443	Ötisheim	Baden-Württemberg	BW	82
75446	Wiernsheim	Baden-Württemberg	BW	82
75447	Sternenfels	Baden-Württemberg	BW	82
75449	Wurmberg	Baden-Württemberg	BW	82
76006	Karlsruhe	Baden-Württemberg	BW	82
76131	Karlsruhe	Baden-Württemberg	BW	82
76133	Karlsruhe	Baden-Württemberg	BW	82
76135	Karlsruhe	Baden-Württemberg	BW	82
76137	Karlsruhe	Baden-Württemberg	BW	82
76139	Karlsruhe	Baden-Württemberg	BW	82
76149	Karlsruhe	Baden-Württemberg	BW	82
76185	Karlsruhe	Baden-Württemberg	BW	82
76187	Karlsruhe	Baden-Württemberg	BW	82
76189	Karlsruhe	Baden-Württemberg	BW	82
76199	Karlsruhe	Baden-Württemberg	BW	82
76227	Karlsruhe	Baden-Württemberg	BW	82
76228	Karlsruhe	Baden-Württemberg	BW	82
76229	Karlsruhe	Baden-Württemberg	BW	82
76275	Ettlingen	Baden-Württemberg	BW	82
76287	Rheinstetten	Baden-Württemberg	BW	82
76297	Stutensee	Baden-Württemberg	BW	82
76307	Karlsbad	Baden-Württemberg	BW	82
76316	Malsch	Baden-Württemberg	BW	82
76327	Pfinztal	Baden-Württemberg	BW	82
76332	Bad Herrenalb	Baden-Württemberg	BW	82
76337	Waldbronn	Baden-Württemberg	BW	82
76344	Eggenstein-Leopoldshafen	Baden-Württemberg	BW	82
76351	Linkenheim-Hochstetten	Baden-Württemberg	BW	82
76356	Weingarten	Baden-Württemberg	BW	82
76359	Marxzell	Baden-Württemberg	BW	82
76437	Rastatt	Baden-Württemberg	BW	82
76448	Durmersheim	Baden-Württemberg	BW	82
76456	Kuppenheim	Baden-Württemberg	BW	82
76461	Muggensturm	Baden-Württemberg	BW	82
76467	Bietigheim	Baden-Württemberg	BW	82
76470	Ötigheim	Baden-Württemberg	BW	82
76473	Iffezheim	Baden-Württemberg	BW	82
76474	Au am Rhein	Baden-Württemberg	BW	82
76476	Bischweier	Baden-Württemberg	BW	82
76477	Elchesheim-Illingen	Baden-Württemberg	BW	82
76479	Steinmauern	Baden-Württemberg	BW	82
76530	Baden-Baden	Baden-Württemberg	BW	82
76532	Baden-Baden	Baden-Württemberg	BW	82
76534	Baden-Baden	Baden-Württemberg	BW	82
76547	Sinzheim	Baden-Württemberg	BW	82
76549	Hügelsheim	Baden-Württemberg	BW	82
76571	Gaggenau	Baden-Württemberg	BW	82
76593	Gernsbach	Baden-Württemberg	BW	82
76596	Forbach	Baden-Württemberg	BW	82
76597	Loffenau	Baden-Württemberg	BW	82
76599	Weisenbach	Baden-Württemberg	BW	82
76646	Bruchsal	Baden-Württemberg	BW	82
76661	Philippsburg	Baden-Württemberg	BW	82
76669	Bad Schönborn	Baden-Württemberg	BW	82
76676	Graben-Neudorf	Baden-Württemberg	BW	82
76684	Östringen	Baden-Württemberg	BW	82
76689	Karlsdorf-Neuthard	Baden-Württemberg	BW	82
76694	Forst	Baden-Württemberg	BW	82
76698	Ubstadt-Weiher	Baden-Württemberg	BW	82
76703	Kraichtal	Baden-Württemberg	BW	82
76706	Dettenheim	Baden-Württemberg	BW	82
76707	Hambrücken	Baden-Württemberg	BW	82
76709	Kronau	Baden-Württemberg	BW	82
77776	Bad Rippoldsau-Schapbach	Baden-Württemberg	BW	82
77815	Bühl	Baden-Württemberg	BW	82
77830	Bühlertal	Baden-Württemberg	BW	82
77833	Ottersweier	Baden-Württemberg	BW	82
77836	Rheinmünster	Baden-Württemberg	BW	82
77839	Lichtenau	Baden-Württemberg	BW	82
72172	Sulz am Neckar	Baden-Württemberg	BW	83
72175	Dornhan	Baden-Württemberg	BW	83
72189	Vöhringen	Baden-Württemberg	BW	83
77652	Offenburg	Baden-Württemberg	BW	83
77654	Offenburg	Baden-Württemberg	BW	83
77656	Offenburg	Baden-Württemberg	BW	83
77694	Kehl	Baden-Württemberg	BW	83
77704	Oberkirch	Baden-Württemberg	BW	83
77709	Wolfach	Baden-Württemberg	BW	83
77709	Oberwolfach	Baden-Württemberg	BW	83
77716	Hofstetten	Baden-Württemberg	BW	83
77716	Haslach im Kinzigtal	Baden-Württemberg	BW	83
77716	Fischerbach	Baden-Württemberg	BW	83
77723	Gengenbach	Baden-Württemberg	BW	83
77728	Oppenau	Baden-Württemberg	BW	83
77731	Willstätt	Baden-Württemberg	BW	83
77736	Zell am Harmersbach	Baden-Württemberg	BW	83
77740	Bad Peterstal-Griesbach	Baden-Württemberg	BW	83
77743	Neuried	Baden-Württemberg	BW	83
77746	Schutterwald	Baden-Württemberg	BW	83
77749	Hohberg	Baden-Württemberg	BW	83
77756	Hausach	Baden-Württemberg	BW	83
77761	Schiltach	Baden-Württemberg	BW	83
77767	Appenweier	Baden-Württemberg	BW	83
77770	Durbach	Baden-Württemberg	BW	83
77773	Schenkenzell	Baden-Württemberg	BW	83
77781	Biberach	Baden-Württemberg	BW	83
77784	Oberharmersbach	Baden-Württemberg	BW	83
77787	Nordrach	Baden-Württemberg	BW	83
77790	Steinach	Baden-Württemberg	BW	83
77791	Berghaupten	Baden-Württemberg	BW	83
77793	Gutach (Schwarzwaldbahn)	Baden-Württemberg	BW	83
77794	Lautenbach	Baden-Württemberg	BW	83
77796	Mühlenbach	Baden-Württemberg	BW	83
77797	Ohlsbach	Baden-Württemberg	BW	83
77799	Ortenberg	Baden-Württemberg	BW	83
77855	Achern	Baden-Württemberg	BW	83
77866	Rheinau	Baden-Württemberg	BW	83
77871	Renchen	Baden-Württemberg	BW	83
77876	Kappelrodeck	Baden-Württemberg	BW	83
77880	Sasbach	Baden-Württemberg	BW	83
77883	Ottenhöfen im Schwarzwald	Baden-Württemberg	BW	83
77886	Lauf	Baden-Württemberg	BW	83
77887	Sasbachwalden	Baden-Württemberg	BW	83
77889	Seebach	Baden-Württemberg	BW	83
77933	Lahr/Schwarzwald	Baden-Württemberg	BW	83
77944	Friesenheim	Baden-Württemberg	BW	83
77948	Friesenheim	Baden-Württemberg	BW	83
77955	Ettenheim	Baden-Württemberg	BW	83
77960	Seelbach	Baden-Württemberg	BW	83
77963	Schwanau	Baden-Württemberg	BW	83
77966	Kappel-Grafenhausen	Baden-Württemberg	BW	83
77971	Kippenheim	Baden-Württemberg	BW	83
77972	Mahlberg	Baden-Württemberg	BW	83
77974	Meißenheim	Baden-Württemberg	BW	83
77975	Ringsheim	Baden-Württemberg	BW	83
77977	Rust	Baden-Württemberg	BW	83
77978	Schuttertal	Baden-Württemberg	BW	83
78048	Villingen-Schwenningen	Baden-Württemberg	BW	83
78050	Villingen-Schwenningen	Baden-Württemberg	BW	83
78052	Villingen-Schwenningen	Baden-Württemberg	BW	83
78054	Villingen-Schwenningen	Baden-Württemberg	BW	83
78056	Villingen-Schwenningen	Baden-Württemberg	BW	83
78073	Bad Dürrheim	Baden-Württemberg	BW	83
78078	Niedereschach	Baden-Württemberg	BW	83
78083	Dauchingen	Baden-Württemberg	BW	83
78086	Brigachtal	Baden-Württemberg	BW	83
78087	Mönchweiler	Baden-Württemberg	BW	83
78089	Unterkirnach	Baden-Württemberg	BW	83
78098	Triberg	Baden-Württemberg	BW	83
78112	Sankt Georgen im Schwarzwald	Baden-Württemberg	BW	83
78120	Furtwangen im Schwarzwald	Baden-Württemberg	BW	83
78126	Königsfeld im Schwarzwald	Baden-Württemberg	BW	83
78132	Hornberg	Baden-Württemberg	BW	83
78136	Schonach im Schwarzwald	Baden-Württemberg	BW	83
78141	Schönwald im Schwarzwald	Baden-Württemberg	BW	83
78144	Tennenbronn	Baden-Württemberg	BW	83
78147	Vöhrenbach	Baden-Württemberg	BW	83
78148	Gütenbach	Baden-Württemberg	BW	83
78166	Donaueschingen	Baden-Württemberg	BW	83
78176	Blumberg	Baden-Württemberg	BW	83
78183	Hüfingen	Baden-Württemberg	BW	83
78187	Geisingen	Baden-Württemberg	BW	83
78194	Immendingen	Baden-Württemberg	BW	83
78199	Bräunlingen	Baden-Württemberg	BW	83
78224	Singen	Baden-Württemberg	BW	83
78234	Engen	Baden-Württemberg	BW	83
78239	Rielasingen-Worblingen	Baden-Württemberg	BW	83
78244	Gottmadingen	Baden-Württemberg	BW	83
78247	Hilzingen	Baden-Württemberg	BW	83
78250	Tengen	Baden-Württemberg	BW	83
78253	Eigeltingen	Baden-Württemberg	BW	83
78256	Steißlingen	Baden-Württemberg	BW	83
78259	Mühlhausen-Ehingen	Baden-Württemberg	BW	83
78262	Gailingen am Hochrhein	Baden-Württemberg	BW	83
78266	Büsingen am Hochrhein	Baden-Württemberg	BW	83
78267	Aach	Baden-Württemberg	BW	83
78269	Volkertshausen	Baden-Württemberg	BW	83
78315	Radolfzell am Bodensee	Baden-Württemberg	BW	83
78333	Stockach	Baden-Württemberg	BW	83
78337	Öhningen	Baden-Württemberg	BW	83
78343	Gaienhofen	Baden-Württemberg	BW	83
78345	Moos	Baden-Württemberg	BW	83
78351	Bodman-Ludwigshafen	Baden-Württemberg	BW	83
78355	Hohenfels	Baden-Württemberg	BW	83
78357	Mühlingen	Baden-Württemberg	BW	83
78359	Orsingen-Nenzingen	Baden-Württemberg	BW	83
78462	Konstanz	Baden-Württemberg	BW	83
78464	Konstanz	Baden-Württemberg	BW	83
78465	Konstanz	Baden-Württemberg	BW	83
78467	Konstanz	Baden-Württemberg	BW	83
78476	Allensbach	Baden-Württemberg	BW	83
78479	Reichenau	Baden-Württemberg	BW	83
78532	Tuttlingen	Baden-Württemberg	BW	83
78549	Spaichingen	Baden-Württemberg	BW	83
78554	Aldingen	Baden-Württemberg	BW	83
78559	Gosheim	Baden-Württemberg	BW	83
78564	Wehingen	Baden-Württemberg	BW	83
78564	Reichenbach am Heuberg	Baden-Württemberg	BW	83
78567	Fridingen an der Donau	Baden-Württemberg	BW	83
78570	Mühlheim an der Donau	Baden-Württemberg	BW	83
78573	Wurmlingen	Baden-Württemberg	BW	83
78576	Emmingen-Liptingen	Baden-Württemberg	BW	83
78579	Neuhausen ob Eck	Baden-Württemberg	BW	83
78580	Bärenthal	Baden-Württemberg	BW	83
78582	Balgheim	Baden-Württemberg	BW	83
78583	Böttingen	Baden-Württemberg	BW	83
78585	Bubsheim	Baden-Württemberg	BW	83
78586	Deilingen	Baden-Württemberg	BW	83
78588	Denkingen	Baden-Württemberg	BW	83
78589	Dürbheim	Baden-Württemberg	BW	83
78591	Durchhausen	Baden-Württemberg	BW	83
78592	Egesheim	Baden-Württemberg	BW	83
78594	Gunningen	Baden-Württemberg	BW	83
78595	Hausen ob Verena	Baden-Württemberg	BW	83
78597	Irndorf	Baden-Württemberg	BW	83
78598	Königsheim	Baden-Württemberg	BW	83
78600	Kolbingen	Baden-Württemberg	BW	83
78601	Mahlstetten	Baden-Württemberg	BW	83
78603	Renquishausen	Baden-Württemberg	BW	83
78604	Rietheim-Weilheim	Baden-Württemberg	BW	83
78606	Seitingen-Oberflacht	Baden-Württemberg	BW	83
78607	Talheim	Baden-Württemberg	BW	83
78609	Tuningen	Baden-Württemberg	BW	83
78628	Rottweil	Baden-Württemberg	BW	83
78647	Trossingen	Baden-Württemberg	BW	83
78652	Deißlingen	Baden-Württemberg	BW	83
78655	Dunningen	Baden-Württemberg	BW	83
78658	Zimmern ob Rottweil	Baden-Württemberg	BW	83
78661	Dietingen	Baden-Württemberg	BW	83
78662	Bösingen	Baden-Württemberg	BW	83
78664	Eschbronn	Baden-Württemberg	BW	83
78665	Frittlingen	Baden-Württemberg	BW	83
78667	Villingendorf	Baden-Württemberg	BW	83
78669	Wellendingen	Baden-Württemberg	BW	83
78713	Schramberg	Baden-Württemberg	BW	83
78727	Oberndorf am Neckar	Baden-Württemberg	BW	83
78730	Lauterbach	Baden-Württemberg	BW	83
78733	Aichhalden	Baden-Württemberg	BW	83
78736	Epfendorf	Baden-Württemberg	BW	83
78737	Fluorn-Winzeln	Baden-Württemberg	BW	83
78739	Hardt	Baden-Württemberg	BW	83
79098	Freiburg im Breisgau	Baden-Württemberg	BW	83
79100	Freiburg im Breisgau	Baden-Württemberg	BW	83
79102	Freiburg im Breisgau	Baden-Württemberg	BW	83
79104	Freiburg im Breisgau	Baden-Württemberg	BW	83
79106	Freiburg im Breisgau	Baden-Württemberg	BW	83
79108	Freiburg im Breisgau	Baden-Württemberg	BW	83
79110	Freiburg im Breisgau	Baden-Württemberg	BW	83
79111	Freiburg im Breisgau	Baden-Württemberg	BW	83
79112	Freiburg im Breisgau	Baden-Württemberg	BW	83
79114	Freiburg im Breisgau	Baden-Württemberg	BW	83
79115	Freiburg im Breisgau	Baden-Württemberg	BW	83
79117	Freiburg im Breisgau	Baden-Württemberg	BW	83
79183	Waldkirch	Baden-Württemberg	BW	83
79189	Bad Krozingen	Baden-Württemberg	BW	83
79194	Gundelfingen	Baden-Württemberg	BW	83
79194	Heuweiler	Baden-Württemberg	BW	83
79199	Kirchzarten	Baden-Württemberg	BW	83
79206	Breisach am Rhein	Baden-Württemberg	BW	83
79211	Denzlingen	Baden-Württemberg	BW	83
79215	Biederbach	Baden-Württemberg	BW	83
79215	Elzach	Baden-Württemberg	BW	83
79219	Staufen im Breisgau	Baden-Württemberg	BW	83
79224	Umkirch	Baden-Württemberg	BW	83
79227	Schallstadt	Baden-Württemberg	BW	83
79232	March	Baden-Württemberg	BW	83
79235	Vogtsburg im Kaiserstuhl	Baden-Württemberg	BW	83
79238	Ehrenkirchen	Baden-Württemberg	BW	83
79241	Ihringen	Baden-Württemberg	BW	83
79244	Münstertal	Baden-Württemberg	BW	83
79249	Merzhausen	Baden-Württemberg	BW	83
79252	Stegen	Baden-Württemberg	BW	83
79254	Oberried	Baden-Württemberg	BW	83
79256	Buchenbach	Baden-Württemberg	BW	83
79258	Hartheim	Baden-Württemberg	BW	83
79261	Gutach im Breisgau	Baden-Württemberg	BW	83
79263	Simonswald	Baden-Württemberg	BW	83
79268	Bötzingen	Baden-Württemberg	BW	83
79271	Sankt Peter	Baden-Württemberg	BW	83
79274	Sankt Märgen	Baden-Württemberg	BW	83
79276	Reute	Baden-Württemberg	BW	83
79279	Vörstetten	Baden-Württemberg	BW	83
79282	Ballrechten-Dottingen	Baden-Württemberg	BW	83
79283	Bollschweil	Baden-Württemberg	BW	83
79285	Ebringen	Baden-Württemberg	BW	83
79286	Glottertal	Baden-Württemberg	BW	83
79288	Gottenheim	Baden-Württemberg	BW	83
79289	Horben	Baden-Württemberg	BW	83
79291	Merdingen	Baden-Württemberg	BW	83
79292	Pfaffenweiler	Baden-Württemberg	BW	83
79294	Sölden	Baden-Württemberg	BW	83
79295	Sulzburg	Baden-Württemberg	BW	83
79297	Winden im Elztal	Baden-Württemberg	BW	83
79299	Wittnau	Baden-Württemberg	BW	83
79312	Emmendingen	Baden-Württemberg	BW	83
79331	Teningen	Baden-Württemberg	BW	83
79336	Herbolzheim	Baden-Württemberg	BW	83
79341	Kenzingen	Baden-Württemberg	BW	83
79346	Endingen am Kaiserstuhl	Baden-Württemberg	BW	83
79348	Freiamt	Baden-Württemberg	BW	83
79350	Sexau	Baden-Württemberg	BW	83
79353	Bahlingen am Kaiserstuhl	Baden-Württemberg	BW	83
79356	Eichstetten am Kaiserstuhl	Baden-Württemberg	BW	83
79359	Riegel am Kaiserstuhl	Baden-Württemberg	BW	83
79361	Sasbach am Kaiserstuhl	Baden-Württemberg	BW	83
79362	Forchheim	Baden-Württemberg	BW	83
79364	Malterdingen	Baden-Württemberg	BW	83
79365	Rheinhausen	Baden-Württemberg	BW	83
79367	Weisweil	Baden-Württemberg	BW	83
79369	Wyhl am Kaiserstuhl	Baden-Württemberg	BW	83
79379	Müllheim	Baden-Württemberg	BW	83
79395	Neuenburg am Rhein	Baden-Württemberg	BW	83
79400	Kandern	Baden-Württemberg	BW	83
79410	Badenweiler	Baden-Württemberg	BW	83
79415	Bad Bellingen	Baden-Württemberg	BW	83
79418	Schliengen	Baden-Württemberg	BW	83
79423	Heitersheim	Baden-Württemberg	BW	83
79424	Auggen	Baden-Württemberg	BW	83
79426	Buggingen	Baden-Württemberg	BW	83
79427	Eschbach	Baden-Württemberg	BW	83
79429	Malsburg-Marzell	Baden-Württemberg	BW	83
79513	Röttlerweiler	Baden-Württemberg	BW	83
79539	Lörrach	Baden-Württemberg	BW	83
79540	Lörrach	Baden-Württemberg	BW	83
79541	Lörrach	Baden-Württemberg	BW	83
79576	Weil am Rhein	Baden-Württemberg	BW	83
79578	Steinen	Baden-Württemberg	BW	83
79585	Steinen	Baden-Württemberg	BW	83
79588	Efringen-Kirchen	Baden-Württemberg	BW	83
79589	Binzen	Baden-Württemberg	BW	83
79591	Eimeldingen	Baden-Württemberg	BW	83
79592	Fischingen	Baden-Württemberg	BW	83
79594	Inzlingen	Baden-Württemberg	BW	83
79595	Rümmingen	Baden-Württemberg	BW	83
79597	Schallbach	Baden-Württemberg	BW	83
79599	Wittlingen	Baden-Württemberg	BW	83
79618	Rheinfelden	Baden-Württemberg	BW	83
79639	Grenzach-Wyhlen	Baden-Württemberg	BW	83
79650	Schopfheim	Baden-Württemberg	BW	83
79664	Wehr	Baden-Württemberg	BW	83
79669	Zell im Wiesental	Baden-Württemberg	BW	83
79674	Todtnau	Baden-Württemberg	BW	83
79677	Schönau im Schwarzwald	Baden-Württemberg	BW	83
79677	Fröhnd	Baden-Württemberg	BW	83
79677	Tunau	Baden-Württemberg	BW	83
79677	Aitern	Baden-Württemberg	BW	83
79677	Schönenberg	Baden-Württemberg	BW	83
79677	Böllen	Baden-Württemberg	BW	83
79677	Wembach	Baden-Württemberg	BW	83
79682	Todtmoos	Baden-Württemberg	BW	83
79683	Bürchau	Baden-Württemberg	BW	83
79685	Häg-Ehrsberg	Baden-Württemberg	BW	83
79686	Hasel	Baden-Württemberg	BW	83
79688	Hausen im Wiesental	Baden-Württemberg	BW	83
79689	Maulburg	Baden-Württemberg	BW	83
79691	Neuenweg	Baden-Württemberg	BW	83
79692	Elbenschwand	Baden-Württemberg	BW	83
79692	Tegernau	Baden-Württemberg	BW	83
79692	Raich	Baden-Württemberg	BW	83
79692	Sallneck	Baden-Württemberg	BW	83
79694	Utzenfeld	Baden-Württemberg	BW	83
79695	Wieden	Baden-Württemberg	BW	83
79697	Wies	Baden-Württemberg	BW	83
79699	Wieslet	Baden-Württemberg	BW	83
79713	Bad Säckingen	Baden-Württemberg	BW	83
79725	Laufenburg	Baden-Württemberg	BW	83
79730	Murg	Baden-Württemberg	BW	83
79733	Görwihl	Baden-Württemberg	BW	83
79736	Rickenbach	Baden-Württemberg	BW	83
79737	Herrischried	Baden-Württemberg	BW	83
79739	Schwörstadt	Baden-Württemberg	BW	83
79761	Waldshut-Tiengen	Baden-Württemberg	BW	83
79771	Klettgau	Baden-Württemberg	BW	83
79774	Albbruck	Baden-Württemberg	BW	83
79777	Ühlingen-Birkendorf	Baden-Württemberg	BW	83
79780	Stühlingen	Baden-Württemberg	BW	83
79787	Lauchringen	Baden-Württemberg	BW	83
79790	Küssaberg	Baden-Württemberg	BW	83
79793	Wutöschingen	Baden-Württemberg	BW	83
79798	Jestetten	Baden-Württemberg	BW	83
79801	Hohentengen am Hochrhein	Baden-Württemberg	BW	83
79802	Dettighofen	Baden-Württemberg	BW	83
79804	Dogern	Baden-Württemberg	BW	83
79805	Eggingen	Baden-Württemberg	BW	83
79807	Lottstetten	Baden-Württemberg	BW	83
79809	Weilheim	Baden-Württemberg	BW	83
79822	Titisee-Neustadt	Baden-Württemberg	BW	83
79837	Häusern	Baden-Württemberg	BW	83
79837	Sankt Blasien	Baden-Württemberg	BW	83
79837	Ibach	Baden-Württemberg	BW	83
79843	Löffingen	Baden-Württemberg	BW	83
79848	Bonndorf im Schwarzwald	Baden-Württemberg	BW	83
79853	Lenzkirch	Baden-Württemberg	BW	83
79856	Hinterzarten	Baden-Württemberg	BW	83
79859	Schluchsee	Baden-Württemberg	BW	83
79862	Höchenschwand	Baden-Württemberg	BW	83
79865	Grafenhausen	Baden-Württemberg	BW	83
79868	Feldberg	Baden-Württemberg	BW	83
79871	Eisenbach (Hochschwarzwald)	Baden-Württemberg	BW	83
79872	Bernau	Baden-Württemberg	BW	83
79874	Breitnau	Baden-Württemberg	BW	83
79875	Dachsberg	Baden-Württemberg	BW	83
79877	Friedenweiler	Baden-Württemberg	BW	83
79879	Wutach	Baden-Württemberg	BW	83
88637	Buchheim	Baden-Württemberg	BW	83
72070	Tübingen	Baden-Württemberg	BW	84
72072	Tübingen	Baden-Württemberg	BW	84
72074	Tübingen	Baden-Württemberg	BW	84
72076	Tübingen	Baden-Württemberg	BW	84
72108	Rottenburg am Neckar	Baden-Württemberg	BW	84
72116	Mössingen	Baden-Württemberg	BW	84
72119	Ammerbuch	Baden-Württemberg	BW	84
72124	Pliezhausen	Baden-Württemberg	BW	84
72127	Kusterdingen	Baden-Württemberg	BW	84
72131	Ofterdingen	Baden-Württemberg	BW	84
72135	Dettenhausen	Baden-Württemberg	BW	84
72138	Kirchentellinsfurt	Baden-Württemberg	BW	84
72141	Walddorfhäslach	Baden-Württemberg	BW	84
72144	Dußlingen	Baden-Württemberg	BW	84
72145	Hirrlingen	Baden-Württemberg	BW	84
72147	Nehren	Baden-Württemberg	BW	84
72149	Neustetten	Baden-Württemberg	BW	84
72181	Starzach	Baden-Württemberg	BW	84
72336	Balingen	Baden-Württemberg	BW	84
72348	Rosenfeld	Baden-Württemberg	BW	84
72351	Geislingen	Baden-Württemberg	BW	84
72355	Schömberg	Baden-Württemberg	BW	84
72356	Dautmergen	Baden-Württemberg	BW	84
72358	Dormettingen	Baden-Württemberg	BW	84
72359	Dotternhausen	Baden-Württemberg	BW	84
72361	Hausen am Tann	Baden-Württemberg	BW	84
72362	Nusplingen	Baden-Württemberg	BW	84
72364	Obernheim	Baden-Württemberg	BW	84
72365	Ratshausen	Baden-Württemberg	BW	84
72367	Weilen unter den Rinnen	Baden-Württemberg	BW	84
72369	Zimmern unter der Burg	Baden-Württemberg	BW	84
72379	Hechingen	Baden-Württemberg	BW	84
72393	Burladingen	Baden-Württemberg	BW	84
72401	Haigerloch	Baden-Württemberg	BW	84
72406	Bisingen	Baden-Württemberg	BW	84
72411	Bodelshausen	Baden-Württemberg	BW	84
72414	Rangendingen	Baden-Württemberg	BW	84
72415	Grosselfingen	Baden-Württemberg	BW	84
72417	Jungingen	Baden-Württemberg	BW	84
72419	Neufra	Baden-Württemberg	BW	84
72458	Albstadt	Baden-Württemberg	BW	84
72459	Albstadt	Baden-Württemberg	BW	84
72461	Albstadt	Baden-Württemberg	BW	84
72469	Meßstetten	Baden-Württemberg	BW	84
72474	Winterlingen	Baden-Württemberg	BW	84
72475	Bitz	Baden-Württemberg	BW	84
72477	Schwenningen	Baden-Württemberg	BW	84
72479	Straßberg	Baden-Württemberg	BW	84
72488	Sigmaringen	Baden-Württemberg	BW	84
72501	Gammertingen	Baden-Württemberg	BW	84
72505	Krauchenwies	Baden-Württemberg	BW	84
72510	Stetten am kalten Markt	Baden-Württemberg	BW	84
72511	Bingen	Baden-Württemberg	BW	84
72513	Hettingen	Baden-Württemberg	BW	84
72514	Inzigkofen	Baden-Württemberg	BW	84
72516	Scheer	Baden-Württemberg	BW	84
72517	Sigmaringendorf	Baden-Württemberg	BW	84
72519	Veringenstadt	Baden-Württemberg	BW	84
72525	Münsingen	Baden-Württemberg	BW	84
72531	Hohenstein Bernloch	Baden-Württemberg	BW	84
72531	Hohenstein Meidelstetten	Baden-Württemberg	BW	84
72531	Hohenstein Oberstetten	Baden-Württemberg	BW	84
72531	Hohenstein	Baden-Württemberg	BW	84
72531	Hohenstein Eglingen	Baden-Württemberg	BW	84
72531	Hohenstein Ödenwaldstetten	Baden-Württemberg	BW	84
72532	Gomadingen	Baden-Württemberg	BW	84
72534	Hayingen	Baden-Württemberg	BW	84
72535	Heroldstatt	Baden-Württemberg	BW	84
72535	Heroldstatt Ennabeuren	Baden-Württemberg	BW	84
72535	Heroldstatt Sontheim	Baden-Württemberg	BW	84
72537	Mehrstetten	Baden-Württemberg	BW	84
72539	Pfronstetten	Baden-Württemberg	BW	84
72555	Metzingen	Baden-Württemberg	BW	84
72574	Bad Urach	Baden-Württemberg	BW	84
72581	Dettingen an der Erms	Baden-Württemberg	BW	84
72582	Grabenstetten	Baden-Württemberg	BW	84
72584	Hülben	Baden-Württemberg	BW	84
72585	Riederich	Baden-Württemberg	BW	84
72587	Römerstein	Baden-Württemberg	BW	84
72587	Römerstein Donnstetten	Baden-Württemberg	BW	84
72587	Römerstein Zainingen	Baden-Württemberg	BW	84
72589	Westerheim	Baden-Württemberg	BW	84
72661	Grafenberg	Baden-Württemberg	BW	84
72760	Reutlingen	Baden-Württemberg	BW	84
72762	Reutlingen	Baden-Württemberg	BW	84
72764	Reutlingen	Baden-Württemberg	BW	84
72766	Reutlingen	Baden-Württemberg	BW	84
72768	Reutlingen	Baden-Württemberg	BW	84
72770	Reutlingen	Baden-Württemberg	BW	84
72793	Pfullingen	Baden-Württemberg	BW	84
72800	Eningen unter Achalm	Baden-Württemberg	BW	84
72805	Lichtenstein	Baden-Württemberg	BW	84
72810	Gomaringen	Baden-Württemberg	BW	84
72813	Sankt Johann	Baden-Württemberg	BW	84
72818	Trochtelfingen	Baden-Württemberg	BW	84
72820	Sonnenbühl	Baden-Württemberg	BW	84
72827	Wannweil	Baden-Württemberg	BW	84
72829	Engstingen Kohlstetten	Baden-Württemberg	BW	84
72829	Engstingen	Baden-Württemberg	BW	84
72829	Engstingen Großengstingen	Baden-Württemberg	BW	84
72829	Engstingen Kleinengstingen	Baden-Württemberg	BW	84
73340	Amstetten	Baden-Württemberg	BW	84
78354	Sipplingen	Baden-Württemberg	BW	84
88045	Friedrichshafen	Baden-Württemberg	BW	84
88046	Friedrichshafen	Baden-Württemberg	BW	84
88048	Friedrichshafen	Baden-Württemberg	BW	84
88069	Tettnang	Baden-Württemberg	BW	84
88074	Meckenbeuren	Baden-Württemberg	BW	84
88079	Kressbronn am Bodensee	Baden-Württemberg	BW	84
88085	Langenargen	Baden-Württemberg	BW	84
88086	Immenstaad am Bodensee	Baden-Württemberg	BW	84
88090	Immenstaad am Bodensee	Baden-Württemberg	BW	84
88094	Oberteuringen	Baden-Württemberg	BW	84
88097	Eriskirch	Baden-Württemberg	BW	84
88099	Neukirch	Baden-Württemberg	BW	84
88147	Achberg	Baden-Württemberg	BW	84
88212	Ravensburg	Baden-Württemberg	BW	84
88213	Ravensburg	Baden-Württemberg	BW	84
88214	Ravensburg	Baden-Württemberg	BW	84
88239	Wangen im Allgäu	Baden-Württemberg	BW	84
88250	Weingarten	Baden-Württemberg	BW	84
88255	Baienfurt	Baden-Württemberg	BW	84
88255	Baindt	Baden-Württemberg	BW	84
88260	Argenbühl	Baden-Württemberg	BW	84
88263	Horgenzell	Baden-Württemberg	BW	84
88267	Vogt	Baden-Württemberg	BW	84
88271	Wilhelmsdorf	Baden-Württemberg	BW	84
88273	Fronreute	Baden-Württemberg	BW	84
88276	Berg	Baden-Württemberg	BW	84
88279	Amtzell	Baden-Württemberg	BW	84
88281	Schlier	Baden-Württemberg	BW	84
88284	Wolpertswende	Baden-Württemberg	BW	84
88285	Bodnegg	Baden-Württemberg	BW	84
88287	Grünkraut	Baden-Württemberg	BW	84
88289	Waldburg	Baden-Württemberg	BW	84
88299	Leutkirch im Allgäu	Baden-Württemberg	BW	84
88316	Isny im Allgäu	Baden-Württemberg	BW	84
88317	Aichstetten	Baden-Württemberg	BW	84
88319	Aitrach	Baden-Württemberg	BW	84
88326	Aulendorf	Baden-Württemberg	BW	84
88339	Bad Waldsee	Baden-Württemberg	BW	84
88348	Bad Saulgau	Baden-Württemberg	BW	84
88348	Allmannsweiler	Baden-Württemberg	BW	84
88353	Kißlegg	Baden-Württemberg	BW	84
88356	Ostrach	Baden-Württemberg	BW	84
88361	Eichstegen	Baden-Württemberg	BW	84
88361	Boms	Baden-Württemberg	BW	84
88361	Altshausen	Baden-Württemberg	BW	84
88364	Wolfegg	Baden-Württemberg	BW	84
88367	Hohentengen	Baden-Württemberg	BW	84
88368	Bergatreute	Baden-Württemberg	BW	84
88370	Ebenweiler	Baden-Württemberg	BW	84
88371	Ebersbach-Musbach	Baden-Württemberg	BW	84
88373	Fleischwangen	Baden-Württemberg	BW	84
88374	Hoßkirch	Baden-Württemberg	BW	84
88376	Königseggwald	Baden-Württemberg	BW	84
88377	Riedhausen	Baden-Württemberg	BW	84
88379	Unterwaldhausen	Baden-Württemberg	BW	84
88379	Guggenhausen	Baden-Württemberg	BW	84
88400	Biberach an der Riß Bergerhausen	Baden-Württemberg	BW	84
88400	Biberach an der Riß	Baden-Württemberg	BW	84
88410	Bad Wurzach	Baden-Württemberg	BW	84
88416	Ochsenhausen	Baden-Württemberg	BW	84
88416	Erlenmoos	Baden-Württemberg	BW	84
88416	Steinhausen an der Rottum	Baden-Württemberg	BW	84
88422	Tiefenbach	Baden-Württemberg	BW	84
88422	Kanzach	Baden-Württemberg	BW	84
88422	Oggelshausen	Baden-Württemberg	BW	84
88422	Seekirch	Baden-Württemberg	BW	84
88422	Alleshausen	Baden-Württemberg	BW	84
88422	Dürnau	Baden-Württemberg	BW	84
88422	Moosburg	Baden-Württemberg	BW	84
88422	Betzenweiler	Baden-Württemberg	BW	84
88422	Bad Buchau	Baden-Württemberg	BW	84
88427	Bad Schussenried	Baden-Württemberg	BW	84
88427	Bad Schussenried Dunzenhausen	Baden-Württemberg	BW	84
88430	Rot an der Rot	Baden-Württemberg	BW	84
88433	Schemmerhofen	Baden-Württemberg	BW	84
88436	Eberhardzell	Baden-Württemberg	BW	84
88436	Eberhardzell Füramoos	Baden-Württemberg	BW	84
88436	Eberhardzell Füramoos; Altbellamont	Baden-Württemberg	BW	84
88437	Maselheim	Baden-Württemberg	BW	84
88441	Mittelbiberach	Baden-Württemberg	BW	84
88444	Ummendorf	Baden-Württemberg	BW	84
88447	Warthausen	Baden-Württemberg	BW	84
88448	Attenweiler	Baden-Württemberg	BW	84
88450	Berkheim	Baden-Württemberg	BW	84
88451	Dettingen an der Iller	Baden-Württemberg	BW	84
88453	Erolzheim	Baden-Württemberg	BW	84
88454	Hochdorf	Baden-Württemberg	BW	84
88456	Ingoldingen	Baden-Württemberg	BW	84
88457	Kirchdorf an der Iller	Baden-Württemberg	BW	84
88459	Tannheim	Baden-Württemberg	BW	84
88471	Laupheim	Baden-Württemberg	BW	84
88477	Schwendi	Baden-Württemberg	BW	84
88480	Achstetten	Baden-Württemberg	BW	84
88481	Balzheim	Baden-Württemberg	BW	84
88483	Burgrieden	Baden-Württemberg	BW	84
88484	Gutenzell-Hürbel	Baden-Württemberg	BW	84
88486	Kirchberg an der Iller	Baden-Württemberg	BW	84
88487	Mietingen	Baden-Württemberg	BW	84
88489	Wain	Baden-Württemberg	BW	84
88499	Altheim	Baden-Württemberg	BW	84
88499	Riedlingen	Baden-Württemberg	BW	84
88499	Emeringen	Baden-Württemberg	BW	84
88512	Mengen	Baden-Württemberg	BW	84
88515	Langenenslingen	Baden-Württemberg	BW	84
88518	Herbertingen	Baden-Württemberg	BW	84
88521	Ertingen	Baden-Württemberg	BW	84
88524	Uttenweiler	Baden-Württemberg	BW	84
88525	Dürmentingen	Baden-Württemberg	BW	84
88527	Unlingen	Baden-Württemberg	BW	84
88529	Zwiefalten	Baden-Württemberg	BW	84
88605	Sauldorf	Baden-Württemberg	BW	84
88605	Meßkirch	Baden-Württemberg	BW	84
88630	Pfullendorf	Baden-Württemberg	BW	84
88631	Beuron	Baden-Württemberg	BW	84
88633	Heiligenberg	Baden-Württemberg	BW	84
88634	Herdwangen-Schönach	Baden-Württemberg	BW	84
88636	Illmensee	Baden-Württemberg	BW	84
88637	Leibertingen	Baden-Württemberg	BW	84
88639	Wald	Baden-Württemberg	BW	84
88662	Überlingen	Baden-Württemberg	BW	84
88677	Markdorf	Baden-Württemberg	BW	84
88682	Salem	Baden-Württemberg	BW	84
88690	Uhldingen-Mühlhofen	Baden-Württemberg	BW	84
88693	Deggenhausertal	Baden-Württemberg	BW	84
88696	Owingen	Baden-Württemberg	BW	84
88697	Bermatingen	Baden-Württemberg	BW	84
88699	Frickingen	Baden-Württemberg	BW	84
88709	Hagnau am Bodensee	Baden-Württemberg	BW	84
88709	Meersburg	Baden-Württemberg	BW	84
88718	Daisendorf	Baden-Württemberg	BW	84
88719	Stetten	Baden-Württemberg	BW	84
89040	Ulm	Baden-Württemberg	BW	84
89073	Ulm	Baden-Württemberg	BW	84
89075	Ulm	Baden-Württemberg	BW	84
89077	Ulm	Baden-Württemberg	BW	84
89079	Ulm	Baden-Württemberg	BW	84
89081	Ulm	Baden-Württemberg	BW	84
89081	Ulm Jungingen	Baden-Württemberg	BW	84
89129	Nerenstetten	Baden-Württemberg	BW	84
89129	Öllingen	Baden-Württemberg	BW	84
89129	Langenau	Baden-Württemberg	BW	84
89129	Setzingen	Baden-Württemberg	BW	84
89134	Blaustein	Baden-Württemberg	BW	84
89143	Blaubeuren Wennenden	Baden-Württemberg	BW	84
89143	Blaubeuren	Baden-Württemberg	BW	84
89143	Blaubeuren Sonderbuch	Baden-Württemberg	BW	84
89143	Blaubeuren Asch	Baden-Württemberg	BW	84
89143	Blaubeuren Gerhausen	Baden-Württemberg	BW	84
89143	Blaubeuren Seißen	Baden-Württemberg	BW	84
89150	Laichingen	Baden-Württemberg	BW	84
89150	Laichingen Machtolsheim	Baden-Württemberg	BW	84
89150	Laichingen Feldstetten	Baden-Württemberg	BW	84
89150	Laichingen Suppingen	Baden-Württemberg	BW	84
89155	Erbach	Baden-Württemberg	BW	84
89160	Dornstadt	Baden-Württemberg	BW	84
89160	Dornstadt Scharenstetten	Baden-Württemberg	BW	84
89165	Dietenheim	Baden-Württemberg	BW	84
89171	Illerkirchberg	Baden-Württemberg	BW	84
89173	Lonsee	Baden-Württemberg	BW	84
89174	Altheim (Alb)	Baden-Württemberg	BW	84
89176	Asselfingen	Baden-Württemberg	BW	84
89177	Ballendorf	Baden-Württemberg	BW	84
89177	Börslingen	Baden-Württemberg	BW	84
89179	Beimerstetten	Baden-Württemberg	BW	84
89180	Berghülen	Baden-Württemberg	BW	84
89180	Berghülen Treffensbuch	Baden-Württemberg	BW	84
89180	Berghülen Bühlenhausen	Baden-Württemberg	BW	84
89182	Bernstadt	Baden-Württemberg	BW	84
89183	Holzkirch	Baden-Württemberg	BW	84
89183	Breitingen	Baden-Württemberg	BW	84
89185	Hüttisheim	Baden-Württemberg	BW	84
89186	Illerrieden	Baden-Württemberg	BW	84
89188	Merklingen	Baden-Württemberg	BW	84
89188	Merklingen Widderstall	Baden-Württemberg	BW	84
89189	Neenstetten	Baden-Württemberg	BW	84
89191	Nellingen Oppingen	Baden-Württemberg	BW	84
89191	Nellingen Aichen	Baden-Württemberg	BW	84
89191	Nellingen	Baden-Württemberg	BW	84
89192	Rammingen	Baden-Württemberg	BW	84
89194	Schnürpflingen	Baden-Württemberg	BW	84
89195	Staig	Baden-Württemberg	BW	84
89197	Weidenstetten	Baden-Württemberg	BW	84
89198	Westerstetten	Baden-Württemberg	BW	84
89584	Lauterach	Baden-Württemberg	BW	84
89584	Ehingen an der Donau	Baden-Württemberg	BW	84
89597	Hausen am Bussen	Baden-Württemberg	BW	84
89597	Munderkingen	Baden-Württemberg	BW	84
89597	Unterwachingen	Baden-Württemberg	BW	84
89601	Schelklingen	Baden-Württemberg	BW	84
89604	Allmendingen	Baden-Württemberg	BW	84
89605	Altheim	Baden-Württemberg	BW	84
89607	Emerkingen	Baden-Württemberg	BW	84
89608	Griesingen	Baden-Württemberg	BW	84
89610	Oberdischingen	Baden-Württemberg	BW	84
89611	Rechtenstein	Baden-Württemberg	BW	84
89611	Obermarchtal	Baden-Württemberg	BW	84
89613	Grundsheim	Baden-Württemberg	BW	84
89613	Oberstadion	Baden-Württemberg	BW	84
89614	Öpfingen	Baden-Württemberg	BW	84
89616	Rottenacker	Baden-Württemberg	BW	84
89617	Untermarchtal	Baden-Württemberg	BW	84
89619	Unterstadion	Baden-Württemberg	BW	84
80331	München	Bayern	BY	91
80333	München	Bayern	BY	91
80335	München	Bayern	BY	91
80336	München	Bayern	BY	91
80337	München	Bayern	BY	91
80339	München	Bayern	BY	91
80469	München	Bayern	BY	91
80538	München	Bayern	BY	91
80539	München	Bayern	BY	91
80634	München	Bayern	BY	91
80636	München	Bayern	BY	91
80637	München	Bayern	BY	91
80638	München	Bayern	BY	91
80639	München	Bayern	BY	91
80686	München	Bayern	BY	91
80687	München	Bayern	BY	91
80689	München	Bayern	BY	91
80796	München	Bayern	BY	91
80797	München	Bayern	BY	91
80798	München	Bayern	BY	91
80799	München	Bayern	BY	91
80801	München	Bayern	BY	91
80802	München	Bayern	BY	91
80803	München	Bayern	BY	91
80804	München	Bayern	BY	91
80805	München	Bayern	BY	91
80807	München	Bayern	BY	91
80809	München	Bayern	BY	91
80933	München	Bayern	BY	91
80935	München	Bayern	BY	91
80937	München	Bayern	BY	91
80939	München	Bayern	BY	91
80992	München	Bayern	BY	91
80993	München	Bayern	BY	91
80995	München	Bayern	BY	91
80997	München	Bayern	BY	91
80999	München	Bayern	BY	91
81241	München	Bayern	BY	91
81243	München	Bayern	BY	91
81245	München	Bayern	BY	91
81247	München	Bayern	BY	91
81249	München	Bayern	BY	91
81369	München	Bayern	BY	91
81371	München	Bayern	BY	91
81373	München	Bayern	BY	91
81375	München	Bayern	BY	91
81377	München	Bayern	BY	91
81379	München	Bayern	BY	91
81475	München	Bayern	BY	91
81476	München	Bayern	BY	91
81477	München	Bayern	BY	91
81479	München	Bayern	BY	91
81539	München	Bayern	BY	91
81541	München	Bayern	BY	91
81543	München	Bayern	BY	91
81545	München	Bayern	BY	91
81547	München	Bayern	BY	91
81549	München	Bayern	BY	91
81667	München	Bayern	BY	91
81669	München	Bayern	BY	91
81671	München	Bayern	BY	91
81673	München	Bayern	BY	91
81675	München	Bayern	BY	91
81677	München	Bayern	BY	91
81679	München	Bayern	BY	91
81735	München	Bayern	BY	91
81737	München	Bayern	BY	91
81739	München	Bayern	BY	91
81825	München	Bayern	BY	91
81827	München	Bayern	BY	91
81829	München	Bayern	BY	91
81925	München	Bayern	BY	91
81927	München	Bayern	BY	91
81929	München	Bayern	BY	91
82008	Unterhaching	Bayern	BY	91
82024	Taufkirchen	Bayern	BY	91
82031	Grünwald	Bayern	BY	91
82032	Deisenhofen bei München	Bayern	BY	91
82041	Oberhaching	Bayern	BY	91
82049	Pullach im Isartal	Bayern	BY	91
82054	Sauerlach	Bayern	BY	91
82057	Icking	Bayern	BY	91
82061	Neuried	Bayern	BY	91
82064	Straßlach-Dingharting	Bayern	BY	91
82065	Baierbrunn	Bayern	BY	91
82067	Kloster Schäftlarn	Bayern	BY	91
82069	Schäftlarn	Bayern	BY	91
82110	Germering	Bayern	BY	91
82131	Gauting	Bayern	BY	91
82140	Olching	Bayern	BY	91
82152	Krailling	Bayern	BY	91
82152	Planegg	Bayern	BY	91
82166	Gräfelfing	Bayern	BY	91
82178	Puchheim	Bayern	BY	91
82194	Gröbenzell	Bayern	BY	91
82205	Gilching	Bayern	BY	91
82211	Herrsching am Ammersee	Bayern	BY	91
82216	Maisach	Bayern	BY	91
82223	Eichenau	Bayern	BY	91
82229	Seefeld	Bayern	BY	91
82234	Weßling	Bayern	BY	91
82237	Wörthsee	Bayern	BY	91
82239	Alling	Bayern	BY	91
82256	Fürstenfeldbruck	Bayern	BY	91
82266	Inning am Ammersee	Bayern	BY	91
82269	Geltendorf	Bayern	BY	91
82272	Moorenweis	Bayern	BY	91
82275	Emmering	Bayern	BY	91
82276	Adelshofen	Bayern	BY	91
82278	Althegnenberg	Bayern	BY	91
82279	Eching am Ammersee	Bayern	BY	91
82281	Egenhofen	Bayern	BY	91
82282	Pischertshofen	Bayern	BY	91
82284	Grafrath	Bayern	BY	91
82285	Hattenhofen	Bayern	BY	91
82287	Jesenwang	Bayern	BY	91
82288	Kottgeisering	Bayern	BY	91
82290	Landsberied	Bayern	BY	91
82291	Mammendorf	Bayern	BY	91
82293	Mittelstetten	Bayern	BY	91
82294	Oberschweinbach	Bayern	BY	91
82296	Schöngeising	Bayern	BY	91
82299	Türkenfeld	Bayern	BY	91
82319	Starnberg	Bayern	BY	91
82327	Tutzing	Bayern	BY	91
82335	Berg	Bayern	BY	91
82340	Feldafing	Bayern	BY	91
82343	Pöcking	Bayern	BY	91
82346	Andechs	Bayern	BY	91
82347	Bernried	Bayern	BY	91
82349	Pentenried	Bayern	BY	91
82362	Weilheim in Oberbayern	Bayern	BY	91
82377	Penzberg	Bayern	BY	91
82380	Peißenberg	Bayern	BY	91
82383	Hohenpeißenberg	Bayern	BY	91
82386	Oberhausen	Bayern	BY	91
82386	Huglfing	Bayern	BY	91
82387	Antdorf	Bayern	BY	91
82389	Böbing	Bayern	BY	91
82390	Eberfing	Bayern	BY	91
82392	Habach	Bayern	BY	91
82393	Iffeldorf	Bayern	BY	91
82395	Obersöchering	Bayern	BY	91
82396	Pähl	Bayern	BY	91
82398	Polling	Bayern	BY	91
82399	Raisting	Bayern	BY	91
82401	Rottenbuch	Bayern	BY	91
82402	Seeshaupt	Bayern	BY	91
82404	Sindelsdorf	Bayern	BY	91
82405	Wessobrunn	Bayern	BY	91
82407	Wielenbach	Bayern	BY	91
82409	Wildsteig	Bayern	BY	91
82418	Riegsee	Bayern	BY	91
82418	Seehausen am Staffelsee	Bayern	BY	91
82418	Murnau am Staffelsee	Bayern	BY	91
82431	Kochel am See	Bayern	BY	91
82432	Urfeld; Oberbayern	Bayern	BY	91
82433	Bad Kohlgrub	Bayern	BY	91
82435	Bad Bayersoien	Bayern	BY	91
82436	Eglfing	Bayern	BY	91
82438	Eschenlohe	Bayern	BY	91
82439	Großweil	Bayern	BY	91
82441	Ohlstadt	Bayern	BY	91
82442	Saulgrub	Bayern	BY	91
82444	Schlehdorf	Bayern	BY	91
82445	Schwaigen	Bayern	BY	91
82447	Spatzenhausen	Bayern	BY	91
82449	Uffing am Staffelsee	Bayern	BY	91
82467	Garmisch-Partenkirchen	Bayern	BY	91
82481	Mittenwald	Bayern	BY	91
82487	Oberammergau	Bayern	BY	91
82488	Ettal	Bayern	BY	91
82490	Farchant	Bayern	BY	91
82491	Grainau	Bayern	BY	91
82493	Klais	Bayern	BY	91
82494	Krün	Bayern	BY	91
82496	Oberau	Bayern	BY	91
82497	Unterammergau	Bayern	BY	91
82499	Wallgau	Bayern	BY	91
82515	Wolfratshausen	Bayern	BY	91
82538	Geretsried	Bayern	BY	91
82541	Münsing	Bayern	BY	91
82544	Egling	Bayern	BY	91
82547	Eurasburg	Bayern	BY	91
82549	Königsdorf	Bayern	BY	91
83022	Rosenheim	Bayern	BY	91
83024	Rosenheim	Bayern	BY	91
83026	Rosenheim	Bayern	BY	91
83043	Bad Aibling	Bayern	BY	91
83052	Bruckmühl	Bayern	BY	91
83059	Kolbermoor	Bayern	BY	91
83064	Raubling	Bayern	BY	91
83071	Stephanskirchen	Bayern	BY	91
83075	Bad Feilnbach	Bayern	BY	91
83080	Oberaudorf	Bayern	BY	91
83083	Riedering	Bayern	BY	91
83088	Kiefersfelden	Bayern	BY	91
83093	Bad Endorf	Bayern	BY	91
83098	Brannenburg	Bayern	BY	91
83101	Rohrdorf	Bayern	BY	91
83104	Tuntenhausen	Bayern	BY	91
83109	Großkarolinenfeld	Bayern	BY	91
83112	Frasdorf	Bayern	BY	91
83115	Neubeuern	Bayern	BY	91
83119	Obing	Bayern	BY	91
83122	Samerberg	Bayern	BY	91
83123	Amerang	Bayern	BY	91
83125	Eggstätt	Bayern	BY	91
83126	Flintsbach	Bayern	BY	91
83128	Halfing	Bayern	BY	91
83129	Höslwang	Bayern	BY	91
83131	Nußdorf am Inn	Bayern	BY	91
83132	Pittenhart	Bayern	BY	91
83134	Prutting	Bayern	BY	91
83135	Schechen	Bayern	BY	91
83137	Schonstett	Bayern	BY	91
83139	Söchtenau	Bayern	BY	91
83209	Prien am Chiemsee	Bayern	BY	91
83224	Staudach-Egerndach	Bayern	BY	91
83224	Grassau	Bayern	BY	91
83229	Aschau im Chiemgau	Bayern	BY	91
83233	Bernau am Chiemsee	Bayern	BY	91
83236	Übersee	Bayern	BY	91
83242	Reit im Winkl	Bayern	BY	91
83246	Unterwössen	Bayern	BY	91
83250	Marquartstein	Bayern	BY	91
83253	Rimsting	Bayern	BY	91
83254	Breitbrunn am Chiemsee	Bayern	BY	91
83256	Chiemsee	Bayern	BY	91
83257	Gstadt am Chiemsee	Bayern	BY	91
83259	Schleching	Bayern	BY	91
83278	Traunstein	Bayern	BY	91
83301	Traunreut	Bayern	BY	91
83308	Trostberg	Bayern	BY	91
83313	Siegsdorf	Bayern	BY	91
83317	Teisendorf	Bayern	BY	91
83324	Ruhpolding	Bayern	BY	91
83329	Wonneberg	Bayern	BY	91
83329	Waging am See	Bayern	BY	91
83334	Inzell	Bayern	BY	91
83339	Chieming	Bayern	BY	91
83342	Tacherting	Bayern	BY	91
83344	Bergen	Bayern	BY	91
83346	Bergen	Bayern	BY	91
83349	Palling	Bayern	BY	91
83352	Altenmarkt an der Alz	Bayern	BY	91
83355	Grabenstätt	Bayern	BY	91
83358	Seeon-Seebruck	Bayern	BY	91
83359	Hallabruck	Bayern	BY	91
83361	Kienberg	Bayern	BY	91
83362	Surberg	Bayern	BY	91
83364	Graben bei Neukirchen am Teisenberg	Bayern	BY	91
83365	Nußdorf	Bayern	BY	91
83367	Petting	Bayern	BY	91
83368	Anning bei Sankt Georgen; Chiemgau	Bayern	BY	91
83370	Seeon-Seebruck	Bayern	BY	91
83371	Roitham bei Stein an der Traun	Bayern	BY	91
83373	Taching am See	Bayern	BY	91
83374	Niedling	Bayern	BY	91
83376	Castrum	Bayern	BY	91
83377	Vachendorf	Bayern	BY	91
83379	Wonneberg	Bayern	BY	91
83395	Freilassing	Bayern	BY	91
83404	Ainring	Bayern	BY	91
83410	Laufen	Bayern	BY	91
83413	Fridolfing	Bayern	BY	91
83416	Saaldorf-Surheim	Bayern	BY	91
83417	Kirchanschöring	Bayern	BY	91
83435	Bad Reichenhall	Bayern	BY	91
83451	Piding	Bayern	BY	91
83454	Anger	Bayern	BY	91
83457	Bayerisch Gmain	Bayern	BY	91
83458	Schneizlreuth	Bayern	BY	91
83471	Schönau am Königssee	Bayern	BY	91
83471	Berchtesgaden	Bayern	BY	91
83483	Bischofswiesen	Bayern	BY	91
83486	Ramsau	Bayern	BY	91
83487	Marktschellenberg	Bayern	BY	91
83489	Strub	Bayern	BY	91
83512	Wasserburg am Inn	Bayern	BY	91
83527	Haag in Oberbayern	Bayern	BY	91
83527	Kirchdorf	Bayern	BY	91
83530	Schnaitsee	Bayern	BY	91
83533	Edling	Bayern	BY	91
83536	Gars am Inn	Bayern	BY	91
83539	Albaching	Bayern	BY	91
83539	Pfaffing	Bayern	BY	91
83543	Rott am Inn	Bayern	BY	91
83544	Albaching	Bayern	BY	91
83546	Biburg; Gemeinde Gars am Inn	Bayern	BY	91
83547	Babensham	Bayern	BY	91
83549	Eiselfing	Bayern	BY	91
83550	Emmering	Bayern	BY	91
83552	Durrhausen	Bayern	BY	91
83553	Frauenneuharting	Bayern	BY	91
83555	Haiden bei Gars Bahnhof	Bayern	BY	91
83556	Griesstätt	Bayern	BY	91
83558	Maitenbeth	Bayern	BY	91
83559	Reiser; Gemeinde Gars am Inn	Bayern	BY	91
83561	Ramerberg	Bayern	BY	91
83562	Rechtmehring	Bayern	BY	91
83564	Soyen	Bayern	BY	91
83565	Ast; Gemeinde Frauenneuharting	Bayern	BY	91
83567	Unterreit	Bayern	BY	91
83569	Vogtareuth	Bayern	BY	91
83607	Holzkirchen	Bayern	BY	91
83620	Feldkirchen-Westerham	Bayern	BY	91
83623	Dietramszell	Bayern	BY	91
83624	Otterfing	Bayern	BY	91
83626	Valley	Bayern	BY	91
83627	Warngau	Bayern	BY	91
83629	Weyarn	Bayern	BY	91
83646	Wackersberg	Bayern	BY	91
83646	Bad Tölz	Bayern	BY	91
83661	Lenggries	Bayern	BY	91
83666	Waakirchen	Bayern	BY	91
83670	Bad Heilbrunn	Bayern	BY	91
83671	Benediktbeuern	Bayern	BY	91
83673	Bichl	Bayern	BY	91
83674	Gaißach	Bayern	BY	91
83676	Jachenau	Bayern	BY	91
83677	Reichersbeuern	Bayern	BY	91
83677	Greiling	Bayern	BY	91
83679	Sachsenkam	Bayern	BY	91
83684	Tegernsee	Bayern	BY	91
83700	Rottach-Egern	Bayern	BY	91
83703	Gmund am Tegernsee	Bayern	BY	91
83707	Bad Wiessee	Bayern	BY	91
83708	Kreuth	Bayern	BY	91
83714	Miesbach	Bayern	BY	91
83727	Schliersee	Bayern	BY	91
83730	Fischbachau	Bayern	BY	91
83734	Hausham	Bayern	BY	91
83735	Bayrischzell	Bayern	BY	91
83737	Irschenberg	Bayern	BY	91
83739	Hofreuth bei Wörnsmühl	Bayern	BY	91
84072	Au in der Hallertau	Bayern	BY	91
84104	Rudelzhausen	Bayern	BY	91
84405	Dorfen	Bayern	BY	91
84416	Inning am Holz	Bayern	BY	91
84416	Taufkirchen (Vils)	Bayern	BY	91
84419	Schwindegg	Bayern	BY	91
84419	Obertaufkirchen	Bayern	BY	91
84424	Isen	Bayern	BY	91
84427	Sankt Wolfgang	Bayern	BY	91
84428	Buchbach	Bayern	BY	91
84431	Rattenkirchen	Bayern	BY	91
84431	Heldenstein	Bayern	BY	91
84432	Hohenpolding	Bayern	BY	91
84434	Kirchberg	Bayern	BY	91
84435	Lengdorf	Bayern	BY	91
84437	Reichertsheim	Bayern	BY	91
84439	Steinkirchen	Bayern	BY	91
84453	Mühldorf am Inn	Bayern	BY	91
84478	Waldkraiburg	Bayern	BY	91
84489	Burghausen	Bayern	BY	91
84494	Niederbergkirchen	Bayern	BY	91
84494	Neumarkt-Sankt Veit	Bayern	BY	91
84494	Lohkirchen	Bayern	BY	91
84494	Niedertaufkirchen	Bayern	BY	91
84503	Altötting	Bayern	BY	91
84508	Burgkirchen an der Alz	Bayern	BY	91
84513	Töging am Inn	Bayern	BY	91
84513	Erharting	Bayern	BY	91
84518	Garching an der Alz	Bayern	BY	91
84524	Neuötting	Bayern	BY	91
84529	Tittmoning	Bayern	BY	91
84533	Haiming	Bayern	BY	91
84533	Stammham	Bayern	BY	91
84533	Marktl	Bayern	BY	91
84539	Ampfing	Bayern	BY	91
84539	Zangberg	Bayern	BY	91
84543	Winhöring	Bayern	BY	91
84544	Aschau am Inn	Bayern	BY	91
84546	Egglkofen	Bayern	BY	91
84547	Emmerting	Bayern	BY	91
84549	Engelsberg	Bayern	BY	91
84550	Feichten an der Alz	Bayern	BY	91
84553	Halsbach; Altötting	Bayern	BY	91
84555	Jettenbach	Bayern	BY	91
84556	Kastl	Bayern	BY	91
84558	Tyrlaching	Bayern	BY	91
84558	Halsbach	Bayern	BY	91
84558	Kirchweidach	Bayern	BY	91
84559	Kraiburg am Inn	Bayern	BY	91
84561	Mehring	Bayern	BY	91
84562	Mettenheim	Bayern	BY	91
84564	Oberbergkirchen	Bayern	BY	91
84565	Oberneukirchen	Bayern	BY	91
84567	Perach	Bayern	BY	91
84567	Erlbach	Bayern	BY	91
84568	Pleiskirchen	Bayern	BY	91
84570	Polling	Bayern	BY	91
84571	Reischach	Bayern	BY	91
84573	Schönberg	Bayern	BY	91
84574	Taufkirchen	Bayern	BY	91
84576	Teising	Bayern	BY	91
84577	Tüßling	Bayern	BY	91
84579	Unterneukirchen	Bayern	BY	91
85049	Ingolstadt	Bayern	BY	91
85051	Ingolstadt	Bayern	BY	91
85053	Ingolstadt	Bayern	BY	91
85055	Ingolstadt	Bayern	BY	91
85057	Ingolstadt	Bayern	BY	91
85072	Eichstätt	Bayern	BY	91
85077	Manching	Bayern	BY	91
85080	Gaimersheim	Bayern	BY	91
85084	Reichertshofen	Bayern	BY	91
85088	Vohburg an der Donau	Bayern	BY	91
85092	Kösching	Bayern	BY	91
85095	Denkendorf	Bayern	BY	91
85098	Großmehring	Bayern	BY	91
85101	Lenting	Bayern	BY	91
85104	Pförring	Bayern	BY	91
85107	Baar-Ebenhausen	Bayern	BY	91
85110	Kipfenberg	Bayern	BY	91
85111	Adelschlag	Bayern	BY	91
85113	Böhmfeld	Bayern	BY	91
85114	Buxheim	Bayern	BY	91
85116	Egweil	Bayern	BY	91
85117	Eitensheim	Bayern	BY	91
85119	Ernsgaden	Bayern	BY	91
85120	Hepberg	Bayern	BY	91
85122	Hitzhofen	Bayern	BY	91
85123	Karlskron	Bayern	BY	91
85125	Kinding	Bayern	BY	91
85126	Münchsmünster	Bayern	BY	91
85128	Nassenfels	Bayern	BY	91
85129	Oberdolling	Bayern	BY	91
85131	Pollenfeld	Bayern	BY	91
85132	Schernfeld	Bayern	BY	91
85134	Stammham	Bayern	BY	91
85135	Titting	Bayern	BY	91
85137	Walting	Bayern	BY	91
85139	Wettstetten	Bayern	BY	91
85221	Dachau	Bayern	BY	91
85229	Markt Indersdorf	Bayern	BY	91
85232	Bergkirchen	Bayern	BY	91
85235	Odelzhausen	Bayern	BY	91
85235	Pfaffenhofen an der Glonn	Bayern	BY	91
85238	Petershausen	Bayern	BY	91
85241	Hebertshausen	Bayern	BY	91
85244	Röhrmoos	Bayern	BY	91
85247	Schwabhausen	Bayern	BY	91
85250	Altomünster	Bayern	BY	91
85253	Erdweg	Bayern	BY	91
85254	Sulzemoos	Bayern	BY	91
85256	Vierkirchen	Bayern	BY	91
85258	Weichs	Bayern	BY	91
85259	Wiedenzhausen	Bayern	BY	91
85276	Hettenshausen	Bayern	BY	91
85276	Pfaffenhofen an der Ilm	Bayern	BY	91
85283	Wolnzach	Bayern	BY	91
85290	Geisenfeld	Bayern	BY	91
85293	Reichertshausen	Bayern	BY	91
85296	Rohrbach	Bayern	BY	91
85298	Scheyern	Bayern	BY	91
85301	Schweitenkirchen	Bayern	BY	91
85302	Gerolsbach	Bayern	BY	91
85304	Ilmmünster	Bayern	BY	91
85305	Jetzendorf	Bayern	BY	91
85307	Paunzhausen	Bayern	BY	91
85309	Pörnbach	Bayern	BY	91
85354	Freising	Bayern	BY	91
85356	Freising	Bayern	BY	91
85368	Moosburg	Bayern	BY	91
85368	Wang	Bayern	BY	91
85375	Neufahrn bei Freising	Bayern	BY	91
85376	Hetzenhausen	Bayern	BY	91
85386	Eching	Bayern	BY	91
85391	Allershausen	Bayern	BY	91
85395	Wolfersdorf	Bayern	BY	91
85395	Attenkirchen	Bayern	BY	91
85399	Hallbergmoos	Bayern	BY	91
85402	Kranzberg	Bayern	BY	91
85405	Nandlstadt	Bayern	BY	91
85406	Zolling	Bayern	BY	91
85408	Gammelsdorf	Bayern	BY	91
85410	Haag an der Amper	Bayern	BY	91
85411	Hohenkammer	Bayern	BY	91
85413	Hörgertshausen	Bayern	BY	91
85414	Kirchdorf an der Amper	Bayern	BY	91
85416	Langenbach	Bayern	BY	91
85417	Marzling	Bayern	BY	91
85419	Mauern	Bayern	BY	91
85435	Erding	Bayern	BY	91
85445	Oberding	Bayern	BY	91
85447	Fraunberg	Bayern	BY	91
85452	Moosinning	Bayern	BY	91
85456	Wartenberg	Bayern	BY	91
85457	Wörth	Bayern	BY	91
85459	Berglern	Bayern	BY	91
85461	Bockhorn	Bayern	BY	91
85462	Eitting	Bayern	BY	91
85464	Finsing	Bayern	BY	91
85465	Langenpreising	Bayern	BY	91
85467	Neuching	Bayern	BY	91
85469	Walpertskirchen	Bayern	BY	91
85521	Ottobrunn	Bayern	BY	91
85540	Haar	Bayern	BY	91
85551	Kirchheim bei München	Bayern	BY	91
85560	Ebersberg	Bayern	BY	91
85567	Bruck	Bayern	BY	91
85567	Grafing bei München	Bayern	BY	91
85570	Markt Schwaben	Bayern	BY	91
85570	Ottenhofen	Bayern	BY	91
85579	Neubiberg	Bayern	BY	91
85586	Poing	Bayern	BY	91
85591	Vaterstetten	Bayern	BY	91
85598	Baldham	Bayern	BY	91
85599	Parsdorf	Bayern	BY	91
85604	Zorneding	Bayern	BY	91
85609	Aschheim	Bayern	BY	91
85614	Kirchseeon	Bayern	BY	91
85617	Aßling	Bayern	BY	91
85622	Feldkirchen	Bayern	BY	91
85625	Glonn	Bayern	BY	91
85625	Baiern	Bayern	BY	91
85630	Grasbrunn	Bayern	BY	91
85635	Höhenkirchen-Siegertsbrunn	Bayern	BY	91
85640	Putzbrunn	Bayern	BY	91
85643	Steinhöring	Bayern	BY	91
85646	Anzing	Bayern	BY	91
85649	Brunnthal	Bayern	BY	91
85652	Pliening	Bayern	BY	91
85653	Aying	Bayern	BY	91
85655	Loibersdorf bei Großhelfendorf	Bayern	BY	91
85656	Buch am Buchrain	Bayern	BY	91
85658	Egmating	Bayern	BY	91
85659	Forstern	Bayern	BY	91
85661	Forstinning	Bayern	BY	91
85662	Hohenbrunn	Bayern	BY	91
85664	Hohenlinden	Bayern	BY	91
85665	Moosach	Bayern	BY	91
85667	Oberpframmern	Bayern	BY	91
85669	Pastetten	Bayern	BY	91
85716	Unterschleißheim	Bayern	BY	91
85737	Ismaning	Bayern	BY	91
85748	Garching bei München	Bayern	BY	91
85757	Karlsfeld	Bayern	BY	91
85764	Oberschleißheim	Bayern	BY	91
85774	Unterföhring	Bayern	BY	91
85777	Fahrenzhausen	Bayern	BY	91
85778	Haimhausen	Bayern	BY	91
86492	Egling an der Paar	Bayern	BY	91
86529	Schrobenhausen	Bayern	BY	91
86558	Hohenwart	Bayern	BY	91
86561	Aresing	Bayern	BY	91
86562	Berg im Gau	Bayern	BY	91
86564	Brunnen	Bayern	BY	91
86565	Gachenbach	Bayern	BY	91
86567	Hilgertshausen-Tandern	Bayern	BY	91
86571	Langenmosen	Bayern	BY	91
86579	Waidhofen	Bayern	BY	91
86633	Neuburg an der Donau	Bayern	BY	91
86643	Rennertshofen	Bayern	BY	91
86666	Burgheim	Bayern	BY	91
86668	Karlshuld	Bayern	BY	91
86669	Königsmoos	Bayern	BY	91
86673	Bergheim	Bayern	BY	91
86676	Ehekirchen	Bayern	BY	91
86697	Oberhausen	Bayern	BY	91
86701	Rohrenfels	Bayern	BY	91
86706	Weichering	Bayern	BY	91
86836	Obermeitingen	Bayern	BY	91
86857	Hurlach	Bayern	BY	91
86859	Igling	Bayern	BY	91
86899	Landsberg am Lech	Bayern	BY	91
86911	Dießen am Ammersee	Bayern	BY	91
86916	Kaufering	Bayern	BY	91
86919	Utting am Ammersee	Bayern	BY	91
86920	Denklingen	Bayern	BY	91
86922	Eresing	Bayern	BY	91
86923	Finning	Bayern	BY	91
86925	Fuchstal	Bayern	BY	91
86926	Greifenberg	Bayern	BY	91
86928	Hofstetten	Bayern	BY	91
86929	Penzing	Bayern	BY	91
86931	Prittriching	Bayern	BY	91
86932	Pürgen	Bayern	BY	91
86934	Reichling	Bayern	BY	91
86935	Rott	Bayern	BY	91
86937	Scheuring	Bayern	BY	91
86938	Schondorf am Ammersee	Bayern	BY	91
86940	Schwifting	Bayern	BY	91
86941	Sankt Ottilien	Bayern	BY	91
86943	Thaining	Bayern	BY	91
86944	Unterdießen	Bayern	BY	91
86946	Vilgertshofen	Bayern	BY	91
86947	Weil	Bayern	BY	91
86949	Windach	Bayern	BY	91
86956	Schongau	Bayern	BY	91
86971	Peiting	Bayern	BY	91
86972	Altenstadt	Bayern	BY	91
86974	Apfeldorf	Bayern	BY	91
86975	Bernbeuren	Bayern	BY	91
86977	Burggen	Bayern	BY	91
86978	Hohenfurch	Bayern	BY	91
86980	Ingenried	Bayern	BY	91
86981	Kinsau	Bayern	BY	91
86984	Prem	Bayern	BY	91
86986	Schwabbruck	Bayern	BY	91
86987	Schwabsoien	Bayern	BY	91
86989	Steingaden	Bayern	BY	91
91795	Dollnstein	Bayern	BY	91
91804	Mörnsheim	Bayern	BY	91
91809	Wellheim	Bayern	BY	91
92339	Beilngries	Bayern	BY	91
93336	Altmannstein	Bayern	BY	91
93349	Mindelstetten	Bayern	BY	91
84028	Landshut	Bayern	BY	92
84030	Ergolding	Bayern	BY	92
84030	Landshut	Bayern	BY	92
84032	Landshut	Bayern	BY	92
84032	Altdorf	Bayern	BY	92
84034	Landshut	Bayern	BY	92
84036	Landshut	Bayern	BY	92
84036	Kumhausen	Bayern	BY	92
84048	Mainburg	Bayern	BY	92
84051	Essenbach	Bayern	BY	92
84056	Rottenburg an der Laaber	Bayern	BY	92
84061	Ergoldsbach	Bayern	BY	92
84066	Mallersdorf-Pfaffenberg	Bayern	BY	92
84076	Pfeffenhausen	Bayern	BY	92
84079	Bruckberg	Bayern	BY	92
84082	Laberweinting	Bayern	BY	92
84085	Langquaid	Bayern	BY	92
84088	Neufahrn in Niederbayern	Bayern	BY	92
84089	Aiglsbach	Bayern	BY	92
84091	Attenhofen	Bayern	BY	92
84092	Bayerbach	Bayern	BY	92
84094	Elsendorf	Bayern	BY	92
84095	Furth	Bayern	BY	92
84097	Herrngiersdorf	Bayern	BY	92
84098	Hohenthann	Bayern	BY	92
84100	Niederaichbach	Bayern	BY	92
84101	Obersüßbach	Bayern	BY	92
84103	Postau	Bayern	BY	92
84106	Volkenschwand	Bayern	BY	92
84107	Weihmichl	Bayern	BY	92
84109	Wörth an der Isar	Bayern	BY	92
84130	Dingolfing	Bayern	BY	92
84137	Vilsbiburg	Bayern	BY	92
84140	Gangkofen	Bayern	BY	92
84144	Geisenhausen	Bayern	BY	92
84149	Velden	Bayern	BY	92
84152	Mengkofen	Bayern	BY	92
84155	Bodenkirchen	Bayern	BY	92
84160	Frontenhausen	Bayern	BY	92
84163	Marklkofen	Bayern	BY	92
84164	Moosthenning	Bayern	BY	92
84166	Adlkofen	Bayern	BY	92
84168	Aham	Bayern	BY	92
84169	Altfraunhofen	Bayern	BY	92
84171	Baierbach	Bayern	BY	92
84172	Buch am Erlbach	Bayern	BY	92
84174	Eching	Bayern	BY	92
84175	Schalkham	Bayern	BY	92
84175	Gerzen	Bayern	BY	92
84177	Gottfrieding	Bayern	BY	92
84178	Kröning	Bayern	BY	92
84180	Loiching	Bayern	BY	92
84181	Neufraunhofen	Bayern	BY	92
84183	Niederviehbach	Bayern	BY	92
84184	Tiefenbach	Bayern	BY	92
84186	Vilsheim	Bayern	BY	92
84187	Weng	Bayern	BY	92
84189	Wurmsham	Bayern	BY	92
84307	Eggenfelden	Bayern	BY	92
84323	Massing	Bayern	BY	92
84326	Falkenberg	Bayern	BY	92
84326	Rimbach	Bayern	BY	92
84329	Wurmannsquick	Bayern	BY	92
84332	Hebertsfelden	Bayern	BY	92
84333	Malgersdorf	Bayern	BY	92
84335	Mitterskirchen	Bayern	BY	92
84337	Schönau	Bayern	BY	92
84339	Unterdietfurt	Bayern	BY	92
84347	Pfarrkirchen	Bayern	BY	92
84359	Simbach am Inn	Bayern	BY	92
84364	Bad Birnbach	Bayern	BY	92
84367	Tann	Bayern	BY	92
84367	Reut	Bayern	BY	92
84367	Zeilarn	Bayern	BY	92
84371	Triftern	Bayern	BY	92
84375	Kirchdorf am Inn	Bayern	BY	92
84378	Dietersburg	Bayern	BY	92
84381	Johanniskirchen	Bayern	BY	92
84384	Wittibreut	Bayern	BY	92
84385	Egglham	Bayern	BY	92
84387	Julbach	Bayern	BY	92
84389	Postmünster	Bayern	BY	92
84552	Geratskirchen	Bayern	BY	92
93077	Bad Abbach	Bayern	BY	92
93309	Kelheim	Bayern	BY	92
93326	Abensberg	Bayern	BY	92
93333	Neustadt an der Donau	Bayern	BY	92
93339	Riedenburg	Bayern	BY	92
93342	Saal an der Donau	Bayern	BY	92
93343	Essing	Bayern	BY	92
93345	Hausen	Bayern	BY	92
93346	Ihrlerstein	Bayern	BY	92
93348	Kirchdorf	Bayern	BY	92
93351	Painten	Bayern	BY	92
93352	Rohr in Niederbayern	Bayern	BY	92
93354	Biburg	Bayern	BY	92
93354	Siegenburg	Bayern	BY	92
93356	Teugn	Bayern	BY	92
93358	Train	Bayern	BY	92
93359	Wildenberg	Bayern	BY	92
93471	Arnbruck	Bayern	BY	92
94032	Passau	Bayern	BY	92
94034	Passau	Bayern	BY	92
94036	Passau	Bayern	BY	92
94051	Hauzenberg	Bayern	BY	92
94060	Pocking	Bayern	BY	92
94065	Waldkirchen	Bayern	BY	92
94072	Bad Füssing	Bayern	BY	92
94078	Freyung	Bayern	BY	92
94081	Fürstenzell	Bayern	BY	92
94086	Bad Griesbach im Rottal	Bayern	BY	92
94089	Neureichenau	Bayern	BY	92
94094	Rotthalmünster	Bayern	BY	92
94094	Malching	Bayern	BY	92
94099	Ruhstorf an der Rott	Bayern	BY	92
94104	Witzmannsberg	Bayern	BY	92
94104	Tittling	Bayern	BY	92
94107	Untergriesbach	Bayern	BY	92
94110	Wegscheid	Bayern	BY	92
94113	Tiefenbach	Bayern	BY	92
94116	Hutthurm	Bayern	BY	92
94118	Jandelsbrunn	Bayern	BY	92
94121	Salzweg	Bayern	BY	92
94124	Büchlberg	Bayern	BY	92
94127	Neuburg am Inn	Bayern	BY	92
94130	Obernzell	Bayern	BY	92
94133	Röhrnbach	Bayern	BY	92
94136	Thyrnau	Bayern	BY	92
94137	Bayerbach	Bayern	BY	92
94139	Breitenberg	Bayern	BY	92
94140	Ering	Bayern	BY	92
94142	Fürsteneck	Bayern	BY	92
94143	Grainet	Bayern	BY	92
94145	Haidmühle	Bayern	BY	92
94146	Hinterschmiding	Bayern	BY	92
94148	Kirchham	Bayern	BY	92
94149	Kößlarn	Bayern	BY	92
94151	Mauth	Bayern	BY	92
94152	Neuhaus am Inn	Bayern	BY	92
94154	Neukirchen vorm Wald	Bayern	BY	92
94155	Otterskirchen	Bayern	BY	92
94157	Perlesreut	Bayern	BY	92
94158	Philippsreut	Bayern	BY	92
94160	Ringelai	Bayern	BY	92
94161	Ruderting	Bayern	BY	92
94163	Saldenburg	Bayern	BY	92
94164	Sonnen	Bayern	BY	92
94166	Stubenberg	Bayern	BY	92
94167	Tettenweis	Bayern	BY	92
94169	Thurmansbang	Bayern	BY	92
94209	Regen	Bayern	BY	92
94227	Zwiesel	Bayern	BY	92
94227	Lindberg	Bayern	BY	92
94234	Viechtach	Bayern	BY	92
94239	Zachenberg	Bayern	BY	92
94239	Gotteszell	Bayern	BY	92
94239	Ruhmannsfelden	Bayern	BY	92
94244	Geiersthal	Bayern	BY	92
94244	Teisnach	Bayern	BY	92
94249	Bodenmais	Bayern	BY	92
94250	Achslach	Bayern	BY	92
94252	Bayerisch Eisenstein	Bayern	BY	92
94253	Bischofsmais	Bayern	BY	92
94255	Böbrach	Bayern	BY	92
94256	Drachselsried	Bayern	BY	92
94258	Frauenau	Bayern	BY	92
94259	Kirchberg im Wald	Bayern	BY	92
94261	Kirchdorf im Wald	Bayern	BY	92
94262	Kollnburg	Bayern	BY	92
94264	Langdorf	Bayern	BY	92
94265	Patersdorf	Bayern	BY	92
94267	Prackenbach	Bayern	BY	92
94269	Rinchnach	Bayern	BY	92
94315	Straubing	Bayern	BY	92
94327	Bogen	Bayern	BY	92
94330	Salching	Bayern	BY	92
94330	Aiterhofen	Bayern	BY	92
94333	Geiselhöring	Bayern	BY	92
94336	Hunderdorf	Bayern	BY	92
94336	Windberg	Bayern	BY	92
94339	Leiblfing	Bayern	BY	92
94342	Straßkirchen	Bayern	BY	92
94342	Irlbach	Bayern	BY	92
94344	Wiesenfelden	Bayern	BY	92
94345	Aholfing	Bayern	BY	92
94347	Ascha	Bayern	BY	92
94348	Atting	Bayern	BY	92
94350	Falkenfels	Bayern	BY	92
94351	Feldkirchen	Bayern	BY	92
94353	Haibach	Bayern	BY	92
94354	Haselbach	Bayern	BY	92
94356	Kirchroth	Bayern	BY	92
94357	Konzell	Bayern	BY	92
94359	Loitzendorf	Bayern	BY	92
94360	Mitterfels	Bayern	BY	92
94362	Neukirchen	Bayern	BY	92
94363	Oberschneiding	Bayern	BY	92
94365	Parkstetten	Bayern	BY	92
94366	Perasdorf	Bayern	BY	92
94368	Perkam	Bayern	BY	92
94369	Rain	Bayern	BY	92
94371	Rattenberg	Bayern	BY	92
94372	Rattiszell	Bayern	BY	92
94374	Schwarzach	Bayern	BY	92
94375	Stallwang	Bayern	BY	92
94377	Steinach	Bayern	BY	92
94379	Sankt Englmar	Bayern	BY	92
94405	Landau an der Isar	Bayern	BY	92
94419	Reisbach	Bayern	BY	92
94424	Arnstorf	Bayern	BY	92
94428	Eichendorf	Bayern	BY	92
94431	Pilsting	Bayern	BY	92
94436	Simbach	Bayern	BY	92
94437	Mamming	Bayern	BY	92
94439	Roßbach	Bayern	BY	92
94447	Plattling	Bayern	BY	92
94469	Deggendorf	Bayern	BY	92
94474	Vilshofen	Bayern	BY	92
94481	Grafenau	Bayern	BY	92
94486	Osterhofen	Bayern	BY	92
94491	Hengersberg	Bayern	BY	92
94496	Ortenburg	Bayern	BY	92
94501	Beutelsbach	Bayern	BY	92
94501	Aldersbach	Bayern	BY	92
94501	Aidenbach	Bayern	BY	92
94505	Bernried	Bayern	BY	92
94508	Schöllnach	Bayern	BY	92
94513	Schönberg	Bayern	BY	92
94518	Spiegelau	Bayern	BY	92
94522	Wallersdorf	Bayern	BY	92
94526	Metten	Bayern	BY	92
94527	Aholming	Bayern	BY	92
94529	Aicha vorm Wald	Bayern	BY	92
94530	Auerbach	Bayern	BY	92
94532	Außernzell	Bayern	BY	92
94533	Buchhofen	Bayern	BY	92
94535	Eging am See	Bayern	BY	92
94536	Eppenschlag	Bayern	BY	92
94538	Fürstenstein	Bayern	BY	92
94539	Grafling	Bayern	BY	92
94541	Grattersdorf	Bayern	BY	92
94542	Haarbach	Bayern	BY	92
94544	Hofkirchen	Bayern	BY	92
94545	Hohenau	Bayern	BY	92
94547	Iggensbach	Bayern	BY	92
94548	Innernzell	Bayern	BY	92
94550	Künzing	Bayern	BY	92
94551	Lalling	Bayern	BY	92
94551	Hunding	Bayern	BY	92
94553	Mariaposching	Bayern	BY	92
94554	Moos	Bayern	BY	92
94556	Neuschönau	Bayern	BY	92
94557	Niederalteich	Bayern	BY	92
94559	Niederwinkling	Bayern	BY	92
94560	Offenberg	Bayern	BY	92
94562	Oberpöring	Bayern	BY	92
94563	Otzing	Bayern	BY	92
94565	Erlhof bei Rathsmannsdorf	Bayern	BY	92
94566	Sankt Oswald-Riedlhütte	Bayern	BY	92
94568	Sankt Oswald-Riedlhütte	Bayern	BY	92
94569	Stephansposching	Bayern	BY	92
94571	Schaufling	Bayern	BY	92
94572	Schöfweg	Bayern	BY	92
94574	Wallerfing	Bayern	BY	92
94575	Windorf	Bayern	BY	92
94577	Winzer	Bayern	BY	92
94579	Zenting	Bayern	BY	92
84069	Schierling	Bayern	BY	93
90602	Pyrbaum	Bayern	BY	93
91249	Weigendorf	Bayern	BY	93
91275	Auerbach in der Oberpfalz	Bayern	BY	93
91281	Kirchenthumbach	Bayern	BY	93
92224	Amberg	Bayern	BY	93
92237	Sulzbach-Rosenberg	Bayern	BY	93
92242	Hirschau	Bayern	BY	93
92245	Kümmersbruck	Bayern	BY	93
92249	Vilseck	Bayern	BY	93
92253	Schnaittenbach	Bayern	BY	93
92256	Hahnbach	Bayern	BY	93
92259	Neukirchen bei Sulzbach-Rosenberg	Bayern	BY	93
92260	Ammerthal	Bayern	BY	93
92262	Birgland	Bayern	BY	93
92263	Ebermannsdorf	Bayern	BY	93
92265	Edelsfeld	Bayern	BY	93
92266	Ensdorf	Bayern	BY	93
92268	Etzelwang	Bayern	BY	93
92269	Fensterbach	Bayern	BY	93
92271	Freihung	Bayern	BY	93
92272	Freudenberg	Bayern	BY	93
92274	Gebenbach	Bayern	BY	93
92275	Hirschbach	Bayern	BY	93
92277	Hohenburg	Bayern	BY	93
92278	Illschwang	Bayern	BY	93
92280	Kastl	Bayern	BY	93
92281	Königstein	Bayern	BY	93
92283	Lauterhofen	Bayern	BY	93
92284	Poppenricht	Bayern	BY	93
92286	Rieden	Bayern	BY	93
92287	Schmidmühlen	Bayern	BY	93
92289	Ursensollen	Bayern	BY	93
92318	Neumarkt in der Oberpfalz	Bayern	BY	93
92331	Parsberg	Bayern	BY	93
92331	Lupburg	Bayern	BY	93
92334	Berching	Bayern	BY	93
92342	Freystadt	Bayern	BY	93
92345	Dietfurt an der Altmühl	Bayern	BY	93
92348	Berg bei Neumarkt in der Oberpfalz	Bayern	BY	93
92353	Postbauer-Heng	Bayern	BY	93
92355	Velburg	Bayern	BY	93
92358	Seubersdorf in der Oberpfalz	Bayern	BY	93
92360	Mühlhausen	Bayern	BY	93
92361	Berngau	Bayern	BY	93
92363	Breitenbrunn	Bayern	BY	93
92364	Deining	Bayern	BY	93
92366	Hohenfels	Bayern	BY	93
92367	Pilsach	Bayern	BY	93
92369	Sengenthal	Bayern	BY	93
92421	Schwandorf	Bayern	BY	93
92431	Neunburg vorm Wald	Bayern	BY	93
92436	Bruck in der Oberpfalz	Bayern	BY	93
92439	Bodenwöhr	Bayern	BY	93
92442	Wackersdorf	Bayern	BY	93
92444	Rötz	Bayern	BY	93
92445	Neukirchen-Balbini	Bayern	BY	93
92447	Schwarzhofen	Bayern	BY	93
92449	Steinberg	Bayern	BY	93
92507	Nabburg	Bayern	BY	93
92521	Schwarzenfeld	Bayern	BY	93
92526	Oberviechtach	Bayern	BY	93
92533	Wernberg-Köblitz	Bayern	BY	93
92536	Pfreimd	Bayern	BY	93
92536	Pfreimd Pfreimd	Bayern	BY	93
92536	Pfreimd Untersteinbach	Bayern	BY	93
92536	Pfreimd Weihern	Bayern	BY	93
92536	Iffelsdorf	Bayern	BY	93
92536	Pfreimd Hohentreswitz	Bayern	BY	93
92536	Pfreimd Pamsendorf	Bayern	BY	93
92539	Schönsee	Bayern	BY	93
92540	Altendorf	Bayern	BY	93
92542	Dieterskirchen	Bayern	BY	93
92543	Guteneck	Bayern	BY	93
92545	Niedermurach	Bayern	BY	93
92546	Schmidgaden	Bayern	BY	93
92548	Schwarzach bei Nabburg	Bayern	BY	93
92549	Stadlern	Bayern	BY	93
92551	Stulln	Bayern	BY	93
92552	Teunz	Bayern	BY	93
92554	Thanstein	Bayern	BY	93
92555	Trausnitz	Bayern	BY	93
92557	Weiding	Bayern	BY	93
92559	Winklarn	Bayern	BY	93
92637	Weiden	Bayern	BY	93
92637	Theisseil	Bayern	BY	93
92648	Vohenstrauß	Bayern	BY	93
92655	Grafenwöhr	Bayern	BY	93
92660	Neustadt an der Waldnaab	Bayern	BY	93
92665	Kirchendemenreuth	Bayern	BY	93
92665	Altenstadt an der Waldnaab	Bayern	BY	93
92670	Windischeschenbach	Bayern	BY	93
92676	Speinshart	Bayern	BY	93
92676	Eschenbach in der Oberpfalz	Bayern	BY	93
92681	Erbendorf	Bayern	BY	93
92685	Floß	Bayern	BY	93
92690	Pressath	Bayern	BY	93
92693	Eslarn	Bayern	BY	93
92694	Etzenricht	Bayern	BY	93
92696	Flossenbürg	Bayern	BY	93
92697	Georgenberg	Bayern	BY	93
92699	Irchenrieth	Bayern	BY	93
92699	Bechtsrieth	Bayern	BY	93
92700	Kaltenbrunn; Oberpfalz	Bayern	BY	93
92702	Kohlberg	Bayern	BY	93
92703	Krummennaab	Bayern	BY	93
92705	Leuchtenberg	Bayern	BY	93
92706	Luhe-Wildenau	Bayern	BY	93
92708	Mantel	Bayern	BY	93
92709	Moosbach	Bayern	BY	93
92711	Parkstein	Bayern	BY	93
92712	Pirk	Bayern	BY	93
92714	Pleystein	Bayern	BY	93
92715	Püchersreuth	Bayern	BY	93
92717	Reuth bei Erbendorf	Bayern	BY	93
92718	Schirmitz	Bayern	BY	93
92720	Schwarzenbach	Bayern	BY	93
92721	Störnstein	Bayern	BY	93
92723	Gleiritsch	Bayern	BY	93
92723	Tännesberg	Bayern	BY	93
92724	Trabitz	Bayern	BY	93
92726	Waidhaus	Bayern	BY	93
92727	Waldthurn	Bayern	BY	93
92729	Weiherhammer	Bayern	BY	93
93047	Regensburg	Bayern	BY	93
93049	Regensburg	Bayern	BY	93
93051	Regensburg	Bayern	BY	93
93053	Regensburg	Bayern	BY	93
93055	Regensburg	Bayern	BY	93
93057	Regensburg	Bayern	BY	93
93059	Regensburg	Bayern	BY	93
93073	Neutraubling	Bayern	BY	93
93080	Pentling	Bayern	BY	93
93083	Obertraubling	Bayern	BY	93
93086	Wörth an der Donau	Bayern	BY	93
93087	Alteglofsheim	Bayern	BY	93
93089	Aufhausen	Bayern	BY	93
93090	Bach an der Donau	Bayern	BY	93
93092	Barbing	Bayern	BY	93
93093	Donaustauf	Bayern	BY	93
93095	Hagelstadt	Bayern	BY	93
93096	Köfering	Bayern	BY	93
93098	Mintraching	Bayern	BY	93
93099	Mötzing	Bayern	BY	93
93101	Pfakofen	Bayern	BY	93
93102	Pfatter	Bayern	BY	93
93104	Riekofen	Bayern	BY	93
93104	Sünching	Bayern	BY	93
93105	Tegernheim	Bayern	BY	93
93107	Thalmassing	Bayern	BY	93
93109	Wiesent	Bayern	BY	93
93128	Regenstauf	Bayern	BY	93
93133	Burglengenfeld	Bayern	BY	93
93138	Lappersdorf	Bayern	BY	93
93142	Maxhütte-Haidhof	Bayern	BY	93
93149	Nittenau	Bayern	BY	93
93152	Nittendorf	Bayern	BY	93
93155	Hemau	Bayern	BY	93
93158	Teublitz	Bayern	BY	93
93161	Sinzing	Bayern	BY	93
93164	Laaber	Bayern	BY	93
93164	Brunn	Bayern	BY	93
93167	Falkenstein	Bayern	BY	93
93170	Bernhardswald	Bayern	BY	93
93173	Wenzenbach	Bayern	BY	93
93176	Beratzhausen	Bayern	BY	93
93177	Altenthann	Bayern	BY	93
93179	Brennberg	Bayern	BY	93
93180	Deuerling	Bayern	BY	93
93182	Duggendorf	Bayern	BY	93
93183	Kallmünz	Bayern	BY	93
93183	Holzheim am Forst	Bayern	BY	93
93185	Michelsneukirchen	Bayern	BY	93
93186	Pettendorf	Bayern	BY	93
93188	Pielenhofen	Bayern	BY	93
93189	Reichenbach	Bayern	BY	93
93191	Rettenbach	Bayern	BY	93
93192	Wald	Bayern	BY	93
93194	Walderbach	Bayern	BY	93
93195	Wolfsegg	Bayern	BY	93
93197	Zeitlarn	Bayern	BY	93
93199	Zell	Bayern	BY	93
93413	Cham	Bayern	BY	93
93426	Roding	Bayern	BY	93
93437	Furth im Wald	Bayern	BY	93
93444	Kötzting	Bayern	BY	93
93449	Waldmünchen	Bayern	BY	93
93453	Neukirchen beim Heiligen Blut	Bayern	BY	93
93455	Traitsching	Bayern	BY	93
93458	Eschlkam	Bayern	BY	93
93462	Lam	Bayern	BY	93
93464	Tiefenbach	Bayern	BY	93
93466	Chamerau	Bayern	BY	93
93468	Miltach	Bayern	BY	93
93470	Lohberg	Bayern	BY	93
93473	Arnschwang	Bayern	BY	93
93474	Arrach	Bayern	BY	93
93476	Blaibach	Bayern	BY	93
93477	Gleißenberg	Bayern	BY	93
93479	Grafenwiesen	Bayern	BY	93
93480	Hohenwarth	Bayern	BY	93
93482	Pemfling	Bayern	BY	93
93483	Pösing	Bayern	BY	93
93485	Rimbach	Bayern	BY	93
93486	Runding	Bayern	BY	93
93488	Schönthal	Bayern	BY	93
93489	Schorndorf	Bayern	BY	93
93491	Stamsried	Bayern	BY	93
93492	Treffelstein	Bayern	BY	93
93494	Waffenbrunn	Bayern	BY	93
93495	Weiding	Bayern	BY	93
93497	Willmering	Bayern	BY	93
93499	Zandt	Bayern	BY	93
95478	Kemnath	Bayern	BY	93
95505	Immenreuth	Bayern	BY	93
95506	Kastl	Bayern	BY	93
95508	Kulmain	Bayern	BY	93
95514	Neustadt am Kulm	Bayern	BY	93
95519	Schlammersdorf	Bayern	BY	93
95519	Vorbach	Bayern	BY	93
95643	Tirschenreuth	Bayern	BY	93
95652	Waldsassen	Bayern	BY	93
95666	Leonberg	Bayern	BY	93
95666	Mitterteich	Bayern	BY	93
95671	Bärnau	Bayern	BY	93
95676	Wiesau	Bayern	BY	93
95679	Waldershof	Bayern	BY	93
95682	Brand	Bayern	BY	93
95683	Ebnath	Bayern	BY	93
95685	Falkenberg	Bayern	BY	93
95688	Friedenfels	Bayern	BY	93
95689	Fuchsmühl	Bayern	BY	93
95692	Konnersreuth	Bayern	BY	93
95695	Mähring	Bayern	BY	93
95698	Neualbenreuth	Bayern	BY	93
95700	Neusorg	Bayern	BY	93
95701	Pechbrunn	Bayern	BY	93
95703	Plößberg	Bayern	BY	93
95704	Pullenreuth	Bayern	BY	93
91077	Hetzles	Bayern	BY	94
91077	Dormitz	Bayern	BY	94
91077	Kleinsendelbach	Bayern	BY	94
91077	Neunkirchen am Brand	Bayern	BY	94
91090	Effeltrich	Bayern	BY	94
91094	Langensendelbach	Bayern	BY	94
91099	Poxdorf	Bayern	BY	94
91257	Pegnitz	Bayern	BY	94
91278	Pottenstein	Bayern	BY	94
91282	Betzenstein	Bayern	BY	94
91286	Obertrubach	Bayern	BY	94
91287	Plech	Bayern	BY	94
91289	Schnabelwaid	Bayern	BY	94
91301	Forchheim	Bayern	BY	94
91320	Ebermannstadt	Bayern	BY	94
91322	Gräfenberg	Bayern	BY	94
91327	Gößweinstein	Bayern	BY	94
91330	Eggolsheim	Bayern	BY	94
91332	Heiligenstadt	Bayern	BY	94
91336	Heroldsbach	Bayern	BY	94
91338	Igensdorf	Bayern	BY	94
91344	Waischenfeld	Bayern	BY	94
91346	Wiesenttal	Bayern	BY	94
91347	Aufseß	Bayern	BY	94
91349	Egloffstein	Bayern	BY	94
91352	Hallerndorf	Bayern	BY	94
91353	Hausen	Bayern	BY	94
91355	Hiltpoltstein	Bayern	BY	94
91356	Kirchehrenbach	Bayern	BY	94
91358	Kunreuth	Bayern	BY	94
91359	Leutenbach	Bayern	BY	94
91361	Pinzberg	Bayern	BY	94
91362	Pretzfeld	Bayern	BY	94
91364	Unterleinleiter	Bayern	BY	94
91365	Weilersbach	Bayern	BY	94
91367	Weißenohe	Bayern	BY	94
91369	Wiesenthau	Bayern	BY	94
95028	Hof	Bayern	BY	94
95030	Hof	Bayern	BY	94
95032	Hof	Bayern	BY	94
95100	Selb	Bayern	BY	94
95111	Rehau	Bayern	BY	94
95119	Naila	Bayern	BY	94
95126	Schwarzenbach an der Saale	Bayern	BY	94
95131	Schwarzenbach am Wald	Bayern	BY	94
95138	Bad Steben	Bayern	BY	94
95145	Oberkotzau	Bayern	BY	94
95152	Selbitz	Bayern	BY	94
95158	Kirchenlamitz	Bayern	BY	94
95163	Weißenstadt	Bayern	BY	94
95168	Marktleuthen	Bayern	BY	94
95173	Schönwald	Bayern	BY	94
95176	Konradsreuth	Bayern	BY	94
95179	Geroldsgrün	Bayern	BY	94
95180	Berg	Bayern	BY	94
95182	Döhlau	Bayern	BY	94
95183	Feilitzsch	Bayern	BY	94
95183	Trogen	Bayern	BY	94
95183	Töpen	Bayern	BY	94
95185	Gattendorf	Bayern	BY	94
95186	Höchstädt im Fichtelgebirge	Bayern	BY	94
95188	Issigau	Bayern	BY	94
95189	Köditz	Bayern	BY	94
95191	Leupoldsgrün	Bayern	BY	94
95192	Lichtenberg	Bayern	BY	94
95194	Regnitzlosau	Bayern	BY	94
95195	Röslau	Bayern	BY	94
95197	Schauenstein	Bayern	BY	94
95199	Thierstein	Bayern	BY	94
95213	Münchberg	Bayern	BY	94
95233	Helmbrechts	Bayern	BY	94
95234	Sparneck	Bayern	BY	94
95236	Stammbach	Bayern	BY	94
95237	Weißdorf	Bayern	BY	94
95239	Zell	Bayern	BY	94
95326	Kulmbach	Bayern	BY	94
95336	Mainleus	Bayern	BY	94
95339	Neuenmarkt	Bayern	BY	94
95339	Wirsberg	Bayern	BY	94
95346	Stadtsteinach	Bayern	BY	94
95349	Thurnau	Bayern	BY	94
95352	Marktleugast	Bayern	BY	94
95355	Presseck	Bayern	BY	94
95356	Grafengehaig	Bayern	BY	94
95358	Guttenberg	Bayern	BY	94
95359	Kasendorf	Bayern	BY	94
95361	Ködnitz	Bayern	BY	94
95362	Kupferberg	Bayern	BY	94
95364	Ludwigschorgast	Bayern	BY	94
95365	Rugendorf	Bayern	BY	94
95367	Trebgast	Bayern	BY	94
95369	Untersteinach	Bayern	BY	94
95444	Bayreuth	Bayern	BY	94
95445	Bayreuth	Bayern	BY	94
95447	Bayreuth	Bayern	BY	94
95448	Bayreuth	Bayern	BY	94
95460	Bad Berneck im Fichtelgebirge	Bayern	BY	94
95463	Bindlach	Bayern	BY	94
95466	Weidenberg	Bayern	BY	94
95466	Kirchenpingarten	Bayern	BY	94
95469	Speichersdorf	Bayern	BY	94
95473	Haag	Bayern	BY	94
95473	Creußen	Bayern	BY	94
95473	Prebitz	Bayern	BY	94
95482	Gefrees	Bayern	BY	94
95485	Warmensteinach	Bayern	BY	94
95488	Eckersdorf	Bayern	BY	94
95490	Mistelgau	Bayern	BY	94
95491	Ahorntal	Bayern	BY	94
95493	Bischofsgrün	Bayern	BY	94
95494	Gesees	Bayern	BY	94
95496	Glashütten	Bayern	BY	94
95497	Goldkronach	Bayern	BY	94
95499	Harsdorf	Bayern	BY	94
95500	Heinersreuth	Bayern	BY	94
95502	Himmelkron	Bayern	BY	94
95503	Hummeltal	Bayern	BY	94
95509	Marktschorgast	Bayern	BY	94
95511	Mistelbach	Bayern	BY	94
95512	Neudrossenfeld	Bayern	BY	94
95515	Plankenfels	Bayern	BY	94
95517	Seybothenreuth	Bayern	BY	94
95517	Emtmannsberg	Bayern	BY	94
95615	Marktredwitz	Bayern	BY	94
95632	Wunsiedel	Bayern	BY	94
95659	Arzberg	Bayern	BY	94
95680	Bad Alexandersbad	Bayern	BY	94
95686	Fichtelberg	Bayern	BY	94
95691	Hohenberg an der Eger	Bayern	BY	94
95694	Mehlmeisel	Bayern	BY	94
95697	Nagel	Bayern	BY	94
95706	Schirnding	Bayern	BY	94
95707	Thiersheim	Bayern	BY	94
95709	Tröstau	Bayern	BY	94
96047	Bamberg	Bayern	BY	94
96049	Bamberg	Bayern	BY	94
96050	Bamberg	Bayern	BY	94
96052	Bamberg	Bayern	BY	94
96103	Hallstadt	Bayern	BY	94
96110	Scheßlitz	Bayern	BY	94
96114	Hirschaid	Bayern	BY	94
96117	Memmelsdorf	Bayern	BY	94
96120	Bischberg	Bayern	BY	94
96123	Litzendorf	Bayern	BY	94
96129	Strullendorf	Bayern	BY	94
96132	Schlüsselfeld	Bayern	BY	94
96135	Stegaurach	Bayern	BY	94
96138	Burgebrach	Bayern	BY	94
96142	Hollfeld	Bayern	BY	94
96145	Seßlach	Bayern	BY	94
96146	Altendorf	Bayern	BY	94
96148	Baunach	Bayern	BY	94
96149	Breitengüßbach	Bayern	BY	94
96154	Burgwindheim	Bayern	BY	94
96155	Buttenheim	Bayern	BY	94
96157	Ebrach	Bayern	BY	94
96158	Frensdorf	Bayern	BY	94
96161	Gerach	Bayern	BY	94
96163	Gundelsheim	Bayern	BY	94
96164	Kemmern	Bayern	BY	94
96167	Königsfeld	Bayern	BY	94
96169	Lauter	Bayern	BY	94
96170	Priesendorf	Bayern	BY	94
96173	Oberhaid	Bayern	BY	94
96175	Pettstadt	Bayern	BY	94
96178	Pommersfelden	Bayern	BY	94
96179	Rattelsdorf	Bayern	BY	94
96182	Reckendorf	Bayern	BY	94
96185	Schönbrunn	Bayern	BY	94
96187	Stadelhofen	Bayern	BY	94
96191	Viereth-Trunstadt	Bayern	BY	94
96194	Walsdorf	Bayern	BY	94
96196	Wattendorf	Bayern	BY	94
96197	Wonsees	Bayern	BY	94
96199	Zapfendorf	Bayern	BY	94
96215	Lichtenfels	Bayern	BY	94
96224	Burgkunstadt	Bayern	BY	94
96231	Bad Staffelstein	Bayern	BY	94
96237	Ebersdorf	Bayern	BY	94
96242	Sonnefeld	Bayern	BY	94
96247	Michelau in Oberfranken	Bayern	BY	94
96250	Ebensfeld	Bayern	BY	94
96253	Untersiemau	Bayern	BY	94
96257	Marktgraitz	Bayern	BY	94
96257	Redwitz an der Rodach	Bayern	BY	94
96260	Weismain	Bayern	BY	94
96264	Altenkunstadt	Bayern	BY	94
96268	Mitwitz	Bayern	BY	94
96269	Großheirath	Bayern	BY	94
96271	Grub am Forst	Bayern	BY	94
96272	Hochstadt am Main	Bayern	BY	94
96274	Itzgrund	Bayern	BY	94
96275	Marktzeuln	Bayern	BY	94
96277	Schneckenlohe	Bayern	BY	94
96279	Weidhausen bei Coburg	Bayern	BY	94
96317	Kronach	Bayern	BY	94
96328	Küps	Bayern	BY	94
96332	Pressig	Bayern	BY	94
96337	Ludwigsstadt	Bayern	BY	94
96342	Stockheim	Bayern	BY	94
96346	Wallenfels	Bayern	BY	94
96349	Steinwiesen	Bayern	BY	94
96352	Wilhelmsthal	Bayern	BY	94
96355	Tettau	Bayern	BY	94
96358	Teuschnitz	Bayern	BY	94
96358	Reichenbach	Bayern	BY	94
96361	Steinbach am Wald	Bayern	BY	94
96364	Marktrodach	Bayern	BY	94
96365	Nordhalben	Bayern	BY	94
96367	Tschirn	Bayern	BY	94
96369	Weißenbrunn	Bayern	BY	94
96450	Coburg	Bayern	BY	94
96465	Neustadt bei Coburg	Bayern	BY	94
96472	Rödental	Bayern	BY	94
96476	Bad Rodach	Bayern	BY	94
96479	Weitramsdorf	Bayern	BY	94
96482	Ahorn	Bayern	BY	94
96484	Meeder	Bayern	BY	94
96486	Lautertal	Bayern	BY	94
96487	Dörfles-Esbach	Bayern	BY	94
96489	Niederfüllbach	Bayern	BY	94
90402	Nürnberg	Bayern	BY	95
90403	Nürnberg	Bayern	BY	95
90408	Nürnberg	Bayern	BY	95
90409	Nürnberg	Bayern	BY	95
90411	Nürnberg	Bayern	BY	95
90419	Nürnberg	Bayern	BY	95
90425	Nürnberg	Bayern	BY	95
90427	Nürnberg	Bayern	BY	95
90429	Nürnberg	Bayern	BY	95
90431	Nürnberg	Bayern	BY	95
90439	Nürnberg	Bayern	BY	95
90441	Nürnberg	Bayern	BY	95
90443	Nürnberg	Bayern	BY	95
90449	Nürnberg	Bayern	BY	95
90451	Nürnberg	Bayern	BY	95
90453	Nürnberg	Bayern	BY	95
90455	Nürnberg	Bayern	BY	95
90457	Moorenbrunn	Bayern	BY	95
90459	Nürnberg	Bayern	BY	95
90461	Nürnberg	Bayern	BY	95
90469	Nürnberg	Bayern	BY	95
90471	Nürnberg	Bayern	BY	95
90473	Nürnberg	Bayern	BY	95
90475	Nürnberg	Bayern	BY	95
90478	Nürnberg	Bayern	BY	95
90480	Nürnberg	Bayern	BY	95
90482	Nürnberg	Bayern	BY	95
90489	Nürnberg	Bayern	BY	95
90491	Nürnberg	Bayern	BY	95
90513	Zirndorf	Bayern	BY	95
90518	Altdorf	Bayern	BY	95
90522	Oberasbach	Bayern	BY	95
90530	Wendelstein	Bayern	BY	95
90537	Feucht	Bayern	BY	95
90542	Eckental	Bayern	BY	95
90547	Stein bei Nürnberg	Bayern	BY	95
90552	Röthenbach an der Pegnitz	Bayern	BY	95
90556	Cadolzburg	Bayern	BY	95
90556	Seukendorf	Bayern	BY	95
90559	Burgthann	Bayern	BY	95
90562	Heroldsberg	Bayern	BY	95
90562	Kalchreuth	Bayern	BY	95
90571	Schwaig	Bayern	BY	95
90574	Roßtal	Bayern	BY	95
90579	Langenzenn	Bayern	BY	95
90584	Allersberg	Bayern	BY	95
90587	Tuchenbach	Bayern	BY	95
90587	Obermichelbach	Bayern	BY	95
90587	Veitsbronn	Bayern	BY	95
90592	Schwarzenbruck	Bayern	BY	95
90596	Schwanstetten	Bayern	BY	95
90599	Dietenhofen	Bayern	BY	95
90607	Rückersdorf	Bayern	BY	95
90610	Winkelhaid	Bayern	BY	95
90613	Großhabersdorf	Bayern	BY	95
90614	Ammerndorf	Bayern	BY	95
90616	Neuhof an der Zenn	Bayern	BY	95
90617	Puschendorf	Bayern	BY	95
90619	Trautskirchen	Bayern	BY	95
90762	Fürth	Bayern	BY	95
90763	Fürth	Bayern	BY	95
90765	Fürth	Bayern	BY	95
90766	Fürth	Bayern	BY	95
90768	Fürth	Bayern	BY	95
91052	Erlangen	Bayern	BY	95
91054	Erlangen	Bayern	BY	95
91054	Buckenhof	Bayern	BY	95
91056	Erlangen	Bayern	BY	95
91058	Erlangen	Bayern	BY	95
91074	Herzogenaurach	Bayern	BY	95
91080	Uttenreuth	Bayern	BY	95
91080	Spardorf	Bayern	BY	95
91080	Marloffstein	Bayern	BY	95
91083	Baiersdorf	Bayern	BY	95
91085	Weisendorf	Bayern	BY	95
91086	Aurachtal	Bayern	BY	95
91088	Bubenreuth	Bayern	BY	95
91091	Großenseebach	Bayern	BY	95
91093	Heßdorf	Bayern	BY	95
91096	Möhrendorf	Bayern	BY	95
91097	Oberreichenbach	Bayern	BY	95
91126	Schwabach	Bayern	BY	95
91126	Kammerstein	Bayern	BY	95
91126	Rednitzhembach	Bayern	BY	95
91154	Roth	Bayern	BY	95
91161	Hilpoltstein	Bayern	BY	95
91166	Georgensgmünd	Bayern	BY	95
91171	Greding	Bayern	BY	95
91174	Spalt	Bayern	BY	95
91177	Thalmässing	Bayern	BY	95
91180	Heideck	Bayern	BY	95
91183	Abenberg	Bayern	BY	95
91186	Büchenbach	Bayern	BY	95
91187	Röttenbach	Bayern	BY	95
91189	Rohr	Bayern	BY	95
91207	Lauf an der Pegnitz	Bayern	BY	95
91217	Hersbruck	Bayern	BY	95
91220	Schnaittach	Bayern	BY	95
91224	Pommelsbrunn	Bayern	BY	95
91227	Leinburg	Bayern	BY	95
91230	Happurg	Bayern	BY	95
91233	Neunkirchen am Sand	Bayern	BY	95
91235	Hartenstein	Bayern	BY	95
91235	Velden	Bayern	BY	95
91236	Alfeld	Bayern	BY	95
91238	Engelthal	Bayern	BY	95
91238	Offenhausen	Bayern	BY	95
91239	Henfenfeld	Bayern	BY	95
91241	Kirchensittenbach	Bayern	BY	95
91242	Ottensoos	Bayern	BY	95
91244	Reichenschwand	Bayern	BY	95
91245	Simmelsdorf	Bayern	BY	95
91247	Vorra	Bayern	BY	95
91284	Neuhaus an der Pegnitz	Bayern	BY	95
91315	Höchstadt an der Aisch	Bayern	BY	95
91325	Adelsdorf	Bayern	BY	95
91334	Hemhofen	Bayern	BY	95
91341	Röttenbach	Bayern	BY	95
91350	Gremsdorf	Bayern	BY	95
91413	Neustadt an der Aisch	Bayern	BY	95
91438	Bad Windsheim	Bayern	BY	95
91443	Scheinfeld	Bayern	BY	95
91448	Emskirchen	Bayern	BY	95
91452	Wilhermsdorf	Bayern	BY	95
91456	Diespeck	Bayern	BY	95
91459	Markt Erlbach	Bayern	BY	95
91460	Baudenbach	Bayern	BY	95
91462	Dachsbach	Bayern	BY	95
91463	Dietersheim	Bayern	BY	95
91465	Ergersheim	Bayern	BY	95
91466	Gerhardshofen	Bayern	BY	95
91468	Gutenstetten	Bayern	BY	95
91469	Hagenbüchach	Bayern	BY	95
91471	Illesheim	Bayern	BY	95
91472	Ipsheim	Bayern	BY	95
91474	Langenfeld	Bayern	BY	95
91475	Lonnerstadt	Bayern	BY	95
91477	Markt Bibart	Bayern	BY	95
91478	Markt Nordheim	Bayern	BY	95
91480	Markt Taschendorf	Bayern	BY	95
91481	Münchsteinach	Bayern	BY	95
91483	Oberscheinfeld	Bayern	BY	95
91484	Sugenheim	Bayern	BY	95
91486	Uehlfeld	Bayern	BY	95
91487	Vestenbergsgreuth	Bayern	BY	95
91489	Wilhelmsdorf	Bayern	BY	95
91522	Ansbach	Bayern	BY	95
91541	Rothenburg ob der Tauber	Bayern	BY	95
91550	Dinkelsbühl	Bayern	BY	95
91555	Feuchtwangen	Bayern	BY	95
91560	Heilsbronn	Bayern	BY	95
91564	Neuendettelsau	Bayern	BY	95
91567	Herrieden	Bayern	BY	95
91572	Bechhofen	Bayern	BY	95
91575	Windsbach	Bayern	BY	95
91578	Leutershausen	Bayern	BY	95
91580	Petersaurach	Bayern	BY	95
91583	Schillingsfürst	Bayern	BY	95
91583	Diebach	Bayern	BY	95
91586	Lichtenau	Bayern	BY	95
91587	Adelshofen	Bayern	BY	95
91589	Aurach	Bayern	BY	95
91590	Bruckberg	Bayern	BY	95
91592	Buch am Wald	Bayern	BY	95
91593	Burgbernheim	Bayern	BY	95
91595	Burgoberbach	Bayern	BY	95
91596	Burk	Bayern	BY	95
91598	Colmberg	Bayern	BY	95
91599	Dentlein am Forst	Bayern	BY	95
91601	Dombühl	Bayern	BY	95
91602	Dürrwangen	Bayern	BY	95
91604	Flachslanden	Bayern	BY	95
91605	Gallmersgarten	Bayern	BY	95
91607	Gebsattel	Bayern	BY	95
91608	Geslau	Bayern	BY	95
91610	Insingen	Bayern	BY	95
91611	Lehrberg	Bayern	BY	95
91613	Marktbergel	Bayern	BY	95
91614	Mönchsroth	Bayern	BY	95
91616	Neusitz	Bayern	BY	95
91617	Oberdachstetten	Bayern	BY	95
91619	Obernzenn	Bayern	BY	95
91620	Ohrenbach	Bayern	BY	95
91622	Rügland	Bayern	BY	95
91623	Sachsen	Bayern	BY	95
91625	Schnelldorf	Bayern	BY	95
91626	Schopfloch	Bayern	BY	95
91628	Steinsfeld	Bayern	BY	95
91629	Weihenzell	Bayern	BY	95
91631	Wettringen	Bayern	BY	95
91632	Wieseth	Bayern	BY	95
91634	Wilburgstetten	Bayern	BY	95
91635	Windelsbach	Bayern	BY	95
91637	Wörnitz	Bayern	BY	95
91639	Wolframs-Eschenbach	Bayern	BY	95
91710	Gunzenhausen	Bayern	BY	95
91717	Wassertrüdingen	Bayern	BY	95
91719	Heidenheim	Bayern	BY	95
91720	Absberg	Bayern	BY	95
91722	Arberg	Bayern	BY	95
91723	Dittenheim	Bayern	BY	95
91725	Ehingen	Bayern	BY	95
91726	Gerolfingen	Bayern	BY	95
91728	Gnotzheim	Bayern	BY	95
91729	Haundorf	Bayern	BY	95
91731	Langfurth	Bayern	BY	95
91732	Merkendorf	Bayern	BY	95
91734	Mitteleschenbach	Bayern	BY	95
91735	Muhr am See	Bayern	BY	95
91737	Ornbau	Bayern	BY	95
91738	Pfofeld	Bayern	BY	95
91740	Röckingen	Bayern	BY	95
91741	Theilenhofen	Bayern	BY	95
91743	Unterschwaningen	Bayern	BY	95
91744	Weiltingen	Bayern	BY	95
91746	Weidenbach	Bayern	BY	95
91747	Westheim	Bayern	BY	95
91749	Wittelshofen	Bayern	BY	95
91757	Treuchtlingen	Bayern	BY	95
91781	Weißenburg in Bayern	Bayern	BY	95
91785	Pleinfeld	Bayern	BY	95
91788	Pappenheim	Bayern	BY	95
91790	Nennslingen	Bayern	BY	95
91790	Bergen	Bayern	BY	95
91790	Raitenbuch	Bayern	BY	95
91790	Burgsalach	Bayern	BY	95
91792	Ellingen	Bayern	BY	95
91793	Alesheim	Bayern	BY	95
91796	Ettenstatt	Bayern	BY	95
91798	Höttingen	Bayern	BY	95
91799	Langenaltheim	Bayern	BY	95
91801	Markt Berolzheim	Bayern	BY	95
91802	Meinheim	Bayern	BY	95
91805	Polsingen	Bayern	BY	95
91807	Solnhofen	Bayern	BY	95
96152	Burghaslach	Bayern	BY	95
96172	Mühlhausen	Bayern	BY	95
96193	Wachenroth	Bayern	BY	95
97215	Weigenheim	Bayern	BY	95
97215	Uffenheim	Bayern	BY	95
97215	Simmershofen	Bayern	BY	95
97258	Ippesheim	Bayern	BY	95
97258	Gollhofen	Bayern	BY	95
97258	Hemmersheim	Bayern	BY	95
97258	Oberickelsheim	Bayern	BY	95
63739	Aschaffenburg	Bayern	BY	96
63741	Aschaffenburg	Bayern	BY	96
63743	Aschaffenburg	Bayern	BY	96
63755	Alzenau in Unterfranken	Bayern	BY	96
63762	Großostheim	Bayern	BY	96
63768	Hösbach	Bayern	BY	96
63773	Goldbach	Bayern	BY	96
63776	Mömbris	Bayern	BY	96
63785	Obernburg am Main	Bayern	BY	96
63791	Karlstein am Main	Bayern	BY	96
63796	Kahl am Main	Bayern	BY	96
63801	Kleinostheim	Bayern	BY	96
63808	Haibach	Bayern	BY	96
63811	Stockstadt am Main	Bayern	BY	96
63814	Mainaschaff	Bayern	BY	96
63820	Elsenfeld	Bayern	BY	96
63825	Westerngrund	Bayern	BY	96
63825	Sommerkahl	Bayern	BY	96
63825	Blankenbach	Bayern	BY	96
63825	Schöllkrippen	Bayern	BY	96
63826	Geiselbach	Bayern	BY	96
63828	Kleinkahl	Bayern	BY	96
63829	Krombach	Bayern	BY	96
63831	Wiesen	Bayern	BY	96
63834	Sulzbach am Main	Bayern	BY	96
63839	Kleinwallstadt	Bayern	BY	96
63840	Hausen	Bayern	BY	96
63843	Niedernberg	Bayern	BY	96
63846	Laufach	Bayern	BY	96
63849	Leidersbach	Bayern	BY	96
63853	Mömlingen	Bayern	BY	96
63856	Bessenbach	Bayern	BY	96
63857	Waldaschaff	Bayern	BY	96
63860	Rothenbuch	Bayern	BY	96
63863	Eschau	Bayern	BY	96
63864	Glattbach	Bayern	BY	96
63867	Johannesberg	Bayern	BY	96
63868	Großwallstadt	Bayern	BY	96
63869	Heigenbrücken	Bayern	BY	96
63871	Heinrichsthal	Bayern	BY	96
63872	Heimbuchenthal	Bayern	BY	96
63874	Dammbach	Bayern	BY	96
63875	Mespelbrunn	Bayern	BY	96
63877	Sailauf	Bayern	BY	96
63879	Weibersbrunn	Bayern	BY	96
63897	Miltenberg	Bayern	BY	96
63906	Erlenbach am Main	Bayern	BY	96
63911	Klingenberg am Main	Bayern	BY	96
63916	Amorbach	Bayern	BY	96
63920	Großheubach	Bayern	BY	96
63924	Rüdenau	Bayern	BY	96
63924	Kleinheubach	Bayern	BY	96
63925	Laudenbach	Bayern	BY	96
63927	Bürgstadt	Bayern	BY	96
63928	Eichenbühl	Bayern	BY	96
63930	Neunkirchen	Bayern	BY	96
63931	Kirchzell	Bayern	BY	96
63933	Mönchberg	Bayern	BY	96
63934	Röllbach	Bayern	BY	96
63936	Schneeberg	Bayern	BY	96
63937	Weilbach	Bayern	BY	96
63939	Wörth am Main	Bayern	BY	96
96106	Ebern	Bayern	BY	96
96126	Ermershausen	Bayern	BY	96
96126	Maroldsweisach	Bayern	BY	96
96151	Breitbrunn	Bayern	BY	96
96160	Geiselwind	Bayern	BY	96
96166	Kirchlauter	Bayern	BY	96
96170	Lisberg	Bayern	BY	96
96176	Pfarrweisach	Bayern	BY	96
96181	Rauhenebrach	Bayern	BY	96
96184	Rentweinsdorf	Bayern	BY	96
96188	Stettfeld	Bayern	BY	96
96190	Untermerzbach	Bayern	BY	96
97070	Würzburg	Bayern	BY	96
97072	Würzburg	Bayern	BY	96
97074	Würzburg	Bayern	BY	96
97076	Würzburg	Bayern	BY	96
97078	Würzburg	Bayern	BY	96
97080	Würzburg	Bayern	BY	96
97082	Würzburg	Bayern	BY	96
97084	Würzburg	Bayern	BY	96
97199	Ochsenfurt	Bayern	BY	96
97204	Höchberg	Bayern	BY	96
97209	Veitshöchheim	Bayern	BY	96
97218	Gerbrunn	Bayern	BY	96
97222	Rimpar	Bayern	BY	96
97225	Zellingen	Bayern	BY	96
97228	Rottendorf	Bayern	BY	96
97230	Estenfeld	Bayern	BY	96
97232	Giebelstadt	Bayern	BY	96
97234	Reichenberg	Bayern	BY	96
97236	Randersacker	Bayern	BY	96
97237	Altertheim	Bayern	BY	96
97239	Aub	Bayern	BY	96
97241	Oberpleichfeld	Bayern	BY	96
97241	Bergtheim	Bayern	BY	96
97243	Bieberehren	Bayern	BY	96
97244	Bütthard	Bayern	BY	96
97246	Eibelstadt	Bayern	BY	96
97247	Eisenheim	Bayern	BY	96
97249	Eisingen	Bayern	BY	96
97250	Erlabrunn	Bayern	BY	96
97252	Frickenhausen am Main	Bayern	BY	96
97253	Gaukönigshofen	Bayern	BY	96
97255	Gelchsheim	Bayern	BY	96
97255	Sonderhofen	Bayern	BY	96
97256	Geroldshausen	Bayern	BY	96
97259	Greußenheim	Bayern	BY	96
97261	Güntersleben	Bayern	BY	96
97262	Hausen bei Würzburg	Bayern	BY	96
97264	Helmstadt	Bayern	BY	96
97265	Hettstadt	Bayern	BY	96
97267	Himmelstadt	Bayern	BY	96
97268	Kirchheim	Bayern	BY	96
97270	Kist	Bayern	BY	96
97271	Kleinrinderfeld	Bayern	BY	96
97273	Kürnach	Bayern	BY	96
97274	Leinach	Bayern	BY	96
97276	Margetshöchheim	Bayern	BY	96
97277	Neubrunn	Bayern	BY	96
97279	Prosselsheim	Bayern	BY	96
97280	Remlingen	Bayern	BY	96
97282	Retzstadt	Bayern	BY	96
97283	Riedenheim	Bayern	BY	96
97285	Tauberrettersheim	Bayern	BY	96
97285	Röttingen	Bayern	BY	96
97286	Sommerhausen	Bayern	BY	96
97286	Winterhausen	Bayern	BY	96
97288	Theilheim	Bayern	BY	96
97289	Thüngen	Bayern	BY	96
97291	Thüngersheim	Bayern	BY	96
97292	Holzkirchen	Bayern	BY	96
97292	Uettingen	Bayern	BY	96
97294	Unterpleichfeld	Bayern	BY	96
97295	Waldbrunn	Bayern	BY	96
97297	Waldbüttelbrunn	Bayern	BY	96
97299	Zell am Main	Bayern	BY	96
97318	Biebelried	Bayern	BY	96
97318	Kitzingen	Bayern	BY	96
97320	Albertshofen	Bayern	BY	96
97320	Sulzfeld am Main	Bayern	BY	96
97320	Buchbrunn	Bayern	BY	96
97320	Großlangheim	Bayern	BY	96
97320	Mainstockheim	Bayern	BY	96
97332	Volkach	Bayern	BY	96
97334	Nordheim am Main	Bayern	BY	96
97334	Sommerach	Bayern	BY	96
97337	Dettelbach	Bayern	BY	96
97340	Marktbreit	Bayern	BY	96
97340	Segnitz	Bayern	BY	96
97340	Martinsheim	Bayern	BY	96
97342	Obernbreit	Bayern	BY	96
97342	Marktsteft	Bayern	BY	96
97342	Seinsheim	Bayern	BY	96
97346	Iphofen	Bayern	BY	96
97348	Willanzheim	Bayern	BY	96
97348	Rödelsee	Bayern	BY	96
97348	Markt Einersheim	Bayern	BY	96
97350	Mainbernheim	Bayern	BY	96
97353	Wiesentheid	Bayern	BY	96
97355	Wiesenbronn	Bayern	BY	96
97355	Kleinlangheim	Bayern	BY	96
97355	Abtswind	Bayern	BY	96
97355	Castell	Bayern	BY	96
97355	Rüdenhausen	Bayern	BY	96
97357	Prichsenstadt	Bayern	BY	96
97359	Schwarzach am Main	Bayern	BY	96
97412	Schweinfurt	Bayern	BY	96
97421	Schweinfurt	Bayern	BY	96
97422	Schweinfurt	Bayern	BY	96
97424	Schweinfurt	Bayern	BY	96
97437	Haßfurt	Bayern	BY	96
97440	Werneck	Bayern	BY	96
97447	Frankenwinheim	Bayern	BY	96
97447	Gerolzhofen	Bayern	BY	96
97450	Arnstein	Bayern	BY	96
97453	Schonungen	Bayern	BY	96
97456	Dittelbrunn	Bayern	BY	96
97461	Hofheim in Unterfranken	Bayern	BY	96
97464	Niederwerrn	Bayern	BY	96
97469	Gochsheim	Bayern	BY	96
97475	Zeil am Main	Bayern	BY	96
97478	Knetzgau	Bayern	BY	96
97483	Eltmann	Bayern	BY	96
97486	Königsberg in Bayern	Bayern	BY	96
97488	Stadtlauringen	Bayern	BY	96
97490	Poppenhausen	Bayern	BY	96
97491	Aidhausen	Bayern	BY	96
97493	Bergrheinfeld	Bayern	BY	96
97494	Bundorf	Bayern	BY	96
97496	Burgpreppach	Bayern	BY	96
97497	Dingolshausen	Bayern	BY	96
97499	Donnersdorf	Bayern	BY	96
97500	Ebelsbach	Bayern	BY	96
97502	Euerbach	Bayern	BY	96
97503	Gädheim	Bayern	BY	96
97505	Geldersheim	Bayern	BY	96
97506	Grafenrheinfeld	Bayern	BY	96
97508	Grettstadt	Bayern	BY	96
97509	Kolitzheim	Bayern	BY	96
97511	Lülsfeld	Bayern	BY	96
97513	Michelau im Steigerwald	Bayern	BY	96
97514	Oberaurach	Bayern	BY	96
97516	Oberschwarzach	Bayern	BY	96
97517	Rannungen	Bayern	BY	96
97519	Riedbach	Bayern	BY	96
97520	Röthlein	Bayern	BY	96
97522	Sand am Main	Bayern	BY	96
97523	Schwanfeld	Bayern	BY	96
97525	Schwebheim	Bayern	BY	96
97526	Sennfeld	Bayern	BY	96
97528	Sulzdorf an der Lederhecke	Bayern	BY	96
97529	Sulzheim	Bayern	BY	96
97531	Theres	Bayern	BY	96
97532	Üchtelhausen	Bayern	BY	96
97534	Waigolshausen	Bayern	BY	96
97535	Wasserlosen	Bayern	BY	96
97537	Wipfeld	Bayern	BY	96
97539	Wonfurt	Bayern	BY	96
97616	Salz	Bayern	BY	96
97616	Bad Neustadt an der Saale	Bayern	BY	96
97618	Wülfershausen an der Saale	Bayern	BY	96
97618	Unsleben	Bayern	BY	96
97618	Strahlungen	Bayern	BY	96
97618	Hollstadt	Bayern	BY	96
97618	Niederlauer	Bayern	BY	96
97618	Heustreu	Bayern	BY	96
97618	Wollbach	Bayern	BY	96
97618	Hohenroth	Bayern	BY	96
97618	Rödelmaier	Bayern	BY	96
97631	Bad Königshofen im Grabfeld	Bayern	BY	96
97633	Saal an der Saale	Bayern	BY	96
97633	Aubstadt	Bayern	BY	96
97633	Höchheim	Bayern	BY	96
97633	Trappstadt	Bayern	BY	96
97633	Großbardorf	Bayern	BY	96
97633	Großeibstadt	Bayern	BY	96
97633	Sulzfeld	Bayern	BY	96
97633	Herbstadt	Bayern	BY	96
97638	Mellrichstadt	Bayern	BY	96
97640	Oberstreu	Bayern	BY	96
97640	Stockheim	Bayern	BY	96
97640	Hendungen	Bayern	BY	96
97645	Ostheim vor der Rhön	Bayern	BY	96
97647	Willmars	Bayern	BY	96
97647	Hausen	Bayern	BY	96
97647	Nordheim vor der Rhön	Bayern	BY	96
97647	Sondheim vor der Rhön	Bayern	BY	96
97650	Fladungen	Bayern	BY	96
97653	Bischofsheim an der Rhön	Bayern	BY	96
97654	Bastheim	Bayern	BY	96
97656	Oberelsbach	Bayern	BY	96
97657	Sandberg	Bayern	BY	96
97659	Schönau an der Brend	Bayern	BY	96
97688	Bad Kissingen	Bayern	BY	96
97702	Münnerstadt	Bayern	BY	96
97705	Burkardroth	Bayern	BY	96
97708	Bad Bocklet	Bayern	BY	96
97711	Maßbach	Bayern	BY	96
97711	Thundorf in Unterfranken	Bayern	BY	96
97714	Oerlenbach	Bayern	BY	96
97717	Sulzthal	Bayern	BY	96
97717	Aura an der Saale	Bayern	BY	96
97717	Euerdorf	Bayern	BY	96
97720	Nüdlingen	Bayern	BY	96
97723	Oberthulba	Bayern	BY	96
97724	Burglauer	Bayern	BY	96
97725	Elfershausen	Bayern	BY	96
97727	Fuchsstadt	Bayern	BY	96
97729	Ramsthal	Bayern	BY	96
97737	Gemünden am Main	Bayern	BY	96
97753	Karlstadt	Bayern	BY	96
97762	Hammelburg	Bayern	BY	96
97769	Bad Brückenau	Bayern	BY	96
97772	Wildflecken	Bayern	BY	96
97773	Aura im Sinngrund	Bayern	BY	96
97775	Burgsinn	Bayern	BY	96
97776	Eußenheim	Bayern	BY	96
97778	Fellen	Bayern	BY	96
97779	Geroda	Bayern	BY	96
97780	Gössenheim	Bayern	BY	96
97782	Gräfendorf	Bayern	BY	96
97783	Karsbach	Bayern	BY	96
97785	Mittelsinn	Bayern	BY	96
97786	Motten	Bayern	BY	96
97788	Neuendorf	Bayern	BY	96
97789	Oberleichtersbach	Bayern	BY	96
97791	Obersinn	Bayern	BY	96
97792	Riedenberg	Bayern	BY	96
97794	Rieneck	Bayern	BY	96
97795	Schondra	Bayern	BY	96
97797	Wartmannsroth	Bayern	BY	96
97799	Zeitlofs	Bayern	BY	96
97816	Lohr am Main	Bayern	BY	96
97828	Marktheidenfeld	Bayern	BY	96
97833	Frammersbach	Bayern	BY	96
97834	Birkenfeld	Bayern	BY	96
97836	Bischbrunn	Bayern	BY	96
97837	Erlenbach bei Marktheidenfeld	Bayern	BY	96
97839	Esselbach	Bayern	BY	96
97840	Hafenlohr	Bayern	BY	96
97842	Karbach	Bayern	BY	96
97843	Neuhütten	Bayern	BY	96
97845	Neustadt am Main	Bayern	BY	96
97846	Partenstein	Bayern	BY	96
97848	Rechtenbach	Bayern	BY	96
97849	Roden	Bayern	BY	96
97851	Rothenfels	Bayern	BY	96
97852	Schollbrunn	Bayern	BY	96
97854	Steinfeld	Bayern	BY	96
97855	Triefenstein	Bayern	BY	96
97857	Urspringen	Bayern	BY	96
97859	Wiesthal	Bayern	BY	96
97892	Kreuzwertheim	Bayern	BY	96
97901	Altenbuch	Bayern	BY	96
97903	Collenberg	Bayern	BY	96
97904	Dorfprozelten	Bayern	BY	96
97906	Faulbach	Bayern	BY	96
97907	Hasloch	Bayern	BY	96
97909	Stadtprozelten	Bayern	BY	96
82297	Steindorf	Bayern	BY	97
86150	Augsburg	Bayern	BY	97
86152	Augsburg	Bayern	BY	97
86153	Augsburg	Bayern	BY	97
86154	Augsburg	Bayern	BY	97
86156	Augsburg	Bayern	BY	97
86157	Augsburg	Bayern	BY	97
86159	Augsburg	Bayern	BY	97
86161	Augsburg	Bayern	BY	97
86163	Augsburg	Bayern	BY	97
86165	Augsburg	Bayern	BY	97
86167	Augsburg	Bayern	BY	97
86169	Augsburg	Bayern	BY	97
86179	Augsburg	Bayern	BY	97
86199	Augsburg	Bayern	BY	97
86316	Friedberg	Bayern	BY	97
86343	Königsbrunn	Bayern	BY	97
86356	Neusäß	Bayern	BY	97
86368	Gersthofen	Bayern	BY	97
86381	Krumbach	Bayern	BY	97
86391	Stadtbergen	Bayern	BY	97
86399	Bobingen	Bayern	BY	97
86405	Meitingen	Bayern	BY	97
86415	Mering	Bayern	BY	97
86420	Diedorf	Bayern	BY	97
86424	Dinkelscherben	Bayern	BY	97
86438	Kissing	Bayern	BY	97
86441	Zusmarshausen	Bayern	BY	97
86444	Affing	Bayern	BY	97
86447	Aindling	Bayern	BY	97
86447	Todtenweis	Bayern	BY	97
86450	Altenmünster	Bayern	BY	97
86453	Dasing	Bayern	BY	97
86456	Gablingen	Bayern	BY	97
86459	Gessertshausen	Bayern	BY	97
86462	Langweid am Lech	Bayern	BY	97
86465	Heretsried	Bayern	BY	97
86465	Welden	Bayern	BY	97
86470	Thannhausen	Bayern	BY	97
86473	Ziemetshausen	Bayern	BY	97
86476	Neuburg an der Kammel	Bayern	BY	97
86477	Adelsried	Bayern	BY	97
86479	Aichen	Bayern	BY	97
86480	Waltenhausen	Bayern	BY	97
86480	Aletshausen	Bayern	BY	97
86482	Aystetten	Bayern	BY	97
86483	Balzhausen	Bayern	BY	97
86485	Biberbach	Bayern	BY	97
86486	Bonstetten	Bayern	BY	97
86488	Breitenthal	Bayern	BY	97
86489	Deisenhausen	Bayern	BY	97
86491	Ebershausen	Bayern	BY	97
86494	Emersacker	Bayern	BY	97
86495	Eurasburg	Bayern	BY	97
86497	Horgau	Bayern	BY	97
86498	Kettershausen	Bayern	BY	97
86500	Kutzenhausen	Bayern	BY	97
86502	Laugna	Bayern	BY	97
86504	Merching	Bayern	BY	97
86505	Münsterhausen	Bayern	BY	97
86507	Oberottmarshausen	Bayern	BY	97
86507	Kleinaitingen	Bayern	BY	97
86508	Rehling	Bayern	BY	97
86510	Ried	Bayern	BY	97
86511	Schmiechen	Bayern	BY	97
86513	Ursberg	Bayern	BY	97
86514	Ustersbach	Bayern	BY	97
86517	Wehringen	Bayern	BY	97
86519	Wiesenbach	Bayern	BY	97
86551	Aichach	Bayern	BY	97
86554	Pöttmes	Bayern	BY	97
86556	Kühbach	Bayern	BY	97
86559	Adelzhausen	Bayern	BY	97
86568	Hollenbach	Bayern	BY	97
86570	Inchenhofen	Bayern	BY	97
86573	Obergriesbach	Bayern	BY	97
86574	Petersdorf	Bayern	BY	97
86576	Schiltberg	Bayern	BY	97
86577	Sielenbach	Bayern	BY	97
86609	Donauwörth	Bayern	BY	97
86637	Wertingen	Bayern	BY	97
86641	Rain	Bayern	BY	97
86647	Buttenwiesen	Bayern	BY	97
86650	Wemding	Bayern	BY	97
86653	Monheim	Bayern	BY	97
86653	Daiting	Bayern	BY	97
86655	Harburg	Bayern	BY	97
86657	Bissingen	Bayern	BY	97
86660	Tapfheim	Bayern	BY	97
86663	Asbach-Bäumenheim	Bayern	BY	97
86672	Thierhaupten	Bayern	BY	97
86674	Baar	Bayern	BY	97
86675	Buchdorf	Bayern	BY	97
86678	Ehingen	Bayern	BY	97
86679	Ellgau	Bayern	BY	97
86681	Fünfstetten	Bayern	BY	97
86682	Genderkingen	Bayern	BY	97
86684	Holzheim	Bayern	BY	97
86685	Huisheim	Bayern	BY	97
86687	Kaisheim	Bayern	BY	97
86688	Marxheim	Bayern	BY	97
86690	Mertingen	Bayern	BY	97
86692	Münster	Bayern	BY	97
86694	Niederschönenfeld	Bayern	BY	97
86695	Allmannshofen	Bayern	BY	97
86695	Nordendorf	Bayern	BY	97
86698	Oberndorf am Lech	Bayern	BY	97
86700	Otting	Bayern	BY	97
86703	Rögling	Bayern	BY	97
86704	Tagmersheim	Bayern	BY	97
86707	Kühlenthal	Bayern	BY	97
86707	Westendorf	Bayern	BY	97
86709	Wolferstadt	Bayern	BY	97
86720	Nördlingen	Bayern	BY	97
86732	Oettingen in Bayern	Bayern	BY	97
86733	Alerheim	Bayern	BY	97
86735	Forheim	Bayern	BY	97
86735	Amerdingen	Bayern	BY	97
86736	Auhausen	Bayern	BY	97
86738	Deiningen	Bayern	BY	97
86739	Ederheim	Bayern	BY	97
86741	Ehingen am Ries	Bayern	BY	97
86742	Fremdingen	Bayern	BY	97
86744	Hainsfarth	Bayern	BY	97
86745	Hohenaltheim	Bayern	BY	97
86747	Maihingen	Bayern	BY	97
86748	Marktoffingen	Bayern	BY	97
86750	Megesheim	Bayern	BY	97
86751	Mönchsdeggingen	Bayern	BY	97
86753	Möttingen	Bayern	BY	97
86754	Munningen	Bayern	BY	97
86756	Reimlingen	Bayern	BY	97
86757	Wallerstein	Bayern	BY	97
86759	Wechingen	Bayern	BY	97
86807	Buchloe	Bayern	BY	97
86825	Bad Wörishofen	Bayern	BY	97
86830	Schwabmünchen	Bayern	BY	97
86833	Ettringen	Bayern	BY	97
86836	Untermeitingen	Bayern	BY	97
86836	Klosterlechfeld	Bayern	BY	97
86836	Graben	Bayern	BY	97
86842	Türkheim	Bayern	BY	97
86845	Großaitingen	Bayern	BY	97
86850	Fischach	Bayern	BY	97
86853	Langerringen	Bayern	BY	97
86854	Amberg	Bayern	BY	97
86856	Hiltenfingen	Bayern	BY	97
86860	Jengen	Bayern	BY	97
86862	Lamerdingen	Bayern	BY	97
86863	Langenneufnach	Bayern	BY	97
86865	Markt Wald	Bayern	BY	97
86866	Mickhausen	Bayern	BY	97
86868	Mittelneufnach	Bayern	BY	97
86869	Oberostendorf	Bayern	BY	97
86871	Rammingen	Bayern	BY	97
86872	Scherstetten	Bayern	BY	97
86874	Tussenhausen	Bayern	BY	97
86875	Waal	Bayern	BY	97
86877	Walkertshofen	Bayern	BY	97
86879	Wiedergeltingen	Bayern	BY	97
86983	Lechbruck	Bayern	BY	97
87435	Kempten	Bayern	BY	97
87437	Kempten	Bayern	BY	97
87439	Kempten	Bayern	BY	97
87448	Waltenhofen	Bayern	BY	97
87452	Altusried	Bayern	BY	97
87459	Pfronten	Bayern	BY	97
87463	Dietmannsried	Bayern	BY	97
87466	Oy-Mittelberg	Bayern	BY	97
87471	Durach	Bayern	BY	97
87474	Buchenberg	Bayern	BY	97
87477	Sulzberg	Bayern	BY	97
87480	Weitnau	Bayern	BY	97
87484	Nesselwang	Bayern	BY	97
87487	Wiggensbach	Bayern	BY	97
87488	Betzigau	Bayern	BY	97
87490	Haldenwang	Bayern	BY	97
87493	Lauben	Bayern	BY	97
87494	Rückholz	Bayern	BY	97
87496	Untrasried	Bayern	BY	97
87497	Wertach	Bayern	BY	97
87499	Wildpoldsried	Bayern	BY	97
87509	Immenstadt im Allgäu	Bayern	BY	97
87527	Ofterschwang	Bayern	BY	97
87527	Sonthofen	Bayern	BY	97
87534	Oberstaufen	Bayern	BY	97
87538	Obermaiselstein	Bayern	BY	97
87538	Fischen im Allgäu	Bayern	BY	97
87538	Bolsterlang	Bayern	BY	97
87538	Balderschwang	Bayern	BY	97
87541	Bad Hindelang	Bayern	BY	97
87544	Blaichach	Bayern	BY	97
87545	Burgberg im Allgäu	Bayern	BY	97
87547	Missen-Wilhams	Bayern	BY	97
87549	Rettenberg	Bayern	BY	97
87561	Oberstdorf	Bayern	BY	97
87600	Kaufbeuren	Bayern	BY	97
87616	Wald	Bayern	BY	97
87616	Marktoberdorf	Bayern	BY	97
87629	Füssen	Bayern	BY	97
87634	Günzach	Bayern	BY	97
87634	Obergünzburg	Bayern	BY	97
87637	Eisenberg	Bayern	BY	97
87637	Seeg	Bayern	BY	97
87640	Biessenhofen	Bayern	BY	97
87642	Halblech	Bayern	BY	97
87645	Schwangau	Bayern	BY	97
87647	Unterthingau	Bayern	BY	97
87647	Kraftisried	Bayern	BY	97
87648	Aitrang	Bayern	BY	97
87650	Baisweil	Bayern	BY	97
87651	Bidingen	Bayern	BY	97
87653	Eggenthal	Bayern	BY	97
87654	Friesenried	Bayern	BY	97
87656	Germaringen	Bayern	BY	97
87657	Görisried	Bayern	BY	97
87659	Hopferau	Bayern	BY	97
87660	Irsee	Bayern	BY	97
87662	Osterzell	Bayern	BY	97
87662	Kaltental	Bayern	BY	97
87663	Lengenwang	Bayern	BY	97
87665	Mauerstetten	Bayern	BY	97
87666	Pforzen	Bayern	BY	97
87668	Rieden	Bayern	BY	97
87669	Rieden am Forggensee	Bayern	BY	97
87671	Ronsberg	Bayern	BY	97
87672	Roßhaupten	Bayern	BY	97
87674	Ruderatshofen	Bayern	BY	97
87675	Stötten am Auerberg	Bayern	BY	97
87675	Rettenbach am Auerberg	Bayern	BY	97
87677	Stöttwang	Bayern	BY	97
87679	Westendorf	Bayern	BY	97
87700	Memmingen	Bayern	BY	97
87719	Mindelheim	Bayern	BY	97
87724	Ottobeuren	Bayern	BY	97
87727	Babenhausen	Bayern	BY	97
87730	Bad Grönenbach	Bayern	BY	97
87733	Markt Rettenbach	Bayern	BY	97
87734	Benningen	Bayern	BY	97
87736	Böhen	Bayern	BY	97
87737	Boos	Bayern	BY	97
87739	Breitenbrunn	Bayern	BY	97
87740	Buxheim	Bayern	BY	97
87742	Dirlewang	Bayern	BY	97
87742	Apfeltrach	Bayern	BY	97
87743	Egg an der Günz	Bayern	BY	97
87745	Eppishausen	Bayern	BY	97
87746	Erkheim	Bayern	BY	97
87748	Fellheim	Bayern	BY	97
87749	Hawangen	Bayern	BY	97
87751	Heimertingen	Bayern	BY	97
87752	Holzgünz	Bayern	BY	97
87754	Kammlach	Bayern	BY	97
87755	Kirchhaslach	Bayern	BY	97
87757	Kirchheim in Schwaben	Bayern	BY	97
87758	Kronburg	Bayern	BY	97
87760	Lachen	Bayern	BY	97
87761	Lauben	Bayern	BY	97
87763	Lautrach	Bayern	BY	97
87764	Legau	Bayern	BY	97
87766	Memmingerberg	Bayern	BY	97
87767	Niederrieden	Bayern	BY	97
87769	Oberrieden	Bayern	BY	97
87770	Oberschönegg	Bayern	BY	97
87772	Pfaffenhausen	Bayern	BY	97
87773	Pleß	Bayern	BY	97
87775	Salgen	Bayern	BY	97
87776	Sontheim	Bayern	BY	97
87778	Stetten	Bayern	BY	97
87779	Trunkelsberg	Bayern	BY	97
87781	Ungerhausen	Bayern	BY	97
87782	Unteregg	Bayern	BY	97
87784	Westerheim	Bayern	BY	97
87785	Winterrieden	Bayern	BY	97
87787	Wolfertschwenden	Bayern	BY	97
87789	Woringen	Bayern	BY	97
88131	Lindau (Bodensee)	Bayern	BY	97
88131	Bodolz	Bayern	BY	97
88138	Hergensweiler	Bayern	BY	97
88138	Weißensberg	Bayern	BY	97
88138	Sigmarszell	Bayern	BY	97
88142	Wasserburg (Bodensee)	Bayern	BY	97
88145	Hergatz	Bayern	BY	97
88145	Opfenbach	Bayern	BY	97
88149	Nonnenhorn	Bayern	BY	97
88161	Lindenberg im Allgäu	Bayern	BY	97
88167	Gestratz	Bayern	BY	97
88167	Stiefenhofen	Bayern	BY	97
88167	Maierhöfen	Bayern	BY	97
88167	Grünenbach	Bayern	BY	97
88167	Röthenbach (Allgäu)	Bayern	BY	97
88171	Weiler-Simmerberg	Bayern	BY	97
88175	Scheidegg	Bayern	BY	97
88178	Heimenkirch	Bayern	BY	97
88179	Oberreute	Bayern	BY	97
89231	Neu-Ulm	Bayern	BY	97
89233	Neu-Ulm	Bayern	BY	97
89250	Senden	Bayern	BY	97
89257	Illertissen	Bayern	BY	97
89264	Weißenhorn	Bayern	BY	97
89269	Vöhringen	Bayern	BY	97
89275	Elchingen	Bayern	BY	97
89278	Nersingen	Bayern	BY	97
89281	Altenstadt	Bayern	BY	97
89284	Pfaffenhofen an der Roth	Bayern	BY	97
89287	Bellenberg	Bayern	BY	97
89290	Buch	Bayern	BY	97
89291	Holzheim	Bayern	BY	97
89293	Kellmünz	Bayern	BY	97
89294	Oberroth	Bayern	BY	97
89296	Osterberg	Bayern	BY	97
89297	Roggenburg	Bayern	BY	97
89299	Unterroth	Bayern	BY	97
89312	Günzburg	Bayern	BY	97
89331	Burgau	Bayern	BY	97
89335	Ichenhausen	Bayern	BY	97
89340	Leipheim	Bayern	BY	97
89343	Jettingen-Scheppach	Bayern	BY	97
89344	Aislingen	Bayern	BY	97
89346	Bibertal	Bayern	BY	97
89347	Bubesheim	Bayern	BY	97
89349	Burtenbach	Bayern	BY	97
89350	Dürrlauingen	Bayern	BY	97
89352	Ellzee	Bayern	BY	97
89353	Glött	Bayern	BY	97
89355	Gundremmingen	Bayern	BY	97
89356	Haldenwang	Bayern	BY	97
89358	Kammeltal	Bayern	BY	97
89359	Kötz	Bayern	BY	97
89361	Landensberg	Bayern	BY	97
89362	Offingen	Bayern	BY	97
89364	Rettenbach	Bayern	BY	97
89365	Röfingen	Bayern	BY	97
89367	Waldstetten	Bayern	BY	97
89368	Winterbach	Bayern	BY	97
89407	Dillingen an der Donau	Bayern	BY	97
89415	Lauingen (Donau)	Bayern	BY	97
89420	Höchstädt an der Donau	Bayern	BY	97
89423	Gundelfingen an der Donau	Bayern	BY	97
89426	Mödingen	Bayern	BY	97
89426	Wittislingen	Bayern	BY	97
89428	Syrgenstein	Bayern	BY	97
89429	Bachhagel	Bayern	BY	97
89431	Bächingen an der Brenz	Bayern	BY	97
89432	Binswangen	Bayern	BY	97
89434	Blindheim	Bayern	BY	97
89435	Finningen	Bayern	BY	97
89437	Haunsheim	Bayern	BY	97
89438	Holzheim	Bayern	BY	97
89440	Lutzingen	Bayern	BY	97
89441	Medlingen	Bayern	BY	97
89443	Schwenningen	Bayern	BY	97
89444	Villenbach	Bayern	BY	97
89446	Ziertheim	Bayern	BY	97
89447	Zöschingen	Bayern	BY	97
89449	Zusamaltheim	Bayern	BY	97
27568	Bremerhaven	Bremen	HB	Bremerhaven; Stadt
27570	Bremerhaven	Bremen	HB	Bremerhaven; Stadt
27572	Bremerhaven	Bremen	HB	Bremerhaven; Stadt
27574	Bremerhaven	Bremen	HB	Bremerhaven; Stadt
27576	Bremerhaven	Bremen	HB	Bremerhaven; Stadt
27578	Bremerhaven	Bremen	HB	Bremerhaven; Stadt
27580	Bremerhaven	Bremen	HB	Bremerhaven; Stadt
28195	Bremen	Bremen	HB	Bremen
28197	Bremen	Bremen	HB	Bremen
28199	Bremen	Bremen	HB	Bremen
28201	Bremen	Bremen	HB	Bremen
28203	Bremen	Bremen	HB	Bremen
28205	Bremen	Bremen	HB	Bremen
28207	Bremen	Bremen	HB	Bremen
28209	Bremen	Bremen	HB	Bremen
28211	Bremen	Bremen	HB	Bremen
28213	Bremen	Bremen	HB	Bremen
28215	Bremen	Bremen	HB	Bremen
28217	Bremen	Bremen	HB	Bremen
28219	Bremen	Bremen	HB	Bremen
28237	Bremen	Bremen	HB	Bremen
28239	Bremen	Bremen	HB	Bremen
28259	Bremen	Bremen	HB	Bremen
28277	Bremen	Bremen	HB	Bremen
28279	Bremen	Bremen	HB	Bremen
28307	Bremen	Bremen	HB	Bremen
28309	Bremen	Bremen	HB	Bremen
28325	Bremen	Bremen	HB	Bremen
28327	Bremen	Bremen	HB	Bremen
28329	Bremen	Bremen	HB	Bremen
28335	Bremen	Bremen	HB	Bremen
28355	Bremen	Bremen	HB	Bremen
28357	Bremen	Bremen	HB	Bremen
28359	Bremen	Bremen	HB	Bremen
28717	Bremen	Bremen	HB	Bremen
28719	Bremen	Bremen	HB	Bremen
28755	Bremen	Bremen	HB	Bremen
28757	Bremen	Bremen	HB	Bremen
28759	Bremen	Bremen	HB	Bremen
28777	Bremen	Bremen	HB	Bremen
28779	Bremen	Bremen	HB	Bremen
35510	Butzbach	Hessen	HE	64
35516	Münzenberg	Hessen	HE	64
35519	Rockenberg	Hessen	HE	64
36381	Schlüchtern	Hessen	HE	64
36391	Sinntal	Hessen	HE	64
36396	Steinau an der Straße	Hessen	HE	64
55246	Mainz-Kostheim	Hessen	HE	64
55252	Mainz-Kastel	Hessen	HE	64
60306	Frankfurt am Main	Hessen	HE	64
60308	Frankfurt am Main	Hessen	HE	64
60310	Frankfurt am Main	Hessen	HE	64
60311	Frankfurt am Main	Hessen	HE	64
60313	Frankfurt am Main	Hessen	HE	64
60314	Frankfurt am Main	Hessen	HE	64
60316	Frankfurt am Main	Hessen	HE	64
60318	Frankfurt am Main	Hessen	HE	64
60320	Frankfurt am Main	Hessen	HE	64
60322	Frankfurt am Main	Hessen	HE	64
60323	Frankfurt am Main	Hessen	HE	64
60325	Frankfurt am Main	Hessen	HE	64
60326	Frankfurt am Main	Hessen	HE	64
60327	Frankfurt am Main	Hessen	HE	64
60329	Frankfurt am Main	Hessen	HE	64
60385	Frankfurt am Main	Hessen	HE	64
60386	Frankfurt am Main	Hessen	HE	64
60388	Frankfurt am Main	Hessen	HE	64
60389	Frankfurt am Main	Hessen	HE	64
60431	Frankfurt am Main	Hessen	HE	64
60433	Frankfurt am Main	Hessen	HE	64
60435	Frankfurt am Main	Hessen	HE	64
60437	Frankfurt am Main	Hessen	HE	64
60438	Frankfurt am Main	Hessen	HE	64
60439	Frankfurt am Main	Hessen	HE	64
60486	Frankfurt am Main	Hessen	HE	64
60487	Frankfurt am Main	Hessen	HE	64
60488	Frankfurt am Main	Hessen	HE	64
60489	Frankfurt am Main	Hessen	HE	64
60528	Frankfurt am Main	Hessen	HE	64
60529	Frankfurt am Main	Hessen	HE	64
60549	Frankfurt am Main	Hessen	HE	64
60594	Frankfurt am Main	Hessen	HE	64
60596	Frankfurt am Main	Hessen	HE	64
60598	Frankfurt am Main	Hessen	HE	64
60599	Frankfurt am Main	Hessen	HE	64
61118	Bad Vilbel	Hessen	HE	64
61130	Nidderau	Hessen	HE	64
61137	Schöneck	Hessen	HE	64
61138	Niederdorfelden	Hessen	HE	64
61169	Friedberg	Hessen	HE	64
61184	Karben	Hessen	HE	64
61191	Rosbach vor der Höhe	Hessen	HE	64
61191	Rosbach vor der Höhe Nieder-Rosbach	Hessen	HE	64
61191	Rosbach vor der Höhe Rodheim vor der Höhe	Hessen	HE	64
61191	Rosbach vor der Höhe Ober-Rosbach	Hessen	HE	64
61194	Niddatal	Hessen	HE	64
61197	Florstadt	Hessen	HE	64
61200	Wölfersheim	Hessen	HE	64
61203	Reichelsheim	Hessen	HE	64
61206	Wöllstadt	Hessen	HE	64
61209	Echzell	Hessen	HE	64
61231	Bad Nauheim	Hessen	HE	64
61239	Ober-Mörlen	Hessen	HE	64
61250	Usingen	Hessen	HE	64
61267	Neu-Anspach	Hessen	HE	64
61273	Wehrheim	Hessen	HE	64
61276	Weilrod	Hessen	HE	64
61279	Grävenwiesbach	Hessen	HE	64
61348	Bad Homburg vor der Höhe	Hessen	HE	64
61350	Bad Homburg vor der Höhe	Hessen	HE	64
61352	Bad Homburg vor der Höhe	Hessen	HE	64
61381	Friedrichsdorf	Hessen	HE	64
61389	Schmitten	Hessen	HE	64
61440	Oberursel	Hessen	HE	64
61449	Steinbach (Taunus)	Hessen	HE	64
61462	Königstein im Taunus Falkenstein	Hessen	HE	64
61462	Königstein im Taunus	Hessen	HE	64
61462	Königstein im Taunus Mammolshain	Hessen	HE	64
61462	Königstein im Taunus Schneidhain	Hessen	HE	64
61476	Kronberg im Taunus	Hessen	HE	64
61479	Glashütten	Hessen	HE	64
63065	Offenbach	Hessen	HE	64
63067	Offenbach	Hessen	HE	64
63069	Offenbach	Hessen	HE	64
63071	Offenbach	Hessen	HE	64
63073	Offenbach	Hessen	HE	64
63075	Offenbach	Hessen	HE	64
63110	Rodgau	Hessen	HE	64
63128	Dietzenbach	Hessen	HE	64
63150	Heusenstamm	Hessen	HE	64
63165	Mühlheim	Hessen	HE	64
63179	Obertshausen	Hessen	HE	64
63225	Langen	Hessen	HE	64
63263	Neu-Isenburg	Hessen	HE	64
63303	Dreieich	Hessen	HE	64
63322	Rödermark	Hessen	HE	64
63329	Egelsbach	Hessen	HE	64
63405	Hanau	Hessen	HE	64
63450	Hanau	Hessen	HE	64
63452	Hanau	Hessen	HE	64
63454	Hanau	Hessen	HE	64
63456	Hanau	Hessen	HE	64
63457	Hanau	Hessen	HE	64
63477	Maintal	Hessen	HE	64
63486	Bruchköbel	Hessen	HE	64
63500	Seligenstadt	Hessen	HE	64
63505	Langenselbold	Hessen	HE	64
63512	Hainburg	Hessen	HE	64
63517	Rodenbach	Hessen	HE	64
63526	Erlensee	Hessen	HE	64
63533	Mainhausen	Hessen	HE	64
63538	Großkrotzenburg	Hessen	HE	64
63543	Neuberg	Hessen	HE	64
63546	Hammersbach	Hessen	HE	64
63549	Ronneburg	Hessen	HE	64
63571	Gelnhausen	Hessen	HE	64
63579	Freigericht	Hessen	HE	64
63584	Gründau	Hessen	HE	64
63589	Linsengericht	Hessen	HE	64
63594	Hasselroth	Hessen	HE	64
63599	Biebergemünd	Hessen	HE	64
63607	Wächtersbach	Hessen	HE	64
63619	Bad Orb	Hessen	HE	64
63628	Bad Soden-Salmünster	Hessen	HE	64
63633	Birstein	Hessen	HE	64
63636	Brachttal	Hessen	HE	64
63637	Jossgrund	Hessen	HE	64
63639	Flörsbachtal	Hessen	HE	64
63654	Büdingen	Hessen	HE	64
63667	Nidda	Hessen	HE	64
63674	Altenstadt	Hessen	HE	64
63683	Ortenberg	Hessen	HE	64
63688	Gedern	Hessen	HE	64
63691	Ranstadt	Hessen	HE	64
63694	Limeshain	Hessen	HE	64
63695	Glauburg	Hessen	HE	64
63697	Hirzenhain	Hessen	HE	64
63699	Kefenrod	Hessen	HE	64
64283	Darmstadt	Hessen	HE	64
64285	Darmstadt	Hessen	HE	64
64287	Darmstadt	Hessen	HE	64
64289	Darmstadt	Hessen	HE	64
64291	Darmstadt	Hessen	HE	64
64293	Darmstadt	Hessen	HE	64
64295	Darmstadt	Hessen	HE	64
64297	Darmstadt	Hessen	HE	64
64319	Pfungstadt	Hessen	HE	64
64331	Weiterstadt	Hessen	HE	64
64342	Seeheim-Jugenheim	Hessen	HE	64
64347	Griesheim	Hessen	HE	64
64354	Reinheim	Hessen	HE	64
64367	Mühltal	Hessen	HE	64
64372	Ober-Ramstadt	Hessen	HE	64
64380	Roßdorf	Hessen	HE	64
64385	Reichelsheim	Hessen	HE	64
64390	Erzhausen	Hessen	HE	64
64395	Brensbach	Hessen	HE	64
64397	Modautal	Hessen	HE	64
64401	Groß-Bieberau	Hessen	HE	64
64404	Bickenbach	Hessen	HE	64
64405	Fischbachtal	Hessen	HE	64
64407	Fränkisch-Crumbach	Hessen	HE	64
64409	Messel	Hessen	HE	64
64521	Groß-Gerau	Hessen	HE	64
64546	Mörfelden-Walldorf	Hessen	HE	64
64560	Riedstadt	Hessen	HE	64
64569	Nauheim	Hessen	HE	64
64572	Büttelborn	Hessen	HE	64
64579	Gernsheim	Hessen	HE	64
64584	Biebesheim am Rhein	Hessen	HE	64
64589	Stockstadt am Rhein	Hessen	HE	64
64625	Bensheim	Hessen	HE	64
64646	Heppenheim (Bergstraße)	Hessen	HE	64
64653	Lorsch	Hessen	HE	64
64658	Fürth	Hessen	HE	64
64665	Alsbach-Hähnlein	Hessen	HE	64
64668	Rimbach	Hessen	HE	64
64673	Zwingenberg	Hessen	HE	64
64678	Lindenfels	Hessen	HE	64
64683	Einhausen	Hessen	HE	64
64686	Lautertal	Hessen	HE	64
64689	Grasellenbach	Hessen	HE	64
64711	Erbach	Hessen	HE	64
64720	Michelstadt	Hessen	HE	64
64732	Bad König	Hessen	HE	64
64739	Höchst im Odenwald	Hessen	HE	64
64743	Beerfelden	Hessen	HE	64
64747	Breuberg	Hessen	HE	64
64750	Lützelbach	Hessen	HE	64
64753	Brombachtal	Hessen	HE	64
64754	Hesseneck	Hessen	HE	64
64756	Mossautal	Hessen	HE	64
64757	Rothenberg	Hessen	HE	64
64807	Dieburg	Hessen	HE	64
64823	Groß-Umstadt	Hessen	HE	64
64832	Babenhausen	Hessen	HE	64
64839	Münster	Hessen	HE	64
64846	Groß-Zimmern	Hessen	HE	64
64850	Schaafheim	Hessen	HE	64
64853	Otzberg	Hessen	HE	64
64859	Eppertshausen	Hessen	HE	64
65183	Wiesbaden	Hessen	HE	64
65185	Wiesbaden	Hessen	HE	64
65187	Wiesbaden	Hessen	HE	64
65189	Wiesbaden	Hessen	HE	64
65191	Wiesbaden	Hessen	HE	64
65193	Wiesbaden	Hessen	HE	64
65195	Wiesbaden	Hessen	HE	64
65197	Wiesbaden	Hessen	HE	64
65199	Wiesbaden	Hessen	HE	64
65201	Wiesbaden	Hessen	HE	64
65203	Wiesbaden	Hessen	HE	64
65205	Wiesbaden	Hessen	HE	64
65207	Wiesbaden	Hessen	HE	64
65219	Taunusstein	Hessen	HE	64
65220	Taunusstein	Hessen	HE	64
65221	Taunusstein	Hessen	HE	64
65222	Taunusstein	Hessen	HE	64
65223	Taunusstein	Hessen	HE	64
65224	Taunusstein	Hessen	HE	64
65232	Taunusstein	Hessen	HE	64
65239	Hochheim am Main	Hessen	HE	64
65307	Bad Schwalbach	Hessen	HE	64
65321	Heidenrod	Hessen	HE	64
65326	Aarbergen	Hessen	HE	64
65329	Hohenstein	Hessen	HE	64
65343	Eltville am Rhein	Hessen	HE	64
65344	Eltville am Rhein	Hessen	HE	64
65345	Eltville am Rhein	Hessen	HE	64
65346	Eltville am Rhein	Hessen	HE	64
65347	Eltville am Rhein	Hessen	HE	64
65366	Geisenheim	Hessen	HE	64
65375	Oestrich-Winkel	Hessen	HE	64
65385	Rüdesheim am Rhein	Hessen	HE	64
65388	Schlangenbad	Hessen	HE	64
65391	Lorch	Hessen	HE	64
65396	Walluf	Hessen	HE	64
65399	Kiedrich	Hessen	HE	64
65428	Rüsselsheim	Hessen	HE	64
65439	Flörsheim	Hessen	HE	64
65451	Kelsterbach	Hessen	HE	64
65462	Ginsheim-Gustavsburg	Hessen	HE	64
65468	Trebur	Hessen	HE	64
65474	Bischofsheim	Hessen	HE	64
65479	Raunheim	Hessen	HE	64
65510	Idstein	Hessen	HE	64
65510	Hünstetten	Hessen	HE	64
65527	Niedernhausen	Hessen	HE	64
65529	Waldems	Hessen	HE	64
65719	Hofheim am Taunus	Hessen	HE	64
65760	Eschborn	Hessen	HE	64
65779	Kelkheim (Taunus)	Hessen	HE	64
65795	Hattersheim	Hessen	HE	64
65812	Bad Soden am Taunus	Hessen	HE	64
65817	Eppstein	Hessen	HE	64
65824	Schwalbach am Taunus	Hessen	HE	64
65830	Kriftel	Hessen	HE	64
65835	Liederbach am Taunus	Hessen	HE	64
65843	Sulzbach	Hessen	HE	64
65929	Frankfurt am Main	Hessen	HE	64
65931	Frankfurt am Main	Hessen	HE	64
65933	Frankfurt am Main	Hessen	HE	64
65934	Frankfurt am Main	Hessen	HE	64
65936	Frankfurt am Main	Hessen	HE	64
68519	Viernheim	Hessen	HE	64
68623	Lampertheim	Hessen	HE	64
68642	Bürstadt	Hessen	HE	64
68647	Biblis	Hessen	HE	64
68649	Groß-Rohrheim	Hessen	HE	64
69239	Neckarsteinach	Hessen	HE	64
69434	Hirschhorn	Hessen	HE	64
69483	Wald-Michelbach	Hessen	HE	64
69488	Birkenau	Hessen	HE	64
69509	Mörlenbach	Hessen	HE	64
69517	Gorxheimertal	Hessen	HE	64
69518	Abtsteinach	Hessen	HE	64
35037	Marburg	Hessen	HE	65
35039	Marburg	Hessen	HE	65
35041	Marburg	Hessen	HE	65
35043	Marburg	Hessen	HE	65
35075	Gladenbach	Hessen	HE	65
35080	Bad Endbach	Hessen	HE	65
35083	Wetter	Hessen	HE	65
35085	Ebsdorfergrund	Hessen	HE	65
35091	Cölbe	Hessen	HE	65
35094	Lahntal	Hessen	HE	65
35096	Weimar	Hessen	HE	65
35102	Lohra	Hessen	HE	65
35112	Fronhausen	Hessen	HE	65
35117	Münchhausen	Hessen	HE	65
35216	Biedenkopf	Hessen	HE	65
35232	Dautphetal	Hessen	HE	65
35236	Breidenbach	Hessen	HE	65
35239	Steffenberg	Hessen	HE	65
35260	Stadtallendorf	Hessen	HE	65
35274	Kirchhain	Hessen	HE	65
35279	Neustadt (Hessen)	Hessen	HE	65
35282	Rauschenberg	Hessen	HE	65
35287	Amöneburg	Hessen	HE	65
35288	Wohratal	Hessen	HE	65
35305	Grünberg	Hessen	HE	65
35315	Homberg (Ohm)	Hessen	HE	65
35321	Laubach	Hessen	HE	65
35325	Mücke	Hessen	HE	65
35327	Ulrichstein	Hessen	HE	65
35329	Gemünden (Felda)	Hessen	HE	65
35390	Gießen	Hessen	HE	65
35392	Gießen	Hessen	HE	65
35394	Gießen	Hessen	HE	65
35396	Gießen	Hessen	HE	65
35398	Gießen	Hessen	HE	65
35410	Hungen	Hessen	HE	65
35415	Pohlheim	Hessen	HE	65
35418	Buseck	Hessen	HE	65
35423	Lich	Hessen	HE	65
35428	Langgöns	Hessen	HE	65
35435	Wettenberg	Hessen	HE	65
35440	Linden	Hessen	HE	65
35444	Biebertal	Hessen	HE	65
35447	Reiskirchen	Hessen	HE	65
35452	Heuchelheim	Hessen	HE	65
35457	Lollar	Hessen	HE	65
35460	Staufenberg	Hessen	HE	65
35463	Fernwald	Hessen	HE	65
35466	Rabenau	Hessen	HE	65
35469	Allendorf (Lumda)	Hessen	HE	65
35576	Wetzlar	Hessen	HE	65
35578	Wetzlar	Hessen	HE	65
35579	Wetzlar	Hessen	HE	65
35580	Wetzlar	Hessen	HE	65
35581	Wetzlar	Hessen	HE	65
35582	Wetzlar	Hessen	HE	65
35583	Wetzlar	Hessen	HE	65
35584	Wetzlar	Hessen	HE	65
35585	Wetzlar	Hessen	HE	65
35586	Wetzlar	Hessen	HE	65
35606	Solms	Hessen	HE	65
35614	Aßlar	Hessen	HE	65
35619	Braunfels Tiefenbach	Hessen	HE	65
35619	Braunfels Bonbaden	Hessen	HE	65
35619	Braunfels Braunfels	Hessen	HE	65
35619	Braunfels	Hessen	HE	65
35619	Braunfels Neukirchen	Hessen	HE	65
35619	Braunfels Philippstein	Hessen	HE	65
35619	Braunfels Altenkirchen	Hessen	HE	65
35625	Hüttenberg	Hessen	HE	65
35630	Ehringshausen	Hessen	HE	65
35633	Lahnau	Hessen	HE	65
35638	Leun	Hessen	HE	65
35641	Schöffengrund	Hessen	HE	65
35644	Hohenahr	Hessen	HE	65
35647	Waldsolms	Hessen	HE	65
35649	Bischoffen	Hessen	HE	65
35683	Dillenburg	Hessen	HE	65
35684	Dillenburg	Hessen	HE	65
35685	Dillenburg	Hessen	HE	65
35686	Dillenburg	Hessen	HE	65
35687	Dillenburg	Hessen	HE	65
35688	Dillenburg	Hessen	HE	65
35689	Dillenburg	Hessen	HE	65
35690	Dillenburg	Hessen	HE	65
35708	Haiger	Hessen	HE	65
35713	Eschenburg	Hessen	HE	65
35716	Dietzhölztal	Hessen	HE	65
35719	Angelburg	Hessen	HE	65
35745	Herborn	Hessen	HE	65
35753	Greifenstein	Hessen	HE	65
35756	Mittenaar	Hessen	HE	65
35759	Driedorf	Hessen	HE	65
35764	Sinn	Hessen	HE	65
35767	Breitscheid	Hessen	HE	65
35768	Siegbach	Hessen	HE	65
35781	Weilburg	Hessen	HE	65
35789	Weilmünster	Hessen	HE	65
35792	Löhnberg	Hessen	HE	65
35794	Mengerskirchen	Hessen	HE	65
35796	Weinbach	Hessen	HE	65
35799	Merenberg	Hessen	HE	65
36110	Schlitz	Hessen	HE	65
36304	Alsfeld	Hessen	HE	65
36318	Schwalmtal	Hessen	HE	65
36320	Kirtorf	Hessen	HE	65
36323	Grebenau	Hessen	HE	65
36325	Feldatal	Hessen	HE	65
36326	Antrifttal	Hessen	HE	65
36329	Romrod	Hessen	HE	65
36341	Lauterbach	Hessen	HE	65
36355	Grebenhain	Hessen	HE	65
36358	Herbstein	Hessen	HE	65
36367	Wartenberg	Hessen	HE	65
36369	Lautertal	Hessen	HE	65
36399	Freiensteinau	Hessen	HE	65
63679	Schotten	Hessen	HE	65
65520	Bad Camberg	Hessen	HE	65
65549	Limburg an der Lahn	Hessen	HE	65
65550	Limburg an der Lahn	Hessen	HE	65
65551	Limburg an der Lahn	Hessen	HE	65
65552	Limburg an der Lahn	Hessen	HE	65
65553	Limburg an der Lahn	Hessen	HE	65
65554	Limburg an der Lahn	Hessen	HE	65
65555	Limburg an der Lahn	Hessen	HE	65
65556	Limburg an der Lahn	Hessen	HE	65
65589	Hadamar	Hessen	HE	65
65594	Runkel	Hessen	HE	65
65597	Hünfelden	Hessen	HE	65
65599	Dornburg	Hessen	HE	65
65604	Elz	Hessen	HE	65
65606	Villmar	Hessen	HE	65
65611	Brechen	Hessen	HE	65
65614	Beselich	Hessen	HE	65
65618	Selters (Taunus)	Hessen	HE	65
65620	Waldbrunn (Westerwald)	Hessen	HE	65
65627	Elbtal	Hessen	HE	65
34117	Kassel	Hessen	HE	66
34119	Kassel	Hessen	HE	66
34121	Kassel	Hessen	HE	66
34123	Kassel	Hessen	HE	66
34125	Kassel	Hessen	HE	66
34127	Kassel	Hessen	HE	66
34128	Kassel	Hessen	HE	66
34130	Kassel	Hessen	HE	66
34131	Kassel	Hessen	HE	66
34132	Kassel	Hessen	HE	66
34134	Kassel	Hessen	HE	66
34212	Melsungen	Hessen	HE	66
34225	Baunatal	Hessen	HE	66
34233	Fuldatal	Hessen	HE	66
34246	Vellmar	Hessen	HE	66
34253	Lohfelden	Hessen	HE	66
34260	Kaufungen	Hessen	HE	66
34266	Niestetal	Hessen	HE	66
34270	Schauenburg	Hessen	HE	66
34277	Fuldabrück	Hessen	HE	66
34281	Gudensberg	Hessen	HE	66
34286	Spangenberg	Hessen	HE	66
34289	Zierenberg	Hessen	HE	66
34292	Ahnatal	Hessen	HE	66
34295	Edermünde	Hessen	HE	66
34298	Helsa	Hessen	HE	66
34302	Guxhagen	Hessen	HE	66
34305	Niedenstein	Hessen	HE	66
34308	Bad Emstal	Hessen	HE	66
34311	Naumburg	Hessen	HE	66
34314	Espenau	Hessen	HE	66
34317	Habichtswald	Hessen	HE	66
34320	Söhrewald	Hessen	HE	66
34323	Malsfeld	Hessen	HE	66
34326	Morschen	Hessen	HE	66
34327	Körle	Hessen	HE	66
34329	Nieste	Hessen	HE	66
34359	Reinhardshagen	Hessen	HE	66
34369	Hofgeismar	Hessen	HE	66
34376	Immenhausen	Hessen	HE	66
34379	Calden	Hessen	HE	66
34385	Bad Karlshafen	Hessen	HE	66
34388	Trendelburg	Hessen	HE	66
34393	Grebenstein	Hessen	HE	66
34396	Liebenau	Hessen	HE	66
34399	Oberweser	Hessen	HE	66
34454	Bad Arolsen	Hessen	HE	66
34466	Wolfhagen	Hessen	HE	66
34471	Volkmarsen	Hessen	HE	66
34474	Diemelstadt	Hessen	HE	66
34477	Twistetal	Hessen	HE	66
34479	Breuna	Hessen	HE	66
34497	Korbach	Hessen	HE	66
34508	Willingen (Upland)	Hessen	HE	66
34513	Waldeck	Hessen	HE	66
34516	Vöhl	Hessen	HE	66
34519	Diemelsee	Hessen	HE	66
34537	Bad Wildungen	Hessen	HE	66
34549	Edertal	Hessen	HE	66
34560	Fritzlar	Hessen	HE	66
34576	Homberg (Efze)	Hessen	HE	66
34582	Borken	Hessen	HE	66
34587	Felsberg	Hessen	HE	66
34590	Wabern	Hessen	HE	66
34593	Knüllwald	Hessen	HE	66
34596	Bad Zwesten	Hessen	HE	66
34599	Neuental	Hessen	HE	66
34613	Schwalmstadt	Hessen	HE	66
34621	Frielendorf	Hessen	HE	66
34626	Neukirchen	Hessen	HE	66
34628	Willingshausen	Hessen	HE	66
34630	Gilserberg	Hessen	HE	66
34632	Jesberg	Hessen	HE	66
34633	Ottrau	Hessen	HE	66
34637	Schrecksbach	Hessen	HE	66
34639	Schwarzenborn	Hessen	HE	66
35066	Frankenberg (Eder)	Hessen	HE	66
35088	Battenberg (Eder)	Hessen	HE	66
35099	Burgwald	Hessen	HE	66
35104	Lichtenfels	Hessen	HE	66
35108	Allendorf (Eder) Battenfeld	Hessen	HE	66
35108	Allendorf (Eder) Haine	Hessen	HE	66
35108	Allendorf (Eder)	Hessen	HE	66
35108	Allendorf (Eder) Osterfeld	Hessen	HE	66
35108	Allendorf (Eder) Rennertehausen	Hessen	HE	66
35110	Frankenau	Hessen	HE	66
35114	Haina (Kloster)	Hessen	HE	66
35116	Hatzfeld (Eder)	Hessen	HE	66
35119	Rosenthal	Hessen	HE	66
35285	Gemünden (Wohra)	Hessen	HE	66
36037	Fulda	Hessen	HE	66
36039	Fulda	Hessen	HE	66
36041	Fulda	Hessen	HE	66
36043	Fulda	Hessen	HE	66
36088	Hünfeld	Hessen	HE	66
36093	Künzell	Hessen	HE	66
36100	Petersberg	Hessen	HE	66
36103	Flieden	Hessen	HE	66
36115	Hilders	Hessen	HE	66
36115	Ehrenberg	Hessen	HE	66
36119	Neuhof	Hessen	HE	66
36124	Eichenzell	Hessen	HE	66
36129	Gersfeld	Hessen	HE	66
36132	Eiterfeld	Hessen	HE	66
36137	Großenlüder	Hessen	HE	66
36142	Tann	Hessen	HE	66
36145	Hofbieber	Hessen	HE	66
36148	Kalbach	Hessen	HE	66
36151	Burghaun	Hessen	HE	66
36154	Hosenfeld	Hessen	HE	66
36157	Ebersburg	Hessen	HE	66
36160	Dipperz	Hessen	HE	66
36163	Poppenhausen	Hessen	HE	66
36166	Haunetal	Hessen	HE	66
36167	Nüsttal	Hessen	HE	66
36169	Rasdorf	Hessen	HE	66
36179	Bebra	Hessen	HE	66
36199	Rotenburg an der Fulda	Hessen	HE	66
36205	Sontra	Hessen	HE	66
36208	Wildeck	Hessen	HE	66
36211	Alheim	Hessen	HE	66
36214	Nentershausen	Hessen	HE	66
36217	Ronshausen	Hessen	HE	66
36219	Cornberg	Hessen	HE	66
36251	Bad Hersfeld	Hessen	HE	66
36251	Ludwigsau	Hessen	HE	66
36266	Heringen (Werra)	Hessen	HE	66
36269	Philippsthal (Werra)	Hessen	HE	66
36272	Niederaula	Hessen	HE	66
36275	Kirchheim	Hessen	HE	66
36277	Schenklengsfeld	Hessen	HE	66
36280	Oberaula	Hessen	HE	66
36282	Hauneck	Hessen	HE	66
36284	Hohenroda	Hessen	HE	66
36286	Neuenstein	Hessen	HE	66
36287	Breitenbach am Herzberg	Hessen	HE	66
36289	Friedewald	Hessen	HE	66
36364	Bad Salzschlirf	Hessen	HE	66
37213	Witzenhausen	Hessen	HE	66
37214	Witzenhausen	Hessen	HE	66
37215	Witzenhausen	Hessen	HE	66
37216	Witzenhausen	Hessen	HE	66
37217	Witzenhausen	Hessen	HE	66
37218	Witzenhausen	Hessen	HE	66
37235	Hessisch Lichtenau	Hessen	HE	66
37242	Bad Sooden-Allendorf	Hessen	HE	66
37247	Großalmerode	Hessen	HE	66
37249	Neu-Eichenberg	Hessen	HE	66
37269	Eschwege	Hessen	HE	66
37276	Meinhard	Hessen	HE	66
37281	Wanfried	Hessen	HE	66
37284	Waldkappel	Hessen	HE	66
37287	Wehretal	Hessen	HE	66
37290	Meißner	Hessen	HE	66
37293	Herleshausen	Hessen	HE	66
37296	Ringgau	Hessen	HE	66
37297	Berkatal	Hessen	HE	66
37299	Weißenborn	Hessen	HE	66
59969	Bromskirchen	Hessen	HE	66
20038	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20095	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20095	Hamburg Klostertor	Hamburg	HH	Hamburg; Freie und Hansestadt
20095	Hamburg Sankt Georg	Hamburg	HH	Hamburg; Freie und Hansestadt
20095	Hamburg Altstadt	Hamburg	HH	Hamburg; Freie und Hansestadt
20097	Hamburg Hammerbrook	Hamburg	HH	Hamburg; Freie und Hansestadt
20097	Hamburg Klostertor	Hamburg	HH	Hamburg; Freie und Hansestadt
20097	Hamburg Sankt Georg	Hamburg	HH	Hamburg; Freie und Hansestadt
20097	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20099	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20099	Hamburg Sankt Georg	Hamburg	HH	Hamburg; Freie und Hansestadt
20099	Hamburg Hamburg-Altstadt	Hamburg	HH	Hamburg; Freie und Hansestadt
20144	Hamburg Rotherbaum	Hamburg	HH	Hamburg; Freie und Hansestadt
20144	Hamburg Hoheluft-Ost	Hamburg	HH	Hamburg; Freie und Hansestadt
20144	Hamburg Harvestehude	Hamburg	HH	Hamburg; Freie und Hansestadt
20144	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20144	Hamburg Eimsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
20146	Hamburg Harvestehude	Hamburg	HH	Hamburg; Freie und Hansestadt
20146	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20146	Hamburg Rotherbaum	Hamburg	HH	Hamburg; Freie und Hansestadt
20148	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20148	Hamburg Rotherbaum	Hamburg	HH	Hamburg; Freie und Hansestadt
20148	Hamburg Harvestehude	Hamburg	HH	Hamburg; Freie und Hansestadt
20149	Hamburg Harvestehude	Hamburg	HH	Hamburg; Freie und Hansestadt
20149	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20149	Hamburg Rotherbaum	Hamburg	HH	Hamburg; Freie und Hansestadt
20249	Hamburg Eppendorf	Hamburg	HH	Hamburg; Freie und Hansestadt
20249	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20249	Hamburg Hoheluft-Ost	Hamburg	HH	Hamburg; Freie und Hansestadt
20249	Hamburg Winterhude	Hamburg	HH	Hamburg; Freie und Hansestadt
20249	Hamburg Harvestehude	Hamburg	HH	Hamburg; Freie und Hansestadt
20251	Hamburg Eppendorf	Hamburg	HH	Hamburg; Freie und Hansestadt
20251	Hamburg Hoheluft-Ost	Hamburg	HH	Hamburg; Freie und Hansestadt
20251	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20251	Hamburg Alsterdorf	Hamburg	HH	Hamburg; Freie und Hansestadt
20253	Hamburg Lokstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
20253	Hamburg Hoheluft-Ost	Hamburg	HH	Hamburg; Freie und Hansestadt
20253	Hamburg Eimsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
20253	Hamburg Harvestehude	Hamburg	HH	Hamburg; Freie und Hansestadt
20253	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20253	Hamburg Hoheluft-West	Hamburg	HH	Hamburg; Freie und Hansestadt
20255	Hamburg Eimsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
20255	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20255	Hamburg Stellingen	Hamburg	HH	Hamburg; Freie und Hansestadt
20255	Hamburg Hoheluft-West	Hamburg	HH	Hamburg; Freie und Hansestadt
20255	Hamburg Lokstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
20257	Hamburg Altona-Nord	Hamburg	HH	Hamburg; Freie und Hansestadt
20257	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20257	Hamburg Eimsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
27616	Hollen	Niedersachsen	NI	Cuxhaven
20259	Hamburg Eimsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
20259	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20354	Hamburg Rotherbaum	Hamburg	HH	Hamburg; Freie und Hansestadt
20354	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20354	Hamburg Neustadt	Hamburg	HH	Hamburg; Freie und Hansestadt
20354	Hamburg Sankt Pauli	Hamburg	HH	Hamburg; Freie und Hansestadt
20355	Hamburg Neustadt	Hamburg	HH	Hamburg; Freie und Hansestadt
20355	Hamburg Sankt Pauli	Hamburg	HH	Hamburg; Freie und Hansestadt
20355	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20357	Hamburg Altona-Altstadt	Hamburg	HH	Hamburg; Freie und Hansestadt
20357	Hamburg Rotherbaum	Hamburg	HH	Hamburg; Freie und Hansestadt
20357	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20357	Hamburg Altona-Nord	Hamburg	HH	Hamburg; Freie und Hansestadt
20357	Hamburg Sankt Pauli	Hamburg	HH	Hamburg; Freie und Hansestadt
20357	Hamburg Eimsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
20359	Hamburg Sankt Pauli	Hamburg	HH	Hamburg; Freie und Hansestadt
20359	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20359	Hamburg Altona-Altstadt	Hamburg	HH	Hamburg; Freie und Hansestadt
20359	Hamburg Neustadt	Hamburg	HH	Hamburg; Freie und Hansestadt
20457	Hamburg Kleiner Grasbrook	Hamburg	HH	Hamburg; Freie und Hansestadt
20457	Hamburg Steinwerder	Hamburg	HH	Hamburg; Freie und Hansestadt
20457	Hamburg Neustadt	Hamburg	HH	Hamburg; Freie und Hansestadt
20457	Hamburg Klostertor	Hamburg	HH	Hamburg; Freie und Hansestadt
20457	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20457	Hamburg Hamburg-Altstadt	Hamburg	HH	Hamburg; Freie und Hansestadt
20459	Hamburg Neustadt	Hamburg	HH	Hamburg; Freie und Hansestadt
20459	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20459	Hamburg Hamburg-Altstadt	Hamburg	HH	Hamburg; Freie und Hansestadt
20459	Hamburg Sankt Pauli	Hamburg	HH	Hamburg; Freie und Hansestadt
20535	Hamburg Hamm-Nord	Hamburg	HH	Hamburg; Freie und Hansestadt
20535	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20535	Hamburg Borgfelde	Hamburg	HH	Hamburg; Freie und Hansestadt
20537	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20537	Hamburg Borgfelde	Hamburg	HH	Hamburg; Freie und Hansestadt
20537	Hamburg Hamm-Mitte	Hamburg	HH	Hamburg; Freie und Hansestadt
20537	Hamburg Hammerbrook	Hamburg	HH	Hamburg; Freie und Hansestadt
20537	Hamburg Hamm-Süd	Hamburg	HH	Hamburg; Freie und Hansestadt
20539	Hamburg Rothenburgsort	Hamburg	HH	Hamburg; Freie und Hansestadt
20539	Hamburg Wilhelmsburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20539	Hamburg Kleiner Grasbrook	Hamburg	HH	Hamburg; Freie und Hansestadt
20539	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
20539	Hamburg Veddel	Hamburg	HH	Hamburg; Freie und Hansestadt
21029	Hamburg Altengamme	Hamburg	HH	Hamburg; Freie und Hansestadt
21029	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21029	Hamburg Curslack	Hamburg	HH	Hamburg; Freie und Hansestadt
21029	Hamburg Bergedorf	Hamburg	HH	Hamburg; Freie und Hansestadt
21031	Hamburg Bergedorf	Hamburg	HH	Hamburg; Freie und Hansestadt
21031	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21031	Hamburg Lohbrügge	Hamburg	HH	Hamburg; Freie und Hansestadt
21033	Hamburg Bergedorf	Hamburg	HH	Hamburg; Freie und Hansestadt
21033	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21033	Hamburg Lohbrügge	Hamburg	HH	Hamburg; Freie und Hansestadt
21033	Hamburg Billwerder	Hamburg	HH	Hamburg; Freie und Hansestadt
21035	Hamburg Allermöhe	Hamburg	HH	Hamburg; Freie und Hansestadt
21035	Hamburg Billwerder	Hamburg	HH	Hamburg; Freie und Hansestadt
21035	Hamburg Bergedorf	Hamburg	HH	Hamburg; Freie und Hansestadt
21035	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21037	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21037	Hamburg Curslack	Hamburg	HH	Hamburg; Freie und Hansestadt
21037	Hamburg Allermöhe	Hamburg	HH	Hamburg; Freie und Hansestadt
21037	Hamburg Neuengamme	Hamburg	HH	Hamburg; Freie und Hansestadt
21037	Hamburg Tatenberg	Hamburg	HH	Hamburg; Freie und Hansestadt
21037	Hamburg Kirchwerder	Hamburg	HH	Hamburg; Freie und Hansestadt
21037	Hamburg Ochsenwerder	Hamburg	HH	Hamburg; Freie und Hansestadt
21037	Hamburg Spadenland	Hamburg	HH	Hamburg; Freie und Hansestadt
21037	Hamburg Reitbrook	Hamburg	HH	Hamburg; Freie und Hansestadt
21039	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21073	Hamburg Harburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21073	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21073	Hamburg Heimfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
21073	Hamburg Wilstorf	Hamburg	HH	Hamburg; Freie und Hansestadt
21073	Hamburg Eißendorf	Hamburg	HH	Hamburg; Freie und Hansestadt
21075	Hamburg Harburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21075	Hamburg Heimfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
21075	Hamburg Hausbruch	Hamburg	HH	Hamburg; Freie und Hansestadt
21075	Hamburg Eißendorf	Hamburg	HH	Hamburg; Freie und Hansestadt
21075	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21077	Hamburg Wilstorf	Hamburg	HH	Hamburg; Freie und Hansestadt
21077	Hamburg Rönneburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21077	Hamburg Langenbek	Hamburg	HH	Hamburg; Freie und Hansestadt
21077	Hamburg Sinstorf	Hamburg	HH	Hamburg; Freie und Hansestadt
21077	Hamburg Marmstorf	Hamburg	HH	Hamburg; Freie und Hansestadt
21077	Hamburg Eißendorf	Hamburg	HH	Hamburg; Freie und Hansestadt
21077	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21079	Hamburg Harburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21079	Hamburg Hausbruch	Hamburg	HH	Hamburg; Freie und Hansestadt
21079	Hamburg Heimfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
21079	Hamburg Rönneburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21079	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21079	Hamburg Wilstorf	Hamburg	HH	Hamburg; Freie und Hansestadt
21079	Hamburg Gut Moor	Hamburg	HH	Hamburg; Freie und Hansestadt
21079	Hamburg Moorburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21079	Hamburg Neuland	Hamburg	HH	Hamburg; Freie und Hansestadt
21079	Hamburg Sinstorf	Hamburg	HH	Hamburg; Freie und Hansestadt
21079	Hamburg Langenbek	Hamburg	HH	Hamburg; Freie und Hansestadt
21107	Hamburg Wilhelmsburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21107	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21107	Hamburg Steinwerder	Hamburg	HH	Hamburg; Freie und Hansestadt
21109	Hamburg Wilhelmsburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21109	Hamburg Veddel	Hamburg	HH	Hamburg; Freie und Hansestadt
21109	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21129	Hamburg Altenwerder	Hamburg	HH	Hamburg; Freie und Hansestadt
21129	Hamburg Cranz	Hamburg	HH	Hamburg; Freie und Hansestadt
21129	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21129	Hamburg Francop	Hamburg	HH	Hamburg; Freie und Hansestadt
21129	Hamburg Waltershof	Hamburg	HH	Hamburg; Freie und Hansestadt
21129	Hamburg Finkenwerder	Hamburg	HH	Hamburg; Freie und Hansestadt
21129	Hamburg Moorburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21129	Hamburg Neuenfelde	Hamburg	HH	Hamburg; Freie und Hansestadt
21147	Hamburg Neugraben-Fischbek	Hamburg	HH	Hamburg; Freie und Hansestadt
21147	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21147	Hamburg Hausbruch	Hamburg	HH	Hamburg; Freie und Hansestadt
21149	Hamburg Hausbruch	Hamburg	HH	Hamburg; Freie und Hansestadt
21149	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
21149	Hamburg Neugraben-Fischbek	Hamburg	HH	Hamburg; Freie und Hansestadt
22041	Hamburg Wandsbek	Hamburg	HH	Hamburg; Freie und Hansestadt
22041	Hamburg Marienthal	Hamburg	HH	Hamburg; Freie und Hansestadt
22041	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22041	Hamburg Tonndorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22043	Hamburg Tonndorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22043	Hamburg Jenfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22043	Hamburg Marienthal	Hamburg	HH	Hamburg; Freie und Hansestadt
22043	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22045	Hamburg Tonndorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22045	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22045	Hamburg Jenfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22047	Hamburg Wandsbek	Hamburg	HH	Hamburg; Freie und Hansestadt
22047	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22047	Hamburg Bramfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22047	Hamburg Tonndorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22049	Hamburg Wandsbek	Hamburg	HH	Hamburg; Freie und Hansestadt
22049	Hamburg Dulsberg	Hamburg	HH	Hamburg; Freie und Hansestadt
22049	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22081	Hamburg Barmbek-Süd	Hamburg	HH	Hamburg; Freie und Hansestadt
22081	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22081	Hamburg Uhlenhorst	Hamburg	HH	Hamburg; Freie und Hansestadt
22083	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22083	Hamburg Barmbek-Süd	Hamburg	HH	Hamburg; Freie und Hansestadt
22085	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22085	Hamburg Barmbek-Süd	Hamburg	HH	Hamburg; Freie und Hansestadt
22085	Hamburg Uhlenhorst	Hamburg	HH	Hamburg; Freie und Hansestadt
22087	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22087	Hamburg Uhlenhorst	Hamburg	HH	Hamburg; Freie und Hansestadt
22087	Hamburg Eilbek	Hamburg	HH	Hamburg; Freie und Hansestadt
22087	Hamburg Hamm-Nord	Hamburg	HH	Hamburg; Freie und Hansestadt
22087	Hamburg Hohenfelde	Hamburg	HH	Hamburg; Freie und Hansestadt
22089	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22089	Hamburg Eilbek	Hamburg	HH	Hamburg; Freie und Hansestadt
22089	Hamburg Hohenfelde	Hamburg	HH	Hamburg; Freie und Hansestadt
22089	Hamburg Marienthal	Hamburg	HH	Hamburg; Freie und Hansestadt
22089	Hamburg Wandsbek	Hamburg	HH	Hamburg; Freie und Hansestadt
22089	Hamburg Hamm-Nord	Hamburg	HH	Hamburg; Freie und Hansestadt
22111	Hamburg Billstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22111	Hamburg Billbrook	Hamburg	HH	Hamburg; Freie und Hansestadt
22111	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22111	Hamburg Horn	Hamburg	HH	Hamburg; Freie und Hansestadt
22115	Hamburg Lohbrügge	Hamburg	HH	Hamburg; Freie und Hansestadt
22115	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22115	Hamburg Billstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22117	Hamburg Billstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22117	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22119	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22119	Hamburg Horn	Hamburg	HH	Hamburg; Freie und Hansestadt
22119	Hamburg Billstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22143	Hamburg Rahlstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22143	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22145	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22147	Hamburg Rahlstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22147	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22149	Hamburg Tonndorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22149	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22149	Hamburg Rahlstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22159	Hamburg Tonndorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22159	Hamburg Farmsen-Berne	Hamburg	HH	Hamburg; Freie und Hansestadt
22159	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22159	Hamburg Sasel	Hamburg	HH	Hamburg; Freie und Hansestadt
22159	Hamburg Bramfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22175	Hamburg Bramfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22175	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22177	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22177	Hamburg Bramfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22177	Hamburg Steilshoop	Hamburg	HH	Hamburg; Freie und Hansestadt
22179	Hamburg Bramfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22179	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22297	Hamburg Barmbek-Nord	Hamburg	HH	Hamburg; Freie und Hansestadt
22297	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22297	Hamburg Alsterdorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22297	Hamburg Winterhude	Hamburg	HH	Hamburg; Freie und Hansestadt
22297	Hamburg Groß Borstel	Hamburg	HH	Hamburg; Freie und Hansestadt
22299	Hamburg Winterhude	Hamburg	HH	Hamburg; Freie und Hansestadt
22299	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22301	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22301	Hamburg Winterhude	Hamburg	HH	Hamburg; Freie und Hansestadt
22303	Hamburg Winterhude	Hamburg	HH	Hamburg; Freie und Hansestadt
22303	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22303	Hamburg Barmbek-Nord	Hamburg	HH	Hamburg; Freie und Hansestadt
22305	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22305	Hamburg Barmbek-Süd	Hamburg	HH	Hamburg; Freie und Hansestadt
22305	Hamburg Barmbek-Nord	Hamburg	HH	Hamburg; Freie und Hansestadt
22305	Hamburg Winterhude	Hamburg	HH	Hamburg; Freie und Hansestadt
22307	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22307	Hamburg Barmbek-Nord	Hamburg	HH	Hamburg; Freie und Hansestadt
22309	Hamburg Barmbek-Nord	Hamburg	HH	Hamburg; Freie und Hansestadt
22309	Hamburg Bramfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22309	Hamburg Steilshoop	Hamburg	HH	Hamburg; Freie und Hansestadt
22309	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22309	Hamburg Ohlsdorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22335	Hamburg Ohlsdorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22335	Hamburg Fuhlsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22335	Hamburg Alsterdorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22335	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22335	Hamburg Groß Borstel	Hamburg	HH	Hamburg; Freie und Hansestadt
22337	Hamburg Alsterdorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22337	Hamburg Ohlsdorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22337	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22339	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22339	Hamburg Hummelsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22339	Hamburg Fuhlsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22359	Hamburg Bergstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22359	Hamburg Rahlstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22359	Hamburg Volksdorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22359	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22391	Hamburg Hummelsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22391	Hamburg Wellingsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22391	Hamburg Ohlsdorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22391	Hamburg Bramfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22391	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22391	Hamburg Sasel	Hamburg	HH	Hamburg; Freie und Hansestadt
22391	Hamburg Poppenbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22393	Hamburg Bramfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22393	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22393	Hamburg Sasel	Hamburg	HH	Hamburg; Freie und Hansestadt
22393	Hamburg Poppenbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22393	Hamburg Wellingsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22395	Hamburg Bergstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22395	Hamburg Wohldorf-Ohlstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22395	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22395	Hamburg Sasel	Hamburg	HH	Hamburg; Freie und Hansestadt
22395	Hamburg Poppenbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22397	Hamburg Lemsahl-Mellingstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22397	Hamburg Duvenstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22397	Hamburg Wohldorf-Ohlstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22397	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22399	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22399	Hamburg Lemsahl-Mellingstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22399	Hamburg Poppenbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22399	Hamburg Hummelsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22415	Hamburg Hummelsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22415	Hamburg Langenhorn	Hamburg	HH	Hamburg; Freie und Hansestadt
22415	Hamburg Fuhlsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22415	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22417	Hamburg Langenhorn	Hamburg	HH	Hamburg; Freie und Hansestadt
22417	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22417	Hamburg Hummelsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22419	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22419	Hamburg Langenhorn	Hamburg	HH	Hamburg; Freie und Hansestadt
22453	Hamburg Groß Borstel	Hamburg	HH	Hamburg; Freie und Hansestadt
22453	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22453	Hamburg Fuhlsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22453	Hamburg Niendorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22455	Hamburg Schnelsen	Hamburg	HH	Hamburg; Freie und Hansestadt
22455	Hamburg Niendorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22455	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22457	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22457	Hamburg Niendorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22457	Hamburg Schnelsen	Hamburg	HH	Hamburg; Freie und Hansestadt
22457	Hamburg Eidelstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22459	Hamburg Niendorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22459	Hamburg Schnelsen	Hamburg	HH	Hamburg; Freie und Hansestadt
22459	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22523	Hamburg Eidelstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22523	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22525	Hamburg Bahrenfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22525	Hamburg Eimsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22525	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22525	Hamburg Lurup	Hamburg	HH	Hamburg; Freie und Hansestadt
22525	Hamburg Eidelstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22525	Hamburg Stellingen	Hamburg	HH	Hamburg; Freie und Hansestadt
22527	Hamburg Stellingen	Hamburg	HH	Hamburg; Freie und Hansestadt
22527	Hamburg Eidelstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22527	Hamburg Lokstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22527	Hamburg Eimsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22527	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22529	Hamburg Lokstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22529	Hamburg Groß Borstel	Hamburg	HH	Hamburg; Freie und Hansestadt
22529	Hamburg Eppendorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22529	Hamburg Hoheluft-West	Hamburg	HH	Hamburg; Freie und Hansestadt
22529	Hamburg Niendorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22529	Hamburg Stellingen	Hamburg	HH	Hamburg; Freie und Hansestadt
22529	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22547	Hamburg Bahrenfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22547	Hamburg Lurup	Hamburg	HH	Hamburg; Freie und Hansestadt
22547	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22547	Hamburg Osdorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22547	Hamburg Eidelstedt	Hamburg	HH	Hamburg; Freie und Hansestadt
22549	Hamburg Osdorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22549	Hamburg Lurup	Hamburg	HH	Hamburg; Freie und Hansestadt
22549	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22549	Hamburg Bahrenfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22559	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22559	Hamburg Rissen	Hamburg	HH	Hamburg; Freie und Hansestadt
22587	Hamburg Osdorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22587	Hamburg Sülldorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22587	Hamburg Blankenese	Hamburg	HH	Hamburg; Freie und Hansestadt
22587	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22587	Hamburg Rissen	Hamburg	HH	Hamburg; Freie und Hansestadt
22587	Hamburg Nienstedten	Hamburg	HH	Hamburg; Freie und Hansestadt
22589	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22589	Hamburg Sülldorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22589	Hamburg Osdorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22589	Hamburg Blankenese	Hamburg	HH	Hamburg; Freie und Hansestadt
22589	Hamburg Iserbrook	Hamburg	HH	Hamburg; Freie und Hansestadt
22605	Hamburg Groß Flottbek	Hamburg	HH	Hamburg; Freie und Hansestadt
22605	Hamburg Othmarschen	Hamburg	HH	Hamburg; Freie und Hansestadt
22605	Hamburg Bahrenfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22605	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22607	Hamburg Nienstedten	Hamburg	HH	Hamburg; Freie und Hansestadt
22607	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22607	Hamburg Groß Flottbek	Hamburg	HH	Hamburg; Freie und Hansestadt
22607	Hamburg Othmarschen	Hamburg	HH	Hamburg; Freie und Hansestadt
22607	Hamburg Bahrenfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22609	Hamburg Groß Flottbek	Hamburg	HH	Hamburg; Freie und Hansestadt
22609	Hamburg Nienstedten	Hamburg	HH	Hamburg; Freie und Hansestadt
22609	Hamburg Othmarschen	Hamburg	HH	Hamburg; Freie und Hansestadt
22609	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22609	Hamburg Osdorf	Hamburg	HH	Hamburg; Freie und Hansestadt
22761	Hamburg Bahrenfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22761	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22763	Hamburg Ottensen	Hamburg	HH	Hamburg; Freie und Hansestadt
22763	Hamburg Othmarschen	Hamburg	HH	Hamburg; Freie und Hansestadt
22763	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22765	Hamburg Altona-Nord	Hamburg	HH	Hamburg; Freie und Hansestadt
22765	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22765	Hamburg Altona-Altstadt	Hamburg	HH	Hamburg; Freie und Hansestadt
22765	Hamburg Ottensen	Hamburg	HH	Hamburg; Freie und Hansestadt
22767	Hamburg Altona-Altstadt	Hamburg	HH	Hamburg; Freie und Hansestadt
22767	Hamburg Ottensen	Hamburg	HH	Hamburg; Freie und Hansestadt
22767	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22767	Hamburg Sankt Pauli	Hamburg	HH	Hamburg; Freie und Hansestadt
22769	Hamburg Stellingen	Hamburg	HH	Hamburg; Freie und Hansestadt
22769	Hamburg Sankt Pauli	Hamburg	HH	Hamburg; Freie und Hansestadt
22769	Hamburg Eimsbüttel	Hamburg	HH	Hamburg; Freie und Hansestadt
22769	Hamburg	Hamburg	HH	Hamburg; Freie und Hansestadt
22769	Hamburg Altona-Altstadt	Hamburg	HH	Hamburg; Freie und Hansestadt
22769	Hamburg Bahrenfeld	Hamburg	HH	Hamburg; Freie und Hansestadt
22769	Hamburg Altona-Nord	Hamburg	HH	Hamburg; Freie und Hansestadt
27499	Hamburg Neuwerk	Hamburg	HH	Hamburg; Freie und Hansestadt
17033	Neubrandenburg	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17034	Neubrandenburg	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17036	Neubrandenburg	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17039	Blankenhof	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17039	Staven	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17039	Neddemin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17039	Warlin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17039	Neuenkirchen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17039	Wulkenzin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17039	Sponholz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17039	Neverin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17039	Brunn	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17039	Trollenhagen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17039	Zirzow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17039	Beseritz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17039	Woggersin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17087	Altentreptow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17089	Bartow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17089	Breest	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17089	Siedenbollentin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17089	Burow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17089	Grapzow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17089	Werder	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17089	Gnevkow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17089	Golchen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17089	Gültz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17089	Grischow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17091	Wildberg	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17091	Wolde	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17091	Pripsleben	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17091	Altenhagen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17091	Groß Teetzleben	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17091	Breesen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17091	Mölln	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17091	Rosenow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17091	Knorrendorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17091	Röckwitz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17091	Tützpatz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17091	Kriesow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17094	Cammin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17094	Burg Stargard	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17094	Cölpin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17094	Groß Nemerow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17094	Holldorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17094	Lindetal	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17094	Teschendorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17094	Pragsdorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17098	Friedland	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17099	Brohm	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17099	Glienke	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17099	Genzkow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17099	Eichhorst	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17099	Schwanbeck	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17099	Datzetal	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17109	Demmin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Kletzin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Schönfeld	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Siedenbrünzow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Teusin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Beestland	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Lindenberg	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Warrenzin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Beggerow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Sommersdorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Quitzerow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Hohenbrünzow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Sanzkow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Hohenmocker	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Utzedel	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Nossendorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Borrentin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Sarow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Upost	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Hohenbollentin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Wotenick	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Meesiger	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17111	Kentzlin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17121	Loitz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17121	Sassen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17121	Görmin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17121	Trantow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17121	Wüstenfelde	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17121	Düvier	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17126	Jarmen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17129	Alt Tellin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17129	Daberkow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17129	Plötz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17129	Tutow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17129	Bentzin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17129	Kruckow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17129	Schmarsow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17129	Völschow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17139	Malchin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17139	Basedow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17139	Gielow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17139	Remplin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17139	Schwinkendorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17139	Duckow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17139	Kummerow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17139	Faulenrost	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17153	Reuterstadt Stavenhagen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17153	Briggow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17153	Zettemin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17153	Jürgenstorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17153	Ivenack	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17153	Bredenfelde	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17153	Ritzerow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17153	Kittendorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17153	Grammentin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17153	Gülzow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17154	Neukalen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17159	Wagun	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17159	Brudersdorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17159	Dargun	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17159	Stubbendorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17159	Zarnekow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17166	Alt Sührkow	Mecklenburg-Vorpommern	MV	Rostock
17166	Dalkendorf	Mecklenburg-Vorpommern	MV	Rostock
17166	Bülow	Mecklenburg-Vorpommern	MV	Rostock
17166	Hohen Demzin	Mecklenburg-Vorpommern	MV	Rostock
17166	Dahmen	Mecklenburg-Vorpommern	MV	Rostock
17166	Groß Wokern	Mecklenburg-Vorpommern	MV	Rostock
17166	Teterow	Mecklenburg-Vorpommern	MV	Rostock
17166	Groß Roge	Mecklenburg-Vorpommern	MV	Rostock
17166	Bristow	Mecklenburg-Vorpommern	MV	Rostock
17168	Remlin	Mecklenburg-Vorpommern	MV	Rostock
17168	Jördenstorf	Mecklenburg-Vorpommern	MV	Rostock
17168	Prebberede	Mecklenburg-Vorpommern	MV	Rostock
17168	Warnkenhagen	Mecklenburg-Vorpommern	MV	Rostock
17168	Matgendorf	Mecklenburg-Vorpommern	MV	Rostock
17168	Poggelow	Mecklenburg-Vorpommern	MV	Rostock
17168	Sukow-Marienhof	Mecklenburg-Vorpommern	MV	Rostock
17168	Groß Wüstenfelde	Mecklenburg-Vorpommern	MV	Rostock
17168	Neu Heinde	Mecklenburg-Vorpommern	MV	Rostock
17168	Thürkow	Mecklenburg-Vorpommern	MV	Rostock
17168	Levitzow	Mecklenburg-Vorpommern	MV	Rostock
17168	Lelkendorf	Mecklenburg-Vorpommern	MV	Rostock
17179	Walkendorf	Mecklenburg-Vorpommern	MV	Rostock
17179	Lühburg	Mecklenburg-Vorpommern	MV	Rostock
17179	Altkalen	Mecklenburg-Vorpommern	MV	Rostock
17179	Finkenthal	Mecklenburg-Vorpommern	MV	Rostock
17179	Gnoien	Mecklenburg-Vorpommern	MV	Rostock
17179	Wasdow	Mecklenburg-Vorpommern	MV	Rostock
17179	Boddin	Mecklenburg-Vorpommern	MV	Rostock
17179	Behren-Lübchin	Mecklenburg-Vorpommern	MV	Rostock
17192	Kargow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17192	Varchentin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17192	Waren (Müritz)	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17192	Torgelow am See	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17192	Groß Dratow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17192	Lansen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17192	Alt Schönau	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17192	Groß Gievitz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17192	Schloen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17192	Klink	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17192	Groß Plasten	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17194	Vielist	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17194	Jabel	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17194	Vollrathsruhe	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17194	Lupendorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17194	Klocksin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17194	Hinrichshagen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17194	Neu Gaarz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17194	Hohen Wangelin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17194	Moltzow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17194	Grabowhöfe	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17207	Röbel/Müritz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17207	Bollewick	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17207	Ludorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17207	Kambs	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17207	Groß Kelle	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17207	Gotthun	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Fincken	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Rogeez	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Wredenhagen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Eldetal	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Bütow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Leizen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Walow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Melz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Minzow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Priborn	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Satow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Jaebetz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Stuer	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Kieve	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Zepkow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Vipperow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Massow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Buchholz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Sietow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Altenhof	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17209	Zislow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17213	Adamshoffnung	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17213	Malchow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17213	Grüssow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17213	Lexow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17213	Kogel	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17213	Göhren-Lebbin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17213	Penkow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17214	Silz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17214	Nossentiner Hütte	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17214	Alt Schwerin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17217	Mallin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17217	Lapitz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17217	Groß Vielen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17217	Alt Rehse	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17217	Klein Lukow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17217	Puchow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17217	Penzlin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17217	Krukow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17217	Mollenstorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17219	Möllenhagen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17219	Marihn	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17219	Ankershagen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17219	Groß Flotow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17235	Neustrelitz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17237	Möllenbeck	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17237	Blumenholz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17237	Userin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17237	Hohenzieritz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17237	Carpin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17237	Watzkendorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17237	Wokuhl-Dabelow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17237	Kratzeburg	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17237	Godendorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17237	Grünow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17237	Klein Vielen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17237	Blankensee	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17248	Rechlin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17248	Lärz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17252	Schwarz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17252	Diemitz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17252	Mirow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17252	Roggentin	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17255	Wustrow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17255	Priepert	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17255	Wesenberg	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17258	Feldberger Seenlandschaft	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17259	Feldberger Seenlandschaft	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17309	Viereck	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17309	Damerow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17309	Rollwitz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17309	Polzow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17309	Krugsdorf	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17309	Brietzig	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17309	Züsedom	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17309	Pasewalk	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17309	Koblentz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17309	Schönwalde	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17309	Marienthal	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17309	Zerrenthin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17309	Belling	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17309	Nieden	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17309	Jatznick	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17309	Papendorf	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17309	Fahrenwalde	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17321	Bergholz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17321	Rothenklempenow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17321	Glashütte	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17321	Plöwen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17321	Ramin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17321	Löcknitz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17322	Bismark	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17322	Grambow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17322	Glasow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17322	Rossow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17322	Pampow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17322	Lebehn	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17322	Boock	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17322	Mewegen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17322	Blankensee	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17328	Penkun	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17328	Wollin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17329	Krackow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17329	Nadrensee	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17335	Strasburg	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17337	Galenbeck	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17337	Schönhausen	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17337	Blumenhagen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17337	Groß Luckow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17337	Klein Luckow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17348	Woldegk	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17348	Neu Käbelich	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17348	Petersdorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17348	Groß Daberkow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17348	Mildenitz	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17348	Lindetal	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17349	Neetzka	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17349	Helpt	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17349	Schönbeck	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17349	Voigtsdorf	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17349	Kublank	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17349	Lindetal	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17349	Groß Miltzow	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17358	Torgelow-Holländerei	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17358	Hammer	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17358	Torgelow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17367	Eggesin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17373	Ueckermünde	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17375	Meiersberg	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17375	Hintersee	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17375	Grambin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17375	Leopoldshagen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17375	Ahlbeck	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17375	Liepgarten	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17375	Mönkebude	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17375	Luckow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17375	Altwarp	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17375	Vogelsang-Warsin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17379	Lübs	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17379	Ferdinandshof	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17379	Wilhelmsburg	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17379	Heinrichsruh	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17379	Altwigshagen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17379	Rothemühl	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17379	Wietstock	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17379	Heinrichswalde	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17379	Neuendorf A	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17389	Anklam	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17390	Rubkow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17390	Schmatzin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17390	Ziethen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17390	Murchin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17390	Klein Bünzow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17390	Groß Polzin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17391	Neetzow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17391	Stolpe	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17391	Nerdin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17391	Medow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17391	Krusenfelde	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17391	Krien	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17391	Steinmocker	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17391	Postlow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17391	Liepen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17391	Neuendorf B	Mecklenburg-Vorpommern	MV	Mecklenburgische Seenplatte
17391	Iven	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17392	Drewelow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17392	Butzow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17392	Spantekow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17392	Sarnow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17392	Japenzin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17392	Neuenkirchen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17392	Pelsin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17392	Zinzow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17392	Putzar	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17392	Blesewitz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17392	Boldekow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17398	Bargischow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17398	Bugewitz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17398	Neu Kosenow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17398	Ducherow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17398	Schwerinsburg	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17398	Rathebur	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17398	Löwitz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17398	Rossin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17406	Morgenitz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17406	Rankwitz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17406	Stolpe auf Usedom	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17406	Usedom	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17419	Zirchow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17419	Kamminke	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17419	Garz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17419	Dargen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17419	Ahlbeck	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17419	Korswandt	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17424	Heringsdorf	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17429	Pudagla	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17429	Bansin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17429	Neppermin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17429	Benz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17429	Mellenthin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17438	Wolgast	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17440	Zemitz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17440	Groß Ernsthof	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17440	Krummin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17440	Kröslin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17440	Lassan	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17440	Sauzin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17440	Buddenhagen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17440	Lütow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17440	Hohendorf	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17440	Buggenhagen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17440	Pulow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17449	Mölschow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17449	Karlshagen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17449	Peenemünde	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17449	Trassenheide	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17454	Zinnowitz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17459	Loddin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17459	Koserow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17459	Zempin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17459	Ückeritz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17489	Greifswald	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17491	Greifswald	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17493	Greifswald	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17495	Ranzin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17495	Karlsburg	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17495	Lühmannsdorf	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17495	Groß Kiesow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17495	Züssow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17495	Wrangelsburg	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17498	Diedrichshagen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17498	Behrenhoff	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17498	Dersekow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17498	Wackerow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17498	Dargelin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17498	Mesekenhagen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17498	Levenhagen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17498	Weitenhagen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17498	Neuenkirchen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17498	Hinrichshagen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17506	Gribow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17506	Kölzin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17506	Lüssow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17506	Breechen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17506	Bandelin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17506	Gützkow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17506	Kammin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17509	Loissin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17509	Brünzow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17509	Rubenow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17509	Lubmin	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17509	Neu Boltenhagen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17509	Katzow	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17509	Hanshagen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17509	Wusterhusen	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
17509	Kemnitz	Mecklenburg-Vorpommern	MV	Vorpommern-Greifswald
18055	Rostock	Mecklenburg-Vorpommern	MV	Rostock
18057	Rostock	Mecklenburg-Vorpommern	MV	Rostock
18059	Rostock	Mecklenburg-Vorpommern	MV	Rostock
18059	Ziesendorf	Mecklenburg-Vorpommern	MV	Rostock
18059	Pölchow	Mecklenburg-Vorpommern	MV	Rostock
18059	Papendorf	Mecklenburg-Vorpommern	MV	Rostock
18069	Rostock	Mecklenburg-Vorpommern	MV	Rostock
18069	Lambrechtshagen	Mecklenburg-Vorpommern	MV	Rostock
18106	Rostock	Mecklenburg-Vorpommern	MV	Rostock
18107	Rostock	Mecklenburg-Vorpommern	MV	Rostock
18107	Elmenhorst-Lichtenhagen	Mecklenburg-Vorpommern	MV	Rostock
18109	Rostock	Mecklenburg-Vorpommern	MV	Rostock
18119	Rostock	Mecklenburg-Vorpommern	MV	Rostock
18146	Rostock	Mecklenburg-Vorpommern	MV	Rostock
18147	Rostock	Mecklenburg-Vorpommern	MV	Rostock
18181	Seeheilbad Graal-Müritz	Mecklenburg-Vorpommern	MV	Rostock
18182	Rövershagen	Mecklenburg-Vorpommern	MV	Rostock
18182	Blankenhagen	Mecklenburg-Vorpommern	MV	Rostock
18182	Mönchhagen	Mecklenburg-Vorpommern	MV	Rostock
18182	Bentwisch	Mecklenburg-Vorpommern	MV	Rostock
18182	Gelbensande	Mecklenburg-Vorpommern	MV	Rostock
18184	Klein Kussewitz	Mecklenburg-Vorpommern	MV	Rostock
18184	Broderstorf	Mecklenburg-Vorpommern	MV	Rostock
18184	Thulendorf	Mecklenburg-Vorpommern	MV	Rostock
18184	Steinfeld	Mecklenburg-Vorpommern	MV	Rostock
18184	Poppendorf	Mecklenburg-Vorpommern	MV	Rostock
18184	Hohenfelde	Mecklenburg-Vorpommern	MV	Rostock
18184	Mandelshagen	Mecklenburg-Vorpommern	MV	Rostock
18184	Roggentin	Mecklenburg-Vorpommern	MV	Rostock
18190	Sanitz	Mecklenburg-Vorpommern	MV	Rostock
18195	Tessin	Mecklenburg-Vorpommern	MV	Rostock
18195	Stubbendorf	Mecklenburg-Vorpommern	MV	Rostock
18195	Selpin	Mecklenburg-Vorpommern	MV	Rostock
18195	Cammin	Mecklenburg-Vorpommern	MV	Rostock
18195	Grammow	Mecklenburg-Vorpommern	MV	Rostock
18195	Zarnewanz	Mecklenburg-Vorpommern	MV	Rostock
18195	Gnewitz	Mecklenburg-Vorpommern	MV	Rostock
18195	Nustrow	Mecklenburg-Vorpommern	MV	Rostock
18195	Thelkow	Mecklenburg-Vorpommern	MV	Rostock
18196	Damm	Mecklenburg-Vorpommern	MV	Rostock
18196	Kavelstorf	Mecklenburg-Vorpommern	MV	Rostock
18196	Prisannewitz	Mecklenburg-Vorpommern	MV	Rostock
18196	Kessin	Mecklenburg-Vorpommern	MV	Rostock
18196	Dummerstorf	Mecklenburg-Vorpommern	MV	Rostock
18196	Lieblingshof	Mecklenburg-Vorpommern	MV	Rostock
18198	Stäbelow	Mecklenburg-Vorpommern	MV	Rostock
18198	Kritzmow	Mecklenburg-Vorpommern	MV	Rostock
18209	Bartenshagen-Parkentin	Mecklenburg-Vorpommern	MV	Rostock
18209	Steffenshagen	Mecklenburg-Vorpommern	MV	Rostock
18209	Reddelich	Mecklenburg-Vorpommern	MV	Rostock
18209	Wittenbeck	Mecklenburg-Vorpommern	MV	Rostock
18209	Bad Doberan	Mecklenburg-Vorpommern	MV	Rostock
18211	Nienhagen	Mecklenburg-Vorpommern	MV	Rostock
18211	Admannshagen-Bargeshagen	Mecklenburg-Vorpommern	MV	Rostock
18211	Börgerende-Rethwisch	Mecklenburg-Vorpommern	MV	Rostock
18211	Retschow	Mecklenburg-Vorpommern	MV	Rostock
18225	Kühlungsborn	Mecklenburg-Vorpommern	MV	Rostock
18230	Biendorf	Mecklenburg-Vorpommern	MV	Rostock
18230	Bastorf	Mecklenburg-Vorpommern	MV	Rostock
18230	Rerik	Mecklenburg-Vorpommern	MV	Rostock
18230	Jennewitz	Mecklenburg-Vorpommern	MV	Rostock
18231	Neubukow	Mecklenburg-Vorpommern	MV	Rostock
18233	Kirch Mulsow	Mecklenburg-Vorpommern	MV	Rostock
18233	Neubukow	Mecklenburg-Vorpommern	MV	Rostock
18233	Krempin	Mecklenburg-Vorpommern	MV	Rostock
18233	Kamin	Mecklenburg-Vorpommern	MV	Rostock
18233	Rakow	Mecklenburg-Vorpommern	MV	Rostock
18233	Ravensberg	Mecklenburg-Vorpommern	MV	Rostock
18233	Karin	Mecklenburg-Vorpommern	MV	Rostock
18233	Alt Bukow	Mecklenburg-Vorpommern	MV	Rostock
18233	Pepelow	Mecklenburg-Vorpommern	MV	Rostock
18233	Westenbrügge	Mecklenburg-Vorpommern	MV	Rostock
18236	Kröpelin	Mecklenburg-Vorpommern	MV	Rostock
18236	Schmadebeck	Mecklenburg-Vorpommern	MV	Rostock
18236	Altenhagen	Mecklenburg-Vorpommern	MV	Rostock
18239	Radegast	Mecklenburg-Vorpommern	MV	Rostock
18239	Hanstorf	Mecklenburg-Vorpommern	MV	Rostock
18239	Heiligenhagen	Mecklenburg-Vorpommern	MV	Rostock
18239	Satow	Mecklenburg-Vorpommern	MV	Rostock
18239	Bölkow	Mecklenburg-Vorpommern	MV	Rostock
18239	Reinshagen	Mecklenburg-Vorpommern	MV	Rostock
18246	Steinhagen	Mecklenburg-Vorpommern	MV	Rostock
18246	Jürgenshagen	Mecklenburg-Vorpommern	MV	Rostock
18246	Baumgarten	Mecklenburg-Vorpommern	MV	Rostock
18246	Zepelin	Mecklenburg-Vorpommern	MV	Rostock
18246	Bützow	Mecklenburg-Vorpommern	MV	Rostock
18246	Rühn	Mecklenburg-Vorpommern	MV	Rostock
18246	Neuendorf	Mecklenburg-Vorpommern	MV	Rostock
18246	Klein Belitz	Mecklenburg-Vorpommern	MV	Rostock
18249	Penzin	Mecklenburg-Vorpommern	MV	Rostock
18249	Tarnow	Mecklenburg-Vorpommern	MV	Rostock
18249	Bernitt	Mecklenburg-Vorpommern	MV	Rostock
18249	Dreetz	Mecklenburg-Vorpommern	MV	Rostock
18249	Warnow	Mecklenburg-Vorpommern	MV	Rostock
18258	Kassow	Mecklenburg-Vorpommern	MV	Rostock
18258	Benitz	Mecklenburg-Vorpommern	MV	Rostock
18258	Vorbeck	Mecklenburg-Vorpommern	MV	Rostock
18258	Schwaan	Mecklenburg-Vorpommern	MV	Rostock
18258	Bröbberow	Mecklenburg-Vorpommern	MV	Rostock
18258	Rukieten	Mecklenburg-Vorpommern	MV	Rostock
18258	Wiendorf	Mecklenburg-Vorpommern	MV	Rostock
18273	Güstrow	Mecklenburg-Vorpommern	MV	Rostock
18276	Reimershagen	Mecklenburg-Vorpommern	MV	Rostock
18276	Zehna	Mecklenburg-Vorpommern	MV	Rostock
18276	Prüzen	Mecklenburg-Vorpommern	MV	Rostock
18276	Klein Upahl	Mecklenburg-Vorpommern	MV	Rostock
18276	Recknitz	Mecklenburg-Vorpommern	MV	Rostock
18276	Bülow	Mecklenburg-Vorpommern	MV	Rostock
18276	Lüssow	Mecklenburg-Vorpommern	MV	Rostock
18276	Mühl Rosin	Mecklenburg-Vorpommern	MV	Rostock
18276	Gülzow	Mecklenburg-Vorpommern	MV	Rostock
18276	Gutow	Mecklenburg-Vorpommern	MV	Rostock
18276	Kuhs	Mecklenburg-Vorpommern	MV	Rostock
18276	Glasewitz	Mecklenburg-Vorpommern	MV	Rostock
18276	Groß Schwiesow	Mecklenburg-Vorpommern	MV	Rostock
18276	Lohmen	Mecklenburg-Vorpommern	MV	Rostock
18276	Mistorf	Mecklenburg-Vorpommern	MV	Rostock
18279	Langhagen	Mecklenburg-Vorpommern	MV	Rostock
18279	Plaaz	Mecklenburg-Vorpommern	MV	Rostock
18279	Wattmannshagen	Mecklenburg-Vorpommern	MV	Rostock
18279	Lalendorf	Mecklenburg-Vorpommern	MV	Rostock
18292	Kuchelmiß	Mecklenburg-Vorpommern	MV	Rostock
18292	Bellin	Mecklenburg-Vorpommern	MV	Rostock
18292	Dobbin-Linstow	Mecklenburg-Vorpommern	MV	Rostock
18292	Hoppenrade	Mecklenburg-Vorpommern	MV	Rostock
18292	Krakow am See	Mecklenburg-Vorpommern	MV	Rostock
18292	Dobbin-Linstow Dobbin	Mecklenburg-Vorpommern	MV	Rostock
18299	Liessow	Mecklenburg-Vorpommern	MV	Rostock
18299	Weitendorf	Mecklenburg-Vorpommern	MV	Rostock
18299	Dolgen	Mecklenburg-Vorpommern	MV	Rostock
18299	Pölitz	Mecklenburg-Vorpommern	MV	Rostock
18299	Wardow	Mecklenburg-Vorpommern	MV	Rostock
18299	Laage	Mecklenburg-Vorpommern	MV	Rostock
18299	Hohen Sprenz	Mecklenburg-Vorpommern	MV	Rostock
18299	Alt Kätwin	Mecklenburg-Vorpommern	MV	Rostock
18299	Diekhof	Mecklenburg-Vorpommern	MV	Rostock
18311	Ribnitz-Damgarten	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18314	Bartelshagen II	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18314	Löbnitz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18314	Divitz-Spoldershagen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18314	Kenz-Küstrow	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18314	Lüdershagen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18317	Saal	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18320	Trinwillershagen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18320	Ahrenshagen-Daskow	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18320	Schlemmin	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18320	Dettmannsdorf	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18334	Schulenberg	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18334	Bad Sülze	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18334	Eixen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18334	Böhlendorf	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18334	Breesen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18334	Semlow	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18334	Langsdorf	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18337	Marlow	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18347	Dierhagen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18347	Ahrenshoop	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18347	Wustrow	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18356	Fuhlendorf	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18356	Pruchten	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18356	Barth	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18374	Zingst	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18375	Prerow	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18375	Wieck	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18375	Born a. Darß	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18435	Stralsund	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18437	Stralsund	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18439	Stralsund	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18442	Kummerow	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18442	Wendorf	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18442	Neu Bartelshagen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18442	Steinhagen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18442	Niepars	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18442	Groß Kordshagen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18442	Pantelitz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18442	Jakobsdorf	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18442	Lüssow	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18445	Prohn	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18445	Preetz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18445	Klausdorf	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18445	Altenpleen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18445	Kramerhof	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18445	Groß Mohrdorf	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18461	Richtenberg	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18461	Weitenhagen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18461	Gremersdorf-Buchholz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18461	Millienhagen-Oebelitz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18461	Franzburg	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18465	Drechow	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18465	Hugoldsdorf	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18465	Tribsees	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18469	Velgast	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18469	Karnin	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18507	Grimmen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18510	Stoltenhagen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18510	Zarrendorf	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18510	Elmenhorst	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18510	Papenhagen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
27616	Stubben	Niedersachsen	NI	Cuxhaven
18510	Behnkendorf	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18510	Wittenhagen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18513	Wendisch Baggendorf	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18513	Glewitz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18513	Gransebieth	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18513	Splietsdorf	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18513	Deyelsdorf	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18513	Grammendorf	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18516	Süderholz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18519	Wilmshagen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18519	Reinberg	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18519	Brandshagen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18519	Kirchdorf	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18519	Horst	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18519	Miltzow	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18528	Bergen auf Rügen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18528	Lietzow	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18528	Sehlen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18528	Ralswiek	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18528	Zirkow	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18528	Parchtitz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18528	Patzig	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18528	Rappin	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18528	Thesenvitz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18528	Buschvitz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18546	Sassnitz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18551	Glowe	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18551	Sagard	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18551	Lohme	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18556	Dranske	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18556	Altenkirchen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18556	Putgarten	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18556	Breege	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18556	Wiek	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18565	Insel Hiddensee	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18569	Schaprode	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18569	Trent	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18569	Kluis	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18569	Neuenkirchen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18569	Gingst	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18569	Ummanz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18573	Rambin	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18573	Dreschvitz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18573	Altefähr	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18573	Samtens	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18574	Garz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18574	Gustow	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18574	Karnitz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18574	Poseritz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18574	Zudar	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18581	Putbus	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18586	Lancken-Granitz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18586	Göhren	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18586	Sellin	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18586	Thiessow	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18586	Middelhagen	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18586	Gager	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18586	Baabe	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
18609	Binz	Mecklenburg-Vorpommern	MV	Vorpommern-Rügen
19053	Schwerin	Mecklenburg-Vorpommern	MV	Schwerin
19055	Schwerin	Mecklenburg-Vorpommern	MV	Schwerin
19057	Schwerin	Mecklenburg-Vorpommern	MV	Schwerin
19059	Schwerin	Mecklenburg-Vorpommern	MV	Schwerin
19061	Schwerin	Mecklenburg-Vorpommern	MV	Schwerin
19063	Schwerin	Mecklenburg-Vorpommern	MV	Schwerin
19065	Raben Steinfeld	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19065	Gneven	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19065	Pinnow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19065	Godern	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19067	Cambs	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19067	Retgendorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19067	Leezen	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19067	Rubow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19067	Langen Brütz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19069	Alt Meteln	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19069	Klein Trebbow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19069	Seehof	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19069	Pingelshagen	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19069	Zickhusen	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19069	Böken	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19071	Dalberg-Wendelstorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19071	Brüsewitz	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19071	Grambow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19071	Cramonshagen	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19073	Stralendorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19073	Dümmer	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19073	Klein Rogahn	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19073	Schossin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19073	Wittenförden	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19073	Zülow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19075	Holthusen	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19075	Warsow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19075	Pampow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19077	Rastow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19077	Uelitz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19077	Sülstorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19077	Lübesse	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19079	Banzkow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19079	Sukow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19079	Goldenstädt	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19086	Plate	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19089	Tramm	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19089	Wessin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19089	Barnin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19089	Ruthenbeck	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19089	Demen	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19089	Bülow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19089	Gädebehn	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19089	Göhren	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19089	Zapel	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19089	Crivitz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19205	Krembz	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19205	Pokrent	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19205	Veelböken	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19205	Kneese	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19205	Mühlen Eichsen	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19205	Dragun	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19205	Roggendorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19205	Rögnitz	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19205	Gadebusch	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19209	Badow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19209	Renzow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19209	Gottesgabe	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19209	Lützow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19209	Perlin	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Wedendorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Nesow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Rieps	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Groß Molzahn	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Rehna	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Utecht	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Dechow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Thandorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Holdorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Löwitz	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Köchelstorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Carlow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Vitense	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Bülow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Schlagsdorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Groß Rünz	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19217	Demern	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19230	Bobzin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Gammelin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Bresegard	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Pritzier	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Bandenitz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Kuhstorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Warlitz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Redefin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Alt Zachun	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Toddin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Setzin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Hoort	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Hagenow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Pätow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Belsch	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Moraas	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Picher	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Hülseburg	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Groß Krams	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Strohkirchen	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19230	Kirch Jesar	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19243	Dreilützow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19243	Luckwitz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19243	Wittenburg	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19243	Lehsen	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19243	Tessin bei Wittenburg	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19243	Dodow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19243	Körchow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19243	Waschow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19243	Drönnewitz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19243	Boddin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19243	Karft	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19243	Parum	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19246	Zarrentin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19246	Neuhof	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19246	Valluhn	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19246	Camin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19246	Kogel	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19246	Lassahn	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
41472	Neuss	Nordrhein-Westfalen	NW	51
19246	Bantin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19246	Lüttow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19249	Gößlow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19249	Garlitz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19249	Jessenitz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19249	Lübtheen	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19258	Tessin bei Boizenburg	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19258	Neu Gülze	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19258	Boizenburg	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19258	Schwanheide	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19258	Klein Bengerstorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19258	Nostorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19258	Wiebendorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19258	Gresse	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19258	Gallin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19258	Besitz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19258	Greven	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19260	Bennin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19260	Kloddram	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19260	Banzin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19260	Dersenow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19260	Rodenwalde	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19260	Vellahn	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19273	Brahlstorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19273	Melkof	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19273	Teldau	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19288	Groß Laasch	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19288	Lüblow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19288	Leussow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19288	Fahrbinde	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19288	Ludwigslust	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19288	Warlow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19288	Glaisin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19288	Göhlen	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19288	Alt Krenzlin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19288	Wöbbelin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19288	Kummer	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19294	Dadow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19294	Neu Kaliß	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19294	Karstädt	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19294	Grebs	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19294	Gorlosen	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19294	Karenz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19294	Malk Göhren	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19294	Eldena	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19294	Malliß	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19294	Krinitz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19294	Niendorf an der Rögnitz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19294	Malk Göhren Göhren	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19294	Malk Göhren Malk	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19294	Bresegard	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19300	Milow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19300	Steesow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19300	Werle	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19300	Zierzow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19300	Prislich	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19300	Kremmin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19300	Balow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19300	Muchow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19300	Grabow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19300	Möllenbeck	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19303	Heidhof	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19303	Vielank	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19303	Woosmer	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19303	Tewswoos	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19303	Dömitz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19303	Rüterberg	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19303	Polz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19306	Blievenstorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19306	Brenz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19306	Neustadt-Glewe	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19357	Dambeck	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19370	Parchim	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19372	Spornitz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19372	Herzfeld	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19372	Karrenzin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19372	Rom	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19372	Brunow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19372	Groß Godems	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19372	Matzlow-Garwitz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19372	Stolpe	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19372	Ziegendorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19372	Stralendorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19374	Domsühl	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19374	Friedrichsruhe	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19374	Klinken	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19374	Grebbin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19374	Raduhn	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19374	Herzberg	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19374	Mestlin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19374	Severin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19374	Zölkow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19374	Groß Niendorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19374	Damm	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19376	Siggelkow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19376	Suckow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19376	Tessenow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19376	Marnitz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19386	Granzin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19386	Wahlstorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19386	Gischow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19386	Lübz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19386	Lutheran	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19386	Karbow-Vietlübbe	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19386	Kritzow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19386	Werder	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19386	Kreien	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19386	Broock	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19386	Gallin-Kuppentin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19386	Passow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19395	Barkow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19395	Plau am See	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19395	Retzow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19395	Wendisch Priborn	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19395	Gnevsdorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19395	Karow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19395	Plauerhagen	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19395	Ganzlin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19399	Wendisch Waren	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19399	Diestelow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19399	Langenhagen	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19399	Goldberg	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19399	Neu Poserin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19399	Dobbertin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19399	Techentin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19406	Sternberg	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19406	Mustin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19406	Groß Görnow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19406	Dabel	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19406	Kobrow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19406	Hohen Pritz	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19406	Borkow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19406	Witzin	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19412	Weitendorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19412	Wendorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19412	Blankenberg	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19412	Kuhlen	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19412	Langen Jarchow	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19412	Brüel	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19412	Zahrensdorf	Mecklenburg-Vorpommern	MV	Ludwigslust-Parchim
19417	Ventschow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19417	Bibow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19417	Jesendorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19417	Groß Labenz	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19417	Warin	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23923	Schönberg	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23923	Selmsdorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23923	Menzendorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23923	Lockwisch	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23923	Lüdersdorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23923	Roduchelstorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23923	Niendorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23923	Groß Siemz	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23936	Bernstorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23936	Upahl	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23936	Papenhusen	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23936	Hanshagen	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23936	Testorf-Steinfort	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23936	Roggenstorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23936	Rüting	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23936	Grevesmühlen	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23936	Warnow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23936	Grieben	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23936	Plüschow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23936	Mallentin	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23936	Börzow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23942	Dassow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23942	Harkensee	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23942	Kalkhorst	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23942	Pötenitz	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23944	Ostseebad Boltenhagen	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23946	Boltenhagen	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23948	Groß Walmstorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23948	Klütz	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23948	Elmenhorst	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23948	Moor-Rolofshagen	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23948	Damshagen	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23952	Wismar; Mecklenburg	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23966	Wismar	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23968	Wismar	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23968	Gramkow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23968	Zierow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23968	Barnekow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23968	Gägelow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23970	Wismar	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23970	Benz	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23972	Lübow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23972	Dorf Mecklenburg	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23972	Schimm	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23972	Metelsdorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23972	Groß Stieten	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23974	Blowatz	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23974	Krusenhagen	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23974	Hornstorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23974	Boiensdorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23974	Neuburg	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23992	Passee	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23992	Neukloster	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23992	Zurow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23992	Lübberstorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23992	Glasin	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23992	Züsow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23996	Hohen Viecheln	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23996	Bad Kleinen	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23996	Beidendorf	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23996	Bobitz	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23996	Groß Krankow	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
23999	Insel Poel	Mecklenburg-Vorpommern	MV	Nordwestmecklenburg
19273	Neuhaus	Niedersachsen	NI	Lüneburg
21217	Seevetal	Niedersachsen	NI	Harburg
21218	Seevetal	Niedersachsen	NI	Harburg
21220	Seevetal	Niedersachsen	NI	Harburg
21224	Rosengarten	Niedersachsen	NI	Harburg
21227	Bendestorf	Niedersachsen	NI	Harburg
21228	Harmstorf	Niedersachsen	NI	Harburg
21244	Buchholz in der Nordheide	Niedersachsen	NI	Harburg
21255	Kakenstorf	Niedersachsen	NI	Harburg
21255	Tostedt	Niedersachsen	NI	Harburg
21255	Wistedt	Niedersachsen	NI	Harburg
21255	Königsmoor	Niedersachsen	NI	Harburg
21255	Dohren	Niedersachsen	NI	Harburg
21256	Handeloh	Niedersachsen	NI	Harburg
21258	Heidenau	Niedersachsen	NI	Harburg
21259	Otter	Niedersachsen	NI	Harburg
21261	Welle	Niedersachsen	NI	Harburg
21266	Jesteburg	Niedersachsen	NI	Harburg
21271	Asendorf	Niedersachsen	NI	Harburg
21271	Hanstedt	Niedersachsen	NI	Harburg
21272	Egestorf	Niedersachsen	NI	Harburg
21274	Undeloh	Niedersachsen	NI	Harburg
21279	Hollenstedt	Niedersachsen	NI	Harburg
21279	Wenzendorf	Niedersachsen	NI	Harburg
21279	Appel	Niedersachsen	NI	Harburg
21279	Drestedt	Niedersachsen	NI	Harburg
21335	Lüneburg	Niedersachsen	NI	Lüneburg
21337	Lüneburg	Niedersachsen	NI	Lüneburg
21339	Lüneburg	Niedersachsen	NI	Lüneburg
21354	Bleckede	Niedersachsen	NI	Lüneburg
21357	Bardowick	Niedersachsen	NI	Lüneburg
21357	Barum	Niedersachsen	NI	Lüneburg
21357	Wittorf	Niedersachsen	NI	Lüneburg
21358	Mechtersen	Niedersachsen	NI	Lüneburg
21360	Vögelsen	Niedersachsen	NI	Lüneburg
21365	Adendorf	Niedersachsen	NI	Lüneburg
21368	Boitze	Niedersachsen	NI	Lüneburg
21368	Dahlem	Niedersachsen	NI	Lüneburg
21368	Dahlenburg	Niedersachsen	NI	Lüneburg
21369	Nahrendorf	Niedersachsen	NI	Lüneburg
21371	Tosterglope	Niedersachsen	NI	Lüneburg
21376	Garlstorf	Niedersachsen	NI	Harburg
21376	Eyendorf	Niedersachsen	NI	Harburg
21376	Gödenstorf	Niedersachsen	NI	Harburg
21376	Salzhausen	Niedersachsen	NI	Harburg
21379	Scharnebeck	Niedersachsen	NI	Lüneburg
21379	Echem	Niedersachsen	NI	Lüneburg
21379	Rullstorf	Niedersachsen	NI	Lüneburg
21379	Lüdersburg	Niedersachsen	NI	Lüneburg
21380	Artlenburg	Niedersachsen	NI	Lüneburg
21382	Brietlingen	Niedersachsen	NI	Lüneburg
21385	Oldendorf (Luhe)	Niedersachsen	NI	Lüneburg
21385	Amelinghausen	Niedersachsen	NI	Lüneburg
21385	Rehlingen	Niedersachsen	NI	Lüneburg
21386	Betzendorf	Niedersachsen	NI	Lüneburg
21388	Soderstorf	Niedersachsen	NI	Lüneburg
21391	Dachtmissen	Niedersachsen	NI	Lüneburg
21391	Reppenstedt	Niedersachsen	NI	Lüneburg
21394	Heiligenthal	Niedersachsen	NI	Lüneburg
21394	Westergellersen	Niedersachsen	NI	Lüneburg
21394	Kirchgellersen	Niedersachsen	NI	Lüneburg
21394	Südergellersen	Niedersachsen	NI	Lüneburg
21395	Tespe	Niedersachsen	NI	Harburg
21397	Barendorf	Niedersachsen	NI	Lüneburg
21397	Vastorf	Niedersachsen	NI	Lüneburg
21398	Neetze	Niedersachsen	NI	Lüneburg
21400	Reinstorf	Niedersachsen	NI	Lüneburg
21401	Thomasburg	Niedersachsen	NI	Lüneburg
21403	Wendisch Evern	Niedersachsen	NI	Lüneburg
21406	Barnstedt	Niedersachsen	NI	Lüneburg
21406	Melbeck	Niedersachsen	NI	Lüneburg
21407	Deutsch Evern	Niedersachsen	NI	Lüneburg
21409	Embsen	Niedersachsen	NI	Lüneburg
21423	Drage	Niedersachsen	NI	Harburg
21423	Winsen (Luhe)	Niedersachsen	NI	Harburg
21435	Stelle	Niedersachsen	NI	Harburg
21436	Marschacht	Niedersachsen	NI	Harburg
21438	Brackel	Niedersachsen	NI	Harburg
21439	Marxen	Niedersachsen	NI	Harburg
21441	Garstedt	Niedersachsen	NI	Harburg
21442	Toppenstedt	Niedersachsen	NI	Harburg
21444	Vierhöfen	Niedersachsen	NI	Harburg
21445	Wulfsen	Niedersachsen	NI	Harburg
21447	Handorf	Niedersachsen	NI	Lüneburg
21449	Radbruch	Niedersachsen	NI	Lüneburg
21522	Hohnstorf (Elbe)	Niedersachsen	NI	Lüneburg
21522	Hittbergen	Niedersachsen	NI	Lüneburg
21614	Buxtehude	Niedersachsen	NI	Stade
21629	Neu Wulmstorf	Niedersachsen	NI	Harburg
21635	Jork	Niedersachsen	NI	Stade
21640	Neuenkirchen	Niedersachsen	NI	Stade
21640	Horneburg	Niedersachsen	NI	Stade
21640	Nottensdorf	Niedersachsen	NI	Stade
21640	Bliedersdorf	Niedersachsen	NI	Stade
21641	Apensen	Niedersachsen	NI	Stade
21643	Beckdorf	Niedersachsen	NI	Stade
21644	Sauensiek	Niedersachsen	NI	Stade
21646	Halvesbostel	Niedersachsen	NI	Harburg
21647	Moisburg	Niedersachsen	NI	Harburg
21649	Regesbostel	Niedersachsen	NI	Harburg
21680	Stade	Niedersachsen	NI	Stade
21682	Stade	Niedersachsen	NI	Stade
21683	Stade	Niedersachsen	NI	Stade
21684	Stade	Niedersachsen	NI	Stade
21684	Agathenburg	Niedersachsen	NI	Stade
21698	Brest	Niedersachsen	NI	Stade
21698	Harsefeld	Niedersachsen	NI	Stade
21698	Bargstedt	Niedersachsen	NI	Stade
21702	Ahlerstedt	Niedersachsen	NI	Stade
21706	Drochtersen	Niedersachsen	NI	Stade
21709	Burweg	Niedersachsen	NI	Stade
21709	Düdenbüttel	Niedersachsen	NI	Stade
21709	Himmelpforten	Niedersachsen	NI	Stade
21710	Engelschoff	Niedersachsen	NI	Stade
21712	Großenwörden	Niedersachsen	NI	Stade
21714	Hammah	Niedersachsen	NI	Stade
21717	Fredenbeck	Niedersachsen	NI	Stade
21717	Deinste	Niedersachsen	NI	Stade
21720	Guderhandviertel	Niedersachsen	NI	Stade
21720	Mittelnkirchen	Niedersachsen	NI	Stade
21720	Grünendeich	Niedersachsen	NI	Stade
21720	Steinkirchen	Niedersachsen	NI	Stade
21723	Hollern-Twielenfleth	Niedersachsen	NI	Stade
21726	Kranenburg	Niedersachsen	NI	Stade
21726	Heinbockel	Niedersachsen	NI	Stade
21726	Oldendorf	Niedersachsen	NI	Stade
21727	Estorf	Niedersachsen	NI	Stade
21729	Freiburg (Elbe)	Niedersachsen	NI	Stade
21730	Balje	Niedersachsen	NI	Stade
21732	Krummendeich	Niedersachsen	NI	Stade
21734	Oederquart	Niedersachsen	NI	Stade
21737	Wischhafen	Niedersachsen	NI	Stade
21739	Dollern	Niedersachsen	NI	Stade
21745	Hemmoor	Niedersachsen	NI	Cuxhaven
21755	Hechthausen	Niedersachsen	NI	Cuxhaven
21756	Osten	Niedersachsen	NI	Cuxhaven
21762	Otterndorf	Niedersachsen	NI	Cuxhaven
21762	Osterbruch	Niedersachsen	NI	Cuxhaven
21763	Neuenkirchen	Niedersachsen	NI	Cuxhaven
21765	Nordleda	Niedersachsen	NI	Cuxhaven
21769	Hollnseth	Niedersachsen	NI	Cuxhaven
21769	Armstorf	Niedersachsen	NI	Cuxhaven
21769	Lamstedt	Niedersachsen	NI	Cuxhaven
21770	Mittelstenahe	Niedersachsen	NI	Cuxhaven
21772	Stinstedt	Niedersachsen	NI	Cuxhaven
21775	Ihlienworth	Niedersachsen	NI	Cuxhaven
21775	Odisheim	Niedersachsen	NI	Cuxhaven
21775	Steinau	Niedersachsen	NI	Cuxhaven
21776	Wanna	Niedersachsen	NI	Cuxhaven
21781	Cadenberge	Niedersachsen	NI	Cuxhaven
21782	Bülkau	Niedersachsen	NI	Cuxhaven
21784	Geversdorf	Niedersachsen	NI	Cuxhaven
21785	Neuhaus an der Oste	Niedersachsen	NI	Cuxhaven
21785	Belum	Niedersachsen	NI	Cuxhaven
21787	Oberndorf	Niedersachsen	NI	Cuxhaven
21789	Wingst	Niedersachsen	NI	Cuxhaven
26121	Oldenburg	Niedersachsen	NI	Oldenburg (Oldenburg); Stadt
26122	Oldenburg	Niedersachsen	NI	Oldenburg (Oldenburg); Stadt
26123	Oldenburg	Niedersachsen	NI	Oldenburg (Oldenburg); Stadt
26125	Oldenburg	Niedersachsen	NI	Oldenburg (Oldenburg); Stadt
26127	Oldenburg	Niedersachsen	NI	Oldenburg (Oldenburg); Stadt
26129	Oldenburg	Niedersachsen	NI	Oldenburg (Oldenburg); Stadt
26131	Oldenburg	Niedersachsen	NI	Oldenburg (Oldenburg); Stadt
26133	Oldenburg	Niedersachsen	NI	Oldenburg (Oldenburg); Stadt
26135	Oldenburg	Niedersachsen	NI	Oldenburg (Oldenburg); Stadt
26160	Bad Zwischenahn	Niedersachsen	NI	Ammerland
26169	Friesoythe	Niedersachsen	NI	Cloppenburg
26180	Rastede	Niedersachsen	NI	Ammerland
26188	Edewecht	Niedersachsen	NI	Ammerland
26197	Großenkneten	Niedersachsen	NI	Oldenburg
26203	Wardenburg	Niedersachsen	NI	Oldenburg
26209	Hatten	Niedersachsen	NI	Oldenburg
26215	Wiefelstede	Niedersachsen	NI	Ammerland
26219	Bösel	Niedersachsen	NI	Cloppenburg
26316	Varel Rosenberg	Niedersachsen	NI	Friesland
26316	Varel Neudorf	Niedersachsen	NI	Friesland
26316	Varel Varel	Niedersachsen	NI	Friesland
26316	Varel Grünenkamp	Niedersachsen	NI	Friesland
26316	Varel Obenstrohe	Niedersachsen	NI	Friesland
26316	Varel Hohelucht	Niedersachsen	NI	Friesland
26316	Varel Dangastermoor	Niedersachsen	NI	Friesland
26316	Varel Dangast	Niedersachsen	NI	Friesland
26316	Varel Jeringhave	Niedersachsen	NI	Friesland
26316	Varel Rallenbüschen	Niedersachsen	NI	Friesland
26316	Varel Streek	Niedersachsen	NI	Friesland
26316	Varel Langendamm	Niedersachsen	NI	Friesland
26316	Varel Winkelsheide	Niedersachsen	NI	Friesland
26316	Varel	Niedersachsen	NI	Friesland
26316	Varel Seghorn	Niedersachsen	NI	Friesland
26316	Varel Neuenwege	Niedersachsen	NI	Friesland
26316	Varel Moorhausen	Niedersachsen	NI	Friesland
26316	Varel Altjührden	Niedersachsen	NI	Friesland
26316	Varel Hohenberge	Niedersachsen	NI	Friesland
26316	Varel Borgstede	Niedersachsen	NI	Friesland
26316	Varel Büppel	Niedersachsen	NI	Friesland
26316	Varel Jethausen	Niedersachsen	NI	Friesland
26340	Zetel Zetel	Niedersachsen	NI	Friesland
26340	Zetel	Niedersachsen	NI	Friesland
26340	Zetel Neuenburg	Niedersachsen	NI	Friesland
26345	Bockhorn Petersgroden	Niedersachsen	NI	Friesland
26345	Bockhorn Adelheidsgroden	Niedersachsen	NI	Friesland
26345	Bockhorn Blauhand	Niedersachsen	NI	Friesland
26345	Bockhorn Ellenserdammersiel	Niedersachsen	NI	Friesland
26345	Bockhorn Jührdenerfeld	Niedersachsen	NI	Friesland
26345	Bockhorn Grabstede	Niedersachsen	NI	Friesland
26345	Bockhorn Kranenkamp	Niedersachsen	NI	Friesland
26345	Bockhorn Goelriehenfeld	Niedersachsen	NI	Friesland
26345	Bockhorn Moorwinkelsdamm	Niedersachsen	NI	Friesland
26345	Bockhorn Osterforde	Niedersachsen	NI	Friesland
26345	Bockhorn Bredehorn	Niedersachsen	NI	Friesland
26345	Bockhorn Bockhornerfeld	Niedersachsen	NI	Friesland
26345	Bockhorn Bockhorn	Niedersachsen	NI	Friesland
26345	Bockhorn Steinhausen	Niedersachsen	NI	Friesland
26345	Bockhorn	Niedersachsen	NI	Friesland
26349	Jade	Niedersachsen	NI	Wesermarsch
26382	Wilhelmshaven	Niedersachsen	NI	Wilhelmshaven; Stadt
26384	Wilhelmshaven	Niedersachsen	NI	Wilhelmshaven; Stadt
26386	Wilhelmshaven	Niedersachsen	NI	Wilhelmshaven; Stadt
26388	Wilhelmshaven	Niedersachsen	NI	Wilhelmshaven; Stadt
26389	Wilhelmshaven	Niedersachsen	NI	Wilhelmshaven; Stadt
26409	Wittmund Eggelingen	Niedersachsen	NI	Wittmund
26409	Wittmund Wittmund	Niedersachsen	NI	Wittmund
26409	Wittmund Funnix	Niedersachsen	NI	Wittmund
26409	Wittmund Buttforde	Niedersachsen	NI	Wittmund
26409	Wittmund Carolinensiel	Niedersachsen	NI	Wittmund
26409	Wittmund Ardorf	Niedersachsen	NI	Wittmund
26409	Wittmund Blersum	Niedersachsen	NI	Wittmund
26409	Wittmund Hovel	Niedersachsen	NI	Wittmund
26409	Wittmund Berdum	Niedersachsen	NI	Wittmund
26409	Wittmund Burhafe	Niedersachsen	NI	Wittmund
26409	Wittmund Asel	Niedersachsen	NI	Wittmund
26409	Wittmund Uttel	Niedersachsen	NI	Wittmund
26409	Wittmund Leerhafe	Niedersachsen	NI	Wittmund
26409	Wittmund Willen	Niedersachsen	NI	Wittmund
26409	Wittmund	Niedersachsen	NI	Wittmund
26419	Schortens Oestringfelde	Niedersachsen	NI	Friesland
26419	Schortens Sillenstede	Niedersachsen	NI	Friesland
26419	Schortens Middelsfähr	Niedersachsen	NI	Friesland
26419	Schortens Schortens	Niedersachsen	NI	Friesland
26419	Schortens Upjever	Niedersachsen	NI	Friesland
26419	Schortens Accum	Niedersachsen	NI	Friesland
26419	Schortens Grafschaft	Niedersachsen	NI	Friesland
26419	Schortens Addernhausen	Niedersachsen	NI	Friesland
26419	Schortens Roffhausen	Niedersachsen	NI	Friesland
26419	Schortens Heidmühle	Niedersachsen	NI	Friesland
26419	Schortens Schoost	Niedersachsen	NI	Friesland
26419	Schortens Ostiem	Niedersachsen	NI	Friesland
26419	Schortens	Niedersachsen	NI	Friesland
26427	Moorweg	Niedersachsen	NI	Wittmund
26427	Neuharlingersiel	Niedersachsen	NI	Wittmund
26427	Dunum	Niedersachsen	NI	Wittmund
26427	Stedesdorf	Niedersachsen	NI	Wittmund
26427	Holtgast	Niedersachsen	NI	Wittmund
26427	Werdum	Niedersachsen	NI	Wittmund
26427	Esens	Niedersachsen	NI	Wittmund
26434	Wangerland Hohenkirchen	Niedersachsen	NI	Friesland
26434	Wangerland Tettens	Niedersachsen	NI	Friesland
26434	Wangerland	Niedersachsen	NI	Friesland
26434	Wangerland Minsen	Niedersachsen	NI	Friesland
26434	Wangerland Hooksiel	Niedersachsen	NI	Friesland
26434	Wangerland Waddewarden	Niedersachsen	NI	Friesland
26441	Jever	Niedersachsen	NI	Friesland
26441	Jever Jever	Niedersachsen	NI	Friesland
26446	Friedeburg Reepsholt; Dose	Niedersachsen	NI	Wittmund
26446	Friedeburg Horsten	Niedersachsen	NI	Wittmund
26446	Friedeburg Reepsholt; Reepsholt	Niedersachsen	NI	Wittmund
26446	Friedeburg Bentstreek	Niedersachsen	NI	Wittmund
26446	Friedeburg Reepsholt; Abickhafe	Niedersachsen	NI	Wittmund
26446	Friedeburg Reepsholt; Hoheesche	Niedersachsen	NI	Wittmund
26446	Friedeburg Etzel	Niedersachsen	NI	Wittmund
26446	Friedeburg Reepsholt	Niedersachsen	NI	Wittmund
26446	Friedeburg Wiesede	Niedersachsen	NI	Wittmund
26446	Friedeburg	Niedersachsen	NI	Wittmund
26446	Friedeburg Friedeburg	Niedersachsen	NI	Wittmund
26446	Friedeburg Hesel	Niedersachsen	NI	Wittmund
26446	Friedeburg Wiesedermeer	Niedersachsen	NI	Wittmund
26446	Friedeburg Marx	Niedersachsen	NI	Wittmund
26452	Sande Sanderbusch	Niedersachsen	NI	Friesland
26452	Sande Dykhausen	Niedersachsen	NI	Friesland
26452	Sande Cäciliengroden	Niedersachsen	NI	Friesland
26452	Sande Neustadtgödens	Niedersachsen	NI	Friesland
26452	Sande	Niedersachsen	NI	Friesland
26452	Sande Sande	Niedersachsen	NI	Friesland
26452	Sande Mariensiel	Niedersachsen	NI	Friesland
26465	Langeoog	Niedersachsen	NI	Wittmund
26474	Spiekeroog	Niedersachsen	NI	Wittmund
26486	Wangerooge	Niedersachsen	NI	Friesland
26487	Blomberg	Niedersachsen	NI	Wittmund
26487	Neuschoo	Niedersachsen	NI	Wittmund
26489	Ochtersum	Niedersachsen	NI	Wittmund
26489	Ochtersum Westochtersum	Niedersachsen	NI	Wittmund
26489	Ochtersum Ostochtersum	Niedersachsen	NI	Wittmund
26506	Norden Westermarsch I	Niedersachsen	NI	Aurich
26506	Norden Westermarsch II	Niedersachsen	NI	Aurich
26506	Norden Neuwesteel	Niedersachsen	NI	Aurich
26506	Norden Süderneuland II	Niedersachsen	NI	Aurich
26506	Norden Norden	Niedersachsen	NI	Aurich
26506	Norden Süderneuland I	Niedersachsen	NI	Aurich
26506	Norden Bargebur	Niedersachsen	NI	Aurich
26506	Norden Norddeich	Niedersachsen	NI	Aurich
26506	Norden Ostermarsch	Niedersachsen	NI	Aurich
26506	Norden Tidofeld	Niedersachsen	NI	Aurich
26506	Norden Leybuchtpolder	Niedersachsen	NI	Aurich
26506	Norden	Niedersachsen	NI	Aurich
26524	Halbemond	Niedersachsen	NI	Aurich
26524	Berumbur	Niedersachsen	NI	Aurich
26524	Hage	Niedersachsen	NI	Aurich
26524	Lütetsburg	Niedersachsen	NI	Aurich
26524	Hagermarsch	Niedersachsen	NI	Aurich
26529	Leezdorf	Niedersachsen	NI	Aurich
26529	Upgant-Schott	Niedersachsen	NI	Aurich
26529	Osteel	Niedersachsen	NI	Aurich
26529	Rechtsupweg	Niedersachsen	NI	Aurich
26529	Wirdum	Niedersachsen	NI	Aurich
26529	Marienhafe	Niedersachsen	NI	Aurich
26532	Großheide Arle	Niedersachsen	NI	Aurich
26532	Großheide Berumerfehn	Niedersachsen	NI	Aurich
26532	Großheide	Niedersachsen	NI	Aurich
26532	Großheide Großheide	Niedersachsen	NI	Aurich
26532	Großheide Menstede-Coldinne	Niedersachsen	NI	Aurich
26532	Großheide Menstede-Coldinne; Menstede	Niedersachsen	NI	Aurich
26532	Großheide Menstede-Coldinne; Coldinne	Niedersachsen	NI	Aurich
26532	Großheide Westerende	Niedersachsen	NI	Aurich
26548	Norderney	Niedersachsen	NI	Aurich
26553	Dornum Neßmersiel	Niedersachsen	NI	Aurich
26553	Dornum Nesse	Niedersachsen	NI	Aurich
26553	Dornum Westerbur	Niedersachsen	NI	Aurich
26553	Dornum Dornumersiel	Niedersachsen	NI	Aurich
26553	Dornum Westeraccum	Niedersachsen	NI	Aurich
26553	Dornum	Niedersachsen	NI	Aurich
26553	Dornum Roggenstede	Niedersachsen	NI	Aurich
26553	Dornum Schwittersum	Niedersachsen	NI	Aurich
26553	Dornum Dornumergrode	Niedersachsen	NI	Aurich
26553	Dornum Dornum	Niedersachsen	NI	Aurich
26553	Dornum Westdorf	Niedersachsen	NI	Aurich
26553	Dornum Westeraccumersiel	Niedersachsen	NI	Aurich
26556	Utarp	Niedersachsen	NI	Wittmund
26556	Westerholt	Niedersachsen	NI	Wittmund
26556	Schweindorf	Niedersachsen	NI	Wittmund
26556	Nenndorf	Niedersachsen	NI	Wittmund
26556	Eversmeer	Niedersachsen	NI	Wittmund
26571	Juist	Niedersachsen	NI	Aurich
26579	Baltrum	Niedersachsen	NI	Aurich
26603	Aurich	Niedersachsen	NI	Aurich
26605	Aurich	Niedersachsen	NI	Aurich
26605	Aurich Haxtum	Niedersachsen	NI	Aurich
26605	Aurich Brockzetel	Niedersachsen	NI	Aurich
26605	Aurich Egels	Niedersachsen	NI	Aurich
26607	Aurich	Niedersachsen	NI	Aurich
26624	Südbrookmerland Victorbur	Niedersachsen	NI	Aurich
26624	Südbrookmerland Forlitz-Blaukirchen	Niedersachsen	NI	Aurich
26624	Südbrookmerland Moorhusen	Niedersachsen	NI	Aurich
26624	Südbrookmerland Bedekaspel	Niedersachsen	NI	Aurich
26624	Südbrookmerland Oldeborg	Niedersachsen	NI	Aurich
26624	Südbrookmerland	Niedersachsen	NI	Aurich
26624	Südbrookmerland Theene	Niedersachsen	NI	Aurich
26624	Südbrookmerland Münkeboe	Niedersachsen	NI	Aurich
26624	Südbrookmerland Uthwerdum	Niedersachsen	NI	Aurich
26624	Südbrookmerland Wiegboldsbur	Niedersachsen	NI	Aurich
26624	Südbrookmerland Moordorf	Niedersachsen	NI	Aurich
26629	Großefehn Bagband	Niedersachsen	NI	Aurich
26629	Großefehn Fiebing	Niedersachsen	NI	Aurich
26629	Großefehn Felde	Niedersachsen	NI	Aurich
26629	Großefehn Ostgroßefehn	Niedersachsen	NI	Aurich
26629	Großefehn Timmel	Niedersachsen	NI	Aurich
26629	Großefehn Wrisse	Niedersachsen	NI	Aurich
26629	Großefehn Strackholt	Niedersachsen	NI	Aurich
26629	Großefehn Westgroßefehn	Niedersachsen	NI	Aurich
26629	Großefehn Holtrop	Niedersachsen	NI	Aurich
26629	Großefehn	Niedersachsen	NI	Aurich
26629	Großefehn Spetzerfehn	Niedersachsen	NI	Aurich
26629	Großefehn Akelsbarg	Niedersachsen	NI	Aurich
26629	Großefehn Aurich-Oldendorf	Niedersachsen	NI	Aurich
26629	Großefehn Mittegroßefehn	Niedersachsen	NI	Aurich
26629	Großefehn Ulbargen	Niedersachsen	NI	Aurich
26632	Ihlow Ludwigsdorf	Niedersachsen	NI	Aurich
26632	Ihlow Ochtelbur	Niedersachsen	NI	Aurich
26632	Ihlow Riepsterhammrich	Niedersachsen	NI	Aurich
26632	Ihlow Simonswolde	Niedersachsen	NI	Aurich
26632	Ihlow	Niedersachsen	NI	Aurich
26632	Ihlow Westerende-Holzloog	Niedersachsen	NI	Aurich
26632	Ihlow Westerende-Kirchloog	Niedersachsen	NI	Aurich
26632	Ihlow Ihlowerfehn	Niedersachsen	NI	Aurich
26632	Ihlow Riepe	Niedersachsen	NI	Aurich
26632	Ihlow Bangstede	Niedersachsen	NI	Aurich
26632	Ihlow Ostersander	Niedersachsen	NI	Aurich
26632	Ihlow Barstede	Niedersachsen	NI	Aurich
26639	Wiesmoor	Niedersachsen	NI	Aurich
26639	Wiesmoor Zwischenbergen	Niedersachsen	NI	Aurich
26639	Wiesmoor Voßbarg	Niedersachsen	NI	Aurich
26639	Wiesmoor Wiesmoor	Niedersachsen	NI	Aurich
26639	Wiesmoor Marcardsmoor	Niedersachsen	NI	Aurich
26639	Wiesmoor Wiesederfehn	Niedersachsen	NI	Aurich
26655	Westerstede	Niedersachsen	NI	Ammerland
26670	Uplengen	Niedersachsen	NI	Leer
26676	Barßel	Niedersachsen	NI	Cloppenburg
26683	Saterland	Niedersachsen	NI	Cloppenburg
26689	Apen	Niedersachsen	NI	Ammerland
26721	Emden	Niedersachsen	NI	Emden; Stadt
26723	Emden	Niedersachsen	NI	Emden; Stadt
26725	Emden	Niedersachsen	NI	Emden; Stadt
26736	Krummhörn Grimersum	Niedersachsen	NI	Aurich
26736	Krummhörn Woltzeten	Niedersachsen	NI	Aurich
26736	Krummhörn Canum	Niedersachsen	NI	Aurich
26736	Krummhörn Freepsum	Niedersachsen	NI	Aurich
26736	Krummhörn	Niedersachsen	NI	Aurich
26736	Krummhörn Loquard	Niedersachsen	NI	Aurich
26736	Krummhörn Pewsum	Niedersachsen	NI	Aurich
26736	Krummhörn Groothusen	Niedersachsen	NI	Aurich
26736	Krummhörn Greetsiel	Niedersachsen	NI	Aurich
26736	Krummhörn Visquard	Niedersachsen	NI	Aurich
26736	Krummhörn Woquard	Niedersachsen	NI	Aurich
26736	Krummhörn Upleward	Niedersachsen	NI	Aurich
26736	Krummhörn Manslagt	Niedersachsen	NI	Aurich
26736	Krummhörn Pilsum	Niedersachsen	NI	Aurich
26736	Krummhörn Rysum	Niedersachsen	NI	Aurich
26736	Krummhörn Hamswehrum	Niedersachsen	NI	Aurich
26736	Krummhörn Campen	Niedersachsen	NI	Aurich
26736	Krummhörn Uttum	Niedersachsen	NI	Aurich
26736	Krummhörn Jennelt	Niedersachsen	NI	Aurich
26736	Krummhörn Eilsum	Niedersachsen	NI	Aurich
26757	Borkum	Niedersachsen	NI	Leer
26759	Hinte Canhusen	Niedersachsen	NI	Aurich
26759	Hinte Osterhusen	Niedersachsen	NI	Aurich
26759	Hinte	Niedersachsen	NI	Aurich
26759	Hinte Suurhusen	Niedersachsen	NI	Aurich
26759	Hinte Westerhusen	Niedersachsen	NI	Aurich
26759	Hinte Hinte	Niedersachsen	NI	Aurich
26759	Hinte Cirkwehrum	Niedersachsen	NI	Aurich
26759	Hinte Loppersum	Niedersachsen	NI	Aurich
26759	Hinte Groß Midlum	Niedersachsen	NI	Aurich
26789	Leer (Ostfriesland)	Niedersachsen	NI	Leer
26802	Moormerland	Niedersachsen	NI	Leer
26810	Westoverledingen	Niedersachsen	NI	Leer
26817	Rhauderfehn	Niedersachsen	NI	Leer
26826	Weener	Niedersachsen	NI	Leer
26831	Bunderhee	Niedersachsen	NI	Leer
26831	Wymeer	Niedersachsen	NI	Leer
26831	Dollart	Niedersachsen	NI	Leer
26831	Boen	Niedersachsen	NI	Leer
26831	Bunde	Niedersachsen	NI	Leer
26835	Firrel	Niedersachsen	NI	Leer
26835	Brinkum	Niedersachsen	NI	Leer
26835	Schwerinsdorf	Niedersachsen	NI	Leer
26835	Neukamperfehn	Niedersachsen	NI	Leer
26835	Hesel	Niedersachsen	NI	Leer
26835	Holtland	Niedersachsen	NI	Leer
26842	Ostrhauderfehn	Niedersachsen	NI	Leer
26844	Jemgum	Niedersachsen	NI	Leer
26845	Nortmoor	Niedersachsen	NI	Leer
26847	Detern	Niedersachsen	NI	Leer
26849	Filsum	Niedersachsen	NI	Leer
26871	Papenburg	Niedersachsen	NI	Emsland
26892	Dörpen	Niedersachsen	NI	Emsland
26892	Kluse	Niedersachsen	NI	Emsland
26892	Heede	Niedersachsen	NI	Emsland
26892	Lehe	Niedersachsen	NI	Emsland
26892	Wippingen	Niedersachsen	NI	Emsland
26897	Hilkenbrook	Niedersachsen	NI	Emsland
26897	Bockhorst	Niedersachsen	NI	Emsland
26897	Breddenberg	Niedersachsen	NI	Emsland
26897	Esterwegen	Niedersachsen	NI	Emsland
26899	Rhede	Niedersachsen	NI	Emsland
26901	Rastdorf	Niedersachsen	NI	Emsland
26901	Lorup	Niedersachsen	NI	Emsland
26903	Surwold	Niedersachsen	NI	Emsland
26904	Börger	Niedersachsen	NI	Emsland
26906	Dersum	Niedersachsen	NI	Emsland
26907	Walchum	Niedersachsen	NI	Emsland
26909	Neubörger	Niedersachsen	NI	Emsland
26909	Neulehe	Niedersachsen	NI	Emsland
26919	Brake	Niedersachsen	NI	Wesermarsch
26931	Elsfleth	Niedersachsen	NI	Wesermarsch
26935	Stadland	Niedersachsen	NI	Wesermarsch
26936	Stadland	Niedersachsen	NI	Wesermarsch
26937	Stadland	Niedersachsen	NI	Wesermarsch
26939	Ovelgönne	Niedersachsen	NI	Wesermarsch
26954	Nordenham	Niedersachsen	NI	Wesermarsch
26969	Butjadingen	Niedersachsen	NI	Wesermarsch
27211	Bassum	Niedersachsen	NI	Diepholz
27232	Sulingen	Niedersachsen	NI	Diepholz
27239	Twistringen	Niedersachsen	NI	Diepholz
27243	Beckeln	Niedersachsen	NI	Oldenburg
27243	Groß Ippener	Niedersachsen	NI	Oldenburg
27243	Colnrade	Niedersachsen	NI	Oldenburg
27243	Harpstedt	Niedersachsen	NI	Oldenburg
27243	Kirchseelte	Niedersachsen	NI	Oldenburg
27243	Prinzhöfte	Niedersachsen	NI	Oldenburg
27243	Winkelsett	Niedersachsen	NI	Oldenburg
27243	Dünsen	Niedersachsen	NI	Oldenburg
27245	Barenburg	Niedersachsen	NI	Diepholz
27245	Bahrenborstel	Niedersachsen	NI	Diepholz
27245	Kirchdorf	Niedersachsen	NI	Diepholz
27246	Borstel	Niedersachsen	NI	Diepholz
27248	Ehrenburg	Niedersachsen	NI	Diepholz
27249	Maasen	Niedersachsen	NI	Diepholz
27249	Mellinghausen	Niedersachsen	NI	Diepholz
27251	Neuenkirchen	Niedersachsen	NI	Diepholz
27251	Scholen	Niedersachsen	NI	Diepholz
27252	Schwaförden	Niedersachsen	NI	Diepholz
27254	Staffhorst	Niedersachsen	NI	Diepholz
27254	Siedenburg	Niedersachsen	NI	Diepholz
27257	Sudwalde	Niedersachsen	NI	Diepholz
27257	Affinghausen	Niedersachsen	NI	Diepholz
27259	Varrel	Niedersachsen	NI	Diepholz
27259	Freistatt	Niedersachsen	NI	Diepholz
27259	Wehrbleck	Niedersachsen	NI	Diepholz
27283	Verden (Aller)	Niedersachsen	NI	Verden
27299	Langwedel	Niedersachsen	NI	Verden
27305	Engeln	Niedersachsen	NI	Diepholz
27305	Bruchhausen-Vilsen	Niedersachsen	NI	Diepholz
27305	Süstedt	Niedersachsen	NI	Diepholz
27308	Kirchlinteln	Niedersachsen	NI	Verden
27313	Dörverden	Niedersachsen	NI	Verden
27318	Hoyerhagen	Niedersachsen	NI	Nienburg/Weser
27318	Hoya	Niedersachsen	NI	Nienburg/Weser
27318	Hilgermissen	Niedersachsen	NI	Nienburg/Weser
27321	Thedinghausen	Niedersachsen	NI	Verden
27321	Morsum	Niedersachsen	NI	Verden
27321	Emtinghausen	Niedersachsen	NI	Verden
27324	Hämelhausen	Niedersachsen	NI	Nienburg/Weser
27324	Hassel (Weser)	Niedersachsen	NI	Nienburg/Weser
27324	Eystrup	Niedersachsen	NI	Nienburg/Weser
27324	Gandesbergen	Niedersachsen	NI	Nienburg/Weser
27327	Schwarme	Niedersachsen	NI	Diepholz
27327	Martfeld	Niedersachsen	NI	Diepholz
27330	Asendorf	Niedersachsen	NI	Diepholz
27333	Warpe	Niedersachsen	NI	Nienburg/Weser
27333	Bücken	Niedersachsen	NI	Nienburg/Weser
27333	Schweringen	Niedersachsen	NI	Nienburg/Weser
27336	Häuslingen	Niedersachsen	NI	Heidekreis
27336	Frankenfeld	Niedersachsen	NI	Heidekreis
27336	Rethem (Aller)	Niedersachsen	NI	Heidekreis
27337	Blender	Niedersachsen	NI	Verden
27339	Riede	Niedersachsen	NI	Verden
27356	Rotenburg (Wümme)	Niedersachsen	NI	Rotenburg (Wümme)
27367	Sottrum	Niedersachsen	NI	Rotenburg (Wümme)
27367	Horstedt	Niedersachsen	NI	Rotenburg (Wümme)
27367	Bötersen	Niedersachsen	NI	Rotenburg (Wümme)
27367	Ahausen	Niedersachsen	NI	Rotenburg (Wümme)
27367	Hellwege	Niedersachsen	NI	Rotenburg (Wümme)
27367	Reeßum	Niedersachsen	NI	Rotenburg (Wümme)
27367	Hassendorf	Niedersachsen	NI	Rotenburg (Wümme)
27374	Visselhövede	Niedersachsen	NI	Rotenburg (Wümme)
27383	Scheeßel	Niedersachsen	NI	Rotenburg (Wümme)
27386	Brockel	Niedersachsen	NI	Rotenburg (Wümme)
27386	Kirchwalsede	Niedersachsen	NI	Rotenburg (Wümme)
27386	Hemslingen	Niedersachsen	NI	Rotenburg (Wümme)
27386	Westerwalsede	Niedersachsen	NI	Rotenburg (Wümme)
27386	Bothel	Niedersachsen	NI	Rotenburg (Wümme)
27386	Hemsbünde	Niedersachsen	NI	Rotenburg (Wümme)
27389	Stemmen	Niedersachsen	NI	Rotenburg (Wümme)
27389	Lauenbrück	Niedersachsen	NI	Rotenburg (Wümme)
27389	Vahlde	Niedersachsen	NI	Rotenburg (Wümme)
27389	Fintel	Niedersachsen	NI	Rotenburg (Wümme)
27389	Helvesiek	Niedersachsen	NI	Rotenburg (Wümme)
27404	Rhade	Niedersachsen	NI	Rotenburg (Wümme)
27404	Ostereistedt	Niedersachsen	NI	Rotenburg (Wümme)
27404	Seedorf	Niedersachsen	NI	Rotenburg (Wümme)
27404	Zeven	Niedersachsen	NI	Rotenburg (Wümme)
27404	Elsdorf	Niedersachsen	NI	Rotenburg (Wümme)
27404	Heeslingen	Niedersachsen	NI	Rotenburg (Wümme)
27404	Gyhum	Niedersachsen	NI	Rotenburg (Wümme)
27412	Wilstedt	Niedersachsen	NI	Rotenburg (Wümme)
27412	Breddorf	Niedersachsen	NI	Rotenburg (Wümme)
27412	Bülstedt	Niedersachsen	NI	Rotenburg (Wümme)
27412	Vorwerk	Niedersachsen	NI	Rotenburg (Wümme)
27412	Kirchtimke	Niedersachsen	NI	Rotenburg (Wümme)
27412	Hepstedt	Niedersachsen	NI	Rotenburg (Wümme)
27412	Westertimke	Niedersachsen	NI	Rotenburg (Wümme)
27412	Tarmstedt	Niedersachsen	NI	Rotenburg (Wümme)
27419	Kalbe	Niedersachsen	NI	Rotenburg (Wümme)
27419	Lengenbostel	Niedersachsen	NI	Rotenburg (Wümme)
27419	Groß Meckelsen	Niedersachsen	NI	Rotenburg (Wümme)
27419	Sittensen	Niedersachsen	NI	Rotenburg (Wümme)
27419	Tiste	Niedersachsen	NI	Rotenburg (Wümme)
27419	Hamersen	Niedersachsen	NI	Rotenburg (Wümme)
27419	Wohnste	Niedersachsen	NI	Rotenburg (Wümme)
27419	Vierden	Niedersachsen	NI	Rotenburg (Wümme)
27419	Klein Meckelsen	Niedersachsen	NI	Rotenburg (Wümme)
27432	Basdahl	Niedersachsen	NI	Rotenburg (Wümme)
27432	Bremervörde	Niedersachsen	NI	Rotenburg (Wümme)
27432	Alfstedt	Niedersachsen	NI	Rotenburg (Wümme)
27432	Hipstedt	Niedersachsen	NI	Rotenburg (Wümme)
27432	Ebersdorf	Niedersachsen	NI	Rotenburg (Wümme)
27432	Oerel	Niedersachsen	NI	Rotenburg (Wümme)
27442	Gnarrenburg	Niedersachsen	NI	Rotenburg (Wümme)
27446	Deinstedt	Niedersachsen	NI	Rotenburg (Wümme)
27446	Sandbostel	Niedersachsen	NI	Rotenburg (Wümme)
27446	Anderlingen	Niedersachsen	NI	Rotenburg (Wümme)
27446	Farven	Niedersachsen	NI	Rotenburg (Wümme)
27446	Selsingen	Niedersachsen	NI	Rotenburg (Wümme)
27449	Kutenholz	Niedersachsen	NI	Stade
27472	Cuxhaven	Niedersachsen	NI	Cuxhaven
27474	Cuxhaven	Niedersachsen	NI	Cuxhaven
27476	Cuxhaven	Niedersachsen	NI	Cuxhaven
27478	Cuxhaven	Niedersachsen	NI	Cuxhaven
27607	Langen	Niedersachsen	NI	Cuxhaven
27612	Loxstedt	Niedersachsen	NI	Cuxhaven
27616	Lunestedt	Niedersachsen	NI	Cuxhaven
27616	Appeln	Niedersachsen	NI	Cuxhaven
27616	Frelsdorf	Niedersachsen	NI	Cuxhaven
27616	Beverstedt	Niedersachsen	NI	Cuxhaven
27616	Heerstedt	Niedersachsen	NI	Cuxhaven
27616	Kirchwistedt	Niedersachsen	NI	Cuxhaven
27616	Bokel	Niedersachsen	NI	Cuxhaven
27619	Schiffdorf	Niedersachsen	NI	Cuxhaven
27624	Lintig	Niedersachsen	NI	Cuxhaven
27624	Kührstedt	Niedersachsen	NI	Cuxhaven
27624	Köhlen	Niedersachsen	NI	Cuxhaven
27624	Bad Bederkesa	Niedersachsen	NI	Cuxhaven
27624	Flögeln	Niedersachsen	NI	Cuxhaven
27624	Ringstedt	Niedersachsen	NI	Cuxhaven
27624	Elmlohe	Niedersachsen	NI	Cuxhaven
27624	Drangstedt	Niedersachsen	NI	Cuxhaven
27628	Wulsbüttel	Niedersachsen	NI	Cuxhaven
27628	Driftsethe	Niedersachsen	NI	Cuxhaven
27628	Hagen im Bremischen	Niedersachsen	NI	Cuxhaven
27628	Bramstedt	Niedersachsen	NI	Cuxhaven
27628	Sandstedt	Niedersachsen	NI	Cuxhaven
27628	Uthlede	Niedersachsen	NI	Cuxhaven
27637	Nordholz	Niedersachsen	NI	Cuxhaven
27638	Wremen	Niedersachsen	NI	Cuxhaven
27639	Mulsum	Niedersachsen	NI	Cuxhaven
27639	Dorum	Niedersachsen	NI	Cuxhaven
27639	Cappel	Niedersachsen	NI	Cuxhaven
27639	Midlum	Niedersachsen	NI	Cuxhaven
27639	Misselwarden	Niedersachsen	NI	Cuxhaven
27639	Padingbüttel	Niedersachsen	NI	Cuxhaven
27711	Osterholz-Scharmbeck	Niedersachsen	NI	Osterholz
27721	Ritterhude	Niedersachsen	NI	Osterholz
27726	Worpswede	Niedersachsen	NI	Osterholz
27729	Lübberstedt	Niedersachsen	NI	Osterholz
27729	Hambergen	Niedersachsen	NI	Osterholz
27729	Holste	Niedersachsen	NI	Osterholz
27729	Axstedt	Niedersachsen	NI	Osterholz
27729	Vollersode	Niedersachsen	NI	Osterholz
27749	Delmenhorst	Niedersachsen	NI	Delmenhorst; Stadt
27751	Delmenhorst	Niedersachsen	NI	Delmenhorst; Stadt
27753	Delmenhorst	Niedersachsen	NI	Delmenhorst; Stadt
27755	Delmenhorst	Niedersachsen	NI	Delmenhorst; Stadt
27777	Ganderkesee	Niedersachsen	NI	Oldenburg
27793	Wildeshausen	Niedersachsen	NI	Oldenburg
27798	Hude (Oldenburg)	Niedersachsen	NI	Oldenburg
27801	Dötlingen	Niedersachsen	NI	Oldenburg
27804	Berne	Niedersachsen	NI	Wesermarsch
27809	Lemwerder	Niedersachsen	NI	Wesermarsch
28790	Schwanewede	Niedersachsen	NI	Osterholz
28816	Stuhr	Niedersachsen	NI	Diepholz
28832	Achim	Niedersachsen	NI	Verden
28844	Weyhe	Niedersachsen	NI	Diepholz
28857	Syke	Niedersachsen	NI	Diepholz
28865	Lilienthal	Niedersachsen	NI	Osterholz
28870	Ottersberg	Niedersachsen	NI	Verden
28876	Oyten	Niedersachsen	NI	Verden
28879	Grasberg	Niedersachsen	NI	Osterholz
29221	Celle	Niedersachsen	NI	Celle
29223	Celle	Niedersachsen	NI	Celle
29225	Celle	Niedersachsen	NI	Celle
29227	Celle	Niedersachsen	NI	Celle
29229	Celle	Niedersachsen	NI	Celle
29303	Bergen	Niedersachsen	NI	Celle
29308	Winsen (Aller)	Niedersachsen	NI	Celle
29313	Hambühren	Niedersachsen	NI	Celle
29320	Hermannsburg	Niedersachsen	NI	Celle
29323	Wietze	Niedersachsen	NI	Celle
29328	Faßberg	Niedersachsen	NI	Celle
29331	Lachendorf	Niedersachsen	NI	Celle
29336	Nienhagen	Niedersachsen	NI	Celle
29339	Wathlingen	Niedersachsen	NI	Celle
29342	Wienhausen	Niedersachsen	NI	Celle
29345	Unterlüß	Niedersachsen	NI	Celle
29348	Scharnhorst	Niedersachsen	NI	Celle
29348	Eschede	Niedersachsen	NI	Celle
29351	Eldingen	Niedersachsen	NI	Celle
29352	Adelheidsdorf	Niedersachsen	NI	Celle
29353	Ahnsbeck	Niedersachsen	NI	Celle
29355	Beedenbostel	Niedersachsen	NI	Celle
29356	Bröckel	Niedersachsen	NI	Celle
29358	Eicklingen	Niedersachsen	NI	Celle
29359	Habighorst	Niedersachsen	NI	Celle
29361	Höfer	Niedersachsen	NI	Celle
29362	Hohne	Niedersachsen	NI	Celle
29364	Langlingen	Niedersachsen	NI	Celle
29365	Sprakensehl	Niedersachsen	NI	Gifhorn
29367	Steinhorst	Niedersachsen	NI	Gifhorn
29369	Ummern	Niedersachsen	NI	Gifhorn
29378	Wittingen	Niedersachsen	NI	Gifhorn
29379	Wittingen	Niedersachsen	NI	Gifhorn
29386	Hankensbüttel	Niedersachsen	NI	Gifhorn
29386	Dedelstorf	Niedersachsen	NI	Gifhorn
29386	Obernholz	Niedersachsen	NI	Gifhorn
29389	Bad Bodenteich	Niedersachsen	NI	Uelzen
29392	Wesendorf	Niedersachsen	NI	Gifhorn
29393	Groß Oesingen	Niedersachsen	NI	Gifhorn
29394	Lüder	Niedersachsen	NI	Uelzen
29396	Schönewörde	Niedersachsen	NI	Gifhorn
29399	Wahrenholz	Niedersachsen	NI	Gifhorn
29439	Lüchow	Niedersachsen	NI	Lüchow-Dannenberg
29451	Schaafhausen	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Neu Tramm	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Schmarsau	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Nebenstedt	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Liepehöfen	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Dambeck	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Bückau	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Prisser	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Tramm	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Prabstorf	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Seedorf	Niedersachsen	NI	Lüchow-Dannenberg
46535	Dinslaken	Nordrhein-Westfalen	NW	51
29451	Dannenberg (Elbe) Lüggau	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Penkefitz	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Tripkau	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Predöhlsau	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Soven	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Dannenberg	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Pisselberg	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Klein Heide	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Splietau	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Streetz	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Seybruch	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Groß Heide	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Riskau	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Riekau	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Gümse	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Breese in der Marsch	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Sipnitz	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe) Niestedt	Niedersachsen	NI	Lüchow-Dannenberg
29451	Dannenberg (Elbe)	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Posade	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Grabau	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Wussegel	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Gut Hagen	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Meudelfitz; Eichengrund	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Seerau	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Meudelfitz; Gut Meudelfitz	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Wietzetze bei Hitzacker	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Bahrendorf	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Kähmen	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Harlingen	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Sarchem	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Tiesmesland	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Pussade	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Nienwedel	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Meudelfitz	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Leitstade	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Hitzacker	Niedersachsen	NI	Lüchow-Dannenberg
29456	Hitzacker Tießau	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Granstedt	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Prießeck	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Kussebode	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Dalitz	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Mützen	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Lefitz	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Vaddensen	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Seelwig	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Guhreitzen	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Kloster	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Gistenbeck	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Groß Sachau	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Kassau	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Gohlefanz	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Reddereitz	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Bausen	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Beseland	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Bösen	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Quartzau	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Meußließen	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Satkau	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Braudel	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Schlannau	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Bussau	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Clenze	Niedersachsen	NI	Lüchow-Dannenberg
29459	Clenze Korvin	Niedersachsen	NI	Lüchow-Dannenberg
29462	Wustrow	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Warpke	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Winterweyhe	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Gledeberg	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Proitze	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Starrel	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Külitz	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Oldendorf	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Gielau	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Lütenthien	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Schnega	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Thune	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Solkau	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Billerbeck	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Molden	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Leisten	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Grotenhof	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Kreyenhagen	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Harpe	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Schnega/Bahnhof	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Loitze	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Proitzer Mühle	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Bahnhof Varbitz	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Gielauer Mühle	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Harper Mühle	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Oldendorfer Mühle	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Göhr	Niedersachsen	NI	Lüchow-Dannenberg
29465	Schnega Schäpingen	Niedersachsen	NI	Lüchow-Dannenberg
29468	Bergen (Dumme) Banzau	Niedersachsen	NI	Lüchow-Dannenberg
29468	Bergen (Dumme)	Niedersachsen	NI	Lüchow-Dannenberg
29468	Bergen (Dumme) Wöhningen	Niedersachsen	NI	Lüchow-Dannenberg
29468	Bergen (Dumme) Bergen	Niedersachsen	NI	Lüchow-Dannenberg
29468	Bergen (Dumme) Belau	Niedersachsen	NI	Lüchow-Dannenberg
29468	Bergen (Dumme) Nienbergen	Niedersachsen	NI	Lüchow-Dannenberg
29468	Bergen (Dumme) Jiggel	Niedersachsen	NI	Lüchow-Dannenberg
29468	Bergen (Dumme) Brüchauer Mühle	Niedersachsen	NI	Lüchow-Dannenberg
29468	Bergen (Dumme) Spithal	Niedersachsen	NI	Lüchow-Dannenberg
29468	Bergen (Dumme) Malsleben	Niedersachsen	NI	Lüchow-Dannenberg
29471	Gartow Falkenmoor	Niedersachsen	NI	Lüchow-Dannenberg
29471	Gartow Rondel	Niedersachsen	NI	Lüchow-Dannenberg
29471	Gartow Gartow	Niedersachsen	NI	Lüchow-Dannenberg
29471	Gartow Nienwalde	Niedersachsen	NI	Lüchow-Dannenberg
29471	Gartow Laasche	Niedersachsen	NI	Lüchow-Dannenberg
29471	Gartow Quarnstedt	Niedersachsen	NI	Lüchow-Dannenberg
29471	Gartow Rucksmoor	Niedersachsen	NI	Lüchow-Dannenberg
29471	Gartow	Niedersachsen	NI	Lüchow-Dannenberg
29472	Damnatz Landsatz	Niedersachsen	NI	Lüchow-Dannenberg
29472	Damnatz	Niedersachsen	NI	Lüchow-Dannenberg
29472	Damnatz Barnitz	Niedersachsen	NI	Lüchow-Dannenberg
29472	Damnatz Damnatz	Niedersachsen	NI	Lüchow-Dannenberg
29472	Damnatz Kamerun	Niedersachsen	NI	Lüchow-Dannenberg
29472	Damnatz Jasebeck	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde Nadlitz	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde Schnadlitz	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde Zienitz	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde Kollase	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde Dübbekold	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde Wedderin	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde Mailage	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde Bredenbock	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde Plumbohm	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde Govelin	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde Tollendorf	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde Schmessau	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde Sarenseck	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde Schmardau	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde Göhrde	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde Metzingen	Niedersachsen	NI	Lüchow-Dannenberg
29473	Göhrde	Niedersachsen	NI	Lüchow-Dannenberg
29475	Gorleben Gorleben	Niedersachsen	NI	Lüchow-Dannenberg
29475	Gorleben	Niedersachsen	NI	Lüchow-Dannenberg
29475	Gorleben Meetschow	Niedersachsen	NI	Lüchow-Dannenberg
29476	Gusborn Klein Gusborn	Niedersachsen	NI	Lüchow-Dannenberg
29476	Gusborn Zadrau	Niedersachsen	NI	Lüchow-Dannenberg
29476	Gusborn Groß Gusborn	Niedersachsen	NI	Lüchow-Dannenberg
29476	Gusborn	Niedersachsen	NI	Lüchow-Dannenberg
29476	Gusborn Quickborn	Niedersachsen	NI	Lüchow-Dannenberg
29476	Gusborn Siemen	Niedersachsen	NI	Lüchow-Dannenberg
29478	Höhbeck	Niedersachsen	NI	Lüchow-Dannenberg
29478	Höhbeck Restorf	Niedersachsen	NI	Lüchow-Dannenberg
29478	Höhbeck Pevestorf	Niedersachsen	NI	Lüchow-Dannenberg
29478	Höhbeck Vietze	Niedersachsen	NI	Lüchow-Dannenberg
29478	Höhbeck Brünkendorf	Niedersachsen	NI	Lüchow-Dannenberg
29478	Höhbeck Schwedenschanze	Niedersachsen	NI	Lüchow-Dannenberg
29479	Jameln Jamelner Mühle	Niedersachsen	NI	Lüchow-Dannenberg
29479	Jameln Platenlaase	Niedersachsen	NI	Lüchow-Dannenberg
29479	Jameln Breese im Bruche	Niedersachsen	NI	Lüchow-Dannenberg
29479	Jameln Langenhorst	Niedersachsen	NI	Lüchow-Dannenberg
29479	Jameln Hoheluft	Niedersachsen	NI	Lüchow-Dannenberg
29479	Jameln Mehlfien	Niedersachsen	NI	Lüchow-Dannenberg
29479	Jameln Jameln	Niedersachsen	NI	Lüchow-Dannenberg
29479	Jameln Breustian	Niedersachsen	NI	Lüchow-Dannenberg
29479	Jameln	Niedersachsen	NI	Lüchow-Dannenberg
29479	Jameln Volkfien	Niedersachsen	NI	Lüchow-Dannenberg
29479	Jameln Teichlosen	Niedersachsen	NI	Lüchow-Dannenberg
29479	Jameln Wibbese	Niedersachsen	NI	Lüchow-Dannenberg
29479	Jameln Breselenz	Niedersachsen	NI	Lüchow-Dannenberg
29481	Karwitz Lenzen	Niedersachsen	NI	Lüchow-Dannenberg
29481	Karwitz	Niedersachsen	NI	Lüchow-Dannenberg
29481	Karwitz Karwitz	Niedersachsen	NI	Lüchow-Dannenberg
29481	Karwitz Thunpadel	Niedersachsen	NI	Lüchow-Dannenberg
29481	Karwitz Dragahn	Niedersachsen	NI	Lüchow-Dannenberg
29481	Karwitz Pudripp/Bahnhof	Niedersachsen	NI	Lüchow-Dannenberg
29481	Karwitz Gamehlen	Niedersachsen	NI	Lüchow-Dannenberg
29481	Karwitz Lebbien	Niedersachsen	NI	Lüchow-Dannenberg
29481	Karwitz Nausen	Niedersachsen	NI	Lüchow-Dannenberg
29481	Karwitz Pudripp	Niedersachsen	NI	Lüchow-Dannenberg
29482	Küsten Krummasel	Niedersachsen	NI	Lüchow-Dannenberg
29482	Küsten Saggrian	Niedersachsen	NI	Lüchow-Dannenberg
29482	Küsten Sallahn	Niedersachsen	NI	Lüchow-Dannenberg
29482	Küsten Karmitz	Niedersachsen	NI	Lüchow-Dannenberg
29482	Küsten Tolstefanz	Niedersachsen	NI	Lüchow-Dannenberg
29482	Küsten Tüschau	Niedersachsen	NI	Lüchow-Dannenberg
29482	Küsten Oldemühle	Niedersachsen	NI	Lüchow-Dannenberg
29482	Küsten Klein Witzeetze	Niedersachsen	NI	Lüchow-Dannenberg
29482	Küsten	Niedersachsen	NI	Lüchow-Dannenberg
29484	Langendorf	Niedersachsen	NI	Lüchow-Dannenberg
29485	Lemgow	Niedersachsen	NI	Lüchow-Dannenberg
29487	Luckau	Niedersachsen	NI	Lüchow-Dannenberg
29488	Lübbow	Niedersachsen	NI	Lüchow-Dannenberg
29490	Neu Darchau	Niedersachsen	NI	Lüchow-Dannenberg
29491	Prezelle	Niedersachsen	NI	Lüchow-Dannenberg
29493	Schnackenburg	Niedersachsen	NI	Lüchow-Dannenberg
29494	Trebel	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Maddau	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Waddeweitz	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Kukate	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Kiefen	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Hohenvolkfien	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Salderatzen	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Schlanze	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Kröte	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Dickfeitzen	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Zebelin	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Gohlau	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Marlin	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Klein Gaddau	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Diahren	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Dommatzen	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Wittfeitzen	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Wittfeitzen; Klein Wittfeitzen	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Bischof	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Wittfeitzen; Groß Wittfeitzen	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Sareitz	Niedersachsen	NI	Lüchow-Dannenberg
29496	Waddeweitz Groß Gaddau	Niedersachsen	NI	Lüchow-Dannenberg
29497	Woltersdorf	Niedersachsen	NI	Lüchow-Dannenberg
29499	Zernien	Niedersachsen	NI	Lüchow-Dannenberg
29525	Uelzen	Niedersachsen	NI	Uelzen
29549	Bad Bevensen	Niedersachsen	NI	Uelzen
29553	Bienenbüttel	Niedersachsen	NI	Uelzen
29556	Suderburg	Niedersachsen	NI	Uelzen
29559	Wrestedt	Niedersachsen	NI	Uelzen
29562	Suhlendorf	Niedersachsen	NI	Uelzen
29565	Wriedel	Niedersachsen	NI	Uelzen
29568	Wieren	Niedersachsen	NI	Uelzen
29571	Rosche	Niedersachsen	NI	Uelzen
29574	Ebstorf	Niedersachsen	NI	Uelzen
29575	Altenmedingen	Niedersachsen	NI	Uelzen
29576	Barum	Niedersachsen	NI	Uelzen
29578	Eimke	Niedersachsen	NI	Uelzen
29579	Emmendorf	Niedersachsen	NI	Uelzen
29581	Gerdau	Niedersachsen	NI	Uelzen
29582	Hanstedt I	Niedersachsen	NI	Uelzen
29584	Himbergen	Niedersachsen	NI	Uelzen
29585	Jelmstorf	Niedersachsen	NI	Uelzen
29587	Natendorf	Niedersachsen	NI	Uelzen
29588	Oetzen	Niedersachsen	NI	Uelzen
29590	Rätzlingen	Niedersachsen	NI	Uelzen
29591	Römstedt	Niedersachsen	NI	Uelzen
29593	Schwienau	Niedersachsen	NI	Uelzen
29594	Soltendieck	Niedersachsen	NI	Uelzen
29596	Stadensen	Niedersachsen	NI	Uelzen
29597	Stoetze	Niedersachsen	NI	Uelzen
29599	Weste	Niedersachsen	NI	Uelzen
29614	Soltau	Niedersachsen	NI	Heidekreis
29633	Munster	Niedersachsen	NI	Heidekreis
29640	Schneverdingen	Niedersachsen	NI	Heidekreis
29643	Neuenkirchen	Niedersachsen	NI	Heidekreis
29646	Bispingen	Niedersachsen	NI	Heidekreis
29649	Wietzendorf	Niedersachsen	NI	Heidekreis
29664	Walsrode	Niedersachsen	NI	Heidekreis
29683	Fallingbostel	Niedersachsen	NI	Heidekreis
29690	Buchholz (Aller)	Niedersachsen	NI	Heidekreis
29690	Lindwedel	Niedersachsen	NI	Heidekreis
29690	Grethem	Niedersachsen	NI	Heidekreis
29690	Schwarmstedt	Niedersachsen	NI	Heidekreis
29690	Gilten	Niedersachsen	NI	Heidekreis
29690	Essel	Niedersachsen	NI	Heidekreis
29693	Hodenhagen	Niedersachsen	NI	Heidekreis
29693	Böhme	Niedersachsen	NI	Heidekreis
29693	Ahlden (Aller)	Niedersachsen	NI	Heidekreis
29693	Hademstorf	Niedersachsen	NI	Heidekreis
29693	Eickeloh	Niedersachsen	NI	Heidekreis
29699	Bomlitz	Niedersachsen	NI	Heidekreis
30159	Hannover	Niedersachsen	NI	Region Hannover
30161	Hannover	Niedersachsen	NI	Region Hannover
30163	Hannover	Niedersachsen	NI	Region Hannover
30165	Hannover	Niedersachsen	NI	Region Hannover
30167	Hannover	Niedersachsen	NI	Region Hannover
30169	Hannover	Niedersachsen	NI	Region Hannover
30171	Hannover	Niedersachsen	NI	Region Hannover
30173	Hannover	Niedersachsen	NI	Region Hannover
30175	Hannover	Niedersachsen	NI	Region Hannover
30177	Hannover	Niedersachsen	NI	Region Hannover
30179	Hannover	Niedersachsen	NI	Region Hannover
30419	Hannover	Niedersachsen	NI	Region Hannover
30449	Hannover	Niedersachsen	NI	Region Hannover
30451	Hannover	Niedersachsen	NI	Region Hannover
30453	Hannover	Niedersachsen	NI	Region Hannover
30455	Hannover	Niedersachsen	NI	Region Hannover
30457	Hannover	Niedersachsen	NI	Region Hannover
30459	Hannover	Niedersachsen	NI	Region Hannover
30519	Hannover	Niedersachsen	NI	Region Hannover
30521	Hannover	Niedersachsen	NI	Region Hannover
30539	Hannover	Niedersachsen	NI	Region Hannover
30559	Hannover	Niedersachsen	NI	Region Hannover
30625	Hannover	Niedersachsen	NI	Region Hannover
30627	Hannover	Niedersachsen	NI	Region Hannover
30629	Hannover	Niedersachsen	NI	Region Hannover
30655	Hannover	Niedersachsen	NI	Region Hannover
30657	Hannover	Niedersachsen	NI	Region Hannover
30659	Hannover	Niedersachsen	NI	Region Hannover
30669	Hannover	Niedersachsen	NI	Region Hannover
30823	Garbsen	Niedersachsen	NI	Region Hannover
30826	Garbsen	Niedersachsen	NI	Region Hannover
30827	Garbsen	Niedersachsen	NI	Region Hannover
30851	Langenhagen	Niedersachsen	NI	Region Hannover
30853	Langenhagen	Niedersachsen	NI	Region Hannover
30855	Langenhagen	Niedersachsen	NI	Region Hannover
30880	Laatzen	Niedersachsen	NI	Region Hannover
30890	Barsinghausen	Niedersachsen	NI	Region Hannover
30900	Wedemark	Niedersachsen	NI	Region Hannover
30916	Isernhagen	Niedersachsen	NI	Region Hannover
30926	Seelze	Niedersachsen	NI	Region Hannover
30938	Burgwedel	Niedersachsen	NI	Region Hannover
30952	Ronnenberg	Niedersachsen	NI	Region Hannover
30966	Hemmingen	Niedersachsen	NI	Region Hannover
30974	Wennigsen	Niedersachsen	NI	Region Hannover
30982	Pattensen	Niedersachsen	NI	Region Hannover
30989	Gehrden	Niedersachsen	NI	Region Hannover
31008	Elze	Niedersachsen	NI	Hildesheim
31020	Salzhemmendorf	Niedersachsen	NI	Hameln-Pyrmont
31028	Gronau (Leine)	Niedersachsen	NI	Hildesheim
31029	Banteln	Niedersachsen	NI	Hildesheim
31032	Betheln	Niedersachsen	NI	Hildesheim
31033	Brüggen	Niedersachsen	NI	Hildesheim
31036	Eime	Niedersachsen	NI	Hildesheim
31039	Rheden	Niedersachsen	NI	Hildesheim
31061	Alfeld (Leine)	Niedersachsen	NI	Hildesheim
31073	Delligsen	Niedersachsen	NI	Holzminden
31079	Sibbesse	Niedersachsen	NI	Hildesheim
31079	Eberholzen	Niedersachsen	NI	Hildesheim
31079	Adenstedt	Niedersachsen	NI	Hildesheim
31079	Westfeld	Niedersachsen	NI	Hildesheim
31079	Almstedt	Niedersachsen	NI	Hildesheim
31084	Freden (Leine)	Niedersachsen	NI	Hildesheim
31085	Everode	Niedersachsen	NI	Hildesheim
31088	Winzenburg	Niedersachsen	NI	Hildesheim
31089	Duingen	Niedersachsen	NI	Hildesheim
31091	Coppengrave	Niedersachsen	NI	Hildesheim
31093	Hoyershausen	Niedersachsen	NI	Hildesheim
31094	Marienhagen	Niedersachsen	NI	Hildesheim
31096	Weenzen	Niedersachsen	NI	Hildesheim
31097	Harbarnsen	Niedersachsen	NI	Hildesheim
31099	Woltershausen	Niedersachsen	NI	Hildesheim
31134	Hildesheim	Niedersachsen	NI	Hildesheim
31135	Hildesheim	Niedersachsen	NI	Hildesheim
31137	Hildesheim	Niedersachsen	NI	Hildesheim
31139	Hildesheim	Niedersachsen	NI	Hildesheim
31141	Hildesheim	Niedersachsen	NI	Hildesheim
31157	Sarstedt	Niedersachsen	NI	Hildesheim
31162	Bad Salzdetfurth	Niedersachsen	NI	Hildesheim
31167	Bockenem	Niedersachsen	NI	Hildesheim
31171	Nordstemmen	Niedersachsen	NI	Hildesheim
31174	Schellerten	Niedersachsen	NI	Hildesheim
31177	Harsum	Niedersachsen	NI	Hildesheim
31180	Giesen	Niedersachsen	NI	Hildesheim
31185	Söhlde	Niedersachsen	NI	Hildesheim
31188	Holle	Niedersachsen	NI	Hildesheim
31191	Algermissen	Niedersachsen	NI	Hildesheim
31195	Lamspringe	Niedersachsen	NI	Hildesheim
31195	Neuhof	Niedersachsen	NI	Hildesheim
31196	Sehlem	Niedersachsen	NI	Hildesheim
31199	Diekholzen	Niedersachsen	NI	Hildesheim
31224	Peine	Niedersachsen	NI	Peine
31226	Peine	Niedersachsen	NI	Peine
31228	Peine	Niedersachsen	NI	Peine
31234	Edemissen	Niedersachsen	NI	Peine
31241	Ilsede	Niedersachsen	NI	Peine
31246	Lahstedt	Niedersachsen	NI	Peine
31249	Hohenhameln	Niedersachsen	NI	Peine
31275	Lehrte	Niedersachsen	NI	Region Hannover
31303	Burgdorf	Niedersachsen	NI	Region Hannover
31311	Uetze	Niedersachsen	NI	Region Hannover
31319	Sehnde	Niedersachsen	NI	Region Hannover
31515	Wunstorf	Niedersachsen	NI	Region Hannover
31535	Neustadt am Rübenberge	Niedersachsen	NI	Region Hannover
31542	Bad Nenndorf	Niedersachsen	NI	Schaumburg
31542	Bad Nenndorf Bad Nenndorf	Niedersachsen	NI	Schaumburg
31542	Bad Nenndorf Riepen	Niedersachsen	NI	Schaumburg
31542	Bad Nenndorf Waltringhausen	Niedersachsen	NI	Schaumburg
31542	Bad Nenndorf Horsten	Niedersachsen	NI	Schaumburg
31547	Rehburg-Loccum Winzlar	Niedersachsen	NI	Nienburg/Weser
31547	Rehburg-Loccum Loccum	Niedersachsen	NI	Nienburg/Weser
31547	Rehburg-Loccum Rehburg	Niedersachsen	NI	Nienburg/Weser
31547	Rehburg-Loccum Bad Rehburg	Niedersachsen	NI	Nienburg/Weser
31547	Rehburg-Loccum Münchehagen	Niedersachsen	NI	Nienburg/Weser
31547	Rehburg-Loccum	Niedersachsen	NI	Nienburg/Weser
31552	Rodenberg	Niedersachsen	NI	Schaumburg
31552	Apelern	Niedersachsen	NI	Schaumburg
31552	Apelern Kleinhegesdorf	Niedersachsen	NI	Schaumburg
31552	Rodenberg Algesdorf	Niedersachsen	NI	Schaumburg
31552	Apelern Lyhren	Niedersachsen	NI	Schaumburg
31552	Rodenberg Rodenberg	Niedersachsen	NI	Schaumburg
31552	Apelern Soldorf	Niedersachsen	NI	Schaumburg
31552	Apelern Reinsdorf	Niedersachsen	NI	Schaumburg
31552	Apelern Groß Hegesdorf	Niedersachsen	NI	Schaumburg
31552	Apelern Apelern	Niedersachsen	NI	Schaumburg
31553	Sachsenhagen	Niedersachsen	NI	Schaumburg
31553	Auhagen Düdinghausen	Niedersachsen	NI	Schaumburg
31553	Sachsenhagen Sachsenhagen	Niedersachsen	NI	Schaumburg
46537	Dinslaken	Nordrhein-Westfalen	NW	51
31553	Sachsenhagen Nienbrügge	Niedersachsen	NI	Schaumburg
31553	Auhagen Auhagen	Niedersachsen	NI	Schaumburg
31553	Auhagen	Niedersachsen	NI	Schaumburg
31555	Suthfeld	Niedersachsen	NI	Schaumburg
31555	Suthfeld Helsinghausen	Niedersachsen	NI	Schaumburg
31555	Suthfeld Riehe	Niedersachsen	NI	Schaumburg
31555	Suthfeld Kreuzriehe	Niedersachsen	NI	Schaumburg
31556	Wölpinghausen Wölpinghausen	Niedersachsen	NI	Schaumburg
31556	Wölpinghausen Schmalenbruch-Windhorn	Niedersachsen	NI	Schaumburg
31556	Wölpinghausen	Niedersachsen	NI	Schaumburg
31556	Wölpinghausen Wiedenbrügge	Niedersachsen	NI	Schaumburg
31556	Wölpinghausen Bergkirchen	Niedersachsen	NI	Schaumburg
31558	Hagenburg Hagenburg	Niedersachsen	NI	Schaumburg
31558	Hagenburg	Niedersachsen	NI	Schaumburg
31558	Hagenburg Altenhagen	Niedersachsen	NI	Schaumburg
31559	Hohnhorst Hohnhorst	Niedersachsen	NI	Schaumburg
31559	Haste	Niedersachsen	NI	Schaumburg
31559	Hohnhorst Rehren A.R.	Niedersachsen	NI	Schaumburg
31559	Hohnhorst	Niedersachsen	NI	Schaumburg
31559	Hohnhorst Ohndorf	Niedersachsen	NI	Schaumburg
31582	Nienburg (Weser) Nienburg (Weser)	Niedersachsen	NI	Nienburg/Weser
31582	Nienburg (Weser) Erichshagen	Niedersachsen	NI	Nienburg/Weser
31582	Nienburg (Weser) Langendamm	Niedersachsen	NI	Nienburg/Weser
31582	Nienburg (Weser) Holtorf	Niedersachsen	NI	Nienburg/Weser
31582	Nienburg (Weser)	Niedersachsen	NI	Nienburg/Weser
31592	Stolzenau Nendorf	Niedersachsen	NI	Nienburg/Weser
31592	Stolzenau Holzhausen	Niedersachsen	NI	Nienburg/Weser
31592	Stolzenau Anemolter-Schinna; Schinna	Niedersachsen	NI	Nienburg/Weser
31592	Stolzenau	Niedersachsen	NI	Nienburg/Weser
31592	Stolzenau Anemolter-Schinna	Niedersachsen	NI	Nienburg/Weser
31592	Stolzenau Anemolter-Schinna; Anemolter	Niedersachsen	NI	Nienburg/Weser
31592	Stolzenau Stolzenau	Niedersachsen	NI	Nienburg/Weser
31592	Stolzenau Frestorf	Niedersachsen	NI	Nienburg/Weser
31592	Stolzenau Müsleringen	Niedersachsen	NI	Nienburg/Weser
31592	Stolzenau Diethe	Niedersachsen	NI	Nienburg/Weser
31592	Stolzenau Hibben	Niedersachsen	NI	Nienburg/Weser
31595	Steyerberg Düdinghausen	Niedersachsen	NI	Nienburg/Weser
31595	Steyerberg Voigtei	Niedersachsen	NI	Nienburg/Weser
31595	Steyerberg Deblinghausen	Niedersachsen	NI	Nienburg/Weser
31595	Steyerberg Wellie	Niedersachsen	NI	Nienburg/Weser
31595	Steyerberg Steyerberg	Niedersachsen	NI	Nienburg/Weser
31595	Steyerberg	Niedersachsen	NI	Nienburg/Weser
31600	Uchte	Niedersachsen	NI	Nienburg/Weser
31603	Diepenau	Niedersachsen	NI	Nienburg/Weser
31604	Raddestorf	Niedersachsen	NI	Nienburg/Weser
31606	Warmsen	Niedersachsen	NI	Nienburg/Weser
31608	Marklohe	Niedersachsen	NI	Nienburg/Weser
31609	Balge	Niedersachsen	NI	Nienburg/Weser
31613	Wietzen	Niedersachsen	NI	Nienburg/Weser
31618	Liebenau	Niedersachsen	NI	Nienburg/Weser
31619	Binnen	Niedersachsen	NI	Nienburg/Weser
31621	Pennigsehl	Niedersachsen	NI	Nienburg/Weser
31622	Heemsen Anderten	Niedersachsen	NI	Nienburg/Weser
31622	Heemsen Lichtenmoor	Niedersachsen	NI	Nienburg/Weser
31622	Heemsen	Niedersachsen	NI	Nienburg/Weser
31622	Heemsen Gadesbünden	Niedersachsen	NI	Nienburg/Weser
31622	Heemsen Heemsen	Niedersachsen	NI	Nienburg/Weser
31623	Drakenburg	Niedersachsen	NI	Nienburg/Weser
31626	Haßbergen	Niedersachsen	NI	Nienburg/Weser
31627	Rohrsen	Niedersachsen	NI	Nienburg/Weser
31628	Landesbergen Brokeloh	Niedersachsen	NI	Nienburg/Weser
31628	Landesbergen Landesbergen	Niedersachsen	NI	Nienburg/Weser
31628	Landesbergen	Niedersachsen	NI	Nienburg/Weser
31628	Landesbergen Heidhausen	Niedersachsen	NI	Nienburg/Weser
31628	Landesbergen Hahnenberg	Niedersachsen	NI	Nienburg/Weser
31629	Estorf Leeseringen	Niedersachsen	NI	Nienburg/Weser
31629	Estorf	Niedersachsen	NI	Nienburg/Weser
31629	Estorf Estorf	Niedersachsen	NI	Nienburg/Weser
31632	Husum	Niedersachsen	NI	Nienburg/Weser
31633	Leese	Niedersachsen	NI	Nienburg/Weser
31634	Steimbke Steimbke	Niedersachsen	NI	Nienburg/Weser
31634	Steimbke	Niedersachsen	NI	Nienburg/Weser
31634	Steimbke Wendenborstel	Niedersachsen	NI	Nienburg/Weser
31634	Steimbke Lichtenhorst	Niedersachsen	NI	Nienburg/Weser
31634	Steimbke Wenden	Niedersachsen	NI	Nienburg/Weser
31636	Linsburg	Niedersachsen	NI	Nienburg/Weser
31637	Rodewald	Niedersachsen	NI	Nienburg/Weser
31638	Stöckse	Niedersachsen	NI	Nienburg/Weser
31655	Stadthagen	Niedersachsen	NI	Schaumburg
31655	Stadthagen Habichhorst-Blyinghausen	Niedersachsen	NI	Schaumburg
31655	Stadthagen Reinsen-Remeringhausen	Niedersachsen	NI	Schaumburg
31655	Stadthagen Hörkamp-Langenbruch	Niedersachsen	NI	Schaumburg
31655	Stadthagen Enzen	Niedersachsen	NI	Schaumburg
31655	Stadthagen Wendthagen-Ehlen	Niedersachsen	NI	Schaumburg
31655	Stadthagen Stadthagen	Niedersachsen	NI	Schaumburg
31655	Stadthagen Habichhorst-Blyinghausen; Habichhorst	Niedersachsen	NI	Schaumburg
31655	Stadthagen Habichhorst-Blyinghausen; Blyinghausen	Niedersachsen	NI	Schaumburg
31655	Stadthagen Obernwöhren	Niedersachsen	NI	Schaumburg
31655	Stadthagen Probsthagen	Niedersachsen	NI	Schaumburg
31655	Stadthagen Hobbensen	Niedersachsen	NI	Schaumburg
31655	Stadthagen Krebshagen	Niedersachsen	NI	Schaumburg
31675	Bückeburg Achum	Niedersachsen	NI	Schaumburg
31675	Bückeburg Bergdorf	Niedersachsen	NI	Schaumburg
31675	Bückeburg Warber	Niedersachsen	NI	Schaumburg
31675	Bückeburg Cammer	Niedersachsen	NI	Schaumburg
31675	Bückeburg Bückeburg	Niedersachsen	NI	Schaumburg
31675	Bückeburg Evesen	Niedersachsen	NI	Schaumburg
31675	Bückeburg Rusbend	Niedersachsen	NI	Schaumburg
31675	Bückeburg Scheie	Niedersachsen	NI	Schaumburg
31675	Bückeburg Meinsen	Niedersachsen	NI	Schaumburg
31675	Bückeburg Müsingen	Niedersachsen	NI	Schaumburg
31675	Bückeburg	Niedersachsen	NI	Schaumburg
31683	Obernkirchen	Niedersachsen	NI	Schaumburg
31683	Obernkirchen Obernkirchen	Niedersachsen	NI	Schaumburg
31683	Obernkirchen Krainhagen	Niedersachsen	NI	Schaumburg
31683	Obernkirchen Röhrkasten	Niedersachsen	NI	Schaumburg
31683	Obernkirchen Vehlen	Niedersachsen	NI	Schaumburg
31683	Obernkirchen Gelldorf	Niedersachsen	NI	Schaumburg
31688	Nienstädt Liekwegen	Niedersachsen	NI	Schaumburg
31688	Nienstädt	Niedersachsen	NI	Schaumburg
31688	Nienstädt Nienstädt	Niedersachsen	NI	Schaumburg
31691	Helpsen Südhorsten	Niedersachsen	NI	Schaumburg
31691	Helpsen Kirchhorsten	Niedersachsen	NI	Schaumburg
31691	Seggebruch Tallensen-Echtorf	Niedersachsen	NI	Schaumburg
31691	Helpsen Helpsen	Niedersachsen	NI	Schaumburg
31691	Helpsen	Niedersachsen	NI	Schaumburg
31691	Seggebruch Schierneichen-Deinsen	Niedersachsen	NI	Schaumburg
31691	Seggebruch	Niedersachsen	NI	Schaumburg
31691	Seggebruch Seggebruch	Niedersachsen	NI	Schaumburg
31693	Hespe Hespe-Hiddensen	Niedersachsen	NI	Schaumburg
31693	Hespe Stemmen	Niedersachsen	NI	Schaumburg
31693	Hespe	Niedersachsen	NI	Schaumburg
31693	Hespe Levesen	Niedersachsen	NI	Schaumburg
31698	Lindhorst Lindhorst	Niedersachsen	NI	Schaumburg
31698	Lindhorst Schöttlingen	Niedersachsen	NI	Schaumburg
31698	Lindhorst	Niedersachsen	NI	Schaumburg
31698	Lindhorst Ottensen	Niedersachsen	NI	Schaumburg
31699	Beckedorf	Niedersachsen	NI	Schaumburg
31700	Heuerßen Heuerßen	Niedersachsen	NI	Schaumburg
31700	Heuerßen	Niedersachsen	NI	Schaumburg
31700	Heuerßen Kobbensen	Niedersachsen	NI	Schaumburg
31702	Lüdersfeld Vornhagen	Niedersachsen	NI	Schaumburg
31702	Lüdersfeld Lüdersfeld	Niedersachsen	NI	Schaumburg
31702	Lüdersfeld	Niedersachsen	NI	Schaumburg
31707	Bad Eilsen	Niedersachsen	NI	Schaumburg
31707	Heeßen	Niedersachsen	NI	Schaumburg
31708	Ahnsen	Niedersachsen	NI	Schaumburg
31710	Buchholz	Niedersachsen	NI	Schaumburg
31711	Luhden Schermbeck	Niedersachsen	NI	Schaumburg
31711	Luhden Luhden	Niedersachsen	NI	Schaumburg
31711	Luhden	Niedersachsen	NI	Schaumburg
31712	Niedernwöhren	Niedersachsen	NI	Schaumburg
31714	Lauenhagen	Niedersachsen	NI	Schaumburg
31714	Lauenhagen Lauenhagen	Niedersachsen	NI	Schaumburg
31714	Lauenhagen Hülshagen	Niedersachsen	NI	Schaumburg
31715	Meerbeck Kuckshagen	Niedersachsen	NI	Schaumburg
31715	Meerbeck Meerbeck	Niedersachsen	NI	Schaumburg
31715	Meerbeck	Niedersachsen	NI	Schaumburg
31715	Meerbeck Volksdorf	Niedersachsen	NI	Schaumburg
31717	Nordsehl	Niedersachsen	NI	Schaumburg
31718	Pollhagen	Niedersachsen	NI	Schaumburg
31719	Wiedensahl	Niedersachsen	NI	Schaumburg
31737	Rinteln	Niedersachsen	NI	Schaumburg
31737	Rinteln Deckbergen	Niedersachsen	NI	Schaumburg
31737	Rinteln Kohlenstädt	Niedersachsen	NI	Schaumburg
31737	Rinteln Friedrichswald	Niedersachsen	NI	Schaumburg
31737	Rinteln Hohenrode	Niedersachsen	NI	Schaumburg
31737	Rinteln Krankenhagen	Niedersachsen	NI	Schaumburg
31737	Rinteln Möllenbeck	Niedersachsen	NI	Schaumburg
31737	Rinteln Strücken	Niedersachsen	NI	Schaumburg
31737	Rinteln Steinbergen	Niedersachsen	NI	Schaumburg
31737	Rinteln Goldbeck	Niedersachsen	NI	Schaumburg
31737	Rinteln Rinteln	Niedersachsen	NI	Schaumburg
31737	Rinteln Volksen	Niedersachsen	NI	Schaumburg
31737	Rinteln Wennenkamp	Niedersachsen	NI	Schaumburg
31737	Rinteln Schaumburg	Niedersachsen	NI	Schaumburg
31737	Rinteln Ahe	Niedersachsen	NI	Schaumburg
31737	Rinteln Westendorf	Niedersachsen	NI	Schaumburg
31737	Rinteln Engern	Niedersachsen	NI	Schaumburg
31737	Rinteln Uchtorf	Niedersachsen	NI	Schaumburg
31737	Rinteln Todenmann	Niedersachsen	NI	Schaumburg
31737	Rinteln Exten	Niedersachsen	NI	Schaumburg
31749	Auetal Escher	Niedersachsen	NI	Schaumburg
31749	Auetal Wiersen	Niedersachsen	NI	Schaumburg
31749	Auetal	Niedersachsen	NI	Schaumburg
31749	Auetal Rehren A.O.	Niedersachsen	NI	Schaumburg
31749	Auetal Altenhagen	Niedersachsen	NI	Schaumburg
31749	Auetal Poggenhagen	Niedersachsen	NI	Schaumburg
31749	Auetal Kathrinhagen	Niedersachsen	NI	Schaumburg
31749	Auetal Borstel	Niedersachsen	NI	Schaumburg
31749	Auetal Antendorf	Niedersachsen	NI	Schaumburg
31749	Auetal Rannenberg	Niedersachsen	NI	Schaumburg
31749	Auetal Bernsen	Niedersachsen	NI	Schaumburg
31749	Auetal Rolfshagen	Niedersachsen	NI	Schaumburg
31749	Auetal Schoholtensen	Niedersachsen	NI	Schaumburg
31749	Auetal Raden	Niedersachsen	NI	Schaumburg
31749	Auetal Westerwald	Niedersachsen	NI	Schaumburg
31749	Auetal Klein Holtensen	Niedersachsen	NI	Schaumburg
31749	Auetal Hattendorf	Niedersachsen	NI	Schaumburg
31785	Hameln	Niedersachsen	NI	Hameln-Pyrmont
31787	Hameln	Niedersachsen	NI	Hameln-Pyrmont
31789	Hameln	Niedersachsen	NI	Hameln-Pyrmont
31812	Bad Pyrmont	Niedersachsen	NI	Hameln-Pyrmont
31832	Springe	Niedersachsen	NI	Region Hannover
31840	Hessisch Oldendorf	Niedersachsen	NI	Hameln-Pyrmont
31848	Bad Münder am Deister	Niedersachsen	NI	Hameln-Pyrmont
31855	Aerzen	Niedersachsen	NI	Hameln-Pyrmont
31860	Emmerthal	Niedersachsen	NI	Hameln-Pyrmont
31863	Coppenbrügge	Niedersachsen	NI	Hameln-Pyrmont
31867	Hülsede	Niedersachsen	NI	Schaumburg
31867	Pohle	Niedersachsen	NI	Schaumburg
31867	Hülsede Schmarrie	Niedersachsen	NI	Schaumburg
31867	Lauenau	Niedersachsen	NI	Schaumburg
31867	Hülsede Meinsen	Niedersachsen	NI	Schaumburg
31867	Lauenau Lauenau	Niedersachsen	NI	Schaumburg
31867	Messenkamp Altenhagen II	Niedersachsen	NI	Schaumburg
31867	Messenkamp Messenkamp	Niedersachsen	NI	Schaumburg
31867	Hülsede Hülsede	Niedersachsen	NI	Schaumburg
31867	Lauenau Feggendorf	Niedersachsen	NI	Schaumburg
31867	Messenkamp	Niedersachsen	NI	Schaumburg
31868	Ottenstein	Niedersachsen	NI	Holzminden
34346	Hannoversch Münden	Niedersachsen	NI	Göttingen
34355	Staufenberg	Niedersachsen	NI	Göttingen
37073	Göttingen	Niedersachsen	NI	Göttingen
37075	Göttingen	Niedersachsen	NI	Göttingen
37077	Göttingen	Niedersachsen	NI	Göttingen
37079	Göttingen	Niedersachsen	NI	Göttingen
37081	Göttingen	Niedersachsen	NI	Göttingen
37083	Göttingen	Niedersachsen	NI	Göttingen
37085	Göttingen	Niedersachsen	NI	Göttingen
37115	Duderstadt	Niedersachsen	NI	Göttingen
37120	Bovenden	Niedersachsen	NI	Göttingen
37124	Rosdorf	Niedersachsen	NI	Göttingen
37127	Bühren	Niedersachsen	NI	Göttingen
37127	Jühnde	Niedersachsen	NI	Göttingen
37127	Dransfeld	Niedersachsen	NI	Göttingen
37127	Niemetal	Niedersachsen	NI	Göttingen
37127	Scheden	Niedersachsen	NI	Göttingen
37130	Gleichen	Niedersachsen	NI	Göttingen
37133	Friedland	Niedersachsen	NI	Göttingen
37136	Seulingen	Niedersachsen	NI	Göttingen
37136	Ebergötzen	Niedersachsen	NI	Göttingen
37136	Waake	Niedersachsen	NI	Göttingen
37136	Seeburg	Niedersachsen	NI	Göttingen
37136	Landolfshausen	Niedersachsen	NI	Göttingen
37139	Adelebsen	Niedersachsen	NI	Göttingen
37154	Northeim	Niedersachsen	NI	Northeim
37170	Uslar	Niedersachsen	NI	Northeim
37176	Nörten-Hardenberg	Niedersachsen	NI	Northeim
37181	Hardegsen	Niedersachsen	NI	Northeim
37186	Moringen	Niedersachsen	NI	Northeim
37191	Katlenburg-Lindau	Niedersachsen	NI	Northeim
37194	Wahlsburg	Niedersachsen	NI	Northeim
37194	Bodenfelde	Niedersachsen	NI	Northeim
37197	Hattorf am Harz	Niedersachsen	NI	Göttingen
37199	Wulften	Niedersachsen	NI	Göttingen
37412	Hörden	Niedersachsen	NI	Göttingen
37412	Elbingerode	Niedersachsen	NI	Göttingen
37412	Herzberg am Harz	Niedersachsen	NI	Göttingen
37431	Bad Lauterberg im Harz	Niedersachsen	NI	Göttingen
37434	Krebeck	Niedersachsen	NI	Göttingen
37434	Gieboldehausen	Niedersachsen	NI	Göttingen
37434	Wollbrandshausen	Niedersachsen	NI	Göttingen
37434	Bodensee	Niedersachsen	NI	Göttingen
37434	Obernfeld	Niedersachsen	NI	Göttingen
37434	Wollershausen	Niedersachsen	NI	Göttingen
37434	Bilshausen	Niedersachsen	NI	Göttingen
37434	Rüdershausen	Niedersachsen	NI	Göttingen
37434	Rhumspringe	Niedersachsen	NI	Göttingen
37434	Rollshausen	Niedersachsen	NI	Göttingen
37441	Bad Sachsa	Niedersachsen	NI	Göttingen
37444	Sankt Andreasberg	Niedersachsen	NI	Goslar
37445	Walkenried	Niedersachsen	NI	Göttingen
37447	Wieda	Niedersachsen	NI	Göttingen
37449	Zorge	Niedersachsen	NI	Göttingen
37520	Osterode am Harz	Niedersachsen	NI	Göttingen
37534	Eisdorf	Niedersachsen	NI	Göttingen
37534	Gittelde	Niedersachsen	NI	Göttingen
37534	Badenhausen	Niedersachsen	NI	Göttingen
37539	Bad Grund (Harz)	Niedersachsen	NI	Göttingen
37539	Windhausen	Niedersachsen	NI	Göttingen
37547	Kreiensen	Niedersachsen	NI	Northeim
37574	Einbeck	Niedersachsen	NI	Northeim
37581	Bad Gandersheim	Niedersachsen	NI	Northeim
37586	Dassel	Niedersachsen	NI	Northeim
37589	Kalefeld	Niedersachsen	NI	Northeim
37603	Holzminden	Niedersachsen	NI	Holzminden
37619	Bodenwerder	Niedersachsen	NI	Holzminden
37619	Kirchbrak	Niedersachsen	NI	Holzminden
37619	Heyen	Niedersachsen	NI	Holzminden
37619	Hehlen	Niedersachsen	NI	Holzminden
37619	Pegestorf	Niedersachsen	NI	Holzminden
37620	Halle	Niedersachsen	NI	Holzminden
37627	Stadtoldendorf	Niedersachsen	NI	Holzminden
37627	Wangelnstedt	Niedersachsen	NI	Holzminden
37627	Heinade	Niedersachsen	NI	Holzminden
37627	Arholzen	Niedersachsen	NI	Holzminden
37627	Deensen	Niedersachsen	NI	Holzminden
37627	Lenne	Niedersachsen	NI	Holzminden
37632	Holzen	Niedersachsen	NI	Holzminden
37632	Eimen	Niedersachsen	NI	Holzminden
37632	Eschershausen	Niedersachsen	NI	Holzminden
37633	Dielmissen	Niedersachsen	NI	Holzminden
37635	Lüerdissen	Niedersachsen	NI	Holzminden
37639	Bevern	Niedersachsen	NI	Holzminden
37640	Golmbach	Niedersachsen	NI	Holzminden
37642	Holenberg	Niedersachsen	NI	Holzminden
37643	Negenborn	Niedersachsen	NI	Holzminden
37647	Polle	Niedersachsen	NI	Holzminden
37647	Vahlbruch	Niedersachsen	NI	Holzminden
37647	Brevörde	Niedersachsen	NI	Holzminden
37649	Heinsen	Niedersachsen	NI	Holzminden
37691	Boffzen	Niedersachsen	NI	Holzminden
37691	Derental	Niedersachsen	NI	Holzminden
37697	Lauenförde	Niedersachsen	NI	Holzminden
37699	Fürstenberg	Niedersachsen	NI	Holzminden
38023	Braunschweig	Niedersachsen	NI	Braunschweig
38100	Braunschweig	Niedersachsen	NI	Braunschweig
38102	Braunschweig	Niedersachsen	NI	Braunschweig
38104	Braunschweig	Niedersachsen	NI	Braunschweig
38106	Braunschweig	Niedersachsen	NI	Braunschweig
38108	Braunschweig	Niedersachsen	NI	Braunschweig
38110	Braunschweig	Niedersachsen	NI	Braunschweig
38112	Braunschweig	Niedersachsen	NI	Braunschweig
38114	Braunschweig	Niedersachsen	NI	Braunschweig
38116	Braunschweig	Niedersachsen	NI	Braunschweig
38118	Braunschweig	Niedersachsen	NI	Braunschweig
38120	Braunschweig	Niedersachsen	NI	Braunschweig
38122	Braunschweig	Niedersachsen	NI	Braunschweig
38124	Braunschweig	Niedersachsen	NI	Braunschweig
38126	Braunschweig	Niedersachsen	NI	Braunschweig
38154	Königslutter am Elm	Niedersachsen	NI	Helmstedt
38159	Vechelde	Niedersachsen	NI	Peine
38162	Cremlingen	Niedersachsen	NI	Wolfenbüttel
38165	Lehre	Niedersachsen	NI	Helmstedt
38170	Dahlum	Niedersachsen	NI	Wolfenbüttel
38170	Kneitlingen	Niedersachsen	NI	Wolfenbüttel
38170	Schöppenstedt	Niedersachsen	NI	Wolfenbüttel
38170	Vahlberg	Niedersachsen	NI	Wolfenbüttel
38170	Uehrde	Niedersachsen	NI	Wolfenbüttel
38170	Winnigstedt	Niedersachsen	NI	Wolfenbüttel
38173	Veltheim	Niedersachsen	NI	Wolfenbüttel
38173	Sickte	Niedersachsen	NI	Wolfenbüttel
38173	Dettum	Niedersachsen	NI	Wolfenbüttel
38173	Erkerode	Niedersachsen	NI	Wolfenbüttel
38173	Evessen	Niedersachsen	NI	Wolfenbüttel
38176	Wendeburg	Niedersachsen	NI	Peine
38179	Schwülper	Niedersachsen	NI	Gifhorn
38226	Salzgitter Lebenstedt	Niedersachsen	NI	Salzgitter; Stadt
38226	Salzgitter	Niedersachsen	NI	Salzgitter; Stadt
38228	Salzgitter	Niedersachsen	NI	Salzgitter; Stadt
38228	Salzgitter Lesse	Niedersachsen	NI	Salzgitter; Stadt
38228	Salzgitter Osterlinde	Niedersachsen	NI	Salzgitter; Stadt
38228	Salzgitter Lebenstedt	Niedersachsen	NI	Salzgitter; Stadt
38228	Salzgitter Bruchmachtersen	Niedersachsen	NI	Salzgitter; Stadt
38228	Salzgitter Lichtenberg	Niedersachsen	NI	Salzgitter; Stadt
38228	Salzgitter Reppner	Niedersachsen	NI	Salzgitter; Stadt
38229	Salzgitter Lebenstedt	Niedersachsen	NI	Salzgitter; Stadt
38229	Salzgitter Calbecht	Niedersachsen	NI	Salzgitter; Stadt
38229	Salzgitter Heerte	Niedersachsen	NI	Salzgitter; Stadt
38229	Salzgitter Engenrode	Niedersachsen	NI	Salzgitter; Stadt
38229	Salzgitter Engelnstedt	Niedersachsen	NI	Salzgitter; Stadt
38229	Salzgitter Barum	Niedersachsen	NI	Salzgitter; Stadt
38229	Salzgitter Gebhardshagen	Niedersachsen	NI	Salzgitter; Stadt
38229	Salzgitter	Niedersachsen	NI	Salzgitter; Stadt
38229	Salzgitter Hallendorf	Niedersachsen	NI	Salzgitter; Stadt
38229	Salzgitter Salder	Niedersachsen	NI	Salzgitter; Stadt
38239	Salzgitter	Niedersachsen	NI	Salzgitter; Stadt
38239	Salzgitter Thiede	Niedersachsen	NI	Salzgitter; Stadt
38239	Salzgitter Bleckenstedt	Niedersachsen	NI	Salzgitter; Stadt
38239	Salzgitter Sauingen	Niedersachsen	NI	Salzgitter; Stadt
38239	Salzgitter Drütte	Niedersachsen	NI	Salzgitter; Stadt
38239	Salzgitter Beddingen	Niedersachsen	NI	Salzgitter; Stadt
38239	Salzgitter Immendorf	Niedersachsen	NI	Salzgitter; Stadt
38239	Salzgitter Watenstedt	Niedersachsen	NI	Salzgitter; Stadt
38239	Salzgitter Üfingen	Niedersachsen	NI	Salzgitter; Stadt
38259	Salzgitter	Niedersachsen	NI	Salzgitter; Stadt
38259	Salzgitter Ringelheim	Niedersachsen	NI	Salzgitter; Stadt
38259	Salzgitter Flachstöckheim	Niedersachsen	NI	Salzgitter; Stadt
38259	Salzgitter Ohlendorf	Niedersachsen	NI	Salzgitter; Stadt
38259	Salzgitter Hohenrode	Niedersachsen	NI	Salzgitter; Stadt
38259	Salzgitter Bad	Niedersachsen	NI	Salzgitter; Stadt
38259	Salzgitter Lobmachtersen	Niedersachsen	NI	Salzgitter; Stadt
38259	Salzgitter Gitter	Niedersachsen	NI	Salzgitter; Stadt
38259	Salzgitter Beinum	Niedersachsen	NI	Salzgitter; Stadt
38259	Salzgitter Groß Mahner	Niedersachsen	NI	Salzgitter; Stadt
38268	Lengede	Niedersachsen	NI	Peine
38271	Baddeckenstedt	Niedersachsen	NI	Wolfenbüttel
38272	Burgdorf	Niedersachsen	NI	Wolfenbüttel
38274	Elbe	Niedersachsen	NI	Wolfenbüttel
38275	Haverlah	Niedersachsen	NI	Wolfenbüttel
38277	Heere	Niedersachsen	NI	Wolfenbüttel
38279	Sehlde	Niedersachsen	NI	Wolfenbüttel
38281	Wolfenbüttel	Niedersachsen	NI	Wolfenbüttel
38300	Wolfenbüttel	Niedersachsen	NI	Wolfenbüttel
38302	Wolfenbüttel	Niedersachsen	NI	Wolfenbüttel
38304	Wolfenbüttel	Niedersachsen	NI	Wolfenbüttel
38312	Dorstadt	Niedersachsen	NI	Wolfenbüttel
38312	Flöthe	Niedersachsen	NI	Wolfenbüttel
38312	Heiningen	Niedersachsen	NI	Wolfenbüttel
38312	Cramme	Niedersachsen	NI	Wolfenbüttel
38312	Ohrum	Niedersachsen	NI	Wolfenbüttel
38312	Achim	Niedersachsen	NI	Wolfenbüttel
38312	Börßum	Niedersachsen	NI	Wolfenbüttel
38315	Schladen	Niedersachsen	NI	Wolfenbüttel
38315	Werlaburgdorf	Niedersachsen	NI	Wolfenbüttel
38315	Gielde	Niedersachsen	NI	Wolfenbüttel
38315	Hornburg	Niedersachsen	NI	Wolfenbüttel
38319	Remlingen	Niedersachsen	NI	Wolfenbüttel
38321	Denkte	Niedersachsen	NI	Wolfenbüttel
38322	Hedeper	Niedersachsen	NI	Wolfenbüttel
38324	Kissenbrück	Niedersachsen	NI	Wolfenbüttel
38325	Roklum	Niedersachsen	NI	Wolfenbüttel
38327	Semmenstedt	Niedersachsen	NI	Wolfenbüttel
38329	Wittmar	Niedersachsen	NI	Wolfenbüttel
38350	Helmstedt	Niedersachsen	NI	Helmstedt
38364	Schöningen	Niedersachsen	NI	Helmstedt
38368	Mariental	Niedersachsen	NI	Helmstedt
38368	Querenhorst	Niedersachsen	NI	Helmstedt
38368	Grasleben	Niedersachsen	NI	Helmstedt
38368	Rennau	Niedersachsen	NI	Helmstedt
38372	Büddenstedt	Niedersachsen	NI	Helmstedt
38373	Frellstedt	Niedersachsen	NI	Helmstedt
38373	Süpplingen	Niedersachsen	NI	Helmstedt
38375	Räbke	Niedersachsen	NI	Helmstedt
38376	Süpplingenburg	Niedersachsen	NI	Helmstedt
38378	Warberg	Niedersachsen	NI	Helmstedt
38379	Wolsdorf	Niedersachsen	NI	Helmstedt
38381	Jerxheim	Niedersachsen	NI	Helmstedt
38382	Beierstedt	Niedersachsen	NI	Helmstedt
38384	Gevensleben	Niedersachsen	NI	Helmstedt
38385	Ingeleben	Niedersachsen	NI	Helmstedt
38387	Söllingen	Niedersachsen	NI	Helmstedt
38388	Twieflingen	Niedersachsen	NI	Helmstedt
38440	Wolfsburg	Niedersachsen	NI	Wolfsburg; Stadt
38442	Wolfsburg	Niedersachsen	NI	Wolfsburg; Stadt
38444	Wolfsburg	Niedersachsen	NI	Wolfsburg; Stadt
38446	Wolfsburg	Niedersachsen	NI	Wolfsburg; Stadt
38448	Wolfsburg	Niedersachsen	NI	Wolfsburg; Stadt
38458	Velpke	Niedersachsen	NI	Helmstedt
38459	Bahrdorf	Niedersachsen	NI	Helmstedt
38461	Danndorf	Niedersachsen	NI	Helmstedt
38462	Grafhorst	Niedersachsen	NI	Helmstedt
38464	Groß Twülpstedt	Niedersachsen	NI	Helmstedt
38465	Brome	Niedersachsen	NI	Gifhorn
38467	Bergfeld	Niedersachsen	NI	Gifhorn
38468	Ehra-Lessien	Niedersachsen	NI	Gifhorn
38470	Parsau	Niedersachsen	NI	Gifhorn
38471	Rühen	Niedersachsen	NI	Gifhorn
38473	Tiddische	Niedersachsen	NI	Gifhorn
38474	Tülau	Niedersachsen	NI	Gifhorn
38476	Barwedel	Niedersachsen	NI	Gifhorn
38477	Jembke	Niedersachsen	NI	Gifhorn
38479	Tappenbeck	Niedersachsen	NI	Gifhorn
38518	Gifhorn	Niedersachsen	NI	Gifhorn
38524	Sassenburg	Niedersachsen	NI	Gifhorn
38527	Meine	Niedersachsen	NI	Gifhorn
38528	Adenbüttel	Niedersachsen	NI	Gifhorn
38530	Didderse	Niedersachsen	NI	Gifhorn
38531	Rötgesbüttel	Niedersachsen	NI	Gifhorn
38533	Vordorf	Niedersachsen	NI	Gifhorn
38536	Meinersen	Niedersachsen	NI	Gifhorn
38539	Müden (Aller)	Niedersachsen	NI	Gifhorn
38542	Leiferde	Niedersachsen	NI	Gifhorn
38543	Hillerse	Niedersachsen	NI	Gifhorn
38547	Calberlah	Niedersachsen	NI	Gifhorn
38550	Isenbüttel	Niedersachsen	NI	Gifhorn
38551	Ribbesbüttel	Niedersachsen	NI	Gifhorn
38553	Wasbüttel	Niedersachsen	NI	Gifhorn
38554	Weyhausen	Niedersachsen	NI	Gifhorn
38556	Bokensdorf	Niedersachsen	NI	Gifhorn
38557	Osloß	Niedersachsen	NI	Gifhorn
38559	Wagenhoff	Niedersachsen	NI	Gifhorn
38640	Goslar	Niedersachsen	NI	Goslar
38640	Goslar Goslar	Niedersachsen	NI	Goslar
38642	Goslar	Niedersachsen	NI	Goslar
38642	Goslar Goslar	Niedersachsen	NI	Goslar
38642	Goslar Oker	Niedersachsen	NI	Goslar
38644	Goslar Hahndorf	Niedersachsen	NI	Goslar
38644	Goslar Hahnenklee-Bockswiese	Niedersachsen	NI	Goslar
38644	Goslar	Niedersachsen	NI	Goslar
38644	Goslar Jerstedt	Niedersachsen	NI	Goslar
38667	Bad Harzburg Eckertal	Niedersachsen	NI	Goslar
38667	Bad Harzburg	Niedersachsen	NI	Goslar
38667	Bad Harzburg Bettingerode	Niedersachsen	NI	Goslar
38667	Bad Harzburg Bad Harzburg	Niedersachsen	NI	Goslar
38667	Bad Harzburg Göttingerode	Niedersachsen	NI	Goslar
38667	Bad Harzburg Westerode	Niedersachsen	NI	Goslar
38667	Bad Harzburg Harlingerode	Niedersachsen	NI	Goslar
38667	Bad Harzburg Bündheim/Schlewecke; Bündheim	Niedersachsen	NI	Goslar
38667	Bad Harzburg Bündheim/Schlewecke	Niedersachsen	NI	Goslar
38667	Bad Harzburg Bündheim/Schlewecke; Schlewecke	Niedersachsen	NI	Goslar
38678	Clausthal-Zellerfeld	Niedersachsen	NI	Goslar
38685	Langelsheim	Niedersachsen	NI	Goslar
38690	Vienenburg	Niedersachsen	NI	Goslar
38700	Braunlage	Niedersachsen	NI	Goslar
38704	Liebenburg	Niedersachsen	NI	Goslar
38707	Altenau	Niedersachsen	NI	Goslar
38707	Schulenberg im Oberharz	Niedersachsen	NI	Goslar
38709	Wildemann	Niedersachsen	NI	Goslar
38723	Seesen	Niedersachsen	NI	Goslar
38729	Lutter am Barenberge	Niedersachsen	NI	Goslar
38729	Hahausen	Niedersachsen	NI	Goslar
38729	Wallmoden	Niedersachsen	NI	Goslar
48455	Bad Bentheim	Niedersachsen	NI	Grafschaft Bentheim
48465	Ohne	Niedersachsen	NI	Grafschaft Bentheim
48465	Samern	Niedersachsen	NI	Grafschaft Bentheim
48465	Quendorf	Niedersachsen	NI	Grafschaft Bentheim
48465	Isterberg	Niedersachsen	NI	Grafschaft Bentheim
48465	Suddendorf	Niedersachsen	NI	Grafschaft Bentheim
48465	Schüttorf	Niedersachsen	NI	Grafschaft Bentheim
48465	Engden	Niedersachsen	NI	Grafschaft Bentheim
48480	Schapen	Niedersachsen	NI	Emsland
48480	Lünne	Niedersachsen	NI	Emsland
48480	Spelle	Niedersachsen	NI	Emsland
48488	Emsbüren	Niedersachsen	NI	Emsland
48499	Salzbergen	Niedersachsen	NI	Emsland
48527	Nordhorn	Niedersachsen	NI	Grafschaft Bentheim
48529	Nordhorn	Niedersachsen	NI	Grafschaft Bentheim
48531	Nordhorn	Niedersachsen	NI	Grafschaft Bentheim
49074	Osnabrück	Niedersachsen	NI	Osnabrück; Stadt
49076	Osnabrück	Niedersachsen	NI	Osnabrück; Stadt
49078	Osnabrück	Niedersachsen	NI	Osnabrück; Stadt
49080	Osnabrück	Niedersachsen	NI	Osnabrück; Stadt
49082	Osnabrück	Niedersachsen	NI	Osnabrück; Stadt
49084	Osnabrück	Niedersachsen	NI	Osnabrück; Stadt
49086	Osnabrück	Niedersachsen	NI	Osnabrück; Stadt
49088	Osnabrück	Niedersachsen	NI	Osnabrück; Stadt
49090	Osnabrück	Niedersachsen	NI	Osnabrück; Stadt
49124	Georgsmarienhütte	Niedersachsen	NI	Osnabrück
49134	Wallenhorst	Niedersachsen	NI	Osnabrück
49143	Bissendorf	Niedersachsen	NI	Osnabrück
49152	Bad Essen	Niedersachsen	NI	Osnabrück
49163	Bohmte	Niedersachsen	NI	Osnabrück
49170	Hagen am Teutoburger Wald	Niedersachsen	NI	Osnabrück
49176	Hilter am Teutoburger Wald	Niedersachsen	NI	Osnabrück
49179	Ostercappeln	Niedersachsen	NI	Osnabrück
49186	Bad Iburg	Niedersachsen	NI	Osnabrück
49191	Belm	Niedersachsen	NI	Osnabrück
49196	Bad Laer	Niedersachsen	NI	Osnabrück
49201	Dissen am Teutoburger Wald	Niedersachsen	NI	Osnabrück
49205	Hasbergen	Niedersachsen	NI	Osnabrück
49214	Bad Rothenfelde	Niedersachsen	NI	Osnabrück
49219	Glandorf	Niedersachsen	NI	Osnabrück
49324	Melle	Niedersachsen	NI	Osnabrück
49326	Melle	Niedersachsen	NI	Osnabrück
49328	Melle	Niedersachsen	NI	Osnabrück
49356	Diepholz	Niedersachsen	NI	Diepholz
49377	Vechta	Niedersachsen	NI	Vechta
49393	Lohne (Oldenburg)	Niedersachsen	NI	Vechta
49401	Damme	Niedersachsen	NI	Vechta
49406	Drentwede	Niedersachsen	NI	Diepholz
49406	Barnstorf	Niedersachsen	NI	Diepholz
49406	Eydelstedt	Niedersachsen	NI	Diepholz
49413	Dinklage	Niedersachsen	NI	Vechta
49419	Wagenfeld	Niedersachsen	NI	Diepholz
49424	Goldenstedt	Niedersachsen	NI	Vechta
49429	Visbek	Niedersachsen	NI	Vechta
49434	Neuenkirchen-Vörden	Niedersachsen	NI	Vechta
49439	Steinfeld (Oldenburg)	Niedersachsen	NI	Vechta
49448	Brockum	Niedersachsen	NI	Diepholz
49448	Lemförde	Niedersachsen	NI	Diepholz
49448	Quernheim	Niedersachsen	NI	Diepholz
49448	Stemshorn	Niedersachsen	NI	Diepholz
49448	Marl	Niedersachsen	NI	Diepholz
49448	Hüde	Niedersachsen	NI	Diepholz
49451	Holdorf	Niedersachsen	NI	Vechta
49453	Dickel	Niedersachsen	NI	Diepholz
49453	Barver	Niedersachsen	NI	Diepholz
49453	Hemsloh	Niedersachsen	NI	Diepholz
49453	Wetschen	Niedersachsen	NI	Diepholz
49453	Rehden	Niedersachsen	NI	Diepholz
49456	Bakum	Niedersachsen	NI	Vechta
49457	Drebber	Niedersachsen	NI	Diepholz
49459	Lembruch	Niedersachsen	NI	Diepholz
49565	Bramsche	Niedersachsen	NI	Osnabrück
49577	Kettenkamp	Niedersachsen	NI	Osnabrück
49577	Eggermühlen	Niedersachsen	NI	Osnabrück
49577	Ankum	Niedersachsen	NI	Osnabrück
49584	Fürstenau	Niedersachsen	NI	Osnabrück
49586	Neuenkirchen	Niedersachsen	NI	Osnabrück
49586	Merzen	Niedersachsen	NI	Osnabrück
49593	Bersenbrück	Niedersachsen	NI	Osnabrück
49594	Alfhausen	Niedersachsen	NI	Osnabrück
49596	Gehrde	Niedersachsen	NI	Osnabrück
49597	Rieste	Niedersachsen	NI	Osnabrück
49599	Voltlage	Niedersachsen	NI	Osnabrück
49610	Quakenbrück	Niedersachsen	NI	Osnabrück
49624	Löningen	Niedersachsen	NI	Cloppenburg
49626	Berge	Niedersachsen	NI	Osnabrück
49626	Bippen	Niedersachsen	NI	Osnabrück
49632	Essen (Oldenburg)	Niedersachsen	NI	Cloppenburg
49635	Badbergen	Niedersachsen	NI	Osnabrück
49637	Menslage	Niedersachsen	NI	Osnabrück
49638	Nortrup	Niedersachsen	NI	Osnabrück
49661	Cloppenburg	Niedersachsen	NI	Cloppenburg
49681	Garrel	Niedersachsen	NI	Cloppenburg
49685	Emstek	Niedersachsen	NI	Cloppenburg
49688	Lastrup	Niedersachsen	NI	Cloppenburg
49692	Cappeln (Oldenburg)	Niedersachsen	NI	Cloppenburg
49696	Molbergen	Niedersachsen	NI	Cloppenburg
49699	Lindern (Oldenburg)	Niedersachsen	NI	Cloppenburg
49716	Meppen	Niedersachsen	NI	Emsland
49733	Haren	Niedersachsen	NI	Emsland
49740	Haselünne	Niedersachsen	NI	Emsland
49744	Geeste	Niedersachsen	NI	Emsland
49751	Werpeloh	Niedersachsen	NI	Emsland
49751	Hüven	Niedersachsen	NI	Emsland
49751	Sögel	Niedersachsen	NI	Emsland
49751	Spahnharrenstätte	Niedersachsen	NI	Emsland
49757	Vrees	Niedersachsen	NI	Emsland
49757	Lahn	Niedersachsen	NI	Emsland
49757	Werlte	Niedersachsen	NI	Emsland
49762	Renkenberge	Niedersachsen	NI	Emsland
49762	Lathen	Niedersachsen	NI	Emsland
49762	Fresenburg	Niedersachsen	NI	Emsland
49762	Sustrum	Niedersachsen	NI	Emsland
49767	Twist	Niedersachsen	NI	Emsland
49770	Dohren	Niedersachsen	NI	Emsland
49770	Herzlake	Niedersachsen	NI	Emsland
49774	Lähden	Niedersachsen	NI	Emsland
49777	Stavern	Niedersachsen	NI	Emsland
49777	Klein Berßen	Niedersachsen	NI	Emsland
49777	Groß Berßen	Niedersachsen	NI	Emsland
49779	Oberlangen	Niedersachsen	NI	Emsland
49779	Niederlangen	Niedersachsen	NI	Emsland
49808	Lingen	Niedersachsen	NI	Emsland
49809	Lingen	Niedersachsen	NI	Emsland
49811	Lingen	Niedersachsen	NI	Emsland
49824	Laar	Niedersachsen	NI	Grafschaft Bentheim
49824	Emlichheim	Niedersachsen	NI	Grafschaft Bentheim
49824	Ringe	Niedersachsen	NI	Grafschaft Bentheim
49828	Osterwald	Niedersachsen	NI	Grafschaft Bentheim
49828	Neuenhaus	Niedersachsen	NI	Grafschaft Bentheim
49828	Esche	Niedersachsen	NI	Grafschaft Bentheim
49828	Lage	Niedersachsen	NI	Grafschaft Bentheim
49828	Georgsdorf	Niedersachsen	NI	Grafschaft Bentheim
49832	Andervenne	Niedersachsen	NI	Emsland
49832	Freren	Niedersachsen	NI	Emsland
49832	Messingen	Niedersachsen	NI	Emsland
49832	Thuine	Niedersachsen	NI	Emsland
49832	Beesten	Niedersachsen	NI	Emsland
49835	Wietmarschen	Niedersachsen	NI	Grafschaft Bentheim
49838	Wettrup	Niedersachsen	NI	Emsland
49838	Gersten	Niedersachsen	NI	Emsland
49838	Handrup	Niedersachsen	NI	Emsland
49838	Lengerich	Niedersachsen	NI	Emsland
49838	Langen	Niedersachsen	NI	Emsland
49843	Uelsen	Niedersachsen	NI	Grafschaft Bentheim
49843	Halle	Niedersachsen	NI	Grafschaft Bentheim
49843	Getelo	Niedersachsen	NI	Grafschaft Bentheim
49843	Wielen	Niedersachsen	NI	Grafschaft Bentheim
49843	Gölenkamp	Niedersachsen	NI	Grafschaft Bentheim
49844	Bawinkel	Niedersachsen	NI	Emsland
49846	Hoogstede	Niedersachsen	NI	Grafschaft Bentheim
49847	Itterbeck	Niedersachsen	NI	Grafschaft Bentheim
49849	Wilsum	Niedersachsen	NI	Grafschaft Bentheim
40210	Düsseldorf	Nordrhein-Westfalen	NW	51
40211	Düsseldorf	Nordrhein-Westfalen	NW	51
40212	Düsseldorf	Nordrhein-Westfalen	NW	51
40213	Düsseldorf	Nordrhein-Westfalen	NW	51
40215	Düsseldorf	Nordrhein-Westfalen	NW	51
40217	Düsseldorf	Nordrhein-Westfalen	NW	51
40219	Düsseldorf	Nordrhein-Westfalen	NW	51
40221	Düsseldorf	Nordrhein-Westfalen	NW	51
40223	Düsseldorf	Nordrhein-Westfalen	NW	51
40225	Düsseldorf	Nordrhein-Westfalen	NW	51
40227	Düsseldorf	Nordrhein-Westfalen	NW	51
40229	Düsseldorf	Nordrhein-Westfalen	NW	51
40231	Düsseldorf	Nordrhein-Westfalen	NW	51
40233	Düsseldorf	Nordrhein-Westfalen	NW	51
40235	Düsseldorf	Nordrhein-Westfalen	NW	51
40237	Düsseldorf	Nordrhein-Westfalen	NW	51
40239	Düsseldorf	Nordrhein-Westfalen	NW	51
40468	Düsseldorf	Nordrhein-Westfalen	NW	51
40470	Düsseldorf	Nordrhein-Westfalen	NW	51
40472	Düsseldorf	Nordrhein-Westfalen	NW	51
40474	Düsseldorf	Nordrhein-Westfalen	NW	51
40476	Düsseldorf	Nordrhein-Westfalen	NW	51
40477	Düsseldorf	Nordrhein-Westfalen	NW	51
40479	Düsseldorf	Nordrhein-Westfalen	NW	51
40489	Düsseldorf	Nordrhein-Westfalen	NW	51
40545	Düsseldorf	Nordrhein-Westfalen	NW	51
40547	Düsseldorf	Nordrhein-Westfalen	NW	51
40549	Düsseldorf	Nordrhein-Westfalen	NW	51
40589	Düsseldorf	Nordrhein-Westfalen	NW	51
40591	Düsseldorf	Nordrhein-Westfalen	NW	51
40593	Düsseldorf	Nordrhein-Westfalen	NW	51
40595	Düsseldorf	Nordrhein-Westfalen	NW	51
40597	Düsseldorf	Nordrhein-Westfalen	NW	51
40599	Düsseldorf	Nordrhein-Westfalen	NW	51
40625	Düsseldorf	Nordrhein-Westfalen	NW	51
40627	Düsseldorf	Nordrhein-Westfalen	NW	51
40629	Düsseldorf	Nordrhein-Westfalen	NW	51
40667	Meerbusch	Nordrhein-Westfalen	NW	51
40668	Meerbusch	Nordrhein-Westfalen	NW	51
40670	Meerbusch	Nordrhein-Westfalen	NW	51
40699	Erkrath	Nordrhein-Westfalen	NW	51
40721	Hilden	Nordrhein-Westfalen	NW	51
40723	Hilden	Nordrhein-Westfalen	NW	51
40724	Hilden	Nordrhein-Westfalen	NW	51
40764	Langenfeld	Nordrhein-Westfalen	NW	51
40789	Monheim am Rhein	Nordrhein-Westfalen	NW	51
40789	Monheim am Rhein Baumberg	Nordrhein-Westfalen	NW	51
40789	Monheim am Rhein Monheim	Nordrhein-Westfalen	NW	51
40822	Mettmann	Nordrhein-Westfalen	NW	51
40832	Ratingen	Nordrhein-Westfalen	NW	51
40878	Ratingen	Nordrhein-Westfalen	NW	51
40880	Ratingen	Nordrhein-Westfalen	NW	51
40882	Ratingen	Nordrhein-Westfalen	NW	51
40883	Ratingen	Nordrhein-Westfalen	NW	51
40885	Ratingen	Nordrhein-Westfalen	NW	51
41061	Mönchengladbach	Nordrhein-Westfalen	NW	51
41063	Mönchengladbach	Nordrhein-Westfalen	NW	51
41065	Mönchengladbach	Nordrhein-Westfalen	NW	51
41066	Mönchengladbach	Nordrhein-Westfalen	NW	51
41068	Mönchengladbach	Nordrhein-Westfalen	NW	51
41069	Mönchengladbach	Nordrhein-Westfalen	NW	51
41169	Mönchengladbach	Nordrhein-Westfalen	NW	51
41179	Mönchengladbach	Nordrhein-Westfalen	NW	51
41189	Mönchengladbach	Nordrhein-Westfalen	NW	51
41199	Mönchengladbach	Nordrhein-Westfalen	NW	51
41236	Mönchengladbach	Nordrhein-Westfalen	NW	51
41238	Mönchengladbach	Nordrhein-Westfalen	NW	51
41239	Mönchengladbach	Nordrhein-Westfalen	NW	51
41334	Nettetal	Nordrhein-Westfalen	NW	51
41352	Korschenbroich	Nordrhein-Westfalen	NW	51
41363	Jüchen	Nordrhein-Westfalen	NW	51
41366	Schwalmtal	Nordrhein-Westfalen	NW	51
41372	Niederkrüchten	Nordrhein-Westfalen	NW	51
41379	Brüggen	Nordrhein-Westfalen	NW	51
41460	Neuss	Nordrhein-Westfalen	NW	51
41462	Neuss	Nordrhein-Westfalen	NW	51
41464	Neuss	Nordrhein-Westfalen	NW	51
41466	Neuss	Nordrhein-Westfalen	NW	51
41468	Neuss	Nordrhein-Westfalen	NW	51
41469	Neuss	Nordrhein-Westfalen	NW	51
41470	Neuss	Nordrhein-Westfalen	NW	51
41515	Grevenbroich	Nordrhein-Westfalen	NW	51
41516	Grevenbroich	Nordrhein-Westfalen	NW	51
41517	Grevenbroich	Nordrhein-Westfalen	NW	51
41539	Dormagen	Nordrhein-Westfalen	NW	51
41540	Dormagen	Nordrhein-Westfalen	NW	51
41541	Dormagen	Nordrhein-Westfalen	NW	51
41542	Dormagen	Nordrhein-Westfalen	NW	51
41564	Kaarst	Nordrhein-Westfalen	NW	51
41569	Rommerskirchen	Nordrhein-Westfalen	NW	51
41747	Viersen	Nordrhein-Westfalen	NW	51
41748	Viersen	Nordrhein-Westfalen	NW	51
41749	Viersen	Nordrhein-Westfalen	NW	51
41751	Viersen	Nordrhein-Westfalen	NW	51
42103	Wuppertal	Nordrhein-Westfalen	NW	51
42105	Wuppertal	Nordrhein-Westfalen	NW	51
42107	Wuppertal	Nordrhein-Westfalen	NW	51
42109	Wuppertal	Nordrhein-Westfalen	NW	51
42111	Wuppertal	Nordrhein-Westfalen	NW	51
42113	Wuppertal	Nordrhein-Westfalen	NW	51
42115	Wuppertal	Nordrhein-Westfalen	NW	51
42117	Wuppertal	Nordrhein-Westfalen	NW	51
42119	Wuppertal	Nordrhein-Westfalen	NW	51
42275	Wuppertal	Nordrhein-Westfalen	NW	51
42277	Wuppertal	Nordrhein-Westfalen	NW	51
42279	Wuppertal	Nordrhein-Westfalen	NW	51
42281	Wuppertal	Nordrhein-Westfalen	NW	51
42283	Wuppertal	Nordrhein-Westfalen	NW	51
42285	Wuppertal	Nordrhein-Westfalen	NW	51
42287	Wuppertal	Nordrhein-Westfalen	NW	51
42289	Wuppertal	Nordrhein-Westfalen	NW	51
42327	Wuppertal	Nordrhein-Westfalen	NW	51
42329	Wuppertal	Nordrhein-Westfalen	NW	51
42349	Wuppertal	Nordrhein-Westfalen	NW	51
42369	Wuppertal	Nordrhein-Westfalen	NW	51
42389	Wuppertal	Nordrhein-Westfalen	NW	51
42399	Wuppertal	Nordrhein-Westfalen	NW	51
42489	Wülfrath	Nordrhein-Westfalen	NW	51
42549	Velbert	Nordrhein-Westfalen	NW	51
42551	Velbert	Nordrhein-Westfalen	NW	51
42553	Velbert	Nordrhein-Westfalen	NW	51
42555	Velbert	Nordrhein-Westfalen	NW	51
42579	Heiligenhaus	Nordrhein-Westfalen	NW	51
42651	Solingen	Nordrhein-Westfalen	NW	51
42653	Solingen	Nordrhein-Westfalen	NW	51
42655	Solingen	Nordrhein-Westfalen	NW	51
42657	Solingen	Nordrhein-Westfalen	NW	51
42659	Solingen	Nordrhein-Westfalen	NW	51
42697	Solingen	Nordrhein-Westfalen	NW	51
42699	Solingen	Nordrhein-Westfalen	NW	51
42719	Solingen	Nordrhein-Westfalen	NW	51
42781	Haan	Nordrhein-Westfalen	NW	51
42853	Remscheid	Nordrhein-Westfalen	NW	51
42855	Remscheid	Nordrhein-Westfalen	NW	51
42857	Remscheid	Nordrhein-Westfalen	NW	51
42859	Remscheid	Nordrhein-Westfalen	NW	51
42897	Remscheid	Nordrhein-Westfalen	NW	51
42899	Remscheid	Nordrhein-Westfalen	NW	51
45127	Essen	Nordrhein-Westfalen	NW	51
45128	Essen	Nordrhein-Westfalen	NW	51
45130	Essen	Nordrhein-Westfalen	NW	51
45131	Essen	Nordrhein-Westfalen	NW	51
45133	Essen	Nordrhein-Westfalen	NW	51
45134	Essen	Nordrhein-Westfalen	NW	51
45136	Essen	Nordrhein-Westfalen	NW	51
45138	Essen	Nordrhein-Westfalen	NW	51
45139	Essen	Nordrhein-Westfalen	NW	51
45141	Essen	Nordrhein-Westfalen	NW	51
45143	Essen	Nordrhein-Westfalen	NW	51
45144	Essen	Nordrhein-Westfalen	NW	51
45145	Essen	Nordrhein-Westfalen	NW	51
45147	Essen	Nordrhein-Westfalen	NW	51
45149	Essen	Nordrhein-Westfalen	NW	51
45219	Essen	Nordrhein-Westfalen	NW	51
45239	Essen	Nordrhein-Westfalen	NW	51
45257	Essen	Nordrhein-Westfalen	NW	51
45259	Essen	Nordrhein-Westfalen	NW	51
45276	Essen	Nordrhein-Westfalen	NW	51
45277	Essen	Nordrhein-Westfalen	NW	51
45279	Essen	Nordrhein-Westfalen	NW	51
45289	Essen	Nordrhein-Westfalen	NW	51
45307	Essen	Nordrhein-Westfalen	NW	51
45309	Essen	Nordrhein-Westfalen	NW	51
45326	Essen	Nordrhein-Westfalen	NW	51
45327	Essen	Nordrhein-Westfalen	NW	51
45329	Essen	Nordrhein-Westfalen	NW	51
45355	Essen	Nordrhein-Westfalen	NW	51
45356	Essen	Nordrhein-Westfalen	NW	51
45357	Essen	Nordrhein-Westfalen	NW	51
45359	Essen	Nordrhein-Westfalen	NW	51
45403	Mülheim an der Ruhr	Nordrhein-Westfalen	NW	51
45468	Mülheim an der Ruhr	Nordrhein-Westfalen	NW	51
45470	Mülheim an der Ruhr	Nordrhein-Westfalen	NW	51
45472	Mülheim an der Ruhr	Nordrhein-Westfalen	NW	51
45473	Mülheim an der Ruhr	Nordrhein-Westfalen	NW	51
45475	Mülheim an der Ruhr	Nordrhein-Westfalen	NW	51
45476	Mülheim an der Ruhr	Nordrhein-Westfalen	NW	51
45478	Mülheim an der Ruhr	Nordrhein-Westfalen	NW	51
45479	Mülheim an der Ruhr	Nordrhein-Westfalen	NW	51
45481	Mülheim an der Ruhr	Nordrhein-Westfalen	NW	51
46045	Oberhausen	Nordrhein-Westfalen	NW	51
46047	Oberhausen	Nordrhein-Westfalen	NW	51
46049	Oberhausen	Nordrhein-Westfalen	NW	51
46117	Oberhausen	Nordrhein-Westfalen	NW	51
46119	Oberhausen	Nordrhein-Westfalen	NW	51
46145	Oberhausen	Nordrhein-Westfalen	NW	51
46147	Oberhausen	Nordrhein-Westfalen	NW	51
46149	Oberhausen	Nordrhein-Westfalen	NW	51
46446	Emmerich	Nordrhein-Westfalen	NW	51
46459	Rees	Nordrhein-Westfalen	NW	51
46483	Wesel	Nordrhein-Westfalen	NW	51
46485	Wesel	Nordrhein-Westfalen	NW	51
46487	Wesel	Nordrhein-Westfalen	NW	51
46499	Hamminkeln	Nordrhein-Westfalen	NW	51
46509	Xanten	Nordrhein-Westfalen	NW	51
46514	Schermbeck	Nordrhein-Westfalen	NW	51
46519	Alpen	Nordrhein-Westfalen	NW	51
46539	Dinslaken	Nordrhein-Westfalen	NW	51
46562	Voerde	Nordrhein-Westfalen	NW	51
46569	Hünxe	Nordrhein-Westfalen	NW	51
47051	Duisburg	Nordrhein-Westfalen	NW	51
47053	Duisburg	Nordrhein-Westfalen	NW	51
47055	Duisburg	Nordrhein-Westfalen	NW	51
47057	Duisburg	Nordrhein-Westfalen	NW	51
47058	Duisburg	Nordrhein-Westfalen	NW	51
47059	Duisburg	Nordrhein-Westfalen	NW	51
47119	Duisburg	Nordrhein-Westfalen	NW	51
47137	Duisburg	Nordrhein-Westfalen	NW	51
47138	Duisburg	Nordrhein-Westfalen	NW	51
47139	Duisburg	Nordrhein-Westfalen	NW	51
47166	Duisburg	Nordrhein-Westfalen	NW	51
47167	Duisburg	Nordrhein-Westfalen	NW	51
47169	Duisburg	Nordrhein-Westfalen	NW	51
47178	Duisburg	Nordrhein-Westfalen	NW	51
47179	Duisburg	Nordrhein-Westfalen	NW	51
47198	Duisburg	Nordrhein-Westfalen	NW	51
47199	Duisburg	Nordrhein-Westfalen	NW	51
47226	Duisburg	Nordrhein-Westfalen	NW	51
47228	Duisburg	Nordrhein-Westfalen	NW	51
47229	Duisburg	Nordrhein-Westfalen	NW	51
47239	Duisburg	Nordrhein-Westfalen	NW	51
47249	Duisburg	Nordrhein-Westfalen	NW	51
47259	Duisburg	Nordrhein-Westfalen	NW	51
47269	Duisburg	Nordrhein-Westfalen	NW	51
47279	Duisburg	Nordrhein-Westfalen	NW	51
47441	Moers	Nordrhein-Westfalen	NW	51
47443	Moers	Nordrhein-Westfalen	NW	51
47445	Moers	Nordrhein-Westfalen	NW	51
47447	Moers	Nordrhein-Westfalen	NW	51
47475	Kamp-Lintfort	Nordrhein-Westfalen	NW	51
47495	Rheinberg	Nordrhein-Westfalen	NW	51
47506	Neukirchen-Vluyn	Nordrhein-Westfalen	NW	51
47509	Rheurdt	Nordrhein-Westfalen	NW	51
47533	Kleve	Nordrhein-Westfalen	NW	51
47546	Kalkar	Nordrhein-Westfalen	NW	51
47551	Bedburg-Hau	Nordrhein-Westfalen	NW	51
47559	Kranenburg	Nordrhein-Westfalen	NW	51
47574	Goch	Nordrhein-Westfalen	NW	51
47589	Uedem	Nordrhein-Westfalen	NW	51
47608	Geldern	Nordrhein-Westfalen	NW	51
47623	Kevelaer	Nordrhein-Westfalen	NW	51
47624	Kevelaer	Nordrhein-Westfalen	NW	51
47625	Kevelaer	Nordrhein-Westfalen	NW	51
47626	Kevelaer	Nordrhein-Westfalen	NW	51
47627	Kevelaer	Nordrhein-Westfalen	NW	51
47638	Straelen	Nordrhein-Westfalen	NW	51
47647	Kerken	Nordrhein-Westfalen	NW	51
47652	Weeze	Nordrhein-Westfalen	NW	51
47661	Issum	Nordrhein-Westfalen	NW	51
47665	Sonsbeck	Nordrhein-Westfalen	NW	51
47669	Wachtendonk	Nordrhein-Westfalen	NW	51
47798	Krefeld	Nordrhein-Westfalen	NW	51
47799	Krefeld	Nordrhein-Westfalen	NW	51
47800	Krefeld	Nordrhein-Westfalen	NW	51
47802	Krefeld	Nordrhein-Westfalen	NW	51
47803	Krefeld	Nordrhein-Westfalen	NW	51
47804	Krefeld	Nordrhein-Westfalen	NW	51
47805	Krefeld	Nordrhein-Westfalen	NW	51
47807	Krefeld	Nordrhein-Westfalen	NW	51
47809	Krefeld	Nordrhein-Westfalen	NW	51
47829	Krefeld	Nordrhein-Westfalen	NW	51
47839	Krefeld	Nordrhein-Westfalen	NW	51
47877	Willich	Nordrhein-Westfalen	NW	51
47906	Kempen	Nordrhein-Westfalen	NW	51
47918	Tönisvorst	Nordrhein-Westfalen	NW	51
47929	Grefrath	Nordrhein-Westfalen	NW	51
41812	Erkelenz	Nordrhein-Westfalen	NW	53
41836	Hückelhoven	Nordrhein-Westfalen	NW	53
41844	Wegberg	Nordrhein-Westfalen	NW	53
41849	Wassenberg	Nordrhein-Westfalen	NW	53
42477	Radevormwald	Nordrhein-Westfalen	NW	53
42499	Hückeswagen	Nordrhein-Westfalen	NW	53
42799	Leichlingen	Nordrhein-Westfalen	NW	53
42929	Wermelskirchen	Nordrhein-Westfalen	NW	53
50126	Bergheim	Nordrhein-Westfalen	NW	53
50127	Bergheim	Nordrhein-Westfalen	NW	53
50129	Bergheim	Nordrhein-Westfalen	NW	53
50169	Kerpen	Nordrhein-Westfalen	NW	53
50170	Kerpen	Nordrhein-Westfalen	NW	53
50171	Kerpen	Nordrhein-Westfalen	NW	53
50181	Bedburg	Nordrhein-Westfalen	NW	53
50189	Elsdorf	Nordrhein-Westfalen	NW	53
50226	Frechen	Nordrhein-Westfalen	NW	53
50259	Pulheim	Nordrhein-Westfalen	NW	53
50321	Brühl	Nordrhein-Westfalen	NW	53
50354	Hürth	Nordrhein-Westfalen	NW	53
50374	Erftstadt	Nordrhein-Westfalen	NW	53
50389	Wesseling	Nordrhein-Westfalen	NW	53
50667	Köln	Nordrhein-Westfalen	NW	53
50668	Köln	Nordrhein-Westfalen	NW	53
50670	Köln	Nordrhein-Westfalen	NW	53
50672	Köln	Nordrhein-Westfalen	NW	53
50674	Köln	Nordrhein-Westfalen	NW	53
50676	Köln	Nordrhein-Westfalen	NW	53
50677	Köln	Nordrhein-Westfalen	NW	53
50678	Köln	Nordrhein-Westfalen	NW	53
50679	Köln	Nordrhein-Westfalen	NW	53
50733	Köln	Nordrhein-Westfalen	NW	53
50735	Köln	Nordrhein-Westfalen	NW	53
50737	Köln	Nordrhein-Westfalen	NW	53
50739	Köln	Nordrhein-Westfalen	NW	53
50765	Köln	Nordrhein-Westfalen	NW	53
50767	Köln	Nordrhein-Westfalen	NW	53
50769	Köln	Nordrhein-Westfalen	NW	53
50823	Köln	Nordrhein-Westfalen	NW	53
50825	Köln	Nordrhein-Westfalen	NW	53
50827	Köln	Nordrhein-Westfalen	NW	53
50829	Köln	Nordrhein-Westfalen	NW	53
50858	Köln	Nordrhein-Westfalen	NW	53
50859	Köln	Nordrhein-Westfalen	NW	53
50931	Köln	Nordrhein-Westfalen	NW	53
50933	Köln	Nordrhein-Westfalen	NW	53
50935	Köln	Nordrhein-Westfalen	NW	53
50937	Köln	Nordrhein-Westfalen	NW	53
50939	Köln	Nordrhein-Westfalen	NW	53
50968	Köln	Nordrhein-Westfalen	NW	53
50969	Köln	Nordrhein-Westfalen	NW	53
50996	Köln	Nordrhein-Westfalen	NW	53
50997	Köln	Nordrhein-Westfalen	NW	53
50999	Köln	Nordrhein-Westfalen	NW	53
51061	Köln	Nordrhein-Westfalen	NW	53
51063	Köln	Nordrhein-Westfalen	NW	53
51065	Köln	Nordrhein-Westfalen	NW	53
51067	Köln	Nordrhein-Westfalen	NW	53
51069	Köln	Nordrhein-Westfalen	NW	53
51103	Köln	Nordrhein-Westfalen	NW	53
51105	Köln	Nordrhein-Westfalen	NW	53
51107	Köln	Nordrhein-Westfalen	NW	53
51109	Köln	Nordrhein-Westfalen	NW	53
51143	Köln	Nordrhein-Westfalen	NW	53
51145	Köln	Nordrhein-Westfalen	NW	53
51147	Köln	Nordrhein-Westfalen	NW	53
51149	Köln	Nordrhein-Westfalen	NW	53
51371	Leverkusen	Nordrhein-Westfalen	NW	53
51373	Leverkusen	Nordrhein-Westfalen	NW	53
51375	Leverkusen	Nordrhein-Westfalen	NW	53
51377	Leverkusen	Nordrhein-Westfalen	NW	53
51379	Leverkusen	Nordrhein-Westfalen	NW	53
51381	Leverkusen	Nordrhein-Westfalen	NW	53
51399	Burscheid	Nordrhein-Westfalen	NW	53
51427	Bergisch Gladbach	Nordrhein-Westfalen	NW	53
51429	Bergisch Gladbach	Nordrhein-Westfalen	NW	53
51465	Bergisch Gladbach	Nordrhein-Westfalen	NW	53
51467	Bergisch Gladbach	Nordrhein-Westfalen	NW	53
51469	Bergisch Gladbach	Nordrhein-Westfalen	NW	53
51491	Overath	Nordrhein-Westfalen	NW	53
51503	Rösrath	Nordrhein-Westfalen	NW	53
51515	Kürten	Nordrhein-Westfalen	NW	53
51519	Odenthal	Nordrhein-Westfalen	NW	53
51545	Waldbröl	Nordrhein-Westfalen	NW	53
51570	Windeck	Nordrhein-Westfalen	NW	53
51580	Reichshof	Nordrhein-Westfalen	NW	53
51588	Nümbrecht	Nordrhein-Westfalen	NW	53
51597	Morsbach	Nordrhein-Westfalen	NW	53
51643	Gummersbach	Nordrhein-Westfalen	NW	53
51645	Gummersbach	Nordrhein-Westfalen	NW	53
51647	Gummersbach	Nordrhein-Westfalen	NW	53
51674	Wiehl	Nordrhein-Westfalen	NW	53
51688	Wipperfürth	Nordrhein-Westfalen	NW	53
51702	Bergneustadt	Nordrhein-Westfalen	NW	53
51709	Marienheide	Nordrhein-Westfalen	NW	53
51766	Engelskirchen	Nordrhein-Westfalen	NW	53
51789	Lindlar	Nordrhein-Westfalen	NW	53
52062	Aachen	Nordrhein-Westfalen	NW	53
52064	Aachen	Nordrhein-Westfalen	NW	53
52066	Aachen	Nordrhein-Westfalen	NW	53
52068	Aachen	Nordrhein-Westfalen	NW	53
52070	Aachen	Nordrhein-Westfalen	NW	53
52072	Aachen	Nordrhein-Westfalen	NW	53
52074	Aachen	Nordrhein-Westfalen	NW	53
52076	Aachen	Nordrhein-Westfalen	NW	53
52078	Aachen	Nordrhein-Westfalen	NW	53
52080	Aachen	Nordrhein-Westfalen	NW	53
52134	Herzogenrath	Nordrhein-Westfalen	NW	53
52146	Würselen	Nordrhein-Westfalen	NW	53
52152	Simmerath	Nordrhein-Westfalen	NW	53
52156	Monschau	Nordrhein-Westfalen	NW	53
52159	Roetgen	Nordrhein-Westfalen	NW	53
52222	Stolberg (Rheinland)	Nordrhein-Westfalen	NW	53
52223	Stolberg (Rheinland)	Nordrhein-Westfalen	NW	53
52224	Stolberg (Rheinland)	Nordrhein-Westfalen	NW	53
52249	Eschweiler	Nordrhein-Westfalen	NW	53
52349	Düren	Nordrhein-Westfalen	NW	53
52351	Düren	Nordrhein-Westfalen	NW	53
52353	Düren	Nordrhein-Westfalen	NW	53
52355	Düren	Nordrhein-Westfalen	NW	53
52372	Kreuzau	Nordrhein-Westfalen	NW	53
52379	Langerwehe	Nordrhein-Westfalen	NW	53
52382	Niederzier	Nordrhein-Westfalen	NW	53
52385	Nideggen	Nordrhein-Westfalen	NW	53
52388	Nörvenich	Nordrhein-Westfalen	NW	53
52391	Vettweiß	Nordrhein-Westfalen	NW	53
52393	Hürtgenwald	Nordrhein-Westfalen	NW	53
52396	Heimbach	Nordrhein-Westfalen	NW	53
52399	Merzenich	Nordrhein-Westfalen	NW	53
52428	Jülich	Nordrhein-Westfalen	NW	53
52441	Linnich	Nordrhein-Westfalen	NW	53
52445	Titz	Nordrhein-Westfalen	NW	53
52457	Aldenhoven	Nordrhein-Westfalen	NW	53
52459	Inden	Nordrhein-Westfalen	NW	53
52477	Alsdorf	Nordrhein-Westfalen	NW	53
52499	Baesweiler	Nordrhein-Westfalen	NW	53
52511	Geilenkirchen	Nordrhein-Westfalen	NW	53
52525	Waldfeucht	Nordrhein-Westfalen	NW	53
52525	Heinsberg	Nordrhein-Westfalen	NW	53
52531	Übach-Palenberg	Nordrhein-Westfalen	NW	53
52538	Selfkant	Nordrhein-Westfalen	NW	53
52538	Gangelt	Nordrhein-Westfalen	NW	53
53111	Bonn	Nordrhein-Westfalen	NW	53
53113	Bonn	Nordrhein-Westfalen	NW	53
53115	Bonn	Nordrhein-Westfalen	NW	53
53117	Bonn	Nordrhein-Westfalen	NW	53
53119	Bonn	Nordrhein-Westfalen	NW	53
53121	Bonn	Nordrhein-Westfalen	NW	53
53123	Bonn	Nordrhein-Westfalen	NW	53
53125	Bonn	Nordrhein-Westfalen	NW	53
53127	Bonn	Nordrhein-Westfalen	NW	53
53129	Bonn	Nordrhein-Westfalen	NW	53
53173	Bonn	Nordrhein-Westfalen	NW	53
53175	Bonn	Nordrhein-Westfalen	NW	53
53177	Bonn	Nordrhein-Westfalen	NW	53
53179	Bonn	Nordrhein-Westfalen	NW	53
53225	Bonn	Nordrhein-Westfalen	NW	53
53227	Bonn	Nordrhein-Westfalen	NW	53
53229	Bonn	Nordrhein-Westfalen	NW	53
53332	Bornheim	Nordrhein-Westfalen	NW	53
53340	Meckenheim	Nordrhein-Westfalen	NW	53
53343	Wachtberg	Nordrhein-Westfalen	NW	53
53347	Alfter	Nordrhein-Westfalen	NW	53
53359	Rheinbach	Nordrhein-Westfalen	NW	53
53604	Bad Honnef	Nordrhein-Westfalen	NW	53
53639	Königswinter	Nordrhein-Westfalen	NW	53
53721	Siegburg	Nordrhein-Westfalen	NW	53
53757	Sankt Augustin	Nordrhein-Westfalen	NW	53
53773	Hennef	Nordrhein-Westfalen	NW	53
53783	Eitorf	Nordrhein-Westfalen	NW	53
53797	Lohmar	Nordrhein-Westfalen	NW	53
53804	Much	Nordrhein-Westfalen	NW	53
53809	Ruppichteroth	Nordrhein-Westfalen	NW	53
53819	Neunkirchen-Seelscheid	Nordrhein-Westfalen	NW	53
53840	Troisdorf	Nordrhein-Westfalen	NW	53
53842	Troisdorf	Nordrhein-Westfalen	NW	53
53844	Troisdorf	Nordrhein-Westfalen	NW	53
53859	Niederkassel	Nordrhein-Westfalen	NW	53
53879	Euskirchen	Nordrhein-Westfalen	NW	53
53881	Euskirchen	Nordrhein-Westfalen	NW	53
53894	Mechernich	Nordrhein-Westfalen	NW	53
53902	Bad Münstereifel	Nordrhein-Westfalen	NW	53
53909	Zülpich	Nordrhein-Westfalen	NW	53
53913	Swisttal	Nordrhein-Westfalen	NW	53
53919	Weilerswist	Nordrhein-Westfalen	NW	53
53925	Kall	Nordrhein-Westfalen	NW	53
53937	Schleiden	Nordrhein-Westfalen	NW	53
53940	Hellenthal	Nordrhein-Westfalen	NW	53
53945	Blankenheim	Nordrhein-Westfalen	NW	53
53947	Nettersheim	Nordrhein-Westfalen	NW	53
53949	Dahlem	Nordrhein-Westfalen	NW	53
44575	Castrop-Rauxel	Nordrhein-Westfalen	NW	55
44577	Castrop-Rauxel	Nordrhein-Westfalen	NW	55
44579	Castrop-Rauxel	Nordrhein-Westfalen	NW	55
44581	Castrop-Rauxel	Nordrhein-Westfalen	NW	55
45657	Recklinghausen	Nordrhein-Westfalen	NW	55
45659	Recklinghausen	Nordrhein-Westfalen	NW	55
45661	Recklinghausen	Nordrhein-Westfalen	NW	55
45663	Recklinghausen	Nordrhein-Westfalen	NW	55
45665	Recklinghausen	Nordrhein-Westfalen	NW	55
45699	Herten	Nordrhein-Westfalen	NW	55
45701	Herten	Nordrhein-Westfalen	NW	55
45711	Datteln	Nordrhein-Westfalen	NW	55
45721	Haltern am See	Nordrhein-Westfalen	NW	55
45731	Waltrop	Nordrhein-Westfalen	NW	55
45739	Oer-Erkenschwick	Nordrhein-Westfalen	NW	55
45768	Marl	Nordrhein-Westfalen	NW	55
45770	Marl	Nordrhein-Westfalen	NW	55
45772	Marl	Nordrhein-Westfalen	NW	55
45879	Gelsenkirchen	Nordrhein-Westfalen	NW	55
45881	Gelsenkirchen	Nordrhein-Westfalen	NW	55
45883	Gelsenkirchen	Nordrhein-Westfalen	NW	55
45884	Gelsenkirchen	Nordrhein-Westfalen	NW	55
45886	Gelsenkirchen	Nordrhein-Westfalen	NW	55
45888	Gelsenkirchen	Nordrhein-Westfalen	NW	55
45889	Gelsenkirchen	Nordrhein-Westfalen	NW	55
45891	Gelsenkirchen	Nordrhein-Westfalen	NW	55
45892	Gelsenkirchen	Nordrhein-Westfalen	NW	55
45894	Gelsenkirchen	Nordrhein-Westfalen	NW	55
45896	Gelsenkirchen	Nordrhein-Westfalen	NW	55
45897	Gelsenkirchen	Nordrhein-Westfalen	NW	55
45899	Gelsenkirchen	Nordrhein-Westfalen	NW	55
45964	Gladbeck	Nordrhein-Westfalen	NW	55
45966	Gladbeck	Nordrhein-Westfalen	NW	55
45968	Gladbeck	Nordrhein-Westfalen	NW	55
46236	Bottrop	Nordrhein-Westfalen	NW	55
46238	Bottrop	Nordrhein-Westfalen	NW	55
46240	Bottrop	Nordrhein-Westfalen	NW	55
46242	Bottrop	Nordrhein-Westfalen	NW	55
46244	Bottrop	Nordrhein-Westfalen	NW	55
46282	Dorsten	Nordrhein-Westfalen	NW	55
46284	Dorsten	Nordrhein-Westfalen	NW	55
46286	Dorsten	Nordrhein-Westfalen	NW	55
46325	Borken	Nordrhein-Westfalen	NW	55
46342	Velen	Nordrhein-Westfalen	NW	55
46348	Raesfeld	Nordrhein-Westfalen	NW	55
46354	Südlohn	Nordrhein-Westfalen	NW	55
46359	Heiden	Nordrhein-Westfalen	NW	55
46395	Bocholt	Nordrhein-Westfalen	NW	55
46397	Bocholt	Nordrhein-Westfalen	NW	55
46399	Bocholt	Nordrhein-Westfalen	NW	55
46414	Rhede	Nordrhein-Westfalen	NW	55
46419	Isselburg	Nordrhein-Westfalen	NW	55
48079	Münster	Nordrhein-Westfalen	NW	55
48143	Münster	Nordrhein-Westfalen	NW	55
48145	Münster	Nordrhein-Westfalen	NW	55
48147	Münster	Nordrhein-Westfalen	NW	55
48149	Münster	Nordrhein-Westfalen	NW	55
48151	Münster	Nordrhein-Westfalen	NW	55
48153	Münster	Nordrhein-Westfalen	NW	55
48155	Münster	Nordrhein-Westfalen	NW	55
48157	Münster	Nordrhein-Westfalen	NW	55
48159	Münster	Nordrhein-Westfalen	NW	55
48161	Münster	Nordrhein-Westfalen	NW	55
48163	Münster	Nordrhein-Westfalen	NW	55
48165	Münster	Nordrhein-Westfalen	NW	55
48167	Münster	Nordrhein-Westfalen	NW	55
48231	Warendorf	Nordrhein-Westfalen	NW	55
48249	Dülmen	Nordrhein-Westfalen	NW	55
48268	Greven	Nordrhein-Westfalen	NW	55
48282	Emsdetten	Nordrhein-Westfalen	NW	55
48291	Telgte	Nordrhein-Westfalen	NW	55
48301	Nottuln	Nordrhein-Westfalen	NW	55
48308	Senden	Nordrhein-Westfalen	NW	55
48317	Drensteinfurt	Nordrhein-Westfalen	NW	55
48324	Sendenhorst	Nordrhein-Westfalen	NW	55
48329	Havixbeck	Nordrhein-Westfalen	NW	55
48336	Sassenberg	Nordrhein-Westfalen	NW	55
48341	Altenberge	Nordrhein-Westfalen	NW	55
48346	Ostbevern	Nordrhein-Westfalen	NW	55
48351	Everswinkel	Nordrhein-Westfalen	NW	55
48356	Nordwalde	Nordrhein-Westfalen	NW	55
48361	Beelen	Nordrhein-Westfalen	NW	55
48366	Laer	Nordrhein-Westfalen	NW	55
48369	Saerbeck	Nordrhein-Westfalen	NW	55
48429	Rheine	Nordrhein-Westfalen	NW	55
48431	Rheine	Nordrhein-Westfalen	NW	55
48432	Rheine	Nordrhein-Westfalen	NW	55
48477	Hörstel	Nordrhein-Westfalen	NW	55
48485	Neuenkirchen	Nordrhein-Westfalen	NW	55
48493	Wettringen	Nordrhein-Westfalen	NW	55
48496	Hopsten	Nordrhein-Westfalen	NW	55
48565	Steinfurt	Nordrhein-Westfalen	NW	55
48599	Gronau (Westfalen)	Nordrhein-Westfalen	NW	55
48607	Ochtrup	Nordrhein-Westfalen	NW	55
48612	Horstmar	Nordrhein-Westfalen	NW	55
48619	Heek	Nordrhein-Westfalen	NW	55
48624	Schöppingen	Nordrhein-Westfalen	NW	55
48629	Metelen	Nordrhein-Westfalen	NW	55
48653	Coesfeld	Nordrhein-Westfalen	NW	55
48683	Ahaus	Nordrhein-Westfalen	NW	55
48691	Vreden	Nordrhein-Westfalen	NW	55
48703	Stadtlohn	Nordrhein-Westfalen	NW	55
48712	Gescher	Nordrhein-Westfalen	NW	55
48720	Rosendahl	Nordrhein-Westfalen	NW	55
48727	Billerbeck	Nordrhein-Westfalen	NW	55
48734	Reken	Nordrhein-Westfalen	NW	55
48739	Legden	Nordrhein-Westfalen	NW	55
49477	Ibbenbüren	Nordrhein-Westfalen	NW	55
49479	Ibbenbüren	Nordrhein-Westfalen	NW	55
49492	Westerkappeln	Nordrhein-Westfalen	NW	55
49497	Mettingen	Nordrhein-Westfalen	NW	55
49504	Lotte	Nordrhein-Westfalen	NW	55
49509	Recke	Nordrhein-Westfalen	NW	55
49525	Lengerich	Nordrhein-Westfalen	NW	55
49536	Lienen	Nordrhein-Westfalen	NW	55
49545	Tecklenburg	Nordrhein-Westfalen	NW	55
49549	Ladbergen	Nordrhein-Westfalen	NW	55
59227	Ahlen	Nordrhein-Westfalen	NW	55
59229	Ahlen	Nordrhein-Westfalen	NW	55
59269	Beckum	Nordrhein-Westfalen	NW	55
59302	Oelde	Nordrhein-Westfalen	NW	55
59320	Ennigerloh	Nordrhein-Westfalen	NW	55
59329	Wadersloh	Nordrhein-Westfalen	NW	55
59348	Lüdinghausen	Nordrhein-Westfalen	NW	55
59387	Ascheberg	Nordrhein-Westfalen	NW	55
59394	Nordkirchen	Nordrhein-Westfalen	NW	55
59399	Olfen	Nordrhein-Westfalen	NW	55
32049	Herford	Nordrhein-Westfalen	NW	57
32051	Herford	Nordrhein-Westfalen	NW	57
32052	Herford	Nordrhein-Westfalen	NW	57
32105	Bad Salzuflen	Nordrhein-Westfalen	NW	57
32107	Bad Salzuflen	Nordrhein-Westfalen	NW	57
32108	Bad Salzuflen	Nordrhein-Westfalen	NW	57
32120	Hiddenhausen	Nordrhein-Westfalen	NW	57
32130	Enger	Nordrhein-Westfalen	NW	57
32139	Spenge	Nordrhein-Westfalen	NW	57
32257	Bünde	Nordrhein-Westfalen	NW	57
32278	Kirchlengern	Nordrhein-Westfalen	NW	57
32289	Rödinghausen	Nordrhein-Westfalen	NW	57
32312	Lübbecke	Nordrhein-Westfalen	NW	57
32339	Espelkamp	Nordrhein-Westfalen	NW	57
32351	Stemwede	Nordrhein-Westfalen	NW	57
32361	Preußisch Oldendorf	Nordrhein-Westfalen	NW	57
32369	Rahden	Nordrhein-Westfalen	NW	57
32423	Minden	Nordrhein-Westfalen	NW	57
32425	Minden	Nordrhein-Westfalen	NW	57
32427	Minden	Nordrhein-Westfalen	NW	57
32429	Minden	Nordrhein-Westfalen	NW	57
32457	Porta Westfalica	Nordrhein-Westfalen	NW	57
32469	Petershagen	Nordrhein-Westfalen	NW	57
32479	Hille	Nordrhein-Westfalen	NW	57
32545	Bad Oeynhausen	Nordrhein-Westfalen	NW	57
32547	Bad Oeynhausen	Nordrhein-Westfalen	NW	57
32549	Bad Oeynhausen	Nordrhein-Westfalen	NW	57
32584	Löhne	Nordrhein-Westfalen	NW	57
32602	Vlotho	Nordrhein-Westfalen	NW	57
32609	Hüllhorst	Nordrhein-Westfalen	NW	57
32657	Lemgo	Nordrhein-Westfalen	NW	57
32676	Lügde	Nordrhein-Westfalen	NW	57
32683	Barntrup	Nordrhein-Westfalen	NW	57
32689	Kalletal	Nordrhein-Westfalen	NW	57
32694	Dörentrup	Nordrhein-Westfalen	NW	57
32699	Extertal	Nordrhein-Westfalen	NW	57
32756	Detmold	Nordrhein-Westfalen	NW	57
32758	Detmold	Nordrhein-Westfalen	NW	57
32760	Detmold	Nordrhein-Westfalen	NW	57
32791	Lage	Nordrhein-Westfalen	NW	57
32805	Horn-Bad Meinberg	Nordrhein-Westfalen	NW	57
32816	Schieder-Schwalenberg	Nordrhein-Westfalen	NW	57
32825	Blomberg	Nordrhein-Westfalen	NW	57
32832	Augustdorf	Nordrhein-Westfalen	NW	57
32839	Steinheim	Nordrhein-Westfalen	NW	57
33014	Bad Driburg	Nordrhein-Westfalen	NW	57
33034	Brakel	Nordrhein-Westfalen	NW	57
33039	Nieheim	Nordrhein-Westfalen	NW	57
33098	Paderborn	Nordrhein-Westfalen	NW	57
33100	Paderborn	Nordrhein-Westfalen	NW	57
33102	Paderborn	Nordrhein-Westfalen	NW	57
33104	Paderborn	Nordrhein-Westfalen	NW	57
33106	Paderborn	Nordrhein-Westfalen	NW	57
33129	Delbrück	Nordrhein-Westfalen	NW	57
33142	Büren	Nordrhein-Westfalen	NW	57
33154	Salzkotten	Nordrhein-Westfalen	NW	57
33161	Hövelhof	Nordrhein-Westfalen	NW	57
33165	Lichtenau	Nordrhein-Westfalen	NW	57
33175	Bad Lippspringe	Nordrhein-Westfalen	NW	57
33178	Borchen	Nordrhein-Westfalen	NW	57
33181	Bad Wünnenberg	Nordrhein-Westfalen	NW	57
33184	Altenbeken	Nordrhein-Westfalen	NW	57
33189	Schlangen	Nordrhein-Westfalen	NW	57
33311	Gütersloh	Nordrhein-Westfalen	NW	57
33330	Gütersloh	Nordrhein-Westfalen	NW	57
33332	Gütersloh	Nordrhein-Westfalen	NW	57
33334	Gütersloh	Nordrhein-Westfalen	NW	57
33335	Gütersloh	Nordrhein-Westfalen	NW	57
33378	Rheda-Wiedenbrück	Nordrhein-Westfalen	NW	57
33397	Rietberg	Nordrhein-Westfalen	NW	57
33415	Verl	Nordrhein-Westfalen	NW	57
33428	Harsewinkel	Nordrhein-Westfalen	NW	57
33442	Herzebrock-Clarholz	Nordrhein-Westfalen	NW	57
33449	Langenberg	Nordrhein-Westfalen	NW	57
33519	Bielefeld	Nordrhein-Westfalen	NW	57
33602	Bielefeld	Nordrhein-Westfalen	NW	57
33604	Bielefeld	Nordrhein-Westfalen	NW	57
33605	Bielefeld	Nordrhein-Westfalen	NW	57
33607	Bielefeld	Nordrhein-Westfalen	NW	57
33609	Bielefeld	Nordrhein-Westfalen	NW	57
33611	Bielefeld	Nordrhein-Westfalen	NW	57
33613	Bielefeld	Nordrhein-Westfalen	NW	57
33615	Bielefeld	Nordrhein-Westfalen	NW	57
33617	Bielefeld	Nordrhein-Westfalen	NW	57
33619	Bielefeld	Nordrhein-Westfalen	NW	57
33647	Bielefeld	Nordrhein-Westfalen	NW	57
33649	Bielefeld	Nordrhein-Westfalen	NW	57
33659	Bielefeld	Nordrhein-Westfalen	NW	57
33689	Bielefeld	Nordrhein-Westfalen	NW	57
33699	Bielefeld	Nordrhein-Westfalen	NW	57
33719	Bielefeld	Nordrhein-Westfalen	NW	57
33729	Bielefeld	Nordrhein-Westfalen	NW	57
33739	Bielefeld	Nordrhein-Westfalen	NW	57
33758	Schloß Holte-Stukenbrock	Nordrhein-Westfalen	NW	57
33775	Versmold	Nordrhein-Westfalen	NW	57
33790	Halle	Nordrhein-Westfalen	NW	57
33803	Steinhagen	Nordrhein-Westfalen	NW	57
33813	Oerlinghausen	Nordrhein-Westfalen	NW	57
33818	Leopoldshöhe	Nordrhein-Westfalen	NW	57
33824	Werther	Nordrhein-Westfalen	NW	57
33829	Borgholzhausen	Nordrhein-Westfalen	NW	57
34414	Warburg	Nordrhein-Westfalen	NW	57
34434	Borgentreich	Nordrhein-Westfalen	NW	57
34439	Willebadessen	Nordrhein-Westfalen	NW	57
37671	Höxter	Nordrhein-Westfalen	NW	57
37688	Beverungen	Nordrhein-Westfalen	NW	57
37696	Marienmünster	Nordrhein-Westfalen	NW	57
34431	Marsberg	Nordrhein-Westfalen	NW	59
44135	Dortmund	Nordrhein-Westfalen	NW	59
44137	Dortmund	Nordrhein-Westfalen	NW	59
44139	Dortmund	Nordrhein-Westfalen	NW	59
44141	Dortmund	Nordrhein-Westfalen	NW	59
44143	Dortmund	Nordrhein-Westfalen	NW	59
44145	Dortmund	Nordrhein-Westfalen	NW	59
44147	Dortmund	Nordrhein-Westfalen	NW	59
44149	Dortmund	Nordrhein-Westfalen	NW	59
44225	Dortmund	Nordrhein-Westfalen	NW	59
44227	Dortmund	Nordrhein-Westfalen	NW	59
44229	Dortmund	Nordrhein-Westfalen	NW	59
44263	Dortmund	Nordrhein-Westfalen	NW	59
44265	Dortmund	Nordrhein-Westfalen	NW	59
44267	Dortmund	Nordrhein-Westfalen	NW	59
44269	Dortmund	Nordrhein-Westfalen	NW	59
44287	Dortmund	Nordrhein-Westfalen	NW	59
44289	Dortmund	Nordrhein-Westfalen	NW	59
44309	Dortmund	Nordrhein-Westfalen	NW	59
44319	Dortmund	Nordrhein-Westfalen	NW	59
44328	Dortmund	Nordrhein-Westfalen	NW	59
44329	Dortmund	Nordrhein-Westfalen	NW	59
44339	Dortmund	Nordrhein-Westfalen	NW	59
44357	Dortmund	Nordrhein-Westfalen	NW	59
44359	Dortmund	Nordrhein-Westfalen	NW	59
44369	Dortmund	Nordrhein-Westfalen	NW	59
44379	Dortmund	Nordrhein-Westfalen	NW	59
44388	Dortmund	Nordrhein-Westfalen	NW	59
44532	Lünen	Nordrhein-Westfalen	NW	59
44534	Lünen	Nordrhein-Westfalen	NW	59
44536	Lünen	Nordrhein-Westfalen	NW	59
44623	Herne	Nordrhein-Westfalen	NW	59
44625	Herne	Nordrhein-Westfalen	NW	59
44627	Herne	Nordrhein-Westfalen	NW	59
44628	Herne	Nordrhein-Westfalen	NW	59
44629	Herne	Nordrhein-Westfalen	NW	59
44649	Herne	Nordrhein-Westfalen	NW	59
44651	Herne	Nordrhein-Westfalen	NW	59
44652	Herne	Nordrhein-Westfalen	NW	59
44653	Herne	Nordrhein-Westfalen	NW	59
44787	Bochum	Nordrhein-Westfalen	NW	59
44789	Bochum	Nordrhein-Westfalen	NW	59
44791	Bochum	Nordrhein-Westfalen	NW	59
44793	Bochum	Nordrhein-Westfalen	NW	59
44795	Bochum	Nordrhein-Westfalen	NW	59
44797	Bochum	Nordrhein-Westfalen	NW	59
44799	Bochum	Nordrhein-Westfalen	NW	59
44801	Bochum	Nordrhein-Westfalen	NW	59
44803	Bochum	Nordrhein-Westfalen	NW	59
44805	Bochum	Nordrhein-Westfalen	NW	59
44807	Bochum	Nordrhein-Westfalen	NW	59
44809	Bochum	Nordrhein-Westfalen	NW	59
44866	Bochum	Nordrhein-Westfalen	NW	59
44867	Bochum	Nordrhein-Westfalen	NW	59
44869	Bochum	Nordrhein-Westfalen	NW	59
44879	Bochum	Nordrhein-Westfalen	NW	59
44892	Bochum	Nordrhein-Westfalen	NW	59
44894	Bochum	Nordrhein-Westfalen	NW	59
45525	Hattingen	Nordrhein-Westfalen	NW	59
45527	Hattingen	Nordrhein-Westfalen	NW	59
45529	Hattingen	Nordrhein-Westfalen	NW	59
45549	Sprockhövel	Nordrhein-Westfalen	NW	59
57072	Siegen	Nordrhein-Westfalen	NW	59
57074	Siegen	Nordrhein-Westfalen	NW	59
57076	Siegen	Nordrhein-Westfalen	NW	59
57078	Siegen	Nordrhein-Westfalen	NW	59
57080	Siegen	Nordrhein-Westfalen	NW	59
57223	Kreuztal	Nordrhein-Westfalen	NW	59
57234	Wilnsdorf	Nordrhein-Westfalen	NW	59
57250	Netphen	Nordrhein-Westfalen	NW	59
57258	Freudenberg	Nordrhein-Westfalen	NW	59
57271	Hilchenbach	Nordrhein-Westfalen	NW	59
57290	Neunkirchen	Nordrhein-Westfalen	NW	59
57299	Burbach	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Rinthe	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Berghausen	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Sassenhausen	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Elsoff	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Dotzlar	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Wemlighausen	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Girkhausen	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Wunderthausen	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Arfeld	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Hemschlar	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Diedenshausen	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Schüllar	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Alertshausen	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Schwarzenau	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Stünzel	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Richstein	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Raumland	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Bad Berleburg	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Beddelhausen	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Wingeshausen	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Aue	Nordrhein-Westfalen	NW	59
57319	Bad Berleburg Weidenhausen	Nordrhein-Westfalen	NW	59
57334	Bad Laasphe	Nordrhein-Westfalen	NW	59
57339	Erndtebrück	Nordrhein-Westfalen	NW	59
57368	Lennestadt	Nordrhein-Westfalen	NW	59
57392	Schmallenberg	Nordrhein-Westfalen	NW	59
57399	Kirchhundem	Nordrhein-Westfalen	NW	59
57413	Finnentrop	Nordrhein-Westfalen	NW	59
57439	Attendorn	Nordrhein-Westfalen	NW	59
57462	Olpe	Nordrhein-Westfalen	NW	59
57482	Wenden	Nordrhein-Westfalen	NW	59
57489	Drolshagen	Nordrhein-Westfalen	NW	59
58089	Hagen	Nordrhein-Westfalen	NW	59
58091	Hagen	Nordrhein-Westfalen	NW	59
58093	Hagen	Nordrhein-Westfalen	NW	59
58095	Hagen	Nordrhein-Westfalen	NW	59
58097	Hagen	Nordrhein-Westfalen	NW	59
58099	Hagen	Nordrhein-Westfalen	NW	59
58119	Hagen	Nordrhein-Westfalen	NW	59
58135	Hagen	Nordrhein-Westfalen	NW	59
58239	Schwerte	Nordrhein-Westfalen	NW	59
58256	Ennepetal	Nordrhein-Westfalen	NW	59
58285	Gevelsberg	Nordrhein-Westfalen	NW	59
58300	Wetter (Ruhr)	Nordrhein-Westfalen	NW	59
58313	Herdecke	Nordrhein-Westfalen	NW	59
58332	Schwelm	Nordrhein-Westfalen	NW	59
58339	Breckerfeld	Nordrhein-Westfalen	NW	59
58452	Witten	Nordrhein-Westfalen	NW	59
58453	Witten	Nordrhein-Westfalen	NW	59
58454	Witten	Nordrhein-Westfalen	NW	59
58455	Witten	Nordrhein-Westfalen	NW	59
58456	Witten	Nordrhein-Westfalen	NW	59
58507	Lüdenscheid	Nordrhein-Westfalen	NW	59
58509	Lüdenscheid	Nordrhein-Westfalen	NW	59
58511	Lüdenscheid	Nordrhein-Westfalen	NW	59
58513	Lüdenscheid	Nordrhein-Westfalen	NW	59
58515	Lüdenscheid	Nordrhein-Westfalen	NW	59
58540	Meinerzhagen	Nordrhein-Westfalen	NW	59
58553	Halver	Nordrhein-Westfalen	NW	59
58566	Kierspe	Nordrhein-Westfalen	NW	59
58579	Schalksmühle	Nordrhein-Westfalen	NW	59
58636	Iserlohn	Nordrhein-Westfalen	NW	59
58638	Iserlohn	Nordrhein-Westfalen	NW	59
58640	Iserlohn	Nordrhein-Westfalen	NW	59
58642	Iserlohn	Nordrhein-Westfalen	NW	59
58644	Iserlohn	Nordrhein-Westfalen	NW	59
58675	Hemer	Nordrhein-Westfalen	NW	59
58706	Menden	Nordrhein-Westfalen	NW	59
58708	Menden	Nordrhein-Westfalen	NW	59
58710	Menden	Nordrhein-Westfalen	NW	59
58730	Fröndenberg	Nordrhein-Westfalen	NW	59
58739	Wickede	Nordrhein-Westfalen	NW	59
58762	Altena	Nordrhein-Westfalen	NW	59
58769	Nachrodt-Wiblingwerde	Nordrhein-Westfalen	NW	59
58791	Werdohl	Nordrhein-Westfalen	NW	59
58802	Balve	Nordrhein-Westfalen	NW	59
58809	Neuenrade	Nordrhein-Westfalen	NW	59
58840	Plettenberg	Nordrhein-Westfalen	NW	59
58849	Herscheid	Nordrhein-Westfalen	NW	59
59063	Hamm	Nordrhein-Westfalen	NW	59
59065	Hamm	Nordrhein-Westfalen	NW	59
59067	Hamm	Nordrhein-Westfalen	NW	59
59069	Hamm	Nordrhein-Westfalen	NW	59
59071	Hamm	Nordrhein-Westfalen	NW	59
59073	Hamm	Nordrhein-Westfalen	NW	59
59075	Hamm	Nordrhein-Westfalen	NW	59
59077	Hamm	Nordrhein-Westfalen	NW	59
59174	Kamen	Nordrhein-Westfalen	NW	59
59192	Bergkamen	Nordrhein-Westfalen	NW	59
59199	Bönen	Nordrhein-Westfalen	NW	59
59368	Werne	Nordrhein-Westfalen	NW	59
59379	Selm	Nordrhein-Westfalen	NW	59
59423	Unna	Nordrhein-Westfalen	NW	59
59425	Unna	Nordrhein-Westfalen	NW	59
59427	Unna	Nordrhein-Westfalen	NW	59
59439	Holzwickede	Nordrhein-Westfalen	NW	59
59457	Werl	Nordrhein-Westfalen	NW	59
59469	Ense	Nordrhein-Westfalen	NW	59
59494	Soest	Nordrhein-Westfalen	NW	59
59505	Bad Sassendorf	Nordrhein-Westfalen	NW	59
59510	Lippetal	Nordrhein-Westfalen	NW	59
59514	Welver	Nordrhein-Westfalen	NW	59
59519	Möhnesee	Nordrhein-Westfalen	NW	59
59555	Lippstadt	Nordrhein-Westfalen	NW	59
59556	Lippstadt	Nordrhein-Westfalen	NW	59
59557	Lippstadt	Nordrhein-Westfalen	NW	59
59558	Lippstadt	Nordrhein-Westfalen	NW	59
59581	Warstein	Nordrhein-Westfalen	NW	59
59590	Geseke	Nordrhein-Westfalen	NW	59
59597	Erwitte	Nordrhein-Westfalen	NW	59
59602	Rüthen	Nordrhein-Westfalen	NW	59
59609	Anröchte	Nordrhein-Westfalen	NW	59
59755	Arnsberg	Nordrhein-Westfalen	NW	59
59757	Arnsberg	Nordrhein-Westfalen	NW	59
59759	Arnsberg	Nordrhein-Westfalen	NW	59
59821	Arnsberg	Nordrhein-Westfalen	NW	59
59823	Arnsberg	Nordrhein-Westfalen	NW	59
59846	Sundern	Nordrhein-Westfalen	NW	59
59872	Meschede	Nordrhein-Westfalen	NW	59
59889	Eslohe	Nordrhein-Westfalen	NW	59
59909	Bestwig	Nordrhein-Westfalen	NW	59
59929	Brilon	Nordrhein-Westfalen	NW	59
59939	Olsberg	Nordrhein-Westfalen	NW	59
59955	Winterberg	Nordrhein-Westfalen	NW	59
59964	Medebach	Nordrhein-Westfalen	NW	59
59969	Hallenberg	Nordrhein-Westfalen	NW	59
51598	Friesenhagen	Rheinland-Pfalz	RP	Altenkirchen
53424	Remagen	Rheinland-Pfalz	RP	Ahrweiler
53426	Königsfeld	Rheinland-Pfalz	RP	Ahrweiler
53426	Dedenbach	Rheinland-Pfalz	RP	Ahrweiler
53426	Schalkenbach	Rheinland-Pfalz	RP	Ahrweiler
53474	Bad Neuenahr-Ahrweiler	Rheinland-Pfalz	RP	Ahrweiler
53489	Sinzig	Rheinland-Pfalz	RP	Ahrweiler
53498	Bad Breisig	Rheinland-Pfalz	RP	Ahrweiler
53498	Waldorf	Rheinland-Pfalz	RP	Ahrweiler
53498	Gönnersdorf	Rheinland-Pfalz	RP	Ahrweiler
53501	Grafschaft	Rheinland-Pfalz	RP	Ahrweiler
53505	Altenahr	Rheinland-Pfalz	RP	Ahrweiler
53505	Kalenborn	Rheinland-Pfalz	RP	Ahrweiler
53505	Kirchsahr	Rheinland-Pfalz	RP	Ahrweiler
53505	Berg	Rheinland-Pfalz	RP	Ahrweiler
53506	Heckenbach	Rheinland-Pfalz	RP	Ahrweiler
53506	Ahrbrück	Rheinland-Pfalz	RP	Ahrweiler
53506	Hönningen	Rheinland-Pfalz	RP	Ahrweiler
53506	Lind	Rheinland-Pfalz	RP	Ahrweiler
53506	Rech	Rheinland-Pfalz	RP	Ahrweiler
53506	Kesseling	Rheinland-Pfalz	RP	Ahrweiler
53507	Dernau	Rheinland-Pfalz	RP	Ahrweiler
53508	Mayschoß	Rheinland-Pfalz	RP	Ahrweiler
53518	Kottenborn	Rheinland-Pfalz	RP	Ahrweiler
53518	Herschbroich	Rheinland-Pfalz	RP	Ahrweiler
53518	Leimbach	Rheinland-Pfalz	RP	Ahrweiler
53518	Quiddelbach	Rheinland-Pfalz	RP	Ahrweiler
53518	Adenau	Rheinland-Pfalz	RP	Ahrweiler
53518	Welcherath	Rheinland-Pfalz	RP	Vulkaneifel
53518	Wimbach	Rheinland-Pfalz	RP	Ahrweiler
53518	Honerath	Rheinland-Pfalz	RP	Ahrweiler
53520	Hümmel	Rheinland-Pfalz	RP	Ahrweiler
53520	Harscheid	Rheinland-Pfalz	RP	Ahrweiler
53520	Kaltenborn	Rheinland-Pfalz	RP	Ahrweiler
53520	Winnerath	Rheinland-Pfalz	RP	Ahrweiler
53520	Drees	Rheinland-Pfalz	RP	Vulkaneifel
53520	Sierscheid	Rheinland-Pfalz	RP	Ahrweiler
53520	Insul	Rheinland-Pfalz	RP	Ahrweiler
53520	Meuspath	Rheinland-Pfalz	RP	Ahrweiler
53520	Ohlenhard	Rheinland-Pfalz	RP	Ahrweiler
53520	Reifferscheid	Rheinland-Pfalz	RP	Ahrweiler
53520	Senscheid	Rheinland-Pfalz	RP	Ahrweiler
53520	Müllenbach	Rheinland-Pfalz	RP	Ahrweiler
53520	Schuld	Rheinland-Pfalz	RP	Ahrweiler
53520	Rodder	Rheinland-Pfalz	RP	Ahrweiler
53520	Trierscheid	Rheinland-Pfalz	RP	Ahrweiler
53520	Dankerath	Rheinland-Pfalz	RP	Ahrweiler
53520	Wershofen	Rheinland-Pfalz	RP	Ahrweiler
53520	Dümpelfeld	Rheinland-Pfalz	RP	Ahrweiler
53520	Nürburg	Rheinland-Pfalz	RP	Ahrweiler
53533	Antweiler	Rheinland-Pfalz	RP	Ahrweiler
53533	Müsch	Rheinland-Pfalz	RP	Ahrweiler
53533	Aremberg	Rheinland-Pfalz	RP	Ahrweiler
53533	Fuchshofen	Rheinland-Pfalz	RP	Ahrweiler
53533	Eichenbach	Rheinland-Pfalz	RP	Ahrweiler
53533	Dorsel	Rheinland-Pfalz	RP	Ahrweiler
53534	Barweiler	Rheinland-Pfalz	RP	Ahrweiler
53534	Wirft	Rheinland-Pfalz	RP	Ahrweiler
53534	Wiesemscheid	Rheinland-Pfalz	RP	Ahrweiler
53534	Bauler	Rheinland-Pfalz	RP	Ahrweiler
53534	Hoffeld	Rheinland-Pfalz	RP	Ahrweiler
53534	Pomster	Rheinland-Pfalz	RP	Ahrweiler
53539	Bodenbach	Rheinland-Pfalz	RP	Vulkaneifel
53539	Gelenberg	Rheinland-Pfalz	RP	Vulkaneifel
53539	Brücktal	Rheinland-Pfalz	RP	Vulkaneifel
53539	Kirsbach	Rheinland-Pfalz	RP	Vulkaneifel
53539	Reimerath	Rheinland-Pfalz	RP	Vulkaneifel
53539	Kelberg	Rheinland-Pfalz	RP	Vulkaneifel
53539	Bongard	Rheinland-Pfalz	RP	Vulkaneifel
53539	Borler	Rheinland-Pfalz	RP	Vulkaneifel
53545	Linz am Rhein	Rheinland-Pfalz	RP	Neuwied
53545	Ockenfels	Rheinland-Pfalz	RP	Neuwied
53547	Dattenberg	Rheinland-Pfalz	RP	Neuwied
53547	Leubsdorf	Rheinland-Pfalz	RP	Neuwied
53547	Kasbach-Ohlenberg	Rheinland-Pfalz	RP	Neuwied
53547	Roßbach	Rheinland-Pfalz	RP	Neuwied
53547	Hümmerich	Rheinland-Pfalz	RP	Neuwied
53547	Breitscheid	Rheinland-Pfalz	RP	Neuwied
53547	Hausen (Wied)	Rheinland-Pfalz	RP	Neuwied
53557	Bad Hönningen	Rheinland-Pfalz	RP	Neuwied
53560	Vettelschoß	Rheinland-Pfalz	RP	Neuwied
53562	Sankt Katharinen	Rheinland-Pfalz	RP	Neuwied
53567	Asbach	Rheinland-Pfalz	RP	Neuwied
53567	Buchholz (Westerwald)	Rheinland-Pfalz	RP	Neuwied
53572	Unkel	Rheinland-Pfalz	RP	Neuwied
53572	Bruchhausen	Rheinland-Pfalz	RP	Neuwied
53577	Neustadt (Wied)	Rheinland-Pfalz	RP	Neuwied
53578	Windhagen	Rheinland-Pfalz	RP	Neuwied
53579	Erpel	Rheinland-Pfalz	RP	Neuwied
53619	Rheinbreitbach	Rheinland-Pfalz	RP	Neuwied
54290	Trier	Rheinland-Pfalz	RP	Trier;
54292	Trier	Rheinland-Pfalz	RP	Trier;
54293	Trier	Rheinland-Pfalz	RP	Trier;
54294	Trier	Rheinland-Pfalz	RP	Trier;
54295	Trier	Rheinland-Pfalz	RP	Trier;
54296	Trier	Rheinland-Pfalz	RP	Trier;
54298	Igel	Rheinland-Pfalz	RP	Trier-Saarburg
54298	Orenhofen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54298	Aach	Rheinland-Pfalz	RP	Trier-Saarburg
54298	Eisenach	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54298	Greimerath	Rheinland-Pfalz	RP	Trier-Saarburg
54298	Gilzem	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54298	Welschbillig	Rheinland-Pfalz	RP	Trier-Saarburg
54306	Kordel	Rheinland-Pfalz	RP	Trier-Saarburg
54308	Langsur	Rheinland-Pfalz	RP	Trier-Saarburg
54309	Newel	Rheinland-Pfalz	RP	Trier-Saarburg
54310	Ralingen an der Sauer	Rheinland-Pfalz	RP	Trier-Saarburg
54310	Menningen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54310	Minden	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54311	Trierweiler	Rheinland-Pfalz	RP	Trier-Saarburg
54313	Zemmer	Rheinland-Pfalz	RP	Trier-Saarburg
54314	Paschel	Rheinland-Pfalz	RP	Trier-Saarburg
54314	Hentern	Rheinland-Pfalz	RP	Trier-Saarburg
54314	Vierherrenborn	Rheinland-Pfalz	RP	Trier-Saarburg
54314	Schömerich	Rheinland-Pfalz	RP	Trier-Saarburg
54314	Baldringen	Rheinland-Pfalz	RP	Trier-Saarburg
54314	Zerf	Rheinland-Pfalz	RP	Trier-Saarburg
54316	Holzerath	Rheinland-Pfalz	RP	Trier-Saarburg
54316	Lampaden	Rheinland-Pfalz	RP	Trier-Saarburg
54316	Hinzenburg	Rheinland-Pfalz	RP	Trier-Saarburg
54316	Schöndorf	Rheinland-Pfalz	RP	Trier-Saarburg
54316	Pluwig	Rheinland-Pfalz	RP	Trier-Saarburg
54316	Hockweiler	Rheinland-Pfalz	RP	Trier-Saarburg
54316	Franzenheim	Rheinland-Pfalz	RP	Trier-Saarburg
54316	Bonerath	Rheinland-Pfalz	RP	Trier-Saarburg
54316	Ollmuth	Rheinland-Pfalz	RP	Trier-Saarburg
54317	Thomm	Rheinland-Pfalz	RP	Trier-Saarburg
54317	Riveris	Rheinland-Pfalz	RP	Trier-Saarburg
54317	Gusterath	Rheinland-Pfalz	RP	Trier-Saarburg
54317	Herl	Rheinland-Pfalz	RP	Trier-Saarburg
54317	Sommerau	Rheinland-Pfalz	RP	Trier-Saarburg
54317	Korlingen	Rheinland-Pfalz	RP	Trier-Saarburg
54317	Morscheid	Rheinland-Pfalz	RP	Trier-Saarburg
54317	Gutweiler	Rheinland-Pfalz	RP	Trier-Saarburg
54317	Farschweiler	Rheinland-Pfalz	RP	Trier-Saarburg
54317	Osburg	Rheinland-Pfalz	RP	Trier-Saarburg
54317	Lorscheid	Rheinland-Pfalz	RP	Trier-Saarburg
54317	Kasel	Rheinland-Pfalz	RP	Trier-Saarburg
54318	Mertesdorf	Rheinland-Pfalz	RP	Trier-Saarburg
54320	Waldrach	Rheinland-Pfalz	RP	Trier-Saarburg
54329	Konz	Rheinland-Pfalz	RP	Trier-Saarburg
54331	Pellingen	Rheinland-Pfalz	RP	Trier-Saarburg
54331	Oberbillig	Rheinland-Pfalz	RP	Trier-Saarburg
54332	Wasserliesch	Rheinland-Pfalz	RP	Trier-Saarburg
54338	Schweich	Rheinland-Pfalz	RP	Trier-Saarburg
54338	Longen	Rheinland-Pfalz	RP	Trier-Saarburg
54340	Ensch	Rheinland-Pfalz	RP	Trier-Saarburg
54340	Detzem	Rheinland-Pfalz	RP	Trier-Saarburg
54340	Pölich	Rheinland-Pfalz	RP	Trier-Saarburg
54340	Schleich	Rheinland-Pfalz	RP	Trier-Saarburg
54340	Riol	Rheinland-Pfalz	RP	Trier-Saarburg
54340	Köwerich	Rheinland-Pfalz	RP	Trier-Saarburg
54340	Naurath (Eifel)	Rheinland-Pfalz	RP	Trier-Saarburg
54340	Longuich	Rheinland-Pfalz	RP	Trier-Saarburg
54340	Leiwen	Rheinland-Pfalz	RP	Trier-Saarburg
54340	Bekond	Rheinland-Pfalz	RP	Trier-Saarburg
54340	Thörnich	Rheinland-Pfalz	RP	Trier-Saarburg
54340	Klüsserath	Rheinland-Pfalz	RP	Trier-Saarburg
54341	Fell	Rheinland-Pfalz	RP	Trier-Saarburg
54343	Föhren	Rheinland-Pfalz	RP	Trier-Saarburg
54344	Kenn	Rheinland-Pfalz	RP	Trier-Saarburg
54346	Mehring	Rheinland-Pfalz	RP	Trier-Saarburg
54347	Neumagen-Dhron	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54349	Trittenheim	Rheinland-Pfalz	RP	Trier-Saarburg
54411	Hermeskeil	Rheinland-Pfalz	RP	Trier-Saarburg
54411	Rorodt	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54411	Deuselbach	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54413	Gusenburg	Rheinland-Pfalz	RP	Trier-Saarburg
54413	Beuren (Hochwald)	Rheinland-Pfalz	RP	Trier-Saarburg
54413	Rascheid	Rheinland-Pfalz	RP	Trier-Saarburg
54413	Damflos	Rheinland-Pfalz	RP	Trier-Saarburg
54413	Grimburg	Rheinland-Pfalz	RP	Trier-Saarburg
54413	Geisfeld	Rheinland-Pfalz	RP	Trier-Saarburg
54413	Bescheid	Rheinland-Pfalz	RP	Trier-Saarburg
54421	Reinsfeld	Rheinland-Pfalz	RP	Trier-Saarburg
54421	Hinzert-Pölert	Rheinland-Pfalz	RP	Trier-Saarburg
54422	Börfink	Rheinland-Pfalz	RP	Birkenfeld
54422	Neuhütten	Rheinland-Pfalz	RP	Trier-Saarburg
54422	Züsch	Rheinland-Pfalz	RP	Trier-Saarburg
54424	Gielert	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54424	Burtscheid	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54424	Thalfang	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54424	Etgert	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54424	Lückenburg	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54426	Breit	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54426	Hilscheid	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54426	Neunkirchen	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54426	Büdlich	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54426	Gräfendhron	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54426	Heidenburg	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54426	Talling	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54426	Berglicht	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54426	Schönberg	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54426	Malborn	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54426	Immert	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54426	Naurath	Rheinland-Pfalz	RP	Trier-Saarburg
54426	Dhronecken	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54426	Merschbach	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54427	Kell am See	Rheinland-Pfalz	RP	Trier-Saarburg
54429	Heddert	Rheinland-Pfalz	RP	Trier-Saarburg
54429	Schillingen	Rheinland-Pfalz	RP	Trier-Saarburg
54429	Mandern	Rheinland-Pfalz	RP	Trier-Saarburg
54429	Waldweiler	Rheinland-Pfalz	RP	Trier-Saarburg
66871	Körborn	Rheinland-Pfalz	RP	Kusel
54439	Merzkirchen	Rheinland-Pfalz	RP	Trier-Saarburg
54439	Fisch	Rheinland-Pfalz	RP	Trier-Saarburg
54439	Palzem	Rheinland-Pfalz	RP	Trier-Saarburg
54439	Saarburg	Rheinland-Pfalz	RP	Trier-Saarburg
54441	Schoden	Rheinland-Pfalz	RP	Trier-Saarburg
54441	Kirf	Rheinland-Pfalz	RP	Trier-Saarburg
54441	Kastel-Staadt	Rheinland-Pfalz	RP	Trier-Saarburg
54441	Wellen	Rheinland-Pfalz	RP	Trier-Saarburg
54441	Wawern	Rheinland-Pfalz	RP	Trier-Saarburg
54441	Mannebach	Rheinland-Pfalz	RP	Trier-Saarburg
54441	Ockfen	Rheinland-Pfalz	RP	Trier-Saarburg
54441	Trassem	Rheinland-Pfalz	RP	Trier-Saarburg
54441	Ayl	Rheinland-Pfalz	RP	Trier-Saarburg
54441	Taben-Rodt	Rheinland-Pfalz	RP	Trier-Saarburg
54441	Temmels	Rheinland-Pfalz	RP	Trier-Saarburg
54441	Kanzem	Rheinland-Pfalz	RP	Trier-Saarburg
54450	Freudenburg	Rheinland-Pfalz	RP	Trier-Saarburg
54451	Irsch	Rheinland-Pfalz	RP	Trier-Saarburg
54453	Nittel	Rheinland-Pfalz	RP	Trier-Saarburg
54455	Serrig	Rheinland-Pfalz	RP	Trier-Saarburg
54456	Onsdorf	Rheinland-Pfalz	RP	Trier-Saarburg
54456	Tawern	Rheinland-Pfalz	RP	Trier-Saarburg
54457	Wincheringen	Rheinland-Pfalz	RP	Trier-Saarburg
54459	Wiltingen	Rheinland-Pfalz	RP	Trier-Saarburg
54470	Bernkastel-Kues	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54470	Lieser	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54470	Graach	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54472	Gornhausen	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54472	Hochscheid	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54472	Brauneberg	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54472	Veldenz	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54472	Kommen	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54472	Monzelfeld	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54472	Burgen	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54472	Longkamp	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54483	Kleinich	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54484	Maring-Noviand	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54486	Mülheim	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54487	Wintrich	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54492	Zeltingen-Rachtig	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54492	Lösnich	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54492	Erden	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54497	Morbach	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54497	Horath	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54498	Piesport	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54516	Wittlich	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54516	Flußbach	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Binsfeld	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Plein	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Bergweiler	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Kesten	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Dreis	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Heckenmünster	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Minheim	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Sehlem	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Altrich	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Osann-Monzel	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Esch	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Hupperath	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Heidweiler	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Platten	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Minderlittgen	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Gladbach	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Bruch	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Dodenburg	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Niersbach	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Rivenich	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54518	Arenrath	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54523	Hetzerath	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54523	Dierscheid	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54524	Klausen	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54526	Landscheid	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54528	Salmtal	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54529	Spangdahlem	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54531	Pantenburg	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54531	Meerfeld	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54531	Eckfeld	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54531	Manderscheid	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54531	Wallscheid	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54533	Niederöfflingen	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54533	Gransdorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54533	Gipperath	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54533	Oberscheidweiler	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54533	Greimerath	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54533	Oberkail	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54533	Willwerscheid	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54533	Oberöfflingen	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54533	Bettenfeld	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54533	Eisenschmitt	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54533	Hasborn	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54533	Dierfeld	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54533	Niederscheidweiler	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54533	Schwarzenborn	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54533	Laufeld	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54534	Musweiler	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54534	Karl	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54534	Großlittgen	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54534	Schladt	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54536	Kröv	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54538	Diefenbach	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54538	Hontheim	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54538	Kinheim	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54538	Bengel	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54538	Kinderbeuern	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54538	Bausendorf	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54539	Ürzig	Rheinland-Pfalz	RP	Bernkastel-Wittlich
54550	Daun	Rheinland-Pfalz	RP	Vulkaneifel
54552	Dreis-Brück	Rheinland-Pfalz	RP	Vulkaneifel
54552	Hörscheid	Rheinland-Pfalz	RP	Vulkaneifel
54552	Strotzbüsch	Rheinland-Pfalz	RP	Vulkaneifel
54552	Katzwinkel	Rheinland-Pfalz	RP	Vulkaneifel
54552	Ellscheid	Rheinland-Pfalz	RP	Vulkaneifel
54552	Nerdlen	Rheinland-Pfalz	RP	Vulkaneifel
54552	Schönbach	Rheinland-Pfalz	RP	Vulkaneifel
54552	Steineberg	Rheinland-Pfalz	RP	Vulkaneifel
54552	Beinhausen	Rheinland-Pfalz	RP	Vulkaneifel
54552	Brockscheid	Rheinland-Pfalz	RP	Vulkaneifel
54552	Demerath	Rheinland-Pfalz	RP	Vulkaneifel
54552	Dockweiler	Rheinland-Pfalz	RP	Vulkaneifel
54552	Udler	Rheinland-Pfalz	RP	Vulkaneifel
54552	Sarmersbach	Rheinland-Pfalz	RP	Vulkaneifel
54552	Mehren	Rheinland-Pfalz	RP	Vulkaneifel
54552	Boxberg	Rheinland-Pfalz	RP	Vulkaneifel
54552	Steiningen	Rheinland-Pfalz	RP	Vulkaneifel
54552	Utzerath	Rheinland-Pfalz	RP	Vulkaneifel
54552	Darscheid	Rheinland-Pfalz	RP	Vulkaneifel
54552	Hörschhausen	Rheinland-Pfalz	RP	Vulkaneifel
54552	Kradenbach	Rheinland-Pfalz	RP	Vulkaneifel
54552	Üdersdorf	Rheinland-Pfalz	RP	Vulkaneifel
54552	Gefell	Rheinland-Pfalz	RP	Vulkaneifel
54552	Neichen	Rheinland-Pfalz	RP	Vulkaneifel
54552	Schalkenmehren	Rheinland-Pfalz	RP	Vulkaneifel
54552	Immerath	Rheinland-Pfalz	RP	Vulkaneifel
54558	Strohn	Rheinland-Pfalz	RP	Vulkaneifel
54558	Mückeln	Rheinland-Pfalz	RP	Vulkaneifel
54558	Saxler	Rheinland-Pfalz	RP	Vulkaneifel
54558	Gillenfeld	Rheinland-Pfalz	RP	Vulkaneifel
54558	Winkel	Rheinland-Pfalz	RP	Vulkaneifel
54568	Gerolstein	Rheinland-Pfalz	RP	Vulkaneifel
54570	Densborn	Rheinland-Pfalz	RP	Vulkaneifel
54570	Kalenborn-Scheuern	Rheinland-Pfalz	RP	Vulkaneifel
54570	Hohenfels-Essingen	Rheinland-Pfalz	RP	Vulkaneifel
54570	Schutz	Rheinland-Pfalz	RP	Vulkaneifel
54570	Wallenborn	Rheinland-Pfalz	RP	Vulkaneifel
54570	Weidenbach	Rheinland-Pfalz	RP	Vulkaneifel
54570	Berlingen	Rheinland-Pfalz	RP	Vulkaneifel
54570	Meisburg	Rheinland-Pfalz	RP	Vulkaneifel
54570	Bleckhausen	Rheinland-Pfalz	RP	Vulkaneifel
54570	Betteldorf	Rheinland-Pfalz	RP	Vulkaneifel
54570	Neroth	Rheinland-Pfalz	RP	Vulkaneifel
54570	Niederstadtfeld	Rheinland-Pfalz	RP	Vulkaneifel
54570	Kirchweiler	Rheinland-Pfalz	RP	Vulkaneifel
54570	Deudesfeld	Rheinland-Pfalz	RP	Vulkaneifel
54570	Mürlenbach	Rheinland-Pfalz	RP	Vulkaneifel
54570	Rockeskyll	Rheinland-Pfalz	RP	Vulkaneifel
54570	Oberstadtfeld	Rheinland-Pfalz	RP	Vulkaneifel
54570	Hinterweiler	Rheinland-Pfalz	RP	Vulkaneifel
54570	Salm	Rheinland-Pfalz	RP	Vulkaneifel
54570	Pelm	Rheinland-Pfalz	RP	Vulkaneifel
54574	Kopp	Rheinland-Pfalz	RP	Vulkaneifel
54574	Birresborn	Rheinland-Pfalz	RP	Vulkaneifel
54576	Hillesheim	Rheinland-Pfalz	RP	Vulkaneifel
54576	Dohm-Lammersdorf	Rheinland-Pfalz	RP	Vulkaneifel
54578	Nohn	Rheinland-Pfalz	RP	Vulkaneifel
54578	Basberg	Rheinland-Pfalz	RP	Vulkaneifel
54578	Walsdorf	Rheinland-Pfalz	RP	Vulkaneifel
54578	Wiesbaum	Rheinland-Pfalz	RP	Vulkaneifel
54578	Kerpen	Rheinland-Pfalz	RP	Vulkaneifel
54578	Oberbettingen	Rheinland-Pfalz	RP	Vulkaneifel
54578	Oberehe-Stroheich	Rheinland-Pfalz	RP	Vulkaneifel
54578	Berndorf	Rheinland-Pfalz	RP	Vulkaneifel
54579	Üxheim	Rheinland-Pfalz	RP	Vulkaneifel
54584	Jünkerath	Rheinland-Pfalz	RP	Vulkaneifel
54584	Feusdorf	Rheinland-Pfalz	RP	Vulkaneifel
54584	Gönnersdorf	Rheinland-Pfalz	RP	Vulkaneifel
54585	Esch	Rheinland-Pfalz	RP	Vulkaneifel
54586	Schüller	Rheinland-Pfalz	RP	Vulkaneifel
54587	Lissendorf	Rheinland-Pfalz	RP	Vulkaneifel
54587	Birgel	Rheinland-Pfalz	RP	Vulkaneifel
54589	Stadtkyll	Rheinland-Pfalz	RP	Vulkaneifel
54589	Kerschenbach	Rheinland-Pfalz	RP	Vulkaneifel
54595	Prüm	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54595	Pittenbach	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54595	Weinsheim	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54595	Watzerath	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54595	Orlenbach	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54595	Gondenbrett	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Lascheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Neuendorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Plütscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Ormont	Rheinland-Pfalz	RP	Vulkaneifel
54597	Merlscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Olzheim	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Wallersheim	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Reuth	Rheinland-Pfalz	RP	Vulkaneifel
54597	Seiwerath	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Rommersheim	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Burbach	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Schwirzheim	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Habscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Balesfeld	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Pronsfeld	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Duppach	Rheinland-Pfalz	RP	Vulkaneifel
54597	Lierfeld	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Kleinlangenfeld	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Feuerscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Strickscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Lünebach	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Auw bei Prüm	Rheinland-Pfalz	RP	Vulkaneifel
54597	Roth	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Steffeln	Rheinland-Pfalz	RP	Vulkaneifel
54597	Matzerath	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Fleringen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Euscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Kinzenburg	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Neuheilenbach	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Masthorn	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54597	Hersdorf	Rheinland-Pfalz	RP	Vulkaneifel
54608	Brandscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54608	Mützenich	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54608	Winterscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54608	Sellerich	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54608	Buchet	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54608	Oberlascheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54608	Bleialf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54608	Großlangenfeld	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54610	Büdesheim	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54611	Scheid	Rheinland-Pfalz	RP	Vulkaneifel
54611	Hallschlag	Rheinland-Pfalz	RP	Vulkaneifel
54612	Lasel	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54612	Wawern	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54612	Nimshuscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54614	Giesdorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54614	Oberlauch	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54614	Schönecken	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54614	Nimsreuland	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54614	Heisdorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54614	Niederlauch	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54614	Winringen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54614	Dingdorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54616	Winterspelt	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54617	Sevenig (Our)	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54617	Lützkampen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54617	Harspelt	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54619	Herzfeld	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54619	Lichtenborn	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54619	Leidenborn	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54619	Heckhuscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54619	Sengerich	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54619	Roscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54619	Kesfeld	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54619	Großkampenberg	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54619	Reiff	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54619	Eschfeld	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54619	Üttfeld	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54634	Niederstedem	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54634	Oberstedem	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54634	Bitburg	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54634	Birtlingen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54634	Metterich	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Heilenbach	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Ehlenz	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Niederweiler	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Wißmannsdorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Feilsdorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Nattenheim	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Seffern	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Röhl	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Rittersdorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Idesheim	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Eßlingen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Oberweiler	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Brecht	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Scharfbillig	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Hütterscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Trimport	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Hüttingen an der Kyll	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Schleid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Meckel	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Weidingen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Sülm	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Ingendorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Hamm	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Mülbach	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Oberweis	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Sefferweich	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Ließem	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Altscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Dahlem	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Fließem	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Bickendorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Messerich	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Biersdorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Wiersdorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Echtershausen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Baustert	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Dockendorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54636	Wolsfeld	Rheinland-Pfalz	RP	EifelBitburg-Prüm
2826	Görlitz	Sachsen	SN	Görlitz
54636	Idenheim	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54646	Brimingen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54646	Niehl	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54646	Burg	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54646	Hisel	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54646	Halsdorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54646	Enzen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54646	Olsdorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54646	Stockem	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54646	Wettlingen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54646	Bettingen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54647	Dudeldorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54647	Gondorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54647	Pickließem	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54649	Waxweiler	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54649	Lauperath	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54649	Eilscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54649	Pintesfeld	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54649	Manderscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54649	Mauel	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54649	Hargarten	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54649	Dackscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54649	Niederpierscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54649	Oberpierscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54649	Lambertsberg	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54655	Kyllburgweiler	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54655	Wilsecker	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54655	Etteldorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54655	Steinborn	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54655	Malbergweich	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54655	Orsfeld	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54655	Seinsfeld	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54655	Kyllburg	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54655	Sankt Thomas	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54655	Zendscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54655	Usch	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54655	Malberg	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54657	Gindorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54657	Neidenbach	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54657	Badem	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54662	Herforst	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54662	Philippsheim	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54662	Beilingen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54662	Speicher	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54664	Auw an der Kyll	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54664	Preist	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54664	Hosten	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54666	Irrel	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54668	Prümzurlay	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54668	Kaschenbach	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54668	Niederweis	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54668	Alsdorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54668	Ernzen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54668	Schankweiler	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54668	Ferschweiler	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54668	Echternacherbrück	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54668	Holsthum	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54668	Peffingen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54669	Bollendorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Zweifelscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Berkoth	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Herbstmühle	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Karlshausen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Rodershausen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Dauwelshausen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Keppeshausen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Scheuern	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Bauler	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Emmelbaum	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Krautscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Muxerath	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Gemünd	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Hütten	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Neuerburg	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Plascheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Burscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Berscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Nasingen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Leimbach	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Heilbach	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Ammeldingen bei Neuerburg	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Uppershausen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Koxhausen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Waldhof-Falkenstein	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Sevenig	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54673	Scheitenkorb	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Hüttingen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Ammeldingen an der Our	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Fischbach-Oberraden	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Gentingen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Roth an der Our	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Körperich	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Sinspelt	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Utscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Lahr	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Hommerdingen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
2827	Görlitz	Sachsen	SN	Görlitz
54675	Wallendorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Mettendorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Kruchten	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Geichlingen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Nusbaum	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Niederraden	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Obergeckler	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Niedergeckler	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54675	Biesdorf	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54687	Arzfeld	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54689	Kickeshausen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54689	Olmscheid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54689	Übereisenbach	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54689	Irrhausen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54689	Dasburg	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54689	Dahnen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54689	Jucken	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54689	Affler	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54689	Preischeid	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54689	Daleiden	Rheinland-Pfalz	RP	EifelBitburg-Prüm
54689	Reipeldingen	Rheinland-Pfalz	RP	EifelBitburg-Prüm
55116	Mainz	Rheinland-Pfalz	RP	Mainz;
55118	Mainz	Rheinland-Pfalz	RP	Mainz;
55120	Mainz	Rheinland-Pfalz	RP	Mainz;
55122	Mainz	Rheinland-Pfalz	RP	Mainz;
55124	Mainz	Rheinland-Pfalz	RP	Mainz;
55126	Mainz	Rheinland-Pfalz	RP	Mainz;
55127	Mainz	Rheinland-Pfalz	RP	Mainz;
55128	Mainz	Rheinland-Pfalz	RP	Mainz;
55129	Mainz	Rheinland-Pfalz	RP	Mainz;
55130	Mainz	Rheinland-Pfalz	RP	Mainz;
55131	Mainz	Rheinland-Pfalz	RP	Mainz;
55218	Ingelheim am Rhein	Rheinland-Pfalz	RP	Mainz-Bingen
55232	Alzey	Rheinland-Pfalz	RP	Alzey-Worms
55232	Ensheim	Rheinland-Pfalz	RP	Alzey-Worms
55234	Nieder-Wiesen	Rheinland-Pfalz	RP	Alzey-Worms
55234	Dintesheim	Rheinland-Pfalz	RP	Alzey-Worms
55234	Wendelsheim	Rheinland-Pfalz	RP	Alzey-Worms
55234	Wahlheim	Rheinland-Pfalz	RP	Alzey-Worms
55234	Esselborn	Rheinland-Pfalz	RP	Alzey-Worms
55234	Eppelsheim	Rheinland-Pfalz	RP	Alzey-Worms
55234	Nack	Rheinland-Pfalz	RP	Alzey-Worms
55234	Ober-Flörsheim	Rheinland-Pfalz	RP	Alzey-Worms
55234	Offenheim	Rheinland-Pfalz	RP	Alzey-Worms
55234	Kettenheim	Rheinland-Pfalz	RP	Alzey-Worms
55234	Framersheim	Rheinland-Pfalz	RP	Alzey-Worms
55234	Biebelnheim	Rheinland-Pfalz	RP	Alzey-Worms
55234	Hangen-Weisheim	Rheinland-Pfalz	RP	Alzey-Worms
55234	Gau-Heppenheim	Rheinland-Pfalz	RP	Alzey-Worms
55234	Flomborn	Rheinland-Pfalz	RP	Alzey-Worms
55234	Erbes-Büdesheim	Rheinland-Pfalz	RP	Alzey-Worms
55234	Bechtolsheim	Rheinland-Pfalz	RP	Alzey-Worms
55234	Bermersheim vor der Höhe	Rheinland-Pfalz	RP	Alzey-Worms
55234	Freimersheim	Rheinland-Pfalz	RP	Alzey-Worms
55234	Hochborn	Rheinland-Pfalz	RP	Alzey-Worms
55234	Albig	Rheinland-Pfalz	RP	Alzey-Worms
55234	Monzernheim	Rheinland-Pfalz	RP	Alzey-Worms
55234	Bechenheim	Rheinland-Pfalz	RP	Alzey-Worms
55237	Flonheim	Rheinland-Pfalz	RP	Alzey-Worms
55237	Bornheim	Rheinland-Pfalz	RP	Alzey-Worms
55237	Lonsheim	Rheinland-Pfalz	RP	Alzey-Worms
55239	Gau-Odernheim	Rheinland-Pfalz	RP	Alzey-Worms
55257	Budenheim	Rheinland-Pfalz	RP	Mainz-Bingen
55262	Heidesheim am Rhein	Rheinland-Pfalz	RP	Mainz-Bingen
55263	Wackernheim	Rheinland-Pfalz	RP	Mainz-Bingen
55268	Nieder-Olm	Rheinland-Pfalz	RP	Mainz-Bingen
55270	Bubenheim	Rheinland-Pfalz	RP	Mainz-Bingen
55270	Jugenheim	Rheinland-Pfalz	RP	Mainz-Bingen
55270	Sörgenloch	Rheinland-Pfalz	RP	Mainz-Bingen
55270	Zornheim	Rheinland-Pfalz	RP	Mainz-Bingen
55270	Essenheim	Rheinland-Pfalz	RP	Mainz-Bingen
55270	Ober-Olm	Rheinland-Pfalz	RP	Mainz-Bingen
55270	Klein-Winternheim	Rheinland-Pfalz	RP	Mainz-Bingen
55270	Engelstadt	Rheinland-Pfalz	RP	Mainz-Bingen
55270	Schwabenheim an der Selz	Rheinland-Pfalz	RP	Mainz-Bingen
55271	Stadecken-Elsheim	Rheinland-Pfalz	RP	Mainz-Bingen
55276	Oppenheim	Rheinland-Pfalz	RP	Mainz-Bingen
55276	Dienheim	Rheinland-Pfalz	RP	Mainz-Bingen
55278	Eimsheim	Rheinland-Pfalz	RP	Mainz-Bingen
55278	Friesenheim	Rheinland-Pfalz	RP	Mainz-Bingen
55278	Hahnheim	Rheinland-Pfalz	RP	Mainz-Bingen
55278	Dolgesheim	Rheinland-Pfalz	RP	Mainz-Bingen
55278	Dalheim	Rheinland-Pfalz	RP	Mainz-Bingen
55278	Undenheim	Rheinland-Pfalz	RP	Mainz-Bingen
55278	Köngernheim	Rheinland-Pfalz	RP	Mainz-Bingen
55278	Weinolsheim	Rheinland-Pfalz	RP	Mainz-Bingen
55278	Dexheim	Rheinland-Pfalz	RP	Mainz-Bingen
55278	Uelversheim	Rheinland-Pfalz	RP	Mainz-Bingen
55278	Ludwigshöhe	Rheinland-Pfalz	RP	Mainz-Bingen
55278	Selzen	Rheinland-Pfalz	RP	Mainz-Bingen
55278	Mommenheim	Rheinland-Pfalz	RP	Mainz-Bingen
55283	Nierstein	Rheinland-Pfalz	RP	Mainz-Bingen
55286	Wörrstadt	Rheinland-Pfalz	RP	Alzey-Worms
55286	Sulzheim	Rheinland-Pfalz	RP	Alzey-Worms
55288	Spiesheim	Rheinland-Pfalz	RP	Alzey-Worms
55288	Schornsheim	Rheinland-Pfalz	RP	Alzey-Worms
55288	Partenheim	Rheinland-Pfalz	RP	Alzey-Worms
55288	Armsheim	Rheinland-Pfalz	RP	Alzey-Worms
55288	Gabsheim	Rheinland-Pfalz	RP	Alzey-Worms
55288	Udenheim	Rheinland-Pfalz	RP	Alzey-Worms
55291	Saulheim	Rheinland-Pfalz	RP	Alzey-Worms
55294	Bodenheim	Rheinland-Pfalz	RP	Mainz-Bingen
55296	Gau-Bischofsheim	Rheinland-Pfalz	RP	Mainz-Bingen
55296	Lörzweiler	Rheinland-Pfalz	RP	Mainz-Bingen
55296	Harxheim	Rheinland-Pfalz	RP	Mainz-Bingen
55299	Nackenheim	Rheinland-Pfalz	RP	Mainz-Bingen
55411	Bingen am Rhein	Rheinland-Pfalz	RP	Mainz-Bingen
55413	Trechtingshausen	Rheinland-Pfalz	RP	Mainz-Bingen
55413	Weiler	Rheinland-Pfalz	RP	Mainz-Bingen
55413	Oberdiebach	Rheinland-Pfalz	RP	Mainz-Bingen
55413	Oberheimbach	Rheinland-Pfalz	RP	Mainz-Bingen
55413	Manubach	Rheinland-Pfalz	RP	Mainz-Bingen
55413	Niederheimbach	Rheinland-Pfalz	RP	Mainz-Bingen
55422	Bacharach	Rheinland-Pfalz	RP	Mainz-Bingen
55422	Breitscheid	Rheinland-Pfalz	RP	Mainz-Bingen
55424	Münster-Sarmsheim	Rheinland-Pfalz	RP	Mainz-Bingen
55425	Waldalgesheim	Rheinland-Pfalz	RP	Mainz-Bingen
55430	Urbar	Rheinland-Pfalz	RP	Rhein-Hunsrück
55430	Oberwesel	Rheinland-Pfalz	RP	Rhein-Hunsrück
55430	Perscheid	Rheinland-Pfalz	RP	Rhein-Hunsrück
55432	Damscheid	Rheinland-Pfalz	RP	Rhein-Hunsrück
55432	Niederburg	Rheinland-Pfalz	RP	Rhein-Hunsrück
55435	Gau-Algesheim	Rheinland-Pfalz	RP	Mainz-Bingen
55437	Appenheim	Rheinland-Pfalz	RP	Mainz-Bingen
55437	Nieder-Hilbersheim	Rheinland-Pfalz	RP	Mainz-Bingen
55437	Ockenheim	Rheinland-Pfalz	RP	Mainz-Bingen
55437	Ober-Hilbersheim	Rheinland-Pfalz	RP	Mainz-Bingen
55442	Daxweiler	Rheinland-Pfalz	RP	Bad Kreuznach
55442	Roth	Rheinland-Pfalz	RP	Bad Kreuznach
55442	Stromberg	Rheinland-Pfalz	RP	Bad Kreuznach
55442	Warmsroth	Rheinland-Pfalz	RP	Bad Kreuznach
55444	Waldlaubersheim	Rheinland-Pfalz	RP	Bad Kreuznach
55444	Seibersbach	Rheinland-Pfalz	RP	Bad Kreuznach
55444	Eckenroth	Rheinland-Pfalz	RP	Bad Kreuznach
55444	Dörrebach	Rheinland-Pfalz	RP	Bad Kreuznach
55444	Schöneberg	Rheinland-Pfalz	RP	Bad Kreuznach
55444	Schweppenhausen	Rheinland-Pfalz	RP	Bad Kreuznach
55450	Langenlonsheim	Rheinland-Pfalz	RP	Bad Kreuznach
55452	Hergenfeld	Rheinland-Pfalz	RP	Bad Kreuznach
55452	Windesheim	Rheinland-Pfalz	RP	Bad Kreuznach
55452	Dorsheim	Rheinland-Pfalz	RP	Bad Kreuznach
55452	Rümmelsheim/Burg Layen	Rheinland-Pfalz	RP	Bad Kreuznach
55452	Laubenheim	Rheinland-Pfalz	RP	Bad Kreuznach
55452	Guldental	Rheinland-Pfalz	RP	Bad Kreuznach
55457	Horrweiler	Rheinland-Pfalz	RP	Mainz-Bingen
55457	Gensingen	Rheinland-Pfalz	RP	Mainz-Bingen
55459	Grolsheim	Rheinland-Pfalz	RP	Mainz-Bingen
55459	Aspisheim	Rheinland-Pfalz	RP	Mainz-Bingen
55469	Horn	Rheinland-Pfalz	RP	Rhein-Hunsrück
55469	Klosterkumbd	Rheinland-Pfalz	RP	Rhein-Hunsrück
55469	Rayerschied	Rheinland-Pfalz	RP	Rhein-Hunsrück
55469	Bergenhausen	Rheinland-Pfalz	RP	Rhein-Hunsrück
55469	Simmern	Rheinland-Pfalz	RP	Rhein-Hunsrück
55469	Altweidelbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
55469	Mutterschied	Rheinland-Pfalz	RP	Rhein-Hunsrück
55469	Budenbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
55469	Holzbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
55469	Schönborn	Rheinland-Pfalz	RP	Rhein-Hunsrück
55469	Niederkumbd	Rheinland-Pfalz	RP	Rhein-Hunsrück
55469	Nannhausen	Rheinland-Pfalz	RP	Rhein-Hunsrück
55469	Pleizenhausen	Rheinland-Pfalz	RP	Rhein-Hunsrück
55469	Ohlweiler	Rheinland-Pfalz	RP	Rhein-Hunsrück
55469	Riegenroth	Rheinland-Pfalz	RP	Rhein-Hunsrück
55469	Belgweiler	Rheinland-Pfalz	RP	Rhein-Hunsrück
55469	Oppertshausen	Rheinland-Pfalz	RP	Rhein-Hunsrück
55471	Keidelheim	Rheinland-Pfalz	RP	Rhein-Hunsrück
55471	Reich	Rheinland-Pfalz	RP	Rhein-Hunsrück
55471	Fronhofen	Rheinland-Pfalz	RP	Rhein-Hunsrück
55471	Kümbdchen	Rheinland-Pfalz	RP	Rhein-Hunsrück
55471	Sargenroth	Rheinland-Pfalz	RP	Rhein-Hunsrück
55471	Tiefenbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
55471	Wüschheim	Rheinland-Pfalz	RP	Rhein-Hunsrück
55471	Ravengiersburg	Rheinland-Pfalz	RP	Rhein-Hunsrück
55471	Biebern	Rheinland-Pfalz	RP	Rhein-Hunsrück
55471	Neuerkirch	Rheinland-Pfalz	RP	Rhein-Hunsrück
55471	Külz	Rheinland-Pfalz	RP	Rhein-Hunsrück
55481	Hecken	Rheinland-Pfalz	RP	Rhein-Hunsrück
55481	Schwarzen	Rheinland-Pfalz	RP	Rhein-Hunsrück
55481	Metzenhausen	Rheinland-Pfalz	RP	Rhein-Hunsrück
55481	Womrath	Rheinland-Pfalz	RP	Rhein-Hunsrück
55481	Nieder Kostenz	Rheinland-Pfalz	RP	Rhein-Hunsrück
55481	Reckershausen	Rheinland-Pfalz	RP	Rhein-Hunsrück
55481	Dillendorf	Rheinland-Pfalz	RP	Rhein-Hunsrück
55481	Kludenbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
55481	Todenroth	Rheinland-Pfalz	RP	Rhein-Hunsrück
55481	Maitzborn	Rheinland-Pfalz	RP	Rhein-Hunsrück
55481	Rödern	Rheinland-Pfalz	RP	Rhein-Hunsrück
55481	Lindenschied	Rheinland-Pfalz	RP	Rhein-Hunsrück
55481	Kirchberg	Rheinland-Pfalz	RP	Rhein-Hunsrück
55481	Ober Kostenz	Rheinland-Pfalz	RP	Rhein-Hunsrück
55483	Kappel	Rheinland-Pfalz	RP	Rhein-Hunsrück
55483	Horbruch	Rheinland-Pfalz	RP	Birkenfeld
55483	Krummenau	Rheinland-Pfalz	RP	Birkenfeld
55483	Unzenberg	Rheinland-Pfalz	RP	Rhein-Hunsrück
55483	Dickenschied	Rheinland-Pfalz	RP	Rhein-Hunsrück
55483	Hirschfeld	Rheinland-Pfalz	RP	Rhein-Hunsrück
55483	Bärenbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
55483	Schlierschied	Rheinland-Pfalz	RP	Rhein-Hunsrück
55483	Heinzenbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
55483	Lautzenhausen	Rheinland-Pfalz	RP	Rhein-Hunsrück
55487	Sohren	Rheinland-Pfalz	RP	Rhein-Hunsrück
55487	Dill	Rheinland-Pfalz	RP	Rhein-Hunsrück
55487	Sohrschied	Rheinland-Pfalz	RP	Rhein-Hunsrück
55487	Laufersweiler	Rheinland-Pfalz	RP	Rhein-Hunsrück
55487	Niedersohren	Rheinland-Pfalz	RP	Rhein-Hunsrück
55490	Gemünden	Rheinland-Pfalz	RP	Rhein-Hunsrück
55490	Woppenroth	Rheinland-Pfalz	RP	Rhein-Hunsrück
55490	Gehlweiler	Rheinland-Pfalz	RP	Rhein-Hunsrück
55490	Rohrbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
55490	Henau	Rheinland-Pfalz	RP	Rhein-Hunsrück
55490	Mengerschied	Rheinland-Pfalz	RP	Rhein-Hunsrück
55491	Wahlenau	Rheinland-Pfalz	RP	Rhein-Hunsrück
55491	Niederweiler	Rheinland-Pfalz	RP	Rhein-Hunsrück
55491	Büchenbeuren	Rheinland-Pfalz	RP	Rhein-Hunsrück
55494	Rheinböllen	Rheinland-Pfalz	RP	Rhein-Hunsrück
55494	Liebshausen	Rheinland-Pfalz	RP	Rhein-Hunsrück
55494	Mörschbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
55494	Dichtelbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
55494	Benzweiler	Rheinland-Pfalz	RP	Rhein-Hunsrück
55494	Erbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
55494	Wahlbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
55496	Argenthal	Rheinland-Pfalz	RP	Rhein-Hunsrück
55497	Ellern	Rheinland-Pfalz	RP	Rhein-Hunsrück
55497	Schnorbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
55499	Riesweiler	Rheinland-Pfalz	RP	Rhein-Hunsrück
55543	Bad Kreuznach	Rheinland-Pfalz	RP	Bad Kreuznach
55545	Bad Kreuznach	Rheinland-Pfalz	RP	Bad Kreuznach
55546	Pfaffen-Schwabenheim	Rheinland-Pfalz	RP	Bad Kreuznach
55546	Frei-Laubersheim	Rheinland-Pfalz	RP	Bad Kreuznach
55546	Tiefenthal	Rheinland-Pfalz	RP	Bad Kreuznach
55546	Fürfeld	Rheinland-Pfalz	RP	Bad Kreuznach
55546	Hackenheim	Rheinland-Pfalz	RP	Bad Kreuznach
55546	Neu-Bamberg	Rheinland-Pfalz	RP	Bad Kreuznach
55546	Biebelsheim	Rheinland-Pfalz	RP	Bad Kreuznach
55546	Volxheim	Rheinland-Pfalz	RP	Bad Kreuznach
55559	Bretzenheim	Rheinland-Pfalz	RP	Bad Kreuznach
55566	Kirschroth	Rheinland-Pfalz	RP	Bad Kreuznach
55566	Bad Sobernheim	Rheinland-Pfalz	RP	Bad Kreuznach
55566	Daubach	Rheinland-Pfalz	RP	Bad Kreuznach
55566	Ippenschied	Rheinland-Pfalz	RP	Bad Kreuznach
55566	Meddersheim	Rheinland-Pfalz	RP	Bad Kreuznach
55566	Rehbach	Rheinland-Pfalz	RP	Bad Kreuznach
55568	Abtweiler	Rheinland-Pfalz	RP	Bad Kreuznach
55568	Lauschied	Rheinland-Pfalz	RP	Bad Kreuznach
55568	Staudernheim	Rheinland-Pfalz	RP	Bad Kreuznach
55569	Monzingen	Rheinland-Pfalz	RP	Bad Kreuznach
55569	Langenthal	Rheinland-Pfalz	RP	Bad Kreuznach
55569	Auen	Rheinland-Pfalz	RP	Bad Kreuznach
55569	Nußbaum	Rheinland-Pfalz	RP	Bad Kreuznach
55571	Odernheim am Glan	Rheinland-Pfalz	RP	Bad Kreuznach
55576	Sprendlingen	Rheinland-Pfalz	RP	Mainz-Bingen
55576	Pleitersheim	Rheinland-Pfalz	RP	Bad Kreuznach
55576	Welgesheim	Rheinland-Pfalz	RP	Mainz-Bingen
55576	Zotzenheim	Rheinland-Pfalz	RP	Mainz-Bingen
55576	Badenheim	Rheinland-Pfalz	RP	Mainz-Bingen
55578	Wallertheim	Rheinland-Pfalz	RP	Alzey-Worms
55578	Gau-Weinheim	Rheinland-Pfalz	RP	Alzey-Worms
55578	Vendersheim	Rheinland-Pfalz	RP	Alzey-Worms
55578	Wolfsheim	Rheinland-Pfalz	RP	Mainz-Bingen
55578	Sankt Johann	Rheinland-Pfalz	RP	Mainz-Bingen
55583	Bad Münster am Stein-Ebernburg	Rheinland-Pfalz	RP	Bad Kreuznach
55585	Duchroth	Rheinland-Pfalz	RP	Bad Kreuznach
55585	Oberhausen an der Nahe	Rheinland-Pfalz	RP	Bad Kreuznach
55585	Niederhausen	Rheinland-Pfalz	RP	Bad Kreuznach
55585	Altenbamberg	Rheinland-Pfalz	RP	Bad Kreuznach
55585	Hochstätten	Rheinland-Pfalz	RP	Bad Kreuznach
55585	Norheim	Rheinland-Pfalz	RP	Bad Kreuznach
55590	Meisenheim	Rheinland-Pfalz	RP	Bad Kreuznach
55592	Jeckenbach	Rheinland-Pfalz	RP	Bad Kreuznach
55592	Raumbach	Rheinland-Pfalz	RP	Bad Kreuznach
55592	Breitenheim	Rheinland-Pfalz	RP	Bad Kreuznach
55592	Rehborn	Rheinland-Pfalz	RP	Bad Kreuznach
55592	Desloch	Rheinland-Pfalz	RP	Bad Kreuznach
55593	Rüdesheim	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Winterbach	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Braunweiler	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Argenschwang	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Spall	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Sommerloch	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Wallhausen	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Roxheim	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Allenfeld	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Hargesheim	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Gebroth	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Münchwald	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Dalberg	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Spabrücken	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Mandel	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Gutenberg	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Sankt Katharinen	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Traisen	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Boos	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Hüffelsheim	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Burgsponheim	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Winterburg	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Bockenau	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Sponheim	Rheinland-Pfalz	RP	Bad Kreuznach
55595	Weinsheim	Rheinland-Pfalz	RP	Bad Kreuznach
55596	Waldböckelheim	Rheinland-Pfalz	RP	Bad Kreuznach
55596	Oberstreit	Rheinland-Pfalz	RP	Bad Kreuznach
55596	Schloßböckelheim	Rheinland-Pfalz	RP	Bad Kreuznach
55597	Wöllstein	Rheinland-Pfalz	RP	Alzey-Worms
55597	Gumbsheim	Rheinland-Pfalz	RP	Alzey-Worms
55599	Eckelsheim	Rheinland-Pfalz	RP	Alzey-Worms
55599	Gau-Bickelheim	Rheinland-Pfalz	RP	Alzey-Worms
55599	Stein-Bockenheim	Rheinland-Pfalz	RP	Alzey-Worms
55599	Siefersheim	Rheinland-Pfalz	RP	Alzey-Worms
55599	Wonsheim	Rheinland-Pfalz	RP	Alzey-Worms
55606	Kellenbach	Rheinland-Pfalz	RP	Bad Kreuznach
55606	Oberhausen	Rheinland-Pfalz	RP	Bad Kreuznach
55606	Heinzenberg	Rheinland-Pfalz	RP	Bad Kreuznach
55606	Horbach	Rheinland-Pfalz	RP	Bad Kreuznach
55606	Limbach	Rheinland-Pfalz	RP	Bad Kreuznach
55606	Hochstetten-Dhaun	Rheinland-Pfalz	RP	Bad Kreuznach
55606	Hahnenbach	Rheinland-Pfalz	RP	Bad Kreuznach
55606	Brauweiler	Rheinland-Pfalz	RP	Bad Kreuznach
55606	Otzweiler	Rheinland-Pfalz	RP	Bad Kreuznach
55606	Bruschied	Rheinland-Pfalz	RP	Bad Kreuznach
55606	Meckenbach	Rheinland-Pfalz	RP	Bad Kreuznach
55606	Königsau	Rheinland-Pfalz	RP	Bad Kreuznach
55606	Bärweiler	Rheinland-Pfalz	RP	Bad Kreuznach
55606	Heimweiler	Rheinland-Pfalz	RP	Bad Kreuznach
55606	Kirn	Rheinland-Pfalz	RP	Bad Kreuznach
55608	Berschweiler	Rheinland-Pfalz	RP	Birkenfeld
55608	Griebelschied	Rheinland-Pfalz	RP	Birkenfeld
55608	Schneppenbach	Rheinland-Pfalz	RP	Bad Kreuznach
55608	Becherbach bei Kirn	Rheinland-Pfalz	RP	Bad Kreuznach
55608	Bergen	Rheinland-Pfalz	RP	Birkenfeld
55608	Hausen	Rheinland-Pfalz	RP	Birkenfeld
55618	Simmertal	Rheinland-Pfalz	RP	Bad Kreuznach
55619	Hennweiler	Rheinland-Pfalz	RP	Bad Kreuznach
55621	Hundsbach	Rheinland-Pfalz	RP	Bad Kreuznach
55624	Schwerbach	Rheinland-Pfalz	RP	Birkenfeld
55624	Weitersbach	Rheinland-Pfalz	RP	Birkenfeld
55624	Rhaunen	Rheinland-Pfalz	RP	Birkenfeld
55624	Bollenbach	Rheinland-Pfalz	RP	Birkenfeld
55624	Gösenroth	Rheinland-Pfalz	RP	Birkenfeld
55624	Oberkirn	Rheinland-Pfalz	RP	Birkenfeld
55626	Bundenbach	Rheinland-Pfalz	RP	Birkenfeld
55627	Weiler bei Monzingen	Rheinland-Pfalz	RP	Bad Kreuznach
55627	Merxheim	Rheinland-Pfalz	RP	Bad Kreuznach
55627	Martinstein	Rheinland-Pfalz	RP	Bad Kreuznach
55629	Weitersborn	Rheinland-Pfalz	RP	Bad Kreuznach
55629	Schwarzerden	Rheinland-Pfalz	RP	Bad Kreuznach
55629	Seesbach	Rheinland-Pfalz	RP	Bad Kreuznach
55743	Fischbach	Rheinland-Pfalz	RP	Birkenfeld
55743	Gerach	Rheinland-Pfalz	RP	Birkenfeld
55743	Hintertiefenbach	Rheinland-Pfalz	RP	Birkenfeld
55743	Kirschweiler	Rheinland-Pfalz	RP	Birkenfeld
55743	Idar-Oberstein	Rheinland-Pfalz	RP	Birkenfeld
55756	Herrstein	Rheinland-Pfalz	RP	Birkenfeld
55758	Hettenrodt	Rheinland-Pfalz	RP	Birkenfeld
55758	Langweiler	Rheinland-Pfalz	RP	Birkenfeld
55758	Hellertshausen	Rheinland-Pfalz	RP	Birkenfeld
55758	Oberreidenbach	Rheinland-Pfalz	RP	Birkenfeld
55758	Herborn	Rheinland-Pfalz	RP	Birkenfeld
55758	Bruchweiler	Rheinland-Pfalz	RP	Birkenfeld
55758	Sonnschied	Rheinland-Pfalz	RP	Birkenfeld
55758	Stipshausen	Rheinland-Pfalz	RP	Birkenfeld
55758	Wickenrodt	Rheinland-Pfalz	RP	Birkenfeld
55758	Mittelreidenbach	Rheinland-Pfalz	RP	Birkenfeld
55758	Weiden	Rheinland-Pfalz	RP	Birkenfeld
55758	Niederwörresbach	Rheinland-Pfalz	RP	Birkenfeld
55758	Breitenthal	Rheinland-Pfalz	RP	Birkenfeld
55758	Vollmersbach	Rheinland-Pfalz	RP	Birkenfeld
55758	Mörschied	Rheinland-Pfalz	RP	Birkenfeld
55758	Hottenbach	Rheinland-Pfalz	RP	Birkenfeld
55758	Sulzbach	Rheinland-Pfalz	RP	Birkenfeld
55758	Schmidthachenbach	Rheinland-Pfalz	RP	Birkenfeld
55758	Mackenrodt	Rheinland-Pfalz	RP	Birkenfeld
55758	Oberhosenbach	Rheinland-Pfalz	RP	Birkenfeld
55758	Veitsrodt	Rheinland-Pfalz	RP	Birkenfeld
55758	Sienhachenbach	Rheinland-Pfalz	RP	Birkenfeld
55758	Asbach	Rheinland-Pfalz	RP	Birkenfeld
55758	Schauren	Rheinland-Pfalz	RP	Birkenfeld
55758	Allenbach	Rheinland-Pfalz	RP	Birkenfeld
55758	Kempfeld	Rheinland-Pfalz	RP	Birkenfeld
55758	Sien	Rheinland-Pfalz	RP	Birkenfeld
55758	Wirschweiler	Rheinland-Pfalz	RP	Birkenfeld
55758	Sensweiler	Rheinland-Pfalz	RP	Birkenfeld
55758	Oberwörresbach	Rheinland-Pfalz	RP	Birkenfeld
55758	Bärenbach	Rheinland-Pfalz	RP	Bad Kreuznach
55758	Niederhosenbach	Rheinland-Pfalz	RP	Birkenfeld
55758	Dickesbach	Rheinland-Pfalz	RP	Birkenfeld
55765	Dienstweiler	Rheinland-Pfalz	RP	Birkenfeld
55765	Ellenberg	Rheinland-Pfalz	RP	Birkenfeld
55765	Oberhambach	Rheinland-Pfalz	RP	Birkenfeld
55765	Birkenfeld	Rheinland-Pfalz	RP	Birkenfeld
55765	Ellweiler	Rheinland-Pfalz	RP	Birkenfeld
55765	Dambach	Rheinland-Pfalz	RP	Birkenfeld
55765	Rimsberg	Rheinland-Pfalz	RP	Birkenfeld
55765	Elchweiler	Rheinland-Pfalz	RP	Birkenfeld
55765	Schmißberg	Rheinland-Pfalz	RP	Birkenfeld
55767	Sonnenberg-Winnenberg	Rheinland-Pfalz	RP	Birkenfeld
55767	Oberbrombach	Rheinland-Pfalz	RP	Birkenfeld
55767	Gollenberg	Rheinland-Pfalz	RP	Birkenfeld
55767	Rötsweiler-Nockenthal	Rheinland-Pfalz	RP	Birkenfeld
55767	Achtelsbach	Rheinland-Pfalz	RP	Birkenfeld
55767	Schwollen	Rheinland-Pfalz	RP	Birkenfeld
55767	Rinzenberg	Rheinland-Pfalz	RP	Birkenfeld
55767	Wilzenberg-Hußweiler	Rheinland-Pfalz	RP	Birkenfeld
55767	Niederbrombach	Rheinland-Pfalz	RP	Birkenfeld
55767	Buhlenberg	Rheinland-Pfalz	RP	Birkenfeld
55767	Meckenbach	Rheinland-Pfalz	RP	Birkenfeld
55767	Siesbach	Rheinland-Pfalz	RP	Birkenfeld
55767	Leisel	Rheinland-Pfalz	RP	Birkenfeld
55767	Hattgenstein	Rheinland-Pfalz	RP	Birkenfeld
55767	Kronweiler	Rheinland-Pfalz	RP	Birkenfeld
55767	Nohen	Rheinland-Pfalz	RP	Birkenfeld
55767	Gimbweiler	Rheinland-Pfalz	RP	Birkenfeld
55767	Abentheuer	Rheinland-Pfalz	RP	Birkenfeld
55767	Brücken	Rheinland-Pfalz	RP	Birkenfeld
55767	Niederhambach	Rheinland-Pfalz	RP	Birkenfeld
55768	Hoppstädten-Weiersbach	Rheinland-Pfalz	RP	Birkenfeld
55774	Baumholder	Rheinland-Pfalz	RP	Birkenfeld
55776	Berglangenbach	Rheinland-Pfalz	RP	Birkenfeld
55776	Frauenberg	Rheinland-Pfalz	RP	Birkenfeld
55776	Rückweiler	Rheinland-Pfalz	RP	Birkenfeld
55776	Hahnweiler	Rheinland-Pfalz	RP	Birkenfeld
55776	Rohrbach	Rheinland-Pfalz	RP	Birkenfeld
55776	Ruschberg	Rheinland-Pfalz	RP	Birkenfeld
55776	Reichenbach	Rheinland-Pfalz	RP	Birkenfeld
55777	Eckersweiler	Rheinland-Pfalz	RP	Birkenfeld
55777	Mettweiler	Rheinland-Pfalz	RP	Birkenfeld
55777	Berschweiler	Rheinland-Pfalz	RP	Birkenfeld
55777	Fohren-Linden	Rheinland-Pfalz	RP	Birkenfeld
55779	Heimbach	Rheinland-Pfalz	RP	Birkenfeld
55779	Leitzweiler	Rheinland-Pfalz	RP	Birkenfeld
56068	Koblenz	Rheinland-Pfalz	RP	Koblenz;
56070	Koblenz	Rheinland-Pfalz	RP	Koblenz;
56072	Koblenz	Rheinland-Pfalz	RP	Koblenz;
56073	Koblenz	Rheinland-Pfalz	RP	Koblenz;
56075	Koblenz	Rheinland-Pfalz	RP	Koblenz;
56076	Koblenz	Rheinland-Pfalz	RP	Koblenz;
56077	Koblenz	Rheinland-Pfalz	RP	Koblenz;
56112	Lahnstein	Rheinland-Pfalz	RP	Rhein-Lahn
56130	Bad Ems	Rheinland-Pfalz	RP	Rhein-Lahn
56132	Becheln	Rheinland-Pfalz	RP	Rhein-Lahn
56132	Kemmenau	Rheinland-Pfalz	RP	Rhein-Lahn
56132	Dausenau	Rheinland-Pfalz	RP	Rhein-Lahn
56132	Miellen	Rheinland-Pfalz	RP	Rhein-Lahn
56132	Nievern	Rheinland-Pfalz	RP	Rhein-Lahn
56132	Frücht	Rheinland-Pfalz	RP	Rhein-Lahn
56133	Fachbach	Rheinland-Pfalz	RP	Rhein-Lahn
56154	Boppard	Rheinland-Pfalz	RP	Rhein-Hunsrück
56170	Bendorf	Rheinland-Pfalz	RP	Mayen-Koblenz
56179	Niederwerth	Rheinland-Pfalz	RP	Mayen-Koblenz
56179	Vallendar	Rheinland-Pfalz	RP	Mayen-Koblenz
56182	Urbar	Rheinland-Pfalz	RP	Mayen-Koblenz
56191	Weitersburg	Rheinland-Pfalz	RP	Mayen-Koblenz
56203	Höhr-Grenzhausen	Rheinland-Pfalz	RP	Westerwaldkreis
56204	Hillscheid	Rheinland-Pfalz	RP	Westerwaldkreis
56206	Hilgert	Rheinland-Pfalz	RP	Westerwaldkreis
56206	Kammerforst	Rheinland-Pfalz	RP	Westerwaldkreis
56218	Mülheim-Kärlich	Rheinland-Pfalz	RP	Mayen-Koblenz
56220	Sankt Sebastian	Rheinland-Pfalz	RP	Mayen-Koblenz
56220	Kettig	Rheinland-Pfalz	RP	Mayen-Koblenz
56220	Urmitz	Rheinland-Pfalz	RP	Mayen-Koblenz
56220	Kaltenengers	Rheinland-Pfalz	RP	Mayen-Koblenz
56220	Bassenheim	Rheinland-Pfalz	RP	Mayen-Koblenz
56235	Ransbach-Baumbach	Rheinland-Pfalz	RP	Westerwaldkreis
56235	Hundsdorf	Rheinland-Pfalz	RP	Westerwaldkreis
56237	Wittgert	Rheinland-Pfalz	RP	Westerwaldkreis
56237	Nauort	Rheinland-Pfalz	RP	Westerwaldkreis
56237	Wirscheid	Rheinland-Pfalz	RP	Westerwaldkreis
56237	Oberhaid	Rheinland-Pfalz	RP	Westerwaldkreis
56237	Sessenbach	Rheinland-Pfalz	RP	Westerwaldkreis
56237	Deesen	Rheinland-Pfalz	RP	Westerwaldkreis
56237	Breitenau	Rheinland-Pfalz	RP	Westerwaldkreis
56237	Alsbach	Rheinland-Pfalz	RP	Westerwaldkreis
56237	Caan	Rheinland-Pfalz	RP	Westerwaldkreis
56242	Marienrachdorf	Rheinland-Pfalz	RP	Westerwaldkreis
56242	Quirnbach	Rheinland-Pfalz	RP	Westerwaldkreis
56242	Selters	Rheinland-Pfalz	RP	Westerwaldkreis
56242	Nordhofen	Rheinland-Pfalz	RP	Westerwaldkreis
56242	Ellenhausen	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Freilingen	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Arnshöfen	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Niedersayn	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Steinen	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Schenkelberg	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Krümmel	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Ötzingen	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Vielbach	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Leuterod	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Sessenhausen	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Maxsain	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Goddert	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Hartenfels	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Kuhnhöfen	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Freirachdorf	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Rückeroth	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Wölferlingen	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Helferskirchen	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Ewighausen	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Weidenhahn	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Hahn am See	Rheinland-Pfalz	RP	Westerwaldkreis
56244	Ettinghausen	Rheinland-Pfalz	RP	Westerwaldkreis
56249	Herschbach	Rheinland-Pfalz	RP	Westerwaldkreis
56253	Treis-Karden	Rheinland-Pfalz	RP	Cochem-Zell
56254	Müden	Rheinland-Pfalz	RP	Cochem-Zell
56254	Moselkern	Rheinland-Pfalz	RP	Cochem-Zell
56269	Marienhausen	Rheinland-Pfalz	RP	Neuwied
56269	Dierdorf	Rheinland-Pfalz	RP	Neuwied
56271	Isenburg	Rheinland-Pfalz	RP	Neuwied
56271	Kleinmaischeid	Rheinland-Pfalz	RP	Neuwied
56271	Mündersbach	Rheinland-Pfalz	RP	Westerwaldkreis
56271	Roßbach	Rheinland-Pfalz	RP	Westerwaldkreis
56271	Maroth	Rheinland-Pfalz	RP	Westerwaldkreis
56276	Stebach	Rheinland-Pfalz	RP	Neuwied
56276	Großmaischeid	Rheinland-Pfalz	RP	Neuwied
56281	Karbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
56281	Emmelshausen	Rheinland-Pfalz	RP	Rhein-Hunsrück
56281	Hungenroth	Rheinland-Pfalz	RP	Rhein-Hunsrück
56281	Dörth	Rheinland-Pfalz	RP	Rhein-Hunsrück
56281	Schwall	Rheinland-Pfalz	RP	Rhein-Hunsrück
56283	Morshausen	Rheinland-Pfalz	RP	Rhein-Hunsrück
56283	Ney	Rheinland-Pfalz	RP	Rhein-Hunsrück
56283	Beulich	Rheinland-Pfalz	RP	Rhein-Hunsrück
56283	Nörtershausen	Rheinland-Pfalz	RP	Mayen-Koblenz
56283	Halsenbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
56283	Gondershausen	Rheinland-Pfalz	RP	Rhein-Hunsrück
56283	Mermuth	Rheinland-Pfalz	RP	Rhein-Hunsrück
56283	Kratzenburg	Rheinland-Pfalz	RP	Rhein-Hunsrück
56288	Lahr	Rheinland-Pfalz	RP	Rhein-Hunsrück
56288	Bell	Rheinland-Pfalz	RP	Rhein-Hunsrück
56288	Alterkülz	Rheinland-Pfalz	RP	Rhein-Hunsrück
56288	Braunshorn	Rheinland-Pfalz	RP	Rhein-Hunsrück
56288	Korweiler	Rheinland-Pfalz	RP	Rhein-Hunsrück
56288	Kastellaun	Rheinland-Pfalz	RP	Rhein-Hunsrück
56288	Michelbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
56288	Spesenroth	Rheinland-Pfalz	RP	Rhein-Hunsrück
56288	Hasselbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
56288	Roth	Rheinland-Pfalz	RP	Rhein-Hunsrück
56288	Hollnich	Rheinland-Pfalz	RP	Rhein-Hunsrück
56288	Zilshausen	Rheinland-Pfalz	RP	Rhein-Hunsrück
56288	Laubach	Rheinland-Pfalz	RP	Rhein-Hunsrück
56288	Bubach	Rheinland-Pfalz	RP	Rhein-Hunsrück
56290	Mörsdorf	Rheinland-Pfalz	RP	Rhein-Hunsrück
56290	Lieg	Rheinland-Pfalz	RP	Cochem-Zell
56290	Beltheim	Rheinland-Pfalz	RP	Rhein-Hunsrück
56290	Gödenroth	Rheinland-Pfalz	RP	Rhein-Hunsrück
56290	Buch	Rheinland-Pfalz	RP	Rhein-Hunsrück
56290	Macken	Rheinland-Pfalz	RP	Mayen-Koblenz
56290	Lütz	Rheinland-Pfalz	RP	Cochem-Zell
56290	Dommershausen	Rheinland-Pfalz	RP	Rhein-Hunsrück
56290	Uhler	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Wiebelsheim	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Laudert	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Pfalzfeld	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Leiningen	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Hausbay	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Thörlingen	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Bickenbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Kisselbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Utzenhain	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Maisborn	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Mühlpfad	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Badenhard	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Niedert	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Steinbach	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Lingerhahn	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Norath	Rheinland-Pfalz	RP	Rhein-Hunsrück
56291	Birkheim	Rheinland-Pfalz	RP	Rhein-Hunsrück
56294	Kalt	Rheinland-Pfalz	RP	Mayen-Koblenz
56294	Münstermaifeld	Rheinland-Pfalz	RP	Mayen-Koblenz
56294	Wierschem	Rheinland-Pfalz	RP	Mayen-Koblenz
56294	Gappenach	Rheinland-Pfalz	RP	Mayen-Koblenz
56294	Gierschnach	Rheinland-Pfalz	RP	Mayen-Koblenz
56295	Rüber	Rheinland-Pfalz	RP	Mayen-Koblenz
56295	Lonnig	Rheinland-Pfalz	RP	Mayen-Koblenz
56295	Kerben	Rheinland-Pfalz	RP	Mayen-Koblenz
56299	Ochtendung	Rheinland-Pfalz	RP	Mayen-Koblenz
56305	Puderbach	Rheinland-Pfalz	RP	Neuwied
56305	Döttesfeld	Rheinland-Pfalz	RP	Neuwied
56307	Dürrholz	Rheinland-Pfalz	RP	Neuwied
56307	Harschbach	Rheinland-Pfalz	RP	Neuwied
56307	Dernbach	Rheinland-Pfalz	RP	Neuwied
56316	Niederhofen	Rheinland-Pfalz	RP	Neuwied
56316	Hanroth	Rheinland-Pfalz	RP	Neuwied
56316	Raubach	Rheinland-Pfalz	RP	Neuwied
56317	Linkenbach	Rheinland-Pfalz	RP	Neuwied
56317	Urbach	Rheinland-Pfalz	RP	Neuwied
56321	Rhens	Rheinland-Pfalz	RP	Mayen-Koblenz
56321	Brey	Rheinland-Pfalz	RP	Mayen-Koblenz
56322	Spay	Rheinland-Pfalz	RP	Mayen-Koblenz
56323	Waldesch	Rheinland-Pfalz	RP	Mayen-Koblenz
56329	Sankt Goar	Rheinland-Pfalz	RP	Rhein-Hunsrück
56330	Kobern-Gondorf	Rheinland-Pfalz	RP	Mayen-Koblenz
56332	Brodenbach	Rheinland-Pfalz	RP	Mayen-Koblenz
56332	Alken	Rheinland-Pfalz	RP	Mayen-Koblenz
56332	Löf	Rheinland-Pfalz	RP	Mayen-Koblenz
56332	Dieblich	Rheinland-Pfalz	RP	Mayen-Koblenz
56332	Oberfell	Rheinland-Pfalz	RP	Mayen-Koblenz
56332	Wolken	Rheinland-Pfalz	RP	Mayen-Koblenz
56332	Hatzenport	Rheinland-Pfalz	RP	Mayen-Koblenz
56332	Kattenes	Rheinland-Pfalz	RP	Mayen-Koblenz
56332	Burgen	Rheinland-Pfalz	RP	Mayen-Koblenz
56332	Lehmen	Rheinland-Pfalz	RP	Mayen-Koblenz
56332	Niederfell	Rheinland-Pfalz	RP	Mayen-Koblenz
56333	Winningen	Rheinland-Pfalz	RP	Mayen-Koblenz
56335	Neuhäusel	Rheinland-Pfalz	RP	Westerwaldkreis
56337	Arzbach	Rheinland-Pfalz	RP	Rhein-Lahn
56337	Simmern	Rheinland-Pfalz	RP	Westerwaldkreis
56337	Kadenbach	Rheinland-Pfalz	RP	Westerwaldkreis
56337	Eitelborn	Rheinland-Pfalz	RP	Westerwaldkreis
56338	Braubach	Rheinland-Pfalz	RP	Rhein-Lahn
56340	Osterspai	Rheinland-Pfalz	RP	Rhein-Lahn
56340	Dachsenhausen	Rheinland-Pfalz	RP	Rhein-Lahn
56341	Kamp-Bornhofen	Rheinland-Pfalz	RP	Rhein-Lahn
56341	Filsen	Rheinland-Pfalz	RP	Rhein-Lahn
56346	Sankt Goarshausen	Rheinland-Pfalz	RP	Rhein-Lahn
56346	Prath	Rheinland-Pfalz	RP	Rhein-Lahn
56346	Lykershausen	Rheinland-Pfalz	RP	Rhein-Lahn
56348	Kestert	Rheinland-Pfalz	RP	Rhein-Lahn
56348	Dörscheid	Rheinland-Pfalz	RP	Rhein-Lahn
56348	Dahlheim	Rheinland-Pfalz	RP	Rhein-Lahn
56348	Weisel	Rheinland-Pfalz	RP	Rhein-Lahn
56348	Patersberg	Rheinland-Pfalz	RP	Rhein-Lahn
56348	Bornich	Rheinland-Pfalz	RP	Rhein-Lahn
56349	Kaub	Rheinland-Pfalz	RP	Rhein-Lahn
56355	Nastätten	Rheinland-Pfalz	RP	Rhein-Lahn
56355	Hunzel	Rheinland-Pfalz	RP	Rhein-Lahn
56355	Diethardt	Rheinland-Pfalz	RP	Rhein-Lahn
56355	Bettendorf	Rheinland-Pfalz	RP	Rhein-Lahn
56355	Weidenbach	Rheinland-Pfalz	RP	Rhein-Lahn
56355	Kehlbach	Rheinland-Pfalz	RP	Rhein-Lahn
56355	Winterwerb	Rheinland-Pfalz	RP	Rhein-Lahn
56355	Oberbachheim	Rheinland-Pfalz	RP	Rhein-Lahn
56355	Lautert	Rheinland-Pfalz	RP	Rhein-Lahn
56355	Endlichhofen	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Miehlen	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Marienfels	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Oberwallmenach	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Buch	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Gemmerich	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Rettershain	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Eschbach	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Oelsberg	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Ehr	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Kasdorf	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Nochern	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Ruppertshofen	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Obertiefenbach	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Pohl	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Weyer	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Lollschied	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Niederbachheim	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Hainau	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Himmighofen	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Bogel	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Lierschied	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Holzhausen an der Haide	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Lipporn	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Geisig	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Niederwallmenach	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Dessighofen	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Reitzenhain	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Berg	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Dornholzhausen	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Reichenberg	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Welterod	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Strüth	Rheinland-Pfalz	RP	Rhein-Lahn
56357	Auel	Rheinland-Pfalz	RP	Rhein-Lahn
56368	Berghausen	Rheinland-Pfalz	RP	Rhein-Lahn
56368	Roth	Rheinland-Pfalz	RP	Rhein-Lahn
56368	Herold	Rheinland-Pfalz	RP	Rhein-Lahn
56368	Ergeshausen	Rheinland-Pfalz	RP	Rhein-Lahn
56368	Niedertiefenbach	Rheinland-Pfalz	RP	Rhein-Lahn
56368	Klingelbach	Rheinland-Pfalz	RP	Rhein-Lahn
56368	Katzenelnbogen	Rheinland-Pfalz	RP	Rhein-Lahn
56370	Kördorf	Rheinland-Pfalz	RP	Rhein-Lahn
56370	Allendorf	Rheinland-Pfalz	RP	Rhein-Lahn
56370	Wasenbach	Rheinland-Pfalz	RP	Rhein-Lahn
56370	Ebertshausen	Rheinland-Pfalz	RP	Rhein-Lahn
56370	Berndroth	Rheinland-Pfalz	RP	Rhein-Lahn
56370	Oberfischbach	Rheinland-Pfalz	RP	Rhein-Lahn
56370	Eisighofen	Rheinland-Pfalz	RP	Rhein-Lahn
56370	Dörsdorf	Rheinland-Pfalz	RP	Rhein-Lahn
56370	Biebrich	Rheinland-Pfalz	RP	Rhein-Lahn
56370	Attenhausen	Rheinland-Pfalz	RP	Rhein-Lahn
56370	Gutenacker	Rheinland-Pfalz	RP	Rhein-Lahn
56370	Mittelfischbach	Rheinland-Pfalz	RP	Rhein-Lahn
56370	Reckenroth	Rheinland-Pfalz	RP	Rhein-Lahn
56370	Bremberg	Rheinland-Pfalz	RP	Rhein-Lahn
56370	Rettert	Rheinland-Pfalz	RP	Rhein-Lahn
56370	Schönborn	Rheinland-Pfalz	RP	Rhein-Lahn
56377	Misselberg	Rheinland-Pfalz	RP	Rhein-Lahn
56377	Nassau	Rheinland-Pfalz	RP	Rhein-Lahn
56377	Seelbach	Rheinland-Pfalz	RP	Rhein-Lahn
56377	Schweighausen	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Hömberg	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Weinähr	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Zimmerschied	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Horhausen	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Obernhof	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Winden	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Steinsberg	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Charlottenberg	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Oberwies	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Dörnberg	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Singhofen	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Geilnau	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Sulzbach	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Scheidt	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Laurenburg	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Dienethal	Rheinland-Pfalz	RP	Rhein-Lahn
56379	Holzappel	Rheinland-Pfalz	RP	Rhein-Lahn
56410	Montabaur	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Görgeshausen	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Nentershausen	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Gackenbach	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Heilberscheid	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Großholbach	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Oberelbert	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Heiligenroth	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Boden	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Welschneudorf	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Hübingen	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Ruppach-Goldhausen	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Niederelbert	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Girod	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Stahlhofen	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Holler	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Daubach	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Untershausen	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Nomborn	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Horbach	Rheinland-Pfalz	RP	Westerwaldkreis
56412	Niedererbach	Rheinland-Pfalz	RP	Westerwaldkreis
56414	Salz	Rheinland-Pfalz	RP	Westerwaldkreis
56414	Dreikirchen	Rheinland-Pfalz	RP	Westerwaldkreis
56414	Molsberg	Rheinland-Pfalz	RP	Westerwaldkreis
56414	Bilkheim	Rheinland-Pfalz	RP	Westerwaldkreis
56414	Steinefrenz	Rheinland-Pfalz	RP	Westerwaldkreis
56414	Berod bei Wallmerod	Rheinland-Pfalz	RP	Westerwaldkreis
56414	Zehnhausen bei Wallmerod	Rheinland-Pfalz	RP	Westerwaldkreis
56414	Herschbach (Oberwesterwald)	Rheinland-Pfalz	RP	Westerwaldkreis
56414	Meudt	Rheinland-Pfalz	RP	Westerwaldkreis
56414	Weroth	Rheinland-Pfalz	RP	Westerwaldkreis
56414	Oberahr	Rheinland-Pfalz	RP	Westerwaldkreis
56414	Obererbach	Rheinland-Pfalz	RP	Westerwaldkreis
56414	Hundsangen	Rheinland-Pfalz	RP	Westerwaldkreis
56414	Niederahr	Rheinland-Pfalz	RP	Westerwaldkreis
56414	Wallmerod	Rheinland-Pfalz	RP	Westerwaldkreis
56422	Wirges	Rheinland-Pfalz	RP	Westerwaldkreis
56424	Moschheim	Rheinland-Pfalz	RP	Westerwaldkreis
56424	Staudt	Rheinland-Pfalz	RP	Westerwaldkreis
56424	Ebernhahn	Rheinland-Pfalz	RP	Westerwaldkreis
56424	Mogendorf	Rheinland-Pfalz	RP	Westerwaldkreis
56424	Bannberscheid	Rheinland-Pfalz	RP	Westerwaldkreis
56427	Siershahn	Rheinland-Pfalz	RP	Westerwaldkreis
56428	Dernbach (Westerwald)	Rheinland-Pfalz	RP	Westerwaldkreis
56457	Halbs	Rheinland-Pfalz	RP	Westerwaldkreis
56457	Westerburg	Rheinland-Pfalz	RP	Westerwaldkreis
56457	Hergenroth	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Kaden	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Berzhahn	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Winnen	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Pottum	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Willmenrod	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Mähren	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Guckheim	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Weltersburg	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Rothenbach	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Stockum-Püschen	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Elbingen	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Ailertchen	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Stahlhofen am Wiesensee	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Gemünden	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Brandscheid	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Kölbingen	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Langenhahn	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Rotenhain	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Härtlingen	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Girkenroth	Rheinland-Pfalz	RP	Westerwaldkreis
56459	Bellingen	Rheinland-Pfalz	RP	Westerwaldkreis
56462	Höhn	Rheinland-Pfalz	RP	Westerwaldkreis
56470	Bad Marienberg	Rheinland-Pfalz	RP	Westerwaldkreis
56472	Lautzenbrücken	Rheinland-Pfalz	RP	Westerwaldkreis
56472	Fehl-Ritzhausen	Rheinland-Pfalz	RP	Westerwaldkreis
56472	Nisterberg	Rheinland-Pfalz	RP	Altenkirchen
56472	Dreisbach	Rheinland-Pfalz	RP	Westerwaldkreis
56472	Hardt	Rheinland-Pfalz	RP	Westerwaldkreis
56472	Hahn bei Marienberg	Rheinland-Pfalz	RP	Westerwaldkreis
56472	Stockhausen-Illfurth	Rheinland-Pfalz	RP	Westerwaldkreis
56472	Nisterau	Rheinland-Pfalz	RP	Westerwaldkreis
56472	Großseifen	Rheinland-Pfalz	RP	Westerwaldkreis
56472	Hof	Rheinland-Pfalz	RP	Westerwaldkreis
56477	Nister-Möhrendorf	Rheinland-Pfalz	RP	Westerwaldkreis
56477	Rennerod	Rheinland-Pfalz	RP	Westerwaldkreis
56477	Zehnhausen bei Rennerod	Rheinland-Pfalz	RP	Westerwaldkreis
56477	Waigandshain	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Salzburg	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Neunkirchen	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Westernohe	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Stein-Neukirch	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Seck	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Irmtraut	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Willingen	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Homberg	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Neustadt (Westerwald)	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Hellenhahn-Schellenberg	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Waldmühlen	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Oberrod	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Niederroßbach	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Hüblingen	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Liebenscheid	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Rehe	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Bretthausen	Rheinland-Pfalz	RP	Westerwaldkreis
56479	Oberroßbach	Rheinland-Pfalz	RP	Westerwaldkreis
56564	Neuwied	Rheinland-Pfalz	RP	Neuwied
56566	Neuwied	Rheinland-Pfalz	RP	Neuwied
56567	Neuwied	Rheinland-Pfalz	RP	Neuwied
56575	Weißenthurm	Rheinland-Pfalz	RP	Mayen-Koblenz
56579	Hardert	Rheinland-Pfalz	RP	Neuwied
56579	Rengsdorf	Rheinland-Pfalz	RP	Neuwied
56579	Bonefeld	Rheinland-Pfalz	RP	Neuwied
56581	Melsbach	Rheinland-Pfalz	RP	Neuwied
56581	Kurtscheid	Rheinland-Pfalz	RP	Neuwied
56581	Ehlscheid	Rheinland-Pfalz	RP	Neuwied
56584	Thalhausen	Rheinland-Pfalz	RP	Neuwied
56584	Rüscheid	Rheinland-Pfalz	RP	Neuwied
56584	Anhausen	Rheinland-Pfalz	RP	Neuwied
56584	Meinborn	Rheinland-Pfalz	RP	Neuwied
56587	Straßenhaus	Rheinland-Pfalz	RP	Neuwied
56587	Oberhonnefeld-Gierend	Rheinland-Pfalz	RP	Neuwied
56587	Oberraden	Rheinland-Pfalz	RP	Neuwied
56588	Waldbreitbach	Rheinland-Pfalz	RP	Neuwied
56589	Datzeroth	Rheinland-Pfalz	RP	Neuwied
56589	Niederbreitbach	Rheinland-Pfalz	RP	Neuwied
56593	Krunkel	Rheinland-Pfalz	RP	Altenkirchen
56593	Obersteinebach	Rheinland-Pfalz	RP	Altenkirchen
56593	Niedersteinebach	Rheinland-Pfalz	RP	Altenkirchen
56593	Horhausen	Rheinland-Pfalz	RP	Altenkirchen
56593	Pleckhausen	Rheinland-Pfalz	RP	Altenkirchen
56593	Bürdenbach	Rheinland-Pfalz	RP	Altenkirchen
56593	Güllesheim	Rheinland-Pfalz	RP	Altenkirchen
56594	Willroth	Rheinland-Pfalz	RP	Altenkirchen
56598	Hammerstein	Rheinland-Pfalz	RP	Neuwied
56598	Rheinbrohl	Rheinland-Pfalz	RP	Neuwied
56599	Leutesdorf	Rheinland-Pfalz	RP	Neuwied
56626	Andernach	Rheinland-Pfalz	RP	Mayen-Koblenz
56630	Kretz	Rheinland-Pfalz	RP	Mayen-Koblenz
56637	Plaidt	Rheinland-Pfalz	RP	Mayen-Koblenz
56642	Kruft	Rheinland-Pfalz	RP	Mayen-Koblenz
56645	Nickenich	Rheinland-Pfalz	RP	Mayen-Koblenz
56648	Saffig	Rheinland-Pfalz	RP	Mayen-Koblenz
56651	Brenk	Rheinland-Pfalz	RP	Ahrweiler
56651	Niederzissen	Rheinland-Pfalz	RP	Ahrweiler
56651	Oberzissen	Rheinland-Pfalz	RP	Ahrweiler
56651	Galenberg	Rheinland-Pfalz	RP	Ahrweiler
56651	Oberdürenbach	Rheinland-Pfalz	RP	Ahrweiler
56651	Niederdürenbach	Rheinland-Pfalz	RP	Ahrweiler
56653	Wassenach	Rheinland-Pfalz	RP	Ahrweiler
56653	Wehr	Rheinland-Pfalz	RP	Ahrweiler
56653	Glees	Rheinland-Pfalz	RP	Ahrweiler
56656	Brohl-Lützing	Rheinland-Pfalz	RP	Ahrweiler
56659	Burgbrohl	Rheinland-Pfalz	RP	Ahrweiler
56727	Mayen	Rheinland-Pfalz	RP	Mayen-Koblenz
56727	Sankt Johann	Rheinland-Pfalz	RP	Mayen-Koblenz
56727	Reudelsterz	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Siebenbach	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Nitz	Rheinland-Pfalz	RP	Vulkaneifel
56729	Nachtsheim	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Weiler	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Bermel	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Arft	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Anschau	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Kehrig	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Luxem	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Langscheid	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Kirchwald	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Monreal	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Ditscheid	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Virneburg	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Lind	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Münk	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Ettringen	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Herresbach	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Boos	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Langenfeld	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Acht	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Hirten	Rheinland-Pfalz	RP	Mayen-Koblenz
56729	Baar	Rheinland-Pfalz	RP	Vulkaneifel
56729	Welschenbach	Rheinland-Pfalz	RP	Mayen-Koblenz
56736	Kottenheim	Rheinland-Pfalz	RP	Mayen-Koblenz
56743	Mendig	Rheinland-Pfalz	RP	Mayen-Koblenz
56743	Thür	Rheinland-Pfalz	RP	Mayen-Koblenz
56745	Hausten	Rheinland-Pfalz	RP	Mayen-Koblenz
56745	Volkesfeld	Rheinland-Pfalz	RP	Mayen-Koblenz
56745	Rieden	Rheinland-Pfalz	RP	Mayen-Koblenz
56745	Weibern	Rheinland-Pfalz	RP	Ahrweiler
56745	Bell	Rheinland-Pfalz	RP	Mayen-Koblenz
56746	Hohenleimbach	Rheinland-Pfalz	RP	Ahrweiler
56746	Kempenich	Rheinland-Pfalz	RP	Ahrweiler
56746	Spessart	Rheinland-Pfalz	RP	Ahrweiler
56751	Kollig	Rheinland-Pfalz	RP	Mayen-Koblenz
56751	Einig	Rheinland-Pfalz	RP	Mayen-Koblenz
56751	Gering	Rheinland-Pfalz	RP	Mayen-Koblenz
56751	Polch	Rheinland-Pfalz	RP	Mayen-Koblenz
56753	Naunheim	Rheinland-Pfalz	RP	Mayen-Koblenz
56753	Mertloch	Rheinland-Pfalz	RP	Mayen-Koblenz
56753	Welling	Rheinland-Pfalz	RP	Mayen-Koblenz
56753	Pillig	Rheinland-Pfalz	RP	Mayen-Koblenz
56753	Trimbs	Rheinland-Pfalz	RP	Mayen-Koblenz
56754	Brohl	Rheinland-Pfalz	RP	Cochem-Zell
56754	Binningen	Rheinland-Pfalz	RP	Cochem-Zell
56754	Dünfus	Rheinland-Pfalz	RP	Cochem-Zell
56754	Forst (Eifel)	Rheinland-Pfalz	RP	Cochem-Zell
56754	Möntenich	Rheinland-Pfalz	RP	Cochem-Zell
56754	Roes	Rheinland-Pfalz	RP	Cochem-Zell
56759	Kaisersesch	Rheinland-Pfalz	RP	Cochem-Zell
56759	Eppenberg	Rheinland-Pfalz	RP	Cochem-Zell
56759	Leienkaul	Rheinland-Pfalz	RP	Cochem-Zell
56759	Laubach	Rheinland-Pfalz	RP	Cochem-Zell
56759	Kalenborn	Rheinland-Pfalz	RP	Cochem-Zell
56761	Kaifenheim	Rheinland-Pfalz	RP	Cochem-Zell
56761	Gamlen	Rheinland-Pfalz	RP	Cochem-Zell
56761	Urmersbach	Rheinland-Pfalz	RP	Cochem-Zell
56761	Düngenheim	Rheinland-Pfalz	RP	Cochem-Zell
56761	Hauroth	Rheinland-Pfalz	RP	Cochem-Zell
56761	Zettingen	Rheinland-Pfalz	RP	Cochem-Zell
2828	Görlitz	Sachsen	SN	Görlitz
56761	Müllenbach	Rheinland-Pfalz	RP	Cochem-Zell
56761	Eulgem	Rheinland-Pfalz	RP	Cochem-Zell
56761	Hambuch	Rheinland-Pfalz	RP	Cochem-Zell
56761	Masburg	Rheinland-Pfalz	RP	Cochem-Zell
56761	Brachtendorf	Rheinland-Pfalz	RP	Cochem-Zell
56766	Horperath	Rheinland-Pfalz	RP	Vulkaneifel
56766	Filz	Rheinland-Pfalz	RP	Cochem-Zell
56766	Berenbach	Rheinland-Pfalz	RP	Vulkaneifel
56766	Ulmen	Rheinland-Pfalz	RP	Cochem-Zell
56766	Auderath	Rheinland-Pfalz	RP	Cochem-Zell
56767	Mosbruch	Rheinland-Pfalz	RP	Vulkaneifel
56767	Kolverath	Rheinland-Pfalz	RP	Vulkaneifel
56767	Lirstal	Rheinland-Pfalz	RP	Vulkaneifel
56767	Höchstberg	Rheinland-Pfalz	RP	Vulkaneifel
56767	Kötterichen	Rheinland-Pfalz	RP	Vulkaneifel
56767	Kaperich	Rheinland-Pfalz	RP	Vulkaneifel
56767	Sassen	Rheinland-Pfalz	RP	Vulkaneifel
56767	Ueß	Rheinland-Pfalz	RP	Vulkaneifel
56767	Oberelz	Rheinland-Pfalz	RP	Vulkaneifel
56767	Uersfeld	Rheinland-Pfalz	RP	Vulkaneifel
56767	Gunderath	Rheinland-Pfalz	RP	Vulkaneifel
56769	Retterath	Rheinland-Pfalz	RP	Vulkaneifel
56769	Arbach	Rheinland-Pfalz	RP	Vulkaneifel
56769	Mannebach	Rheinland-Pfalz	RP	Vulkaneifel
56769	Bereborn	Rheinland-Pfalz	RP	Vulkaneifel
56812	Dohr	Rheinland-Pfalz	RP	Cochem-Zell
56812	Cochem	Rheinland-Pfalz	RP	Cochem-Zell
56812	Valwig	Rheinland-Pfalz	RP	Cochem-Zell
56814	Bruttig-Fankel	Rheinland-Pfalz	RP	Cochem-Zell
56814	Landkern	Rheinland-Pfalz	RP	Cochem-Zell
56814	Ernst	Rheinland-Pfalz	RP	Cochem-Zell
56814	Greimersburg	Rheinland-Pfalz	RP	Cochem-Zell
56814	Ediger-Eller	Rheinland-Pfalz	RP	Cochem-Zell
56814	Beilstein	Rheinland-Pfalz	RP	Cochem-Zell
56814	Wirfus	Rheinland-Pfalz	RP	Cochem-Zell
56814	Faid	Rheinland-Pfalz	RP	Cochem-Zell
56814	Illerich	Rheinland-Pfalz	RP	Cochem-Zell
56814	Bremm	Rheinland-Pfalz	RP	Cochem-Zell
56818	Klotten	Rheinland-Pfalz	RP	Cochem-Zell
56820	Nehren	Rheinland-Pfalz	RP	Cochem-Zell
56820	Briedern	Rheinland-Pfalz	RP	Cochem-Zell
56820	Senheim-Senhals	Rheinland-Pfalz	RP	Cochem-Zell
56820	Mesenich	Rheinland-Pfalz	RP	Cochem-Zell
56821	Ellenz-Poltersdorf	Rheinland-Pfalz	RP	Cochem-Zell
56823	Büchel	Rheinland-Pfalz	RP	Cochem-Zell
56825	Kliding	Rheinland-Pfalz	RP	Cochem-Zell
56825	Gevenich	Rheinland-Pfalz	RP	Cochem-Zell
56825	Urschmitt	Rheinland-Pfalz	RP	Cochem-Zell
56825	Gillenbeuren	Rheinland-Pfalz	RP	Cochem-Zell
56825	Schmitt	Rheinland-Pfalz	RP	Cochem-Zell
56825	Weiler	Rheinland-Pfalz	RP	Cochem-Zell
56825	Beuren	Rheinland-Pfalz	RP	Cochem-Zell
56826	Lutzerath	Rheinland-Pfalz	RP	Cochem-Zell
56826	Wollmerath	Rheinland-Pfalz	RP	Cochem-Zell
56826	Wagenhausen	Rheinland-Pfalz	RP	Cochem-Zell
56828	Alflen	Rheinland-Pfalz	RP	Cochem-Zell
56829	Brieden	Rheinland-Pfalz	RP	Cochem-Zell
56829	Kail	Rheinland-Pfalz	RP	Cochem-Zell
56829	Pommern	Rheinland-Pfalz	RP	Cochem-Zell
56841	Traben-Trarbach	Rheinland-Pfalz	RP	Bernkastel-Wittlich
56843	Lötzbeuren	Rheinland-Pfalz	RP	Bernkastel-Wittlich
56843	Starkenburg	Rheinland-Pfalz	RP	Bernkastel-Wittlich
56843	Irmenach	Rheinland-Pfalz	RP	Bernkastel-Wittlich
56843	Burg (Mosel)	Rheinland-Pfalz	RP	Bernkastel-Wittlich
56850	Raversbeuren	Rheinland-Pfalz	RP	Rhein-Hunsrück
56850	Hahn	Rheinland-Pfalz	RP	Rhein-Hunsrück
56850	Enkirch	Rheinland-Pfalz	RP	Bernkastel-Wittlich
56856	Zell	Rheinland-Pfalz	RP	Cochem-Zell
56858	Würrich	Rheinland-Pfalz	RP	Rhein-Hunsrück
56858	Sosberg	Rheinland-Pfalz	RP	Cochem-Zell
56858	Sankt Aldegund	Rheinland-Pfalz	RP	Cochem-Zell
56858	Altstrimmig	Rheinland-Pfalz	RP	Cochem-Zell
56858	Neef	Rheinland-Pfalz	RP	Cochem-Zell
56858	Altlay	Rheinland-Pfalz	RP	Cochem-Zell
56858	Haserich	Rheinland-Pfalz	RP	Cochem-Zell
56858	Belg	Rheinland-Pfalz	RP	Rhein-Hunsrück
56858	Mittelstrimmig	Rheinland-Pfalz	RP	Cochem-Zell
56858	Forst (Hunsrück)	Rheinland-Pfalz	RP	Rhein-Hunsrück
56858	Grenderich	Rheinland-Pfalz	RP	Cochem-Zell
56858	Tellig	Rheinland-Pfalz	RP	Cochem-Zell
56858	Liesenich	Rheinland-Pfalz	RP	Cochem-Zell
56858	Rödelhausen	Rheinland-Pfalz	RP	Rhein-Hunsrück
56858	Peterswald-Löffelscheid	Rheinland-Pfalz	RP	Cochem-Zell
56859	Alf	Rheinland-Pfalz	RP	Cochem-Zell
56859	Bullay	Rheinland-Pfalz	RP	Cochem-Zell
56861	Reil	Rheinland-Pfalz	RP	Bernkastel-Wittlich
56862	Pünderich	Rheinland-Pfalz	RP	Cochem-Zell
56864	Bad Bertrich	Rheinland-Pfalz	RP	Cochem-Zell
56865	Blankenrath	Rheinland-Pfalz	RP	Cochem-Zell
56865	Schauren	Rheinland-Pfalz	RP	Cochem-Zell
56865	Walhausen	Rheinland-Pfalz	RP	Cochem-Zell
56865	Panzweiler	Rheinland-Pfalz	RP	Cochem-Zell
56865	Reidenhausen	Rheinland-Pfalz	RP	Cochem-Zell
56865	Hesweiler	Rheinland-Pfalz	RP	Cochem-Zell
56865	Moritzheim	Rheinland-Pfalz	RP	Cochem-Zell
56867	Briedel	Rheinland-Pfalz	RP	Cochem-Zell
56869	Mastershausen	Rheinland-Pfalz	RP	Rhein-Hunsrück
57518	Betzdorf	Rheinland-Pfalz	RP	Altenkirchen
57518	Steineroth	Rheinland-Pfalz	RP	Altenkirchen
57518	Alsdorf	Rheinland-Pfalz	RP	Altenkirchen
57520	Rosenheim	Rheinland-Pfalz	RP	Altenkirchen
57520	Langenbach bei Kirburg	Rheinland-Pfalz	RP	Westerwaldkreis
57520	Derschen	Rheinland-Pfalz	RP	Altenkirchen
57520	Grünebach	Rheinland-Pfalz	RP	Altenkirchen
57520	Schutzbach	Rheinland-Pfalz	RP	Altenkirchen
57520	Dickendorf	Rheinland-Pfalz	RP	Altenkirchen
57520	Steinebach/Sieg	Rheinland-Pfalz	RP	Altenkirchen
57520	Friedewald	Rheinland-Pfalz	RP	Altenkirchen
57520	Mauden	Rheinland-Pfalz	RP	Altenkirchen
57520	Emmerzhausen	Rheinland-Pfalz	RP	Altenkirchen
57520	Niederdreisbach	Rheinland-Pfalz	RP	Altenkirchen
57520	Kausen	Rheinland-Pfalz	RP	Altenkirchen
57520	Molzhain	Rheinland-Pfalz	RP	Altenkirchen
57520	Neunkhausen	Rheinland-Pfalz	RP	Westerwaldkreis
57537	Wissen	Rheinland-Pfalz	RP	Altenkirchen
57537	Forst	Rheinland-Pfalz	RP	Altenkirchen
57537	Mittelhof	Rheinland-Pfalz	RP	Altenkirchen
57539	Hövels	Rheinland-Pfalz	RP	Altenkirchen
57539	Bitzen	Rheinland-Pfalz	RP	Altenkirchen
57539	Selbach	Rheinland-Pfalz	RP	Altenkirchen
57539	Breitscheidt	Rheinland-Pfalz	RP	Altenkirchen
57539	Etzbach	Rheinland-Pfalz	RP	Altenkirchen
57539	Bruchertseifen	Rheinland-Pfalz	RP	Altenkirchen
57539	Fürthen	Rheinland-Pfalz	RP	Altenkirchen
57539	Roth	Rheinland-Pfalz	RP	Altenkirchen
57548	Kirchen	Rheinland-Pfalz	RP	Altenkirchen
57555	Brachbach	Rheinland-Pfalz	RP	Altenkirchen
57555	Mudersbach	Rheinland-Pfalz	RP	Altenkirchen
57562	Herdorf	Rheinland-Pfalz	RP	Altenkirchen
57567	Daaden	Rheinland-Pfalz	RP	Altenkirchen
57572	Niederfischbach	Rheinland-Pfalz	RP	Altenkirchen
57572	Harbach	Rheinland-Pfalz	RP	Altenkirchen
57577	Hamm	Rheinland-Pfalz	RP	Altenkirchen
57577	Seelbach	Rheinland-Pfalz	RP	Altenkirchen
57578	Elkenroth	Rheinland-Pfalz	RP	Altenkirchen
57580	Gebhardshain	Rheinland-Pfalz	RP	Altenkirchen
57580	Fensdorf	Rheinland-Pfalz	RP	Altenkirchen
57580	Elben	Rheinland-Pfalz	RP	Altenkirchen
57581	Katzwinkel	Rheinland-Pfalz	RP	Altenkirchen
57583	Mörlen	Rheinland-Pfalz	RP	Westerwaldkreis
57583	Nauroth	Rheinland-Pfalz	RP	Altenkirchen
57584	Wallmenroth	Rheinland-Pfalz	RP	Altenkirchen
57584	Scheuerfeld	Rheinland-Pfalz	RP	Altenkirchen
57586	Weitefeld	Rheinland-Pfalz	RP	Altenkirchen
57587	Birken-Honigsessen	Rheinland-Pfalz	RP	Altenkirchen
57589	Niederirsen	Rheinland-Pfalz	RP	Altenkirchen
57589	Birkenbeul	Rheinland-Pfalz	RP	Altenkirchen
57589	Pracht	Rheinland-Pfalz	RP	Altenkirchen
57610	Bachenberg	Rheinland-Pfalz	RP	Altenkirchen
57610	Ingelbach	Rheinland-Pfalz	RP	Altenkirchen
57610	Almersbach	Rheinland-Pfalz	RP	Altenkirchen
57610	Gieleroth	Rheinland-Pfalz	RP	Altenkirchen
57610	Altenkirchen	Rheinland-Pfalz	RP	Altenkirchen
57610	Michelbach	Rheinland-Pfalz	RP	Altenkirchen
57612	Helmenzen	Rheinland-Pfalz	RP	Altenkirchen
57612	Kroppach	Rheinland-Pfalz	RP	Westerwaldkreis
57612	Volkerzen	Rheinland-Pfalz	RP	Altenkirchen
57612	Isert	Rheinland-Pfalz	RP	Altenkirchen
57612	Busenhausen	Rheinland-Pfalz	RP	Altenkirchen
57612	Obererbach	Rheinland-Pfalz	RP	Altenkirchen
57612	Heupelzen	Rheinland-Pfalz	RP	Altenkirchen
57612	Eichelhardt	Rheinland-Pfalz	RP	Altenkirchen
57612	Helmeroth	Rheinland-Pfalz	RP	Altenkirchen
57612	Hemmelzen	Rheinland-Pfalz	RP	Altenkirchen
57612	Ölsen	Rheinland-Pfalz	RP	Altenkirchen
57612	Racksen	Rheinland-Pfalz	RP	Altenkirchen
57612	Giesenhausen	Rheinland-Pfalz	RP	Westerwaldkreis
57612	Kettenhausen	Rheinland-Pfalz	RP	Altenkirchen
57612	Idelberg	Rheinland-Pfalz	RP	Altenkirchen
57612	Hilgenroth	Rheinland-Pfalz	RP	Altenkirchen
57612	Birnbach	Rheinland-Pfalz	RP	Altenkirchen
57614	Woldert	Rheinland-Pfalz	RP	Neuwied
57614	Stürzelbach	Rheinland-Pfalz	RP	Altenkirchen
57614	Steimel	Rheinland-Pfalz	RP	Neuwied
57614	Berod bei Höchstenbach	Rheinland-Pfalz	RP	Altenkirchen
57614	Borod	Rheinland-Pfalz	RP	Westerwaldkreis
57614	Oberwambach	Rheinland-Pfalz	RP	Altenkirchen
57614	Niederwambach	Rheinland-Pfalz	RP	Neuwied
57614	Mudenbach	Rheinland-Pfalz	RP	Westerwaldkreis
57614	Wahlrod	Rheinland-Pfalz	RP	Westerwaldkreis
57614	Ratzert	Rheinland-Pfalz	RP	Neuwied
57614	Fluterschen	Rheinland-Pfalz	RP	Altenkirchen
57627	Gehlert	Rheinland-Pfalz	RP	Westerwaldkreis
57627	Marzhausen	Rheinland-Pfalz	RP	Westerwaldkreis
57627	Hachenburg	Rheinland-Pfalz	RP	Westerwaldkreis
57627	Heuzert	Rheinland-Pfalz	RP	Westerwaldkreis
57627	Astert	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Mörsbach	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Kundert	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Linden	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Merkelbach	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Luckenbach	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Norken	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Dreifelden	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Höchstenbach	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Müschenbach	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Lochum	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Atzelgift	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Limbach	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Wied	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Streithausen	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Kirburg	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Malberg	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Heimborn	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Stein-Wingert	Rheinland-Pfalz	RP	Westerwaldkreis
57629	Steinebach an der Wied	Rheinland-Pfalz	RP	Westerwaldkreis
57632	Flammersfeld	Rheinland-Pfalz	RP	Altenkirchen
2829	Neißeaue	Sachsen	SN	Görlitz
57632	Seifen	Rheinland-Pfalz	RP	Altenkirchen
57632	Peterslahr	Rheinland-Pfalz	RP	Altenkirchen
57632	Eichen	Rheinland-Pfalz	RP	Altenkirchen
57632	Orfgen	Rheinland-Pfalz	RP	Altenkirchen
57632	Rott	Rheinland-Pfalz	RP	Altenkirchen
57632	Giershausen	Rheinland-Pfalz	RP	Altenkirchen
57632	Eulenberg	Rheinland-Pfalz	RP	Altenkirchen
57632	Walterschen	Rheinland-Pfalz	RP	Altenkirchen
57632	Schürdt	Rheinland-Pfalz	RP	Altenkirchen
57632	Reiferscheid	Rheinland-Pfalz	RP	Altenkirchen
57632	Berzhausen	Rheinland-Pfalz	RP	Altenkirchen
57632	Ziegenhain	Rheinland-Pfalz	RP	Altenkirchen
57632	Burglahr	Rheinland-Pfalz	RP	Altenkirchen
57632	Seelbach	Rheinland-Pfalz	RP	Altenkirchen
57632	Kescheid	Rheinland-Pfalz	RP	Altenkirchen
57635	Hasselbach	Rheinland-Pfalz	RP	Altenkirchen
57635	Werkhausen	Rheinland-Pfalz	RP	Altenkirchen
57635	Weyerbusch	Rheinland-Pfalz	RP	Altenkirchen
57635	Kircheib	Rheinland-Pfalz	RP	Altenkirchen
57635	Rettersen	Rheinland-Pfalz	RP	Altenkirchen
57635	Kraam	Rheinland-Pfalz	RP	Altenkirchen
57635	Fiersbach	Rheinland-Pfalz	RP	Altenkirchen
57635	Forstmehren	Rheinland-Pfalz	RP	Altenkirchen
57635	Hirz-Maulsbach	Rheinland-Pfalz	RP	Altenkirchen
57635	Mehren	Rheinland-Pfalz	RP	Altenkirchen
57635	Wölmersen	Rheinland-Pfalz	RP	Altenkirchen
57635	Oberirsen	Rheinland-Pfalz	RP	Altenkirchen
57635	Ersfeld	Rheinland-Pfalz	RP	Altenkirchen
57636	Sörth	Rheinland-Pfalz	RP	Altenkirchen
57636	Mammelzen	Rheinland-Pfalz	RP	Altenkirchen
57638	Obernau	Rheinland-Pfalz	RP	Altenkirchen
57638	Schöneberg	Rheinland-Pfalz	RP	Altenkirchen
57638	Neitersen	Rheinland-Pfalz	RP	Altenkirchen
57639	Rodenbach	Rheinland-Pfalz	RP	Neuwied
57639	Oberdreis	Rheinland-Pfalz	RP	Neuwied
57641	Oberlahr	Rheinland-Pfalz	RP	Altenkirchen
57642	Alpenrod	Rheinland-Pfalz	RP	Westerwaldkreis
57644	Welkenbach	Rheinland-Pfalz	RP	Westerwaldkreis
57644	Hattert	Rheinland-Pfalz	RP	Westerwaldkreis
57644	Winkelbach	Rheinland-Pfalz	RP	Westerwaldkreis
57645	Nister	Rheinland-Pfalz	RP	Westerwaldkreis
57647	Enspel	Rheinland-Pfalz	RP	Westerwaldkreis
57647	Nistertal	Rheinland-Pfalz	RP	Westerwaldkreis
57648	Bölsberg	Rheinland-Pfalz	RP	Westerwaldkreis
57648	Unnau	Rheinland-Pfalz	RP	Westerwaldkreis
65391	Sauerthal	Rheinland-Pfalz	RP	Rhein-Lahn
65558	Langenscheid	Rheinland-Pfalz	RP	Rhein-Lahn
65558	Holzheim	Rheinland-Pfalz	RP	Rhein-Lahn
65558	Heistenbach	Rheinland-Pfalz	RP	Rhein-Lahn
65558	Flacht	Rheinland-Pfalz	RP	Rhein-Lahn
65558	Gückingen	Rheinland-Pfalz	RP	Rhein-Lahn
65558	Hirschberg	Rheinland-Pfalz	RP	Rhein-Lahn
65558	Burgschwalbach	Rheinland-Pfalz	RP	Rhein-Lahn
65558	Eppenrod	Rheinland-Pfalz	RP	Rhein-Lahn
65558	Balduinstein	Rheinland-Pfalz	RP	Rhein-Lahn
65558	Isselbach	Rheinland-Pfalz	RP	Rhein-Lahn
65558	Cramberg	Rheinland-Pfalz	RP	Rhein-Lahn
65558	Lohrheim	Rheinland-Pfalz	RP	Rhein-Lahn
65558	Oberneisen	Rheinland-Pfalz	RP	Rhein-Lahn
65558	Kaltenholzhausen	Rheinland-Pfalz	RP	Rhein-Lahn
65582	Aull	Rheinland-Pfalz	RP	Rhein-Lahn
65582	Hambach	Rheinland-Pfalz	RP	Rhein-Lahn
65582	Diez	Rheinland-Pfalz	RP	Rhein-Lahn
65623	Schiesheim	Rheinland-Pfalz	RP	Rhein-Lahn
65623	Hahnstätten	Rheinland-Pfalz	RP	Rhein-Lahn
65623	Mudershausen	Rheinland-Pfalz	RP	Rhein-Lahn
65623	Netzbach	Rheinland-Pfalz	RP	Rhein-Lahn
65624	Altendiez	Rheinland-Pfalz	RP	Rhein-Lahn
65626	Birlenbach	Rheinland-Pfalz	RP	Rhein-Lahn
65629	Niederneisen	Rheinland-Pfalz	RP	Rhein-Lahn
66482	Zweibrücken	Rheinland-Pfalz	RP	Zweibrücken;
66484	Kleinsteinhausen	Rheinland-Pfalz	RP	Südwestpfalz
66484	Schmitshausen	Rheinland-Pfalz	RP	Südwestpfalz
66484	Walshausen	Rheinland-Pfalz	RP	Südwestpfalz
66484	Dietrichingen	Rheinland-Pfalz	RP	Südwestpfalz
66484	Winterbach	Rheinland-Pfalz	RP	Südwestpfalz
66484	Althornbach	Rheinland-Pfalz	RP	Südwestpfalz
66484	Riedelberg	Rheinland-Pfalz	RP	Südwestpfalz
66484	Großsteinhausen	Rheinland-Pfalz	RP	Südwestpfalz
66484	Battweiler	Rheinland-Pfalz	RP	Südwestpfalz
66497	Contwig	Rheinland-Pfalz	RP	Südwestpfalz
66500	Mauschbach	Rheinland-Pfalz	RP	Südwestpfalz
66500	Hornbach	Rheinland-Pfalz	RP	Südwestpfalz
66501	Kleinbundenbach	Rheinland-Pfalz	RP	Südwestpfalz
66501	Großbundenbach	Rheinland-Pfalz	RP	Südwestpfalz
66503	Dellfeld	Rheinland-Pfalz	RP	Südwestpfalz
66504	Bottenbach	Rheinland-Pfalz	RP	Südwestpfalz
66506	Maßweiler	Rheinland-Pfalz	RP	Südwestpfalz
66507	Reifenberg	Rheinland-Pfalz	RP	Südwestpfalz
66509	Rieschweiler-Mühlbach	Rheinland-Pfalz	RP	Südwestpfalz
66849	Landstuhl	Rheinland-Pfalz	RP	Kaiserslautern
66851	Steinalben	Rheinland-Pfalz	RP	Südwestpfalz
66851	Oberarnbach	Rheinland-Pfalz	RP	Kaiserslautern
66851	Mittelbrunn	Rheinland-Pfalz	RP	Kaiserslautern
66851	Queidersbach	Rheinland-Pfalz	RP	Kaiserslautern
66851	Bann	Rheinland-Pfalz	RP	Kaiserslautern
66851	Hauptstuhl	Rheinland-Pfalz	RP	Kaiserslautern
66851	Linden	Rheinland-Pfalz	RP	Kaiserslautern
66851	Horbach	Rheinland-Pfalz	RP	Südwestpfalz
66862	Kindsbach	Rheinland-Pfalz	RP	Kaiserslautern
66869	Kusel	Rheinland-Pfalz	RP	Kusel
66869	Schellweiler	Rheinland-Pfalz	RP	Kusel
66869	Blaubach	Rheinland-Pfalz	RP	Kusel
66869	Ruthweiler	Rheinland-Pfalz	RP	Kusel
66871	Oberalben	Rheinland-Pfalz	RP	Kusel
66871	Reichweiler	Rheinland-Pfalz	RP	Kusel
66871	Herchweiler	Rheinland-Pfalz	RP	Kusel
66871	Ehweiler	Rheinland-Pfalz	RP	Kusel
66871	Etschberg	Rheinland-Pfalz	RP	Kusel
66871	Thallichtenberg	Rheinland-Pfalz	RP	Kusel
66871	Haschbach am Remigiusberg	Rheinland-Pfalz	RP	Kusel
66871	Dennweiler-Frohnbach	Rheinland-Pfalz	RP	Kusel
66871	Pfeffelbach	Rheinland-Pfalz	RP	Kusel
66871	Selchenbach	Rheinland-Pfalz	RP	Kusel
66871	Theisbergstegen	Rheinland-Pfalz	RP	Kusel
66871	Konken	Rheinland-Pfalz	RP	Kusel
66871	Albessen	Rheinland-Pfalz	RP	Kusel
66877	Ramstein-Miesenbach	Rheinland-Pfalz	RP	Kaiserslautern
66879	Kollweiler	Rheinland-Pfalz	RP	Kaiserslautern
66879	Kottweiler-Schwanden	Rheinland-Pfalz	RP	Kaiserslautern
66879	Niedermohr	Rheinland-Pfalz	RP	Kaiserslautern
66879	Steinwenden	Rheinland-Pfalz	RP	Kaiserslautern
66879	Reichenbach-Steegen	Rheinland-Pfalz	RP	Kaiserslautern
66879	Niederstaufenbach	Rheinland-Pfalz	RP	Kusel
66879	Oberstaufenbach	Rheinland-Pfalz	RP	Kusel
66882	Hütschenhausen	Rheinland-Pfalz	RP	Kaiserslautern
66885	Altenglan	Rheinland-Pfalz	RP	Kusel
66885	Bedesbach	Rheinland-Pfalz	RP	Kusel
66887	Sankt Julian	Rheinland-Pfalz	RP	Kusel
66887	Erdesbach	Rheinland-Pfalz	RP	Kusel
66887	Rathsweiler	Rheinland-Pfalz	RP	Kusel
66887	Niederalben	Rheinland-Pfalz	RP	Kusel
66887	Bosenbach	Rheinland-Pfalz	RP	Kusel
66887	Neunkirchen am Potzberg	Rheinland-Pfalz	RP	Kusel
66887	Rammelsbach	Rheinland-Pfalz	RP	Kusel
66887	Welchweiler	Rheinland-Pfalz	RP	Kusel
66887	Glanbrücken	Rheinland-Pfalz	RP	Kusel
66887	Jettenbach	Rheinland-Pfalz	RP	Kusel
66887	Ulmet	Rheinland-Pfalz	RP	Kusel
66887	Horschbach	Rheinland-Pfalz	RP	Kusel
66887	Föckelberg	Rheinland-Pfalz	RP	Kusel
66887	Rutsweiler am Glan	Rheinland-Pfalz	RP	Kusel
66887	Elzweiler	Rheinland-Pfalz	RP	Kusel
66892	Bruchmühlbach-Miesau	Rheinland-Pfalz	RP	Kaiserslautern
66894	Wiesbach	Rheinland-Pfalz	RP	Südwestpfalz
66894	Krähenberg	Rheinland-Pfalz	RP	Südwestpfalz
66894	Bechhofen	Rheinland-Pfalz	RP	Südwestpfalz
66894	Langwieden	Rheinland-Pfalz	RP	Kaiserslautern
66894	Gerhardsbrunn	Rheinland-Pfalz	RP	Kaiserslautern
66894	Rosenkopf	Rheinland-Pfalz	RP	Südwestpfalz
66894	Käshofen	Rheinland-Pfalz	RP	Südwestpfalz
66894	Martinshöhe	Rheinland-Pfalz	RP	Kaiserslautern
66894	Lambsborn	Rheinland-Pfalz	RP	Kaiserslautern
66901	Schönenberg-Kübelberg	Rheinland-Pfalz	RP	Kusel
66903	Ohmbach	Rheinland-Pfalz	RP	Kusel
66903	Dittweiler	Rheinland-Pfalz	RP	Kusel
66903	Frohnhofen	Rheinland-Pfalz	RP	Kusel
66903	Altenkirchen	Rheinland-Pfalz	RP	Kusel
66903	Gries	Rheinland-Pfalz	RP	Kusel
66904	Brücken	Rheinland-Pfalz	RP	Kusel
66904	Börsborn	Rheinland-Pfalz	RP	Kusel
66907	Rehweiler	Rheinland-Pfalz	RP	Kusel
66907	Glan-Münchweiler	Rheinland-Pfalz	RP	Kusel
66909	Hüffler	Rheinland-Pfalz	RP	Kusel
66909	Krottelbach	Rheinland-Pfalz	RP	Kusel
66909	Steinbach am Glan	Rheinland-Pfalz	RP	Kusel
66909	Langenbach	Rheinland-Pfalz	RP	Kusel
66909	Henschtal	Rheinland-Pfalz	RP	Kusel
66909	Wahnwegen	Rheinland-Pfalz	RP	Kusel
66909	Matzenbach	Rheinland-Pfalz	RP	Kusel
66909	Nanzdietschweiler	Rheinland-Pfalz	RP	Kusel
66909	Herschweiler-Pettersheim	Rheinland-Pfalz	RP	Kusel
66909	Quirnbach	Rheinland-Pfalz	RP	Kusel
66914	Waldmohr	Rheinland-Pfalz	RP	Kusel
66916	Dunzweiler	Rheinland-Pfalz	RP	Kusel
66916	Breitenbach	Rheinland-Pfalz	RP	Kusel
66917	Biedershausen	Rheinland-Pfalz	RP	Südwestpfalz
66917	Wallhalben	Rheinland-Pfalz	RP	Südwestpfalz
66917	Knopp-Labach	Rheinland-Pfalz	RP	Südwestpfalz
66919	Schauerberg	Rheinland-Pfalz	RP	Südwestpfalz
66919	Hettenhausen	Rheinland-Pfalz	RP	Südwestpfalz
66919	Hermersberg	Rheinland-Pfalz	RP	Südwestpfalz
66919	Saalstadt	Rheinland-Pfalz	RP	Südwestpfalz
66919	Weselberg	Rheinland-Pfalz	RP	Südwestpfalz
66919	Herschberg	Rheinland-Pfalz	RP	Südwestpfalz
66919	Obernheim-Kirchenarnbach	Rheinland-Pfalz	RP	Südwestpfalz
66953	Pirmasens	Rheinland-Pfalz	RP	Pirmasens;
66954	Pirmasens	Rheinland-Pfalz	RP	Pirmasens;
66955	Pirmasens	Rheinland-Pfalz	RP	Pirmasens;
66957	Schweix	Rheinland-Pfalz	RP	Südwestpfalz
66957	Kröppen	Rheinland-Pfalz	RP	Südwestpfalz
66957	Hilst	Rheinland-Pfalz	RP	Südwestpfalz
66957	Eppenbrunn	Rheinland-Pfalz	RP	Südwestpfalz
66957	Obersimten	Rheinland-Pfalz	RP	Südwestpfalz
66957	Trulben	Rheinland-Pfalz	RP	Südwestpfalz
66957	Ruppertsweiler	Rheinland-Pfalz	RP	Südwestpfalz
66957	Vinningen	Rheinland-Pfalz	RP	Südwestpfalz
66969	Lemberg	Rheinland-Pfalz	RP	Südwestpfalz
66976	Rodalben	Rheinland-Pfalz	RP	Südwestpfalz
66978	Merzalben	Rheinland-Pfalz	RP	Südwestpfalz
66978	Leimen	Rheinland-Pfalz	RP	Südwestpfalz
66978	Donsieders	Rheinland-Pfalz	RP	Südwestpfalz
66978	Clausen	Rheinland-Pfalz	RP	Südwestpfalz
66981	Münchweiler an der Rodalb	Rheinland-Pfalz	RP	Südwestpfalz
66987	Thaleischweiler-Fröschen	Rheinland-Pfalz	RP	Südwestpfalz
66989	Petersberg	Rheinland-Pfalz	RP	Südwestpfalz
66989	Nünschweiler	Rheinland-Pfalz	RP	Südwestpfalz
66989	Höheinöd	Rheinland-Pfalz	RP	Südwestpfalz
66989	Höheischweiler	Rheinland-Pfalz	RP	Südwestpfalz
66989	Höhfröschen	Rheinland-Pfalz	RP	Südwestpfalz
66994	Dahn	Rheinland-Pfalz	RP	Südwestpfalz
66996	Ludwigswinkel	Rheinland-Pfalz	RP	Südwestpfalz
66996	Schönau	Rheinland-Pfalz	RP	Südwestpfalz
66996	Hirschthal	Rheinland-Pfalz	RP	Südwestpfalz
66996	Fischbach bei Dahn	Rheinland-Pfalz	RP	Südwestpfalz
66996	Erfweiler	Rheinland-Pfalz	RP	Südwestpfalz
66996	Schindhard	Rheinland-Pfalz	RP	Südwestpfalz
66999	Hinterweidenthal	Rheinland-Pfalz	RP	Südwestpfalz
67059	Ludwigshafen am Rhein	Rheinland-Pfalz	RP	Ludwigshafen am Rhein;
67061	Ludwigshafen am Rhein	Rheinland-Pfalz	RP	Ludwigshafen am Rhein;
67063	Ludwigshafen am Rhein	Rheinland-Pfalz	RP	Ludwigshafen am Rhein;
67065	Ludwigshafen am Rhein	Rheinland-Pfalz	RP	Ludwigshafen am Rhein;
67067	Ludwigshafen am Rhein	Rheinland-Pfalz	RP	Ludwigshafen am Rhein;
67069	Ludwigshafen am Rhein	Rheinland-Pfalz	RP	Ludwigshafen am Rhein;
67071	Ludwigshafen am Rhein	Rheinland-Pfalz	RP	Ludwigshafen am Rhein;
67098	Bad Dürkheim	Rheinland-Pfalz	RP	Bad Dürkheim
67105	Schifferstadt	Rheinland-Pfalz	RP	Rhein-Pfalz
67112	Mutterstadt	Rheinland-Pfalz	RP	Rhein-Pfalz
67117	Limburgerhof	Rheinland-Pfalz	RP	Rhein-Pfalz
67122	Altrip	Rheinland-Pfalz	RP	Rhein-Pfalz
67125	Dannstadt-Schauernheim	Rheinland-Pfalz	RP	Rhein-Pfalz
67126	Hochdorf-Assenheim	Rheinland-Pfalz	RP	Rhein-Pfalz
67127	Rödersheim-Gronau	Rheinland-Pfalz	RP	Rhein-Pfalz
67133	Maxdorf	Rheinland-Pfalz	RP	Rhein-Pfalz
67134	Birkenheide	Rheinland-Pfalz	RP	Rhein-Pfalz
67136	Fußgönheim	Rheinland-Pfalz	RP	Rhein-Pfalz
67141	Neuhofen	Rheinland-Pfalz	RP	Rhein-Pfalz
67146	Deidesheim	Rheinland-Pfalz	RP	Bad Dürkheim
67147	Forst an der Weinstraße	Rheinland-Pfalz	RP	Bad Dürkheim
67149	Meckenheim	Rheinland-Pfalz	RP	Bad Dürkheim
67150	Niederkirchen bei Deidesheim	Rheinland-Pfalz	RP	Bad Dürkheim
67152	Ruppertsberg	Rheinland-Pfalz	RP	Bad Dürkheim
67157	Wachenheim an der Weinstraße	Rheinland-Pfalz	RP	Bad Dürkheim
67158	Ellerstadt	Rheinland-Pfalz	RP	Bad Dürkheim
67159	Friedelsheim	Rheinland-Pfalz	RP	Bad Dürkheim
67161	Gönnheim	Rheinland-Pfalz	RP	Bad Dürkheim
67165	Waldsee	Rheinland-Pfalz	RP	Rhein-Pfalz
67166	Otterstadt	Rheinland-Pfalz	RP	Rhein-Pfalz
67167	Erpolzheim	Rheinland-Pfalz	RP	Bad Dürkheim
67169	Kallstadt	Rheinland-Pfalz	RP	Bad Dürkheim
67227	Frankenthal (Pfalz)	Rheinland-Pfalz	RP	Frankenthal (Pfalz);
67229	Gerolsheim	Rheinland-Pfalz	RP	Bad Dürkheim
67229	Laumersheim	Rheinland-Pfalz	RP	Bad Dürkheim
67229	Großkarlbach	Rheinland-Pfalz	RP	Bad Dürkheim
67240	Bobenheim-Roxheim	Rheinland-Pfalz	RP	Rhein-Pfalz
67245	Lambsheim	Rheinland-Pfalz	RP	Rhein-Pfalz
67246	Dirmstein	Rheinland-Pfalz	RP	Bad Dürkheim
67251	Freinsheim	Rheinland-Pfalz	RP	Bad Dürkheim
67256	Weisenheim am Sand	Rheinland-Pfalz	RP	Bad Dürkheim
67258	Heßheim	Rheinland-Pfalz	RP	Rhein-Pfalz
67259	Beindersheim	Rheinland-Pfalz	RP	Rhein-Pfalz
67259	Heuchelheim bei Frankenthal	Rheinland-Pfalz	RP	Rhein-Pfalz
67259	Großniedesheim	Rheinland-Pfalz	RP	Rhein-Pfalz
67259	Kleinniedesheim	Rheinland-Pfalz	RP	Rhein-Pfalz
67269	Grünstadt	Rheinland-Pfalz	RP	Bad Dürkheim
67271	Obersülzen	Rheinland-Pfalz	RP	Bad Dürkheim
67271	Battenberg (Pfalz)	Rheinland-Pfalz	RP	Bad Dürkheim
67271	Kindenheim	Rheinland-Pfalz	RP	Bad Dürkheim
67271	Neuleiningen	Rheinland-Pfalz	RP	Bad Dürkheim
67271	Kleinkarlbach	Rheinland-Pfalz	RP	Bad Dürkheim
67271	Mertesheim	Rheinland-Pfalz	RP	Bad Dürkheim
67273	Dackenheim	Rheinland-Pfalz	RP	Bad Dürkheim
67273	Weisenheim am Berg	Rheinland-Pfalz	RP	Bad Dürkheim
67273	Bobenheim am Berg	Rheinland-Pfalz	RP	Bad Dürkheim
67273	Herxheim am Berg	Rheinland-Pfalz	RP	Bad Dürkheim
67278	Bockenheim	Rheinland-Pfalz	RP	Bad Dürkheim
67280	Ebertsheim	Rheinland-Pfalz	RP	Bad Dürkheim
67280	Quirnheim	Rheinland-Pfalz	RP	Bad Dürkheim
67281	Kirchheim an der Weinstraße	Rheinland-Pfalz	RP	Bad Dürkheim
67281	Bissersheim	Rheinland-Pfalz	RP	Bad Dürkheim
67283	Obrigheim	Rheinland-Pfalz	RP	Bad Dürkheim
67292	Kirchheimbolanden	Rheinland-Pfalz	RP	Donnersbergkreis
67294	Ilbesheim	Rheinland-Pfalz	RP	Donnersbergkreis
67294	Orbis	Rheinland-Pfalz	RP	Donnersbergkreis
67294	Bischheim	Rheinland-Pfalz	RP	Donnersbergkreis
67294	Mauchenheim	Rheinland-Pfalz	RP	Alzey-Worms
67294	Rittersheim	Rheinland-Pfalz	RP	Donnersbergkreis
67294	Morschheim	Rheinland-Pfalz	RP	Donnersbergkreis
67294	Oberwiesen	Rheinland-Pfalz	RP	Donnersbergkreis
67294	Gauersheim	Rheinland-Pfalz	RP	Donnersbergkreis
67294	Stetten	Rheinland-Pfalz	RP	Donnersbergkreis
67295	Bolanden	Rheinland-Pfalz	RP	Donnersbergkreis
67297	Marnheim	Rheinland-Pfalz	RP	Donnersbergkreis
67304	Kerzenheim	Rheinland-Pfalz	RP	Donnersbergkreis
67304	Eisenberg	Rheinland-Pfalz	RP	Donnersbergkreis
67305	Ramsen	Rheinland-Pfalz	RP	Donnersbergkreis
67307	Göllheim	Rheinland-Pfalz	RP	Donnersbergkreis
67308	Biedesheim	Rheinland-Pfalz	RP	Donnersbergkreis
67308	Immesheim	Rheinland-Pfalz	RP	Donnersbergkreis
67308	Zell-Zellertal	Rheinland-Pfalz	RP	Donnersbergkreis
67308	Lautersheim	Rheinland-Pfalz	RP	Donnersbergkreis
67308	Bubenheim	Rheinland-Pfalz	RP	Donnersbergkreis
67308	Einselthum	Rheinland-Pfalz	RP	Donnersbergkreis
67308	Ottersheim	Rheinland-Pfalz	RP	Donnersbergkreis
67308	Rüssingen	Rheinland-Pfalz	RP	Donnersbergkreis
67308	Niefernheim-Zellertal	Rheinland-Pfalz	RP	Donnersbergkreis
2829	Schöpstal	Sachsen	SN	Görlitz
67308	Harxheim-Zellertal	Rheinland-Pfalz	RP	Donnersbergkreis
67308	Albisheim (Pfrimm)	Rheinland-Pfalz	RP	Donnersbergkreis
67310	Hettenleidelheim	Rheinland-Pfalz	RP	Bad Dürkheim
67311	Tiefenthal	Rheinland-Pfalz	RP	Bad Dürkheim
67316	Carlsberg	Rheinland-Pfalz	RP	Bad Dürkheim
67317	Altleiningen	Rheinland-Pfalz	RP	Bad Dürkheim
67319	Wattenheim	Rheinland-Pfalz	RP	Bad Dürkheim
67346	Speyer	Rheinland-Pfalz	RP	Speyer;
67354	Römerberg	Rheinland-Pfalz	RP	Rhein-Pfalz
67360	Lingenfeld	Rheinland-Pfalz	RP	Germersheim
67361	Freisbach	Rheinland-Pfalz	RP	Germersheim
67363	Lustadt	Rheinland-Pfalz	RP	Germersheim
67365	Schwegenheim	Rheinland-Pfalz	RP	Germersheim
67366	Weingarten	Rheinland-Pfalz	RP	Germersheim
67368	Westheim	Rheinland-Pfalz	RP	Germersheim
67373	Dudenhofen	Rheinland-Pfalz	RP	Rhein-Pfalz
67374	Hanhofen	Rheinland-Pfalz	RP	Rhein-Pfalz
67376	Harthausen	Rheinland-Pfalz	RP	Rhein-Pfalz
67377	Gommersheim	Rheinland-Pfalz	RP	Südliche Weinstraße
67378	Zeiskam	Rheinland-Pfalz	RP	Germersheim
67433	Neustadt an der Weinstraße	Rheinland-Pfalz	RP	Neustadt an der Weinstraße;
67434	Neustadt an der Weinstraße	Rheinland-Pfalz	RP	Neustadt an der Weinstraße;
67435	Neustadt an der Weinstraße	Rheinland-Pfalz	RP	Neustadt an der Weinstraße;
67454	Haßloch	Rheinland-Pfalz	RP	Bad Dürkheim
67459	Böhl-Iggelheim	Rheinland-Pfalz	RP	Rhein-Pfalz
67466	Lambrecht	Rheinland-Pfalz	RP	Bad Dürkheim
67468	Frankeneck	Rheinland-Pfalz	RP	Bad Dürkheim
67468	Frankenstein	Rheinland-Pfalz	RP	Kaiserslautern
67468	Neidenfels	Rheinland-Pfalz	RP	Bad Dürkheim
67471	Elmstein	Rheinland-Pfalz	RP	Bad Dürkheim
67472	Esthal	Rheinland-Pfalz	RP	Bad Dürkheim
67473	Lindenberg	Rheinland-Pfalz	RP	Bad Dürkheim
67475	Weidenthal	Rheinland-Pfalz	RP	Bad Dürkheim
67480	Edenkoben	Rheinland-Pfalz	RP	Südliche Weinstraße
67482	Böbingen	Rheinland-Pfalz	RP	Südliche Weinstraße
67482	Venningen	Rheinland-Pfalz	RP	Südliche Weinstraße
67482	Freimersheim	Rheinland-Pfalz	RP	Südliche Weinstraße
67482	Altdorf	Rheinland-Pfalz	RP	Südliche Weinstraße
67483	Edesheim	Rheinland-Pfalz	RP	Südliche Weinstraße
67483	Großfischlingen	Rheinland-Pfalz	RP	Südliche Weinstraße
67483	Kleinfischlingen	Rheinland-Pfalz	RP	Südliche Weinstraße
67487	Maikammer	Rheinland-Pfalz	RP	Südliche Weinstraße
67487	Sankt Martin	Rheinland-Pfalz	RP	Südliche Weinstraße
67489	Kirrweiler (Pfalz)	Rheinland-Pfalz	RP	Südliche Weinstraße
67547	Worms	Rheinland-Pfalz	RP	Worms;
67549	Worms	Rheinland-Pfalz	RP	Worms;
67550	Worms	Rheinland-Pfalz	RP	Worms;
67551	Worms	Rheinland-Pfalz	RP	Worms;
67574	Osthofen	Rheinland-Pfalz	RP	Alzey-Worms
67575	Eich	Rheinland-Pfalz	RP	Alzey-Worms
67577	Alsheim	Rheinland-Pfalz	RP	Alzey-Worms
67578	Gimbsheim	Rheinland-Pfalz	RP	Alzey-Worms
67580	Hamm	Rheinland-Pfalz	RP	Alzey-Worms
67582	Mettenheim	Rheinland-Pfalz	RP	Alzey-Worms
67583	Guntersblum	Rheinland-Pfalz	RP	Mainz-Bingen
67585	Dorn-Dürkheim	Rheinland-Pfalz	RP	Mainz-Bingen
67586	Hillesheim	Rheinland-Pfalz	RP	Mainz-Bingen
67587	Wintersheim	Rheinland-Pfalz	RP	Mainz-Bingen
67590	Monsheim	Rheinland-Pfalz	RP	Alzey-Worms
67591	Mölsheim	Rheinland-Pfalz	RP	Alzey-Worms
67591	Hohen-Sülzen	Rheinland-Pfalz	RP	Alzey-Worms
67591	Mörstadt	Rheinland-Pfalz	RP	Alzey-Worms
67591	Wachenheim	Rheinland-Pfalz	RP	Alzey-Worms
67591	Offstein	Rheinland-Pfalz	RP	Alzey-Worms
67592	Flörsheim-Dalsheim	Rheinland-Pfalz	RP	Alzey-Worms
67593	Westhofen	Rheinland-Pfalz	RP	Alzey-Worms
67593	Bermersheim	Rheinland-Pfalz	RP	Alzey-Worms
67595	Bechtheim	Rheinland-Pfalz	RP	Alzey-Worms
67596	Dittelsheim-Heßloch	Rheinland-Pfalz	RP	Alzey-Worms
67596	Frettenheim	Rheinland-Pfalz	RP	Alzey-Worms
67598	Gundersheim	Rheinland-Pfalz	RP	Alzey-Worms
67599	Gundheim	Rheinland-Pfalz	RP	Alzey-Worms
67653	Kaiserslautern	Rheinland-Pfalz	RP	Kaiserslautern;
67655	Kaiserslautern	Rheinland-Pfalz	RP	Kaiserslautern;
67657	Kaiserslautern	Rheinland-Pfalz	RP	Kaiserslautern;
67659	Kaiserslautern	Rheinland-Pfalz	RP	Kaiserslautern;
67661	Kaiserslautern	Rheinland-Pfalz	RP	Kaiserslautern
67663	Kaiserslautern	Rheinland-Pfalz	RP	Kaiserslautern;
67677	Enkenbach-Alsenborn	Rheinland-Pfalz	RP	Kaiserslautern
67678	Mehlingen	Rheinland-Pfalz	RP	Kaiserslautern
67680	Neuhemsbach	Rheinland-Pfalz	RP	Kaiserslautern
67681	Sembach	Rheinland-Pfalz	RP	Kaiserslautern
67681	Wartenberg-Rohrbach	Rheinland-Pfalz	RP	Donnersbergkreis
67685	Weilerbach	Rheinland-Pfalz	RP	Kaiserslautern
67685	Schwedelbach	Rheinland-Pfalz	RP	Kaiserslautern
67685	Erzenhausen	Rheinland-Pfalz	RP	Kaiserslautern
67685	Eulenbis	Rheinland-Pfalz	RP	Kaiserslautern
67686	Mackenbach	Rheinland-Pfalz	RP	Kaiserslautern
67688	Rodenbach	Rheinland-Pfalz	RP	Kaiserslautern
67691	Hochspeyer	Rheinland-Pfalz	RP	Kaiserslautern
67693	Fischbach	Rheinland-Pfalz	RP	Kaiserslautern
67693	Waldleiningen	Rheinland-Pfalz	RP	Kaiserslautern
67697	Otterberg	Rheinland-Pfalz	RP	Kaiserslautern
67699	Heiligenmoschel	Rheinland-Pfalz	RP	Kaiserslautern
67699	Schneckenhausen	Rheinland-Pfalz	RP	Kaiserslautern
67700	Niederkirchen	Rheinland-Pfalz	RP	Kaiserslautern
67701	Schallodenbach	Rheinland-Pfalz	RP	Kaiserslautern
67705	Stelzenberg	Rheinland-Pfalz	RP	Kaiserslautern
67705	Trippstadt	Rheinland-Pfalz	RP	Kaiserslautern
67706	Krickenbach	Rheinland-Pfalz	RP	Kaiserslautern
67707	Schopp	Rheinland-Pfalz	RP	Kaiserslautern
67714	Waldfischbach-Burgalben	Rheinland-Pfalz	RP	Südwestpfalz
67715	Geiselberg	Rheinland-Pfalz	RP	Südwestpfalz
67716	Heltersberg	Rheinland-Pfalz	RP	Südwestpfalz
67718	Schmalenberg	Rheinland-Pfalz	RP	Südwestpfalz
67722	Potzbach	Rheinland-Pfalz	RP	Donnersbergkreis
67722	Winnweiler	Rheinland-Pfalz	RP	Donnersbergkreis
67722	Hochstein	Rheinland-Pfalz	RP	Donnersbergkreis
67722	Alsenbrück-Langmeil	Rheinland-Pfalz	RP	Donnersbergkreis
67724	Gundersweiler	Rheinland-Pfalz	RP	Donnersbergkreis
67724	Höringen	Rheinland-Pfalz	RP	Donnersbergkreis
67724	Gehrweiler	Rheinland-Pfalz	RP	Donnersbergkreis
67724	Gonbach	Rheinland-Pfalz	RP	Donnersbergkreis
67725	Breunigweiler	Rheinland-Pfalz	RP	Donnersbergkreis
67725	Börrstadt	Rheinland-Pfalz	RP	Donnersbergkreis
67727	Lohnsfeld	Rheinland-Pfalz	RP	Donnersbergkreis
67728	Münchweiler an der Alsenz	Rheinland-Pfalz	RP	Donnersbergkreis
67729	Sippersfeld	Rheinland-Pfalz	RP	Donnersbergkreis
67731	Otterbach	Rheinland-Pfalz	RP	Kaiserslautern
67732	Hirschhorn	Rheinland-Pfalz	RP	Kaiserslautern
67734	Sulzbachtal	Rheinland-Pfalz	RP	Kaiserslautern
67734	Katzweiler	Rheinland-Pfalz	RP	Kaiserslautern
67735	Mehlbach	Rheinland-Pfalz	RP	Kaiserslautern
67737	Olsbrücken	Rheinland-Pfalz	RP	Kaiserslautern
67737	Frankelbach	Rheinland-Pfalz	RP	Kaiserslautern
67742	Ginsweiler	Rheinland-Pfalz	RP	Kusel
67742	Deimberg	Rheinland-Pfalz	RP	Kusel
67742	Buborn	Rheinland-Pfalz	RP	Kusel
67742	Adenbach	Rheinland-Pfalz	RP	Kusel
67742	Hausweiler	Rheinland-Pfalz	RP	Kusel
67742	Herren-Sulzbach	Rheinland-Pfalz	RP	Kusel
67742	Lauterecken	Rheinland-Pfalz	RP	Kusel
67742	Heinzenhausen	Rheinland-Pfalz	RP	Kusel
67744	Medard	Rheinland-Pfalz	RP	Kusel
67744	Wiesweiler	Rheinland-Pfalz	RP	Kusel
67744	Kappeln	Rheinland-Pfalz	RP	Kusel
67744	Rathskirchen	Rheinland-Pfalz	RP	Donnersbergkreis
67744	Hoppstädten	Rheinland-Pfalz	RP	Kusel
67744	Hohenöllen	Rheinland-Pfalz	RP	Kusel
67744	Seelen	Rheinland-Pfalz	RP	Donnersbergkreis
67744	Schweinschied	Rheinland-Pfalz	RP	Bad Kreuznach
67744	Kirrweiler	Rheinland-Pfalz	RP	Kusel
67744	Löllbach	Rheinland-Pfalz	RP	Bad Kreuznach
67744	Cronenberg	Rheinland-Pfalz	RP	Kusel
67744	Lohnweiler	Rheinland-Pfalz	RP	Kusel
67744	Homberg	Rheinland-Pfalz	RP	Kusel
67745	Grumbach	Rheinland-Pfalz	RP	Kusel
67746	Langweiler	Rheinland-Pfalz	RP	Kusel
67746	Unterjeckenbach	Rheinland-Pfalz	RP	Kusel
67746	Merzweiler	Rheinland-Pfalz	RP	Kusel
67748	Odenbach	Rheinland-Pfalz	RP	Kusel
67749	Offenbach-Hundheim	Rheinland-Pfalz	RP	Kusel
67749	Nerzweiler	Rheinland-Pfalz	RP	Kusel
67752	Oberweiler-Tiefenbach	Rheinland-Pfalz	RP	Kusel
67752	Rutsweiler an der Lauter	Rheinland-Pfalz	RP	Kusel
67752	Wolfstein	Rheinland-Pfalz	RP	Kusel
67753	Einöllen	Rheinland-Pfalz	RP	Kusel
67753	Hefersweiler	Rheinland-Pfalz	RP	Kusel
67753	Reipoltskirchen	Rheinland-Pfalz	RP	Kusel
67753	Aschbach	Rheinland-Pfalz	RP	Kusel
67753	Rothselberg	Rheinland-Pfalz	RP	Kusel
67754	Eßweiler	Rheinland-Pfalz	RP	Kusel
67756	Relsberg	Rheinland-Pfalz	RP	Kusel
67756	Hinzweiler	Rheinland-Pfalz	RP	Kusel
67756	Oberweiler im Tal	Rheinland-Pfalz	RP	Kusel
67757	Kreimbach-Kaulbach	Rheinland-Pfalz	RP	Kusel
67759	Reichsthal	Rheinland-Pfalz	RP	Donnersbergkreis
67759	Nußbach	Rheinland-Pfalz	RP	Kusel
67806	Marienthal	Rheinland-Pfalz	RP	Donnersbergkreis
67806	Rockenhausen	Rheinland-Pfalz	RP	Donnersbergkreis
67806	Dörrmoschel	Rheinland-Pfalz	RP	Donnersbergkreis
67806	Katzenbach	Rheinland-Pfalz	RP	Donnersbergkreis
67806	Dörnbach	Rheinland-Pfalz	RP	Donnersbergkreis
67806	Teschenmoschel	Rheinland-Pfalz	RP	Donnersbergkreis
67806	Bisterschied	Rheinland-Pfalz	RP	Donnersbergkreis
67808	Imsweiler	Rheinland-Pfalz	RP	Donnersbergkreis
67808	Ruppertsecken	Rheinland-Pfalz	RP	Donnersbergkreis
67808	Weitersweiler	Rheinland-Pfalz	RP	Donnersbergkreis
67808	Bennhausen	Rheinland-Pfalz	RP	Donnersbergkreis
67808	Schönborn	Rheinland-Pfalz	RP	Donnersbergkreis
67808	Stahlberg	Rheinland-Pfalz	RP	Donnersbergkreis
67808	Würzweiler	Rheinland-Pfalz	RP	Donnersbergkreis
67808	Steinbach am Donnersberg	Rheinland-Pfalz	RP	Donnersbergkreis
67808	Bayerfeld-Steckweiler	Rheinland-Pfalz	RP	Donnersbergkreis
67808	Falkenstein	Rheinland-Pfalz	RP	Donnersbergkreis
67808	Schweisweiler	Rheinland-Pfalz	RP	Donnersbergkreis
67808	Ransweiler	Rheinland-Pfalz	RP	Donnersbergkreis
67808	Mörsfeld	Rheinland-Pfalz	RP	Donnersbergkreis
67811	Dielkirchen	Rheinland-Pfalz	RP	Donnersbergkreis
67813	Gerbach	Rheinland-Pfalz	RP	Donnersbergkreis
67813	Sankt Alban	Rheinland-Pfalz	RP	Donnersbergkreis
67814	Dannenfels	Rheinland-Pfalz	RP	Donnersbergkreis
67814	Jakobsweiler	Rheinland-Pfalz	RP	Donnersbergkreis
67816	Standenbühl	Rheinland-Pfalz	RP	Donnersbergkreis
67816	Dreisen	Rheinland-Pfalz	RP	Donnersbergkreis
67817	Imsbach	Rheinland-Pfalz	RP	Donnersbergkreis
67819	Kriegsfeld	Rheinland-Pfalz	RP	Donnersbergkreis
67821	Alsenz	Rheinland-Pfalz	RP	Donnersbergkreis
67821	Oberndorf	Rheinland-Pfalz	RP	Donnersbergkreis
67822	Finkenbach-Gersweiler	Rheinland-Pfalz	RP	Donnersbergkreis
67822	Münsterappel	Rheinland-Pfalz	RP	Donnersbergkreis
67822	Mannweiler-Cölln	Rheinland-Pfalz	RP	Donnersbergkreis
67822	Niederhausen an der Appel	Rheinland-Pfalz	RP	Donnersbergkreis
67822	Oberhausen an der Appel	Rheinland-Pfalz	RP	Donnersbergkreis
67822	Gaugrehweiler	Rheinland-Pfalz	RP	Donnersbergkreis
67822	Waldgrehweiler	Rheinland-Pfalz	RP	Donnersbergkreis
67822	Winterborn	Rheinland-Pfalz	RP	Donnersbergkreis
67822	Kalkofen	Rheinland-Pfalz	RP	Donnersbergkreis
67822	Niedermoschel	Rheinland-Pfalz	RP	Donnersbergkreis
67823	Obermoschel	Rheinland-Pfalz	RP	Donnersbergkreis
67823	Sitters	Rheinland-Pfalz	RP	Donnersbergkreis
67823	Lettweiler	Rheinland-Pfalz	RP	Bad Kreuznach
67823	Unkenbach	Rheinland-Pfalz	RP	Donnersbergkreis
67823	Schiersfeld	Rheinland-Pfalz	RP	Donnersbergkreis
67824	Feilbingert	Rheinland-Pfalz	RP	Bad Kreuznach
67826	Hallgarten	Rheinland-Pfalz	RP	Bad Kreuznach
67827	Becherbach	Rheinland-Pfalz	RP	Bad Kreuznach
67829	Schmittweiler	Rheinland-Pfalz	RP	Bad Kreuznach
67829	Callbach	Rheinland-Pfalz	RP	Bad Kreuznach
67829	Reiffelbach	Rheinland-Pfalz	RP	Bad Kreuznach
76726	Germersheim	Rheinland-Pfalz	RP	Germersheim
76744	Wörth am Rhein	Rheinland-Pfalz	RP	Germersheim
76744	Vollmersweiler	Rheinland-Pfalz	RP	Germersheim
76751	Jockgrim	Rheinland-Pfalz	RP	Germersheim
76756	Bellheim	Rheinland-Pfalz	RP	Germersheim
76761	Rülzheim	Rheinland-Pfalz	RP	Germersheim
76764	Rheinzabern	Rheinland-Pfalz	RP	Germersheim
76767	Hagenbach	Rheinland-Pfalz	RP	Germersheim
76768	Berg (Pfalz)	Rheinland-Pfalz	RP	Germersheim
76770	Hatzenbühl	Rheinland-Pfalz	RP	Germersheim
76771	Hördt	Rheinland-Pfalz	RP	Germersheim
76773	Kuhardt	Rheinland-Pfalz	RP	Germersheim
76774	Leimersheim	Rheinland-Pfalz	RP	Germersheim
76776	Neuburg am Rhein	Rheinland-Pfalz	RP	Germersheim
76777	Neupotz	Rheinland-Pfalz	RP	Germersheim
76779	Scheibenhardt	Rheinland-Pfalz	RP	Germersheim
76829	Leinsweiler	Rheinland-Pfalz	RP	Südliche Weinstraße
76829	Ranschbach	Rheinland-Pfalz	RP	Südliche Weinstraße
76829	Landau in der Pfalz	Rheinland-Pfalz	RP	Landau in der Pfalz
76831	Impflingen	Rheinland-Pfalz	RP	Südliche Weinstraße
76831	Ilbesheim bei Landau in der Pfalz	Rheinland-Pfalz	RP	Südliche Weinstraße
76831	Birkweiler	Rheinland-Pfalz	RP	Südliche Weinstraße
76831	Eschbach	Rheinland-Pfalz	RP	Südliche Weinstraße
76831	Göcklingen	Rheinland-Pfalz	RP	Südliche Weinstraße
76831	Billigheim-Ingenheim	Rheinland-Pfalz	RP	Südliche Weinstraße
76831	Heuchelheim-Klingen	Rheinland-Pfalz	RP	Südliche Weinstraße
76833	Frankweiler	Rheinland-Pfalz	RP	Südliche Weinstraße
76833	Böchingen	Rheinland-Pfalz	RP	Südliche Weinstraße
76833	Siebeldingen	Rheinland-Pfalz	RP	Südliche Weinstraße
76833	Knöringen	Rheinland-Pfalz	RP	Südliche Weinstraße
76833	Walsheim	Rheinland-Pfalz	RP	Südliche Weinstraße
76835	Burrweiler	Rheinland-Pfalz	RP	Südliche Weinstraße
76835	Roschbach	Rheinland-Pfalz	RP	Südliche Weinstraße
76835	Rhodt unter Rietburg	Rheinland-Pfalz	RP	Südliche Weinstraße
76835	Gleisweiler	Rheinland-Pfalz	RP	Südliche Weinstraße
76835	Hainfeld	Rheinland-Pfalz	RP	Südliche Weinstraße
76835	Weyher in der Pfalz	Rheinland-Pfalz	RP	Südliche Weinstraße
76835	Flemlingen	Rheinland-Pfalz	RP	Südliche Weinstraße
76846	Hauenstein	Rheinland-Pfalz	RP	Südwestpfalz
76848	Darstein	Rheinland-Pfalz	RP	Südwestpfalz
76848	Wilgartswiesen	Rheinland-Pfalz	RP	Südwestpfalz
76848	Schwanheim	Rheinland-Pfalz	RP	Südwestpfalz
76848	Lug	Rheinland-Pfalz	RP	Südwestpfalz
76848	Dimbach	Rheinland-Pfalz	RP	Südwestpfalz
76848	Spirkelbach	Rheinland-Pfalz	RP	Südwestpfalz
76855	Annweiler am Trifels	Rheinland-Pfalz	RP	Südliche Weinstraße
76857	Eußerthal	Rheinland-Pfalz	RP	Südliche Weinstraße
76857	Ramberg	Rheinland-Pfalz	RP	Südliche Weinstraße
76857	Waldhambach	Rheinland-Pfalz	RP	Südliche Weinstraße
76857	Dernbach	Rheinland-Pfalz	RP	Südliche Weinstraße
76857	Wernersberg	Rheinland-Pfalz	RP	Südliche Weinstraße
76857	Gossersweiler-Stein	Rheinland-Pfalz	RP	Südliche Weinstraße
76857	Albersweiler	Rheinland-Pfalz	RP	Südliche Weinstraße
76857	Silz	Rheinland-Pfalz	RP	Südliche Weinstraße
76857	Münchweiler am Klingbach	Rheinland-Pfalz	RP	Südliche Weinstraße
76857	Völkersweiler	Rheinland-Pfalz	RP	Südliche Weinstraße
76857	Waldrohrbach	Rheinland-Pfalz	RP	Südliche Weinstraße
76857	Rinnthal	Rheinland-Pfalz	RP	Südliche Weinstraße
76863	Herxheimweyher	Rheinland-Pfalz	RP	Südliche Weinstraße
76863	Herxheim bei Landau/Pfalz	Rheinland-Pfalz	RP	Südliche Weinstraße
76865	Rohrbach	Rheinland-Pfalz	RP	Südliche Weinstraße
76865	Insheim	Rheinland-Pfalz	RP	Südliche Weinstraße
76870	Kandel	Rheinland-Pfalz	RP	Germersheim
76872	Hergersweiler	Rheinland-Pfalz	RP	Südliche Weinstraße
76872	Winden	Rheinland-Pfalz	RP	Germersheim
76872	Steinweiler	Rheinland-Pfalz	RP	Germersheim
76872	Erlenbach	Rheinland-Pfalz	RP	Germersheim
76872	Freckenfeld	Rheinland-Pfalz	RP	Germersheim
76872	Minfeld	Rheinland-Pfalz	RP	Germersheim
76877	Offenbach an der Queich	Rheinland-Pfalz	RP	Südliche Weinstraße
76879	Knittelsheim	Rheinland-Pfalz	RP	Germersheim
76879	Ottersheim	Rheinland-Pfalz	RP	Germersheim
76879	Bornheim	Rheinland-Pfalz	RP	Südliche Weinstraße
76879	Hochstadt	Rheinland-Pfalz	RP	Südliche Weinstraße
76879	Essingen	Rheinland-Pfalz	RP	Südliche Weinstraße
76887	Oberhausen	Rheinland-Pfalz	RP	Südliche Weinstraße
76887	Böllenborn	Rheinland-Pfalz	RP	Südliche Weinstraße
76887	Bad Bergzabern	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Dörrenbach	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Kapellen-Drusweiler	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Pleisweiler-Oberhofen	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Vorderweidenthal	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Gleiszellen-Gleishorbach	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Oberschlettenbach	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Birkenhördt	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Niederhorbach	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Schweigen-Rechtenbach	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Kapsweyer	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Dierbach	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Oberotterbach	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Schweighofen	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Steinfeld	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Klingenmünster	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Niederotterbach	Rheinland-Pfalz	RP	Südliche Weinstraße
76889	Barbelroth	Rheinland-Pfalz	RP	Südliche Weinstraße
76891	Erlenbach	Rheinland-Pfalz	RP	Südwestpfalz
76891	Bruchweiler-Bärenbach	Rheinland-Pfalz	RP	Südwestpfalz
76891	Bobenthal	Rheinland-Pfalz	RP	Südwestpfalz
76891	Niederschlettenbach	Rheinland-Pfalz	RP	Südwestpfalz
76891	Bundenthal	Rheinland-Pfalz	RP	Südwestpfalz
76891	Busenberg	Rheinland-Pfalz	RP	Südwestpfalz
76891	Nothweiler	Rheinland-Pfalz	RP	Südwestpfalz
76891	Rumbach	Rheinland-Pfalz	RP	Südwestpfalz
21039	Börnsen	Schleswig-Holstein	SH	Herzogtum Lauenburg
21039	Hamburg Altengamme	Schleswig-Holstein	SH	Herzogtum Lauenburg
21039	Hamburg Neuengamme	Schleswig-Holstein	SH	Herzogtum Lauenburg
21039	Hamburg Bergedorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
21039	Hamburg Curslack	Schleswig-Holstein	SH	Herzogtum Lauenburg
21039	Escheburg	Schleswig-Holstein	SH	Herzogtum Lauenburg
21465	Wentorf bei Hamburg	Schleswig-Holstein	SH	Herzogtum Lauenburg
21465	Reinbek	Schleswig-Holstein	SH	Stormarn
21481	Lauenburg/Elbe	Schleswig-Holstein	SH	Herzogtum Lauenburg
21481	Buchhorst	Schleswig-Holstein	SH	Herzogtum Lauenburg
21481	Schnakenbek	Schleswig-Holstein	SH	Herzogtum Lauenburg
21483	Krüzen	Schleswig-Holstein	SH	Herzogtum Lauenburg
21483	Basedow	Schleswig-Holstein	SH	Herzogtum Lauenburg
21483	Lütau	Schleswig-Holstein	SH	Herzogtum Lauenburg
21483	Wangelau	Schleswig-Holstein	SH	Herzogtum Lauenburg
21483	Krukow	Schleswig-Holstein	SH	Herzogtum Lauenburg
21483	Gülzow	Schleswig-Holstein	SH	Herzogtum Lauenburg
21483	Lanze	Schleswig-Holstein	SH	Herzogtum Lauenburg
21483	Dalldorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
21483	Juliusburg	Schleswig-Holstein	SH	Herzogtum Lauenburg
21493	Groß Pampau	Schleswig-Holstein	SH	Herzogtum Lauenburg
21493	Basthorst	Schleswig-Holstein	SH	Herzogtum Lauenburg
21493	Schwarzenbek	Schleswig-Holstein	SH	Herzogtum Lauenburg
21493	Mühlenrade	Schleswig-Holstein	SH	Herzogtum Lauenburg
21493	Havekost	Schleswig-Holstein	SH	Herzogtum Lauenburg
21493	Schretstaken	Schleswig-Holstein	SH	Herzogtum Lauenburg
21493	Möhnsen	Schleswig-Holstein	SH	Herzogtum Lauenburg
21493	Talkau	Schleswig-Holstein	SH	Herzogtum Lauenburg
21493	Elmenhorst	Schleswig-Holstein	SH	Herzogtum Lauenburg
21493	Grabau	Schleswig-Holstein	SH	Herzogtum Lauenburg
21493	Fuhlenhagen	Schleswig-Holstein	SH	Herzogtum Lauenburg
21493	Sahms	Schleswig-Holstein	SH	Herzogtum Lauenburg
21493	Grove	Schleswig-Holstein	SH	Herzogtum Lauenburg
21502	Wiershop	Schleswig-Holstein	SH	Herzogtum Lauenburg
21502	Worth	Schleswig-Holstein	SH	Herzogtum Lauenburg
21502	Hamwarde	Schleswig-Holstein	SH	Herzogtum Lauenburg
21502	Geesthacht	Schleswig-Holstein	SH	Herzogtum Lauenburg
21509	Glinde	Schleswig-Holstein	SH	Stormarn
21514	Klein Pampau	Schleswig-Holstein	SH	Herzogtum Lauenburg
21514	Roseburg	Schleswig-Holstein	SH	Herzogtum Lauenburg
21514	Kankelau	Schleswig-Holstein	SH	Herzogtum Lauenburg
21514	Hornbek	Schleswig-Holstein	SH	Herzogtum Lauenburg
21514	Siebeneichen	Schleswig-Holstein	SH	Herzogtum Lauenburg
21514	Güster	Schleswig-Holstein	SH	Herzogtum Lauenburg
21514	Fitzen	Schleswig-Holstein	SH	Herzogtum Lauenburg
21514	Büchen	Schleswig-Holstein	SH	Herzogtum Lauenburg
21514	Witzeeze	Schleswig-Holstein	SH	Herzogtum Lauenburg
21514	Langenlehsten	Schleswig-Holstein	SH	Herzogtum Lauenburg
21514	Bröthen	Schleswig-Holstein	SH	Herzogtum Lauenburg
21514	Göttin	Schleswig-Holstein	SH	Herzogtum Lauenburg
21516	Schulendorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
21516	Woltersdorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
21516	Tramm	Schleswig-Holstein	SH	Herzogtum Lauenburg
21516	Müssen	Schleswig-Holstein	SH	Herzogtum Lauenburg
21521	Wohltorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
21521	Dassendorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
21521	Aumühle	Schleswig-Holstein	SH	Herzogtum Lauenburg
21524	Brunstorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
21526	Hohenhorn	Schleswig-Holstein	SH	Herzogtum Lauenburg
21527	Kollow	Schleswig-Holstein	SH	Herzogtum Lauenburg
21529	Kröppelshagen-Fahrendorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
22113	Hamburg Moorfleet	Schleswig-Holstein	SH	Stormarn
22113	Hamburg Lohbrügge	Schleswig-Holstein	SH	Stormarn
22113	Hamburg Horn	Schleswig-Holstein	SH	Stormarn
22113	Hamburg Billwerder	Schleswig-Holstein	SH	Stormarn
22113	Hamburg	Schleswig-Holstein	SH	Stormarn
22113	Hamburg Billstedt	Schleswig-Holstein	SH	Stormarn
22113	Hamburg Billbrook	Schleswig-Holstein	SH	Stormarn
22113	Hamburg Allermöhe	Schleswig-Holstein	SH	Stormarn
22113	Oststeinbek	Schleswig-Holstein	SH	Stormarn
22145	Stapelfeld	Schleswig-Holstein	SH	Stormarn
22145	Braak	Schleswig-Holstein	SH	Stormarn
22145	Hamburg Rahlstedt	Schleswig-Holstein	SH	Stormarn
22145	Hamburg Farmsen-Berne	Schleswig-Holstein	SH	Stormarn
22844	Norderstedt	Schleswig-Holstein	SH	Segeberg
22846	Norderstedt	Schleswig-Holstein	SH	Segeberg
22848	Norderstedt	Schleswig-Holstein	SH	Segeberg
22850	Norderstedt	Schleswig-Holstein	SH	Segeberg
22851	Norderstedt	Schleswig-Holstein	SH	Segeberg
22869	Schenefeld	Schleswig-Holstein	SH	Pinneberg
22880	Wedel	Schleswig-Holstein	SH	Pinneberg
22885	Barsbüttel	Schleswig-Holstein	SH	Stormarn
22889	Tangstedt	Schleswig-Holstein	SH	Stormarn
22926	Ahrensburg	Schleswig-Holstein	SH	Stormarn
22927	Großhansdorf	Schleswig-Holstein	SH	Stormarn
22929	Schönberg	Schleswig-Holstein	SH	Herzogtum Lauenburg
22929	Köthel	Schleswig-Holstein	SH	Herzogtum Lauenburg
22929	Kasseburg	Schleswig-Holstein	SH	Herzogtum Lauenburg
22929	Delingsdorf	Schleswig-Holstein	SH	Stormarn
22929	Rausdorf	Schleswig-Holstein	SH	Stormarn
22929	Hamfelde in Holstein	Schleswig-Holstein	SH	Stormarn
22929	Hammoor	Schleswig-Holstein	SH	Stormarn
22929	Hamfelde in Lauenburg	Schleswig-Holstein	SH	Herzogtum Lauenburg
22941	Jersbek	Schleswig-Holstein	SH	Stormarn
22941	Bargteheide	Schleswig-Holstein	SH	Stormarn
22946	Dahmker	Schleswig-Holstein	SH	Herzogtum Lauenburg
22946	Trittau	Schleswig-Holstein	SH	Stormarn
22946	Hohenfelde	Schleswig-Holstein	SH	Stormarn
22946	Großensee	Schleswig-Holstein	SH	Stormarn
22946	Grande	Schleswig-Holstein	SH	Stormarn
22946	Brunsbek	Schleswig-Holstein	SH	Stormarn
22949	Ammersbek	Schleswig-Holstein	SH	Stormarn
22952	Lütjensee	Schleswig-Holstein	SH	Stormarn
22955	Hoisdorf	Schleswig-Holstein	SH	Stormarn
22956	Grönwohld	Schleswig-Holstein	SH	Stormarn
22958	Kuddewörde	Schleswig-Holstein	SH	Herzogtum Lauenburg
22959	Linau	Schleswig-Holstein	SH	Herzogtum Lauenburg
22962	Siek	Schleswig-Holstein	SH	Stormarn
22964	Steinburg	Schleswig-Holstein	SH	Stormarn
22965	Todendorf	Schleswig-Holstein	SH	Stormarn
22967	Tremsbüttel	Schleswig-Holstein	SH	Stormarn
22969	Witzhave	Schleswig-Holstein	SH	Stormarn
23539	Lübeck	Schleswig-Holstein	SH	Lübeck; Hansestadt
23552	Lübeck	Schleswig-Holstein	SH	Lübeck; Hansestadt
23554	Lübeck	Schleswig-Holstein	SH	Lübeck; Hansestadt
23556	Lübeck	Schleswig-Holstein	SH	Lübeck; Hansestadt
23558	Lübeck	Schleswig-Holstein	SH	Lübeck; Hansestadt
23560	Lübeck	Schleswig-Holstein	SH	Lübeck; Hansestadt
23562	Lübeck	Schleswig-Holstein	SH	Lübeck; Hansestadt
23564	Lübeck	Schleswig-Holstein	SH	Lübeck; Hansestadt
23566	Lübeck	Schleswig-Holstein	SH	Lübeck; Hansestadt
23568	Lübeck	Schleswig-Holstein	SH	Lübeck; Hansestadt
23569	Lübeck	Schleswig-Holstein	SH	Lübeck; Hansestadt
23570	Lübeck	Schleswig-Holstein	SH	Lübeck; Hansestadt
23611	Bad Schwartau	Schleswig-Holstein	SH	Ostholstein
23617	Stockelsdorf	Schleswig-Holstein	SH	Ostholstein
23619	Hamberge	Schleswig-Holstein	SH	Stormarn
23619	Mönkhagen	Schleswig-Holstein	SH	Stormarn
23619	Rehhorst	Schleswig-Holstein	SH	Stormarn
23619	Badendorf	Schleswig-Holstein	SH	Stormarn
23619	Heilshoop	Schleswig-Holstein	SH	Stormarn
23619	Zarpen	Schleswig-Holstein	SH	Stormarn
23623	Ahrensbök	Schleswig-Holstein	SH	Ostholstein
23626	Ratekau	Schleswig-Holstein	SH	Ostholstein
23627	Groß Sarau	Schleswig-Holstein	SH	Herzogtum Lauenburg
23627	Groß Grönau	Schleswig-Holstein	SH	Herzogtum Lauenburg
23628	Krummesse	Schleswig-Holstein	SH	Herzogtum Lauenburg
23628	Klempau	Schleswig-Holstein	SH	Herzogtum Lauenburg
23629	Sarkwitz	Schleswig-Holstein	SH	Ostholstein
23669	Timmendorfer Strand	Schleswig-Holstein	SH	Ostholstein
23683	Scharbeutz	Schleswig-Holstein	SH	Ostholstein
23684	Scharbeutz	Schleswig-Holstein	SH	Ostholstein
23689	Pansdorf; Holstein	Schleswig-Holstein	SH	Ostholstein
23701	Eutin	Schleswig-Holstein	SH	Ostholstein
23701	Süsel	Schleswig-Holstein	SH	Ostholstein
23714	Kirchnüchel	Schleswig-Holstein	SH	Plön
23714	Malente	Schleswig-Holstein	SH	Ostholstein
23715	Bosau	Schleswig-Holstein	SH	Ostholstein
23717	Kasseedorf	Schleswig-Holstein	SH	Ostholstein
23719	Glasau	Schleswig-Holstein	SH	Segeberg
23730	Neustadt in Holstein	Schleswig-Holstein	SH	Ostholstein
23730	Sierksdorf	Schleswig-Holstein	SH	Ostholstein
23730	Schashagen	Schleswig-Holstein	SH	Ostholstein
23730	Altenkrempe	Schleswig-Holstein	SH	Ostholstein
23738	Manhagen	Schleswig-Holstein	SH	Ostholstein
23738	Lensahn	Schleswig-Holstein	SH	Ostholstein
23738	Beschendorf	Schleswig-Holstein	SH	Ostholstein
23738	Damlos	Schleswig-Holstein	SH	Ostholstein
23738	Harmsdorf	Schleswig-Holstein	SH	Ostholstein
23738	Kabelhorst	Schleswig-Holstein	SH	Ostholstein
23738	Riepsdorf	Schleswig-Holstein	SH	Ostholstein
23743	Grömitz	Schleswig-Holstein	SH	Ostholstein
23744	Schönwalde am Bungsberg	Schleswig-Holstein	SH	Ostholstein
23746	Kellenhusen	Schleswig-Holstein	SH	Ostholstein
23747	Dahme	Schleswig-Holstein	SH	Ostholstein
23749	Grube	Schleswig-Holstein	SH	Ostholstein
23758	Gremersdorf	Schleswig-Holstein	SH	Ostholstein
23758	Wangels	Schleswig-Holstein	SH	Ostholstein
23758	Oldenburg in Holstein	Schleswig-Holstein	SH	Ostholstein
23758	Göhl	Schleswig-Holstein	SH	Ostholstein
23769	Fehmarn	Schleswig-Holstein	SH	Ostholstein
23774	Heiligenhafen	Schleswig-Holstein	SH	Ostholstein
23775	Großenbrode	Schleswig-Holstein	SH	Ostholstein
23777	Heringsdorf	Schleswig-Holstein	SH	Ostholstein
23779	Neukirchen	Schleswig-Holstein	SH	Ostholstein
23795	Groß Rönnau	Schleswig-Holstein	SH	Segeberg
23795	Schwissel	Schleswig-Holstein	SH	Segeberg
23795	Bad Segeberg	Schleswig-Holstein	SH	Segeberg
23795	Klein Rönnau	Schleswig-Holstein	SH	Segeberg
23795	Klein Gladebrügge	Schleswig-Holstein	SH	Segeberg
23795	Negernbötel	Schleswig-Holstein	SH	Segeberg
23795	Fahrenkrug	Schleswig-Holstein	SH	Segeberg
23795	Traventhal	Schleswig-Holstein	SH	Segeberg
23795	Stipsdorf	Schleswig-Holstein	SH	Segeberg
23795	Weede	Schleswig-Holstein	SH	Segeberg
23795	Högersdorf	Schleswig-Holstein	SH	Segeberg
23795	Schieren	Schleswig-Holstein	SH	Segeberg
23795	Mözen	Schleswig-Holstein	SH	Segeberg
23795	Schackendorf	Schleswig-Holstein	SH	Segeberg
23812	Wahlstedt	Schleswig-Holstein	SH	Segeberg
23813	Blunk	Schleswig-Holstein	SH	Segeberg
23813	Nehms	Schleswig-Holstein	SH	Segeberg
23815	Westerrade	Schleswig-Holstein	SH	Segeberg
23815	Geschendorf	Schleswig-Holstein	SH	Segeberg
23815	Strukdorf	Schleswig-Holstein	SH	Segeberg
23816	Leezen	Schleswig-Holstein	SH	Segeberg
23816	Bebensee	Schleswig-Holstein	SH	Segeberg
23816	Neversdorf	Schleswig-Holstein	SH	Segeberg
23816	Groß Niendorf	Schleswig-Holstein	SH	Segeberg
23818	Neuengörs	Schleswig-Holstein	SH	Segeberg
23820	Pronstorf	Schleswig-Holstein	SH	Segeberg
23821	Rohlstorf	Schleswig-Holstein	SH	Segeberg
23823	Seedorf	Schleswig-Holstein	SH	Segeberg
23824	Damsdorf	Schleswig-Holstein	SH	Segeberg
23824	Tensfeld	Schleswig-Holstein	SH	Segeberg
23826	Bark	Schleswig-Holstein	SH	Segeberg
23826	Fredesdorf	Schleswig-Holstein	SH	Segeberg
23826	Todesfelde	Schleswig-Holstein	SH	Segeberg
23827	Travenhorst	Schleswig-Holstein	SH	Segeberg
23827	Wensin	Schleswig-Holstein	SH	Segeberg
23827	Krems II	Schleswig-Holstein	SH	Segeberg
23829	Kükels	Schleswig-Holstein	SH	Segeberg
23829	Wittenborn	Schleswig-Holstein	SH	Segeberg
23843	Bad Oldesloe	Schleswig-Holstein	SH	Stormarn
23843	Rümpel	Schleswig-Holstein	SH	Stormarn
23843	Neritz	Schleswig-Holstein	SH	Stormarn
23843	Travenbrück	Schleswig-Holstein	SH	Stormarn
23845	Wakendorf I	Schleswig-Holstein	SH	Stormarn
23845	Dreggers	Schleswig-Holstein	SH	Segeberg
16798	Zootzen	Brandenburg	BB	Oberhavel
23845	Oering	Schleswig-Holstein	SH	Stormarn
23845	Itzstedt	Schleswig-Holstein	SH	Segeberg
23845	Grabau	Schleswig-Holstein	SH	Stormarn
23845	Bühnsdorf	Schleswig-Holstein	SH	Segeberg
23845	Seth	Schleswig-Holstein	SH	Segeberg
23845	Bahrenhof	Schleswig-Holstein	SH	Segeberg
23847	Meddewade	Schleswig-Holstein	SH	Stormarn
23847	Westerau	Schleswig-Holstein	SH	Stormarn
23847	Düchelsdorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
23847	Schiphorst	Schleswig-Holstein	SH	Herzogtum Lauenburg
23847	Groß Boden	Schleswig-Holstein	SH	Herzogtum Lauenburg
23847	Schürensöhlen	Schleswig-Holstein	SH	Herzogtum Lauenburg
23847	Kastorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
23847	Grinau	Schleswig-Holstein	SH	Herzogtum Lauenburg
23847	Bliestorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
23847	Rethwisch	Schleswig-Holstein	SH	Stormarn
23847	Siebenbäumen	Schleswig-Holstein	SH	Herzogtum Lauenburg
23847	Sierksrade	Schleswig-Holstein	SH	Herzogtum Lauenburg
23847	Steinhorst	Schleswig-Holstein	SH	Herzogtum Lauenburg
23847	Lasbek	Schleswig-Holstein	SH	Stormarn
23847	Stubben	Schleswig-Holstein	SH	Herzogtum Lauenburg
23847	Pölitz	Schleswig-Holstein	SH	Stormarn
23858	Reinfeld (Holstein)	Schleswig-Holstein	SH	Stormarn
23858	Barnitz	Schleswig-Holstein	SH	Stormarn
23858	Heidekamp	Schleswig-Holstein	SH	Stormarn
23858	Wesenberg	Schleswig-Holstein	SH	Stormarn
23858	Feldhorst	Schleswig-Holstein	SH	Stormarn
23860	Groß Schenkenberg	Schleswig-Holstein	SH	Herzogtum Lauenburg
23860	Klein Wesenberg	Schleswig-Holstein	SH	Stormarn
23863	Bargfeld-Stegen	Schleswig-Holstein	SH	Stormarn
23863	Kayhude	Schleswig-Holstein	SH	Segeberg
23863	Nienwohld	Schleswig-Holstein	SH	Stormarn
23866	Nahe	Schleswig-Holstein	SH	Segeberg
23867	Sülfeld	Schleswig-Holstein	SH	Segeberg
23869	Elmenhorst	Schleswig-Holstein	SH	Stormarn
23879	Mölln	Schleswig-Holstein	SH	Herzogtum Lauenburg
23881	Niendorf an der Stecknitz	Schleswig-Holstein	SH	Herzogtum Lauenburg
23881	Alt Mölln	Schleswig-Holstein	SH	Herzogtum Lauenburg
23881	Breitenfelde	Schleswig-Holstein	SH	Herzogtum Lauenburg
23881	Koberg	Schleswig-Holstein	SH	Herzogtum Lauenburg
23881	Lankau	Schleswig-Holstein	SH	Herzogtum Lauenburg
23881	Bälau	Schleswig-Holstein	SH	Herzogtum Lauenburg
23881	Borstorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
23883	Klein Zecher	Schleswig-Holstein	SH	Herzogtum Lauenburg
23883	Brunsmark	Schleswig-Holstein	SH	Herzogtum Lauenburg
23883	Seedorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
23883	Lehmrade	Schleswig-Holstein	SH	Herzogtum Lauenburg
23883	Sterley	Schleswig-Holstein	SH	Herzogtum Lauenburg
23883	Horst	Schleswig-Holstein	SH	Herzogtum Lauenburg
23883	Hollenbek	Schleswig-Holstein	SH	Herzogtum Lauenburg
23883	Grambek	Schleswig-Holstein	SH	Herzogtum Lauenburg
23896	Panten	Schleswig-Holstein	SH	Herzogtum Lauenburg
23896	Nusse	Schleswig-Holstein	SH	Herzogtum Lauenburg
23896	Ritzerau	Schleswig-Holstein	SH	Herzogtum Lauenburg
23896	Poggensee	Schleswig-Holstein	SH	Herzogtum Lauenburg
23896	Walksfelde	Schleswig-Holstein	SH	Herzogtum Lauenburg
23898	Lüchow	Schleswig-Holstein	SH	Herzogtum Lauenburg
23898	Sirksfelde	Schleswig-Holstein	SH	Herzogtum Lauenburg
23898	Sandesneben	Schleswig-Holstein	SH	Herzogtum Lauenburg
23898	Klinkrade	Schleswig-Holstein	SH	Herzogtum Lauenburg
23898	Wentorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
23898	Duvensee	Schleswig-Holstein	SH	Herzogtum Lauenburg
23898	Labenz	Schleswig-Holstein	SH	Herzogtum Lauenburg
23898	Kühsen	Schleswig-Holstein	SH	Herzogtum Lauenburg
23899	Besenthal	Schleswig-Holstein	SH	Herzogtum Lauenburg
23899	Gudow	Schleswig-Holstein	SH	Herzogtum Lauenburg
23909	Bäk	Schleswig-Holstein	SH	Herzogtum Lauenburg
23909	Fredeburg	Schleswig-Holstein	SH	Herzogtum Lauenburg
23909	Albsfelde	Schleswig-Holstein	SH	Herzogtum Lauenburg
23909	Römnitz	Schleswig-Holstein	SH	Herzogtum Lauenburg
23909	Ratzeburg	Schleswig-Holstein	SH	Herzogtum Lauenburg
23909	Mechow	Schleswig-Holstein	SH	Herzogtum Lauenburg
23909	Giesensdorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
23911	Groß Disnack	Schleswig-Holstein	SH	Herzogtum Lauenburg
23911	Harmsdorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
23911	Pogeez	Schleswig-Holstein	SH	Herzogtum Lauenburg
23911	Schmilau	Schleswig-Holstein	SH	Herzogtum Lauenburg
23911	Einhaus	Schleswig-Holstein	SH	Herzogtum Lauenburg
23911	Kittlitz	Schleswig-Holstein	SH	Herzogtum Lauenburg
23911	Buchholz	Schleswig-Holstein	SH	Herzogtum Lauenburg
23911	Kulpin	Schleswig-Holstein	SH	Herzogtum Lauenburg
23911	Salem	Schleswig-Holstein	SH	Herzogtum Lauenburg
23911	Mustin	Schleswig-Holstein	SH	Herzogtum Lauenburg
23911	Ziethen	Schleswig-Holstein	SH	Herzogtum Lauenburg
23919	Göldenitz	Schleswig-Holstein	SH	Herzogtum Lauenburg
23919	Rondeshagen	Schleswig-Holstein	SH	Herzogtum Lauenburg
23919	Niendorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
23919	Behlendorf	Schleswig-Holstein	SH	Herzogtum Lauenburg
23919	Berkenthin	Schleswig-Holstein	SH	Herzogtum Lauenburg
24103	Kiel	Schleswig-Holstein	SH	Kiel
24105	Kiel	Schleswig-Holstein	SH	Kiel
24106	Kiel	Schleswig-Holstein	SH	Kiel
24107	Kiel	Schleswig-Holstein	SH	Kiel
24107	Ottendorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24107	Quarnbek	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24109	Melsdorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
16798	Altthymen	Brandenburg	BB	Oberhavel
24109	Kiel	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24111	Kiel	Schleswig-Holstein	SH	Kiel
24113	Kiel	Schleswig-Holstein	SH	Kiel
24113	Molfsee	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24114	Kiel	Schleswig-Holstein	SH	Kiel
24116	Kiel	Schleswig-Holstein	SH	Kiel
24118	Kiel	Schleswig-Holstein	SH	Kiel
24119	Kronshagen	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24143	Kiel	Schleswig-Holstein	SH	Kiel
24145	Kiel	Schleswig-Holstein	SH	Kiel
24146	Kiel	Schleswig-Holstein	SH	Kiel
24147	Kiel	Schleswig-Holstein	SH	Kiel
24147	Klausdorf	Schleswig-Holstein	SH	Plön
24148	Kiel	Schleswig-Holstein	SH	Kiel
24149	Kiel	Schleswig-Holstein	SH	Kiel
24159	Kiel	Schleswig-Holstein	SH	Kiel
24161	Altenholz	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24211	Kühren	Schleswig-Holstein	SH	Plön
24211	Postfeld	Schleswig-Holstein	SH	Plön
24211	Pohnsdorf	Schleswig-Holstein	SH	Plön
24211	Rastorf	Schleswig-Holstein	SH	Plön
24211	Wahlstorf	Schleswig-Holstein	SH	Plön
24211	Preetz	Schleswig-Holstein	SH	Plön
24211	Lehmkuhlen	Schleswig-Holstein	SH	Plön
24211	Schellhorn	Schleswig-Holstein	SH	Plön
24211	Honigsee	Schleswig-Holstein	SH	Plön
24214	Lindau	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24214	Tüttendorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24214	Gettorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24214	Neuwittenbek	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24214	Neudorf-Bornstein	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24214	Noer	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24214	Schinkel	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24217	Krokau	Schleswig-Holstein	SH	Plön
24217	Krummbek	Schleswig-Holstein	SH	Plön
24217	Bendfeld	Schleswig-Holstein	SH	Plön
24217	Schönberg (Holstein)	Schleswig-Holstein	SH	Plön
24217	Fiefbergen	Schleswig-Holstein	SH	Plön
24217	Höhndorf	Schleswig-Holstein	SH	Plön
24217	Wisch	Schleswig-Holstein	SH	Plön
24217	Stakendorf	Schleswig-Holstein	SH	Plön
24217	Barsbek	Schleswig-Holstein	SH	Plön
24220	Böhnhusen	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24220	Boksee	Schleswig-Holstein	SH	Plön
24220	Techelsdorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24220	Schönhorst	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24220	Flintbek	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24222	Schwentinental	Schleswig-Holstein	SH	Plön
24223	Raisdorf	Schleswig-Holstein	SH	Plön
24226	Heikendorf	Schleswig-Holstein	SH	Plön
24229	Strande	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24229	Schwedeneck	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24229	Dänischenhagen	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24232	Schönkirchen	Schleswig-Holstein	SH	Plön
24232	Dobersdorf	Schleswig-Holstein	SH	Plön
24235	Laboe	Schleswig-Holstein	SH	Plön
24235	Brodersdorf	Schleswig-Holstein	SH	Plön
24235	Stein	Schleswig-Holstein	SH	Plön
24235	Wendtorf	Schleswig-Holstein	SH	Plön
24235	Lutterbek	Schleswig-Holstein	SH	Plön
24238	Mucheln	Schleswig-Holstein	SH	Plön
24238	Selent	Schleswig-Holstein	SH	Plön
24238	Lammershagen	Schleswig-Holstein	SH	Plön
24238	Martensrade	Schleswig-Holstein	SH	Plön
24239	Achterwehr	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24241	Schmalstede	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24241	Schierensee	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24241	Reesdorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24241	Grevenkrug	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24241	Blumenthal	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24241	Sören	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24242	Felde	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24244	Felm	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24245	Klein Barkau	Schleswig-Holstein	SH	Plön
24245	Barmissen	Schleswig-Holstein	SH	Plön
24245	Großbarkau	Schleswig-Holstein	SH	Plön
24245	Kirchbarkau	Schleswig-Holstein	SH	Plön
24247	Mielkendorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24247	Rodenbek	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24248	Mönkeberg	Schleswig-Holstein	SH	Plön
24250	Warnau	Schleswig-Holstein	SH	Plön
24250	Bothkamp	Schleswig-Holstein	SH	Plön
24250	Löptin	Schleswig-Holstein	SH	Plön
24250	Nettelsee	Schleswig-Holstein	SH	Plön
24251	Osdorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24253	Prasdorf	Schleswig-Holstein	SH	Plön
24253	Passade	Schleswig-Holstein	SH	Plön
24253	Fahren	Schleswig-Holstein	SH	Plön
24253	Probsteierhagen	Schleswig-Holstein	SH	Plön
24254	Rumohr	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24256	Stoltenberg	Schleswig-Holstein	SH	Plön
24256	Schlesen	Schleswig-Holstein	SH	Plön
24256	Fargau-Pratjau	Schleswig-Holstein	SH	Plön
24257	Köhn	Schleswig-Holstein	SH	Plön
24257	Hohenfelde	Schleswig-Holstein	SH	Plön
24257	Schwartbuck	Schleswig-Holstein	SH	Plön
24259	Westensee	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24306	Rathjensdorf	Schleswig-Holstein	SH	Plön
24306	Bösdorf	Schleswig-Holstein	SH	Plön
24306	Plön	Schleswig-Holstein	SH	Plön
24306	Wittmoldt	Schleswig-Holstein	SH	Plön
24306	Lebrade	Schleswig-Holstein	SH	Plön
19348	Wolfshagen	Brandenburg	BB	Prignitz
24321	Hohwacht	Schleswig-Holstein	SH	Plön
24321	Giekau	Schleswig-Holstein	SH	Plön
24321	Behrensdorf	Schleswig-Holstein	SH	Plön
24321	Lütjenburg	Schleswig-Holstein	SH	Plön
24321	Tröndel	Schleswig-Holstein	SH	Plön
24321	Klamp	Schleswig-Holstein	SH	Plön
24321	Panker	Schleswig-Holstein	SH	Plön
24321	Helmstorf	Schleswig-Holstein	SH	Plön
24326	Dersau	Schleswig-Holstein	SH	Plön
24326	Stocksee	Schleswig-Holstein	SH	Segeberg
24326	Dörnick	Schleswig-Holstein	SH	Plön
24326	Kalübbe	Schleswig-Holstein	SH	Plön
24326	Ascheberg	Schleswig-Holstein	SH	Plön
24326	Nehmten	Schleswig-Holstein	SH	Plön
24327	Blekendorf	Schleswig-Holstein	SH	Plön
24327	Kletkamp	Schleswig-Holstein	SH	Plön
24327	Högsdorf	Schleswig-Holstein	SH	Plön
24329	Grebin	Schleswig-Holstein	SH	Plön
24329	Dannau	Schleswig-Holstein	SH	Plön
24329	Rantzau	Schleswig-Holstein	SH	Plön
24340	Gammelby	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24340	Eckernförde	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24340	Windeby	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24340	Altenhof	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24340	Goosefeld	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24351	Damp	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24351	Thumby	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24354	Rieseby	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24354	Kosel	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24357	Fleckeby	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24357	Hummelfeld	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24357	Güby	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24358	Ascheffel	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24358	Hütten	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24358	Bistensee	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24360	Barkelsby	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24361	Haby	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24361	Klein Wittensee	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24361	Holzbunge	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24361	Groß Wittensee	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24361	Damendorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24363	Holtsee	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24364	Holzdorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24366	Loose	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24367	Osterby	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24369	Waabs	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24376	Kappeln	Schleswig-Holstein	SH	Schleswig-Flensburg
24376	Arnis	Schleswig-Holstein	SH	Schleswig-Flensburg
24376	Hasselberg	Schleswig-Holstein	SH	Schleswig-Flensburg
24376	Grödersby	Schleswig-Holstein	SH	Schleswig-Flensburg
24376	Rabel	Schleswig-Holstein	SH	Schleswig-Flensburg
24392	Nottfeld	Schleswig-Holstein	SH	Schleswig-Flensburg
24392	Brebel	Schleswig-Holstein	SH	Schleswig-Flensburg
24392	Kiesby	Schleswig-Holstein	SH	Schleswig-Flensburg
24392	Dollrottfeld	Schleswig-Holstein	SH	Schleswig-Flensburg
24392	Norderbrarup	Schleswig-Holstein	SH	Schleswig-Flensburg
24392	Scheggerott	Schleswig-Holstein	SH	Schleswig-Flensburg
24392	Boren	Schleswig-Holstein	SH	Schleswig-Flensburg
24392	Saustrup	Schleswig-Holstein	SH	Schleswig-Flensburg
24392	Ekenis	Schleswig-Holstein	SH	Schleswig-Flensburg
24392	Süderbrarup	Schleswig-Holstein	SH	Schleswig-Flensburg
24392	Wagersrott	Schleswig-Holstein	SH	Schleswig-Flensburg
24395	Kronsgaard	Schleswig-Holstein	SH	Schleswig-Flensburg
24395	Pommerby	Schleswig-Holstein	SH	Schleswig-Flensburg
24395	Niesgrau	Schleswig-Holstein	SH	Schleswig-Flensburg
24395	Gelting	Schleswig-Holstein	SH	Schleswig-Flensburg
24395	Rabenholz	Schleswig-Holstein	SH	Schleswig-Flensburg
24395	Stangheck	Schleswig-Holstein	SH	Schleswig-Flensburg
24395	Nieby	Schleswig-Holstein	SH	Schleswig-Flensburg
24398	Winnemark	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24398	Karby	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24398	Dörphof	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24398	Brodersby	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24399	Arnis	Schleswig-Holstein	SH	Schleswig-Flensburg
24401	Böel	Schleswig-Holstein	SH	Schleswig-Flensburg
24402	Esgrus	Schleswig-Holstein	SH	Schleswig-Flensburg
24404	Maasholm	Schleswig-Holstein	SH	Schleswig-Flensburg
24405	Mohrkirch	Schleswig-Holstein	SH	Schleswig-Flensburg
24405	Rügge	Schleswig-Holstein	SH	Schleswig-Flensburg
24407	Rabenkirchen-Faulück	Schleswig-Holstein	SH	Schleswig-Flensburg
24407	Oersberg	Schleswig-Holstein	SH	Schleswig-Flensburg
24409	Stoltebüll	Schleswig-Holstein	SH	Schleswig-Flensburg
24534	Neumünster	Schleswig-Holstein	SH	Neumünster
24536	Neumünster	Schleswig-Holstein	SH	Neumünster
24536	Tasdorf	Schleswig-Holstein	SH	Plön
24537	Neumünster	Schleswig-Holstein	SH	Neumünster
24539	Neumünster	Schleswig-Holstein	SH	Neumünster
24558	Henstedt-Ulzburg	Schleswig-Holstein	SH	Segeberg
24558	Wakendorf II	Schleswig-Holstein	SH	Segeberg
24568	Kaltenkirchen	Schleswig-Holstein	SH	Segeberg
24568	Kattendorf	Schleswig-Holstein	SH	Segeberg
24568	Oersdorf	Schleswig-Holstein	SH	Segeberg
24568	Winsen	Schleswig-Holstein	SH	Segeberg
24568	Nützen	Schleswig-Holstein	SH	Segeberg
24576	Hitzhusen	Schleswig-Holstein	SH	Segeberg
19348	Nebelin	Brandenburg	BB	Prignitz
24576	Weddelbrook	Schleswig-Holstein	SH	Segeberg
24576	Hagen	Schleswig-Holstein	SH	Segeberg
24576	Bimöhlen	Schleswig-Holstein	SH	Segeberg
24576	Mönkloh	Schleswig-Holstein	SH	Segeberg
24576	Bad Bramstedt	Schleswig-Holstein	SH	Segeberg
24582	Wattenbek	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24582	Brügge	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24582	Bissee	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24582	Groß Buchwald	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24582	Schönbek	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24582	Hoffeld	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24582	Bordesholm	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24582	Mühbrook	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24589	Dätgen	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24589	Ellerdorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24589	Eisendorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24589	Borgdorf-Seedorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24589	Schülp bei Nortorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24589	Nortorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24594	Hohenwestedt	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24594	Remmels	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24594	Mörel	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24594	Rade bei Hohenwestedt	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24594	Jahrsdorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24594	Tappendorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24594	Meezen	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24594	Grauel	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24594	Wapelfeld	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24594	Heinkenborstel	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24594	Nindorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24598	Heidmühlen	Schleswig-Holstein	SH	Segeberg
24598	Boostedt	Schleswig-Holstein	SH	Segeberg
24598	Latendorf	Schleswig-Holstein	SH	Segeberg
24601	Wankendorf	Schleswig-Holstein	SH	Plön
24601	Belau	Schleswig-Holstein	SH	Plön
24601	Ruhwinkel	Schleswig-Holstein	SH	Plön
24601	Stolpe	Schleswig-Holstein	SH	Plön
24610	Trappenkamp	Schleswig-Holstein	SH	Segeberg
24610	Gönnebek	Schleswig-Holstein	SH	Segeberg
24613	Wiedenborstel	Schleswig-Holstein	SH	Steinburg
24613	Aukrug	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24616	Armstedt	Schleswig-Holstein	SH	Segeberg
24616	Brokstedt	Schleswig-Holstein	SH	Steinburg
24616	Willenscharen	Schleswig-Holstein	SH	Steinburg
24616	Sarlhusen	Schleswig-Holstein	SH	Steinburg
24616	Hardebek	Schleswig-Holstein	SH	Segeberg
24616	Hasenkrug	Schleswig-Holstein	SH	Segeberg
24616	Borstel	Schleswig-Holstein	SH	Segeberg
24619	Rendswühren	Schleswig-Holstein	SH	Plön
24619	Tarbek	Schleswig-Holstein	SH	Segeberg
24619	Bornhöved	Schleswig-Holstein	SH	Segeberg
24620	Bönebüttel	Schleswig-Holstein	SH	Plön
24622	Gnutz	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24623	Großenaspe	Schleswig-Holstein	SH	Segeberg
24625	Großharrie	Schleswig-Holstein	SH	Plön
24625	Negenharrie	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24626	Groß Kummerfeld	Schleswig-Holstein	SH	Segeberg
24628	Hartenholm	Schleswig-Holstein	SH	Segeberg
24629	Kisdorf	Schleswig-Holstein	SH	Segeberg
24631	Langwedel	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24632	Lentföhrden	Schleswig-Holstein	SH	Segeberg
24632	Heidmoor	Schleswig-Holstein	SH	Segeberg
24634	Padenstedt	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24634	Arpsdorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24635	Daldorf	Schleswig-Holstein	SH	Segeberg
24635	Rickling	Schleswig-Holstein	SH	Segeberg
24637	Schillsdorf	Schleswig-Holstein	SH	Plön
24638	Schmalensee	Schleswig-Holstein	SH	Segeberg
24640	Hasenmoor	Schleswig-Holstein	SH	Segeberg
24640	Schmalfeld	Schleswig-Holstein	SH	Segeberg
24641	Stuvenborn	Schleswig-Holstein	SH	Segeberg
24641	Hüttblek	Schleswig-Holstein	SH	Segeberg
24641	Sievershütten	Schleswig-Holstein	SH	Segeberg
24643	Struvenhütten	Schleswig-Holstein	SH	Segeberg
24644	Timmaspe	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24644	Loop	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24644	Krogaspe	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24646	Warder	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24647	Ehndorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24647	Wasbek	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24649	Wiemersdorf	Schleswig-Holstein	SH	Segeberg
24649	Fuhlendorf	Schleswig-Holstein	SH	Segeberg
24768	Rendsburg	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24782	Rickert	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24782	Büdelsdorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24783	Osterrönfeld	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24784	Westerrönfeld	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24787	Fockbek	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24790	Schacht-Audorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24790	Ostenfeld	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24790	Rade bei Rendsburg	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24790	Haßmoor	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24790	Schülldorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24791	Alt Duvenstedt	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24793	Oldenhütten	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24793	Bargstedt	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24793	Brammer	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24794	Borgstedt	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24794	Neu Duvenstedt	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24794	Bünsdorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24796	Krummwisch	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24796	Bredenbek	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24796	Bovenau	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24797	Hörsten	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24797	Breiholz	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24799	Christiansholm	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24799	Friedrichsholm	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24799	Friedrichsgraben	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24799	Meggerdorf	Schleswig-Holstein	SH	Schleswig-Flensburg
24799	Königshügel	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24800	Elsdorf-Westermühlen	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24802	Bokel	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24802	Groß Vollstedt	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24802	Emkendorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24803	Tielen	Schleswig-Holstein	SH	Schleswig-Flensburg
24803	Erfde	Schleswig-Holstein	SH	Schleswig-Flensburg
24805	Prinzenmoor	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24805	Hamdorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24806	Bargstall	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24806	Hohn	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24806	Lohe-Föhrden	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24806	Sophienhamm	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24808	Jevenstedt	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24809	Nübbel	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24811	Owschlag	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24811	Ahlefeld	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24811	Brekendorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24813	Schülp bei Rendsburg	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24814	Sehestedt	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24816	Luhnstedt	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24816	Brinjahe	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24816	Stafstedt	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24816	Hamweddel	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24817	Tetenhusen	Schleswig-Holstein	SH	Schleswig-Flensburg
24819	Haale	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24819	Nienborstel	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24819	Embühren	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24819	Todenbüttel	Schleswig-Holstein	SH	Rendsburg-Eckernförde
24837	Schleswig	Schleswig-Holstein	SH	Schleswig-Flensburg
24848	Alt Bennebek	Schleswig-Holstein	SH	Schleswig-Flensburg
24848	Klein Rheide	Schleswig-Holstein	SH	Schleswig-Flensburg
24848	Kropp	Schleswig-Holstein	SH	Schleswig-Flensburg
24848	Klein Bennebek	Schleswig-Holstein	SH	Schleswig-Flensburg
24850	Schuby	Schleswig-Holstein	SH	Schleswig-Flensburg
24850	Lürschau	Schleswig-Holstein	SH	Schleswig-Flensburg
24850	Hüsby	Schleswig-Holstein	SH	Schleswig-Flensburg
24852	Sollerup	Schleswig-Holstein	SH	Schleswig-Flensburg
24852	Eggebek	Schleswig-Holstein	SH	Schleswig-Flensburg
24852	Süderhackstedt	Schleswig-Holstein	SH	Schleswig-Flensburg
24852	Langstedt	Schleswig-Holstein	SH	Schleswig-Flensburg
24855	Bollingstedt	Schleswig-Holstein	SH	Schleswig-Flensburg
24855	Jübek	Schleswig-Holstein	SH	Schleswig-Flensburg
24857	Fahrdorf	Schleswig-Holstein	SH	Schleswig-Flensburg
24857	Borgwedel	Schleswig-Holstein	SH	Schleswig-Flensburg
24860	Uelsby	Schleswig-Holstein	SH	Schleswig-Flensburg
24860	Klappholz	Schleswig-Holstein	SH	Schleswig-Flensburg
24860	Böklund	Schleswig-Holstein	SH	Schleswig-Flensburg
24861	Bergenhusen	Schleswig-Holstein	SH	Schleswig-Flensburg
24863	Börm	Schleswig-Holstein	SH	Schleswig-Flensburg
24864	Goltoft	Schleswig-Holstein	SH	Schleswig-Flensburg
24864	Brodersby	Schleswig-Holstein	SH	Schleswig-Flensburg
24866	Busdorf	Schleswig-Holstein	SH	Schleswig-Flensburg
24867	Dannewerk	Schleswig-Holstein	SH	Schleswig-Flensburg
24869	Dörpstedt	Schleswig-Holstein	SH	Schleswig-Flensburg
24870	Ellingstedt	Schleswig-Holstein	SH	Schleswig-Flensburg
24872	Groß Rheide	Schleswig-Holstein	SH	Schleswig-Flensburg
24873	Havetoft	Schleswig-Holstein	SH	Schleswig-Flensburg
24875	Havetoftloit	Schleswig-Holstein	SH	Schleswig-Flensburg
24876	Hollingstedt	Schleswig-Holstein	SH	Schleswig-Flensburg
24878	Jagel	Schleswig-Holstein	SH	Schleswig-Flensburg
24878	Lottorf	Schleswig-Holstein	SH	Schleswig-Flensburg
24879	Neuberend	Schleswig-Holstein	SH	Schleswig-Flensburg
24879	Idstedt	Schleswig-Holstein	SH	Schleswig-Flensburg
24881	Nübel	Schleswig-Holstein	SH	Schleswig-Flensburg
24882	Schaalby	Schleswig-Holstein	SH	Schleswig-Flensburg
24884	Geltorf	Schleswig-Holstein	SH	Schleswig-Flensburg
24884	Selk	Schleswig-Holstein	SH	Schleswig-Flensburg
24885	Sieverstedt	Schleswig-Holstein	SH	Schleswig-Flensburg
24887	Silberstedt	Schleswig-Holstein	SH	Schleswig-Flensburg
24888	Steinfeld	Schleswig-Holstein	SH	Schleswig-Flensburg
24888	Loit	Schleswig-Holstein	SH	Schleswig-Flensburg
24890	Süderfahrenstedt	Schleswig-Holstein	SH	Schleswig-Flensburg
24890	Stolk	Schleswig-Holstein	SH	Schleswig-Flensburg
24891	Struxdorf	Schleswig-Holstein	SH	Schleswig-Flensburg
24891	Schnarup-Thumby	Schleswig-Holstein	SH	Schleswig-Flensburg
24893	Taarstedt	Schleswig-Holstein	SH	Schleswig-Flensburg
24894	Tolk	Schleswig-Holstein	SH	Schleswig-Flensburg
24894	Twedt	Schleswig-Holstein	SH	Schleswig-Flensburg
24896	Treia	Schleswig-Holstein	SH	Schleswig-Flensburg
24897	Ulsnis	Schleswig-Holstein	SH	Schleswig-Flensburg
24899	Wohlde	Schleswig-Holstein	SH	Schleswig-Flensburg
24937	Flensburg	Schleswig-Holstein	SH	Flensburg
24939	Flensburg	Schleswig-Holstein	SH	Flensburg
24941	Flensburg	Schleswig-Holstein	SH	Flensburg
24941	Jarplund-Weding	Schleswig-Holstein	SH	Schleswig-Flensburg
24943	Tastrup	Schleswig-Holstein	SH	Schleswig-Flensburg
24943	Flensburg	Schleswig-Holstein	SH	Flensburg
24944	Flensburg	Schleswig-Holstein	SH	Flensburg
24955	Harrislee	Schleswig-Holstein	SH	Schleswig-Flensburg
24960	Munkbrarup	Schleswig-Holstein	SH	Schleswig-Flensburg
24960	Glücksburg	Schleswig-Holstein	SH	Schleswig-Flensburg
24963	Jerrishoe	Schleswig-Holstein	SH	Schleswig-Flensburg
24963	Tarp	Schleswig-Holstein	SH	Schleswig-Flensburg
24966	Sörup	Schleswig-Holstein	SH	Schleswig-Flensburg
24969	Großenwiehe	Schleswig-Holstein	SH	Schleswig-Flensburg
24969	Lindewitt	Schleswig-Holstein	SH	Schleswig-Flensburg
24972	Steinberg	Schleswig-Holstein	SH	Schleswig-Flensburg
24972	Steinbergkirche	Schleswig-Holstein	SH	Schleswig-Flensburg
24972	Quern	Schleswig-Holstein	SH	Schleswig-Flensburg
24975	Husby	Schleswig-Holstein	SH	Schleswig-Flensburg
24975	Ausacker	Schleswig-Holstein	SH	Schleswig-Flensburg
24975	Maasbüll	Schleswig-Holstein	SH	Schleswig-Flensburg
24975	Hürup	Schleswig-Holstein	SH	Schleswig-Flensburg
24976	Handewitt	Schleswig-Holstein	SH	Schleswig-Flensburg
24977	Ringsberg	Schleswig-Holstein	SH	Schleswig-Flensburg
24977	Westerholz	Schleswig-Holstein	SH	Schleswig-Flensburg
24977	Grundhof	Schleswig-Holstein	SH	Schleswig-Flensburg
24977	Langballig	Schleswig-Holstein	SH	Schleswig-Flensburg
24980	Hörup	Schleswig-Holstein	SH	Schleswig-Flensburg
24980	Wallsbüll	Schleswig-Holstein	SH	Schleswig-Flensburg
24980	Schafflund	Schleswig-Holstein	SH	Schleswig-Flensburg
24980	Meyn	Schleswig-Holstein	SH	Schleswig-Flensburg
24980	Nordhackstedt	Schleswig-Holstein	SH	Schleswig-Flensburg
24983	Handewitt	Schleswig-Holstein	SH	Schleswig-Flensburg
24986	Rüde	Schleswig-Holstein	SH	Schleswig-Flensburg
24986	Satrup	Schleswig-Holstein	SH	Schleswig-Flensburg
24988	Oeversee	Schleswig-Holstein	SH	Schleswig-Flensburg
24988	Sankelmark	Schleswig-Holstein	SH	Schleswig-Flensburg
24989	Dollerup	Schleswig-Holstein	SH	Schleswig-Flensburg
24991	Großsolt	Schleswig-Holstein	SH	Schleswig-Flensburg
24991	Freienwill	Schleswig-Holstein	SH	Schleswig-Flensburg
24992	Janneby	Schleswig-Holstein	SH	Schleswig-Flensburg
24992	Jörl	Schleswig-Holstein	SH	Schleswig-Flensburg
24994	Holt	Schleswig-Holstein	SH	Schleswig-Flensburg
24994	Medelby	Schleswig-Holstein	SH	Schleswig-Flensburg
24994	Jardelund	Schleswig-Holstein	SH	Schleswig-Flensburg
24994	Osterby	Schleswig-Holstein	SH	Schleswig-Flensburg
24994	Böxlund	Schleswig-Holstein	SH	Schleswig-Flensburg
24994	Weesby	Schleswig-Holstein	SH	Schleswig-Flensburg
24996	Sterup	Schleswig-Holstein	SH	Schleswig-Flensburg
24996	Ahneby	Schleswig-Holstein	SH	Schleswig-Flensburg
24997	Wanderup	Schleswig-Holstein	SH	Schleswig-Flensburg
24999	Wees	Schleswig-Holstein	SH	Schleswig-Flensburg
25335	Bokholt-Hanredder	Schleswig-Holstein	SH	Pinneberg
25335	Neuendorf bei Elmshorn	Schleswig-Holstein	SH	Steinburg
25335	Altenmoor	Schleswig-Holstein	SH	Steinburg
25335	Raa-Besenbek	Schleswig-Holstein	SH	Pinneberg
25335	Elmshorn	Schleswig-Holstein	SH	Pinneberg
25336	Elmshorn	Schleswig-Holstein	SH	Pinneberg
25336	Klein Nordende	Schleswig-Holstein	SH	Pinneberg
25337	Seeth-Ekholt	Schleswig-Holstein	SH	Pinneberg
25337	Elmshorn	Schleswig-Holstein	SH	Pinneberg
25337	Kölln-Reisiek	Schleswig-Holstein	SH	Pinneberg
25348	Glückstadt	Schleswig-Holstein	SH	Steinburg
25348	Engelbrechtsche Wildnis	Schleswig-Holstein	SH	Steinburg
25348	Blomesche Wildnis	Schleswig-Holstein	SH	Steinburg
25355	Bevern	Schleswig-Holstein	SH	Pinneberg
25355	Groß Offenseth-Aspern	Schleswig-Holstein	SH	Pinneberg
25355	Heede	Schleswig-Holstein	SH	Pinneberg
25355	Bullenkuhlen	Schleswig-Holstein	SH	Pinneberg
25355	Barmstedt	Schleswig-Holstein	SH	Pinneberg
25355	Lutzhorn	Schleswig-Holstein	SH	Pinneberg
25358	Horst (Holstein)	Schleswig-Holstein	SH	Steinburg
25358	Sommerland	Schleswig-Holstein	SH	Steinburg
25358	Hohenfelde	Schleswig-Holstein	SH	Steinburg
25361	Süderau	Schleswig-Holstein	SH	Steinburg
25361	Krempe	Schleswig-Holstein	SH	Steinburg
25361	Elskop	Schleswig-Holstein	SH	Steinburg
25361	Grevenkop	Schleswig-Holstein	SH	Steinburg
25364	Osterhorn	Schleswig-Holstein	SH	Pinneberg
25364	Bokel	Schleswig-Holstein	SH	Pinneberg
25364	Brande-Hörnerkirchen	Schleswig-Holstein	SH	Pinneberg
25364	Westerhorn	Schleswig-Holstein	SH	Pinneberg
25365	Klein Offenseth-Sparrieshoop	Schleswig-Holstein	SH	Pinneberg
25368	Kiebitzreihe	Schleswig-Holstein	SH	Steinburg
25370	Seester	Schleswig-Holstein	SH	Pinneberg
25371	Seestermühe	Schleswig-Holstein	SH	Pinneberg
25373	Ellerhoop	Schleswig-Holstein	SH	Pinneberg
25376	Borsfleth	Schleswig-Holstein	SH	Steinburg
25376	Krempdorf	Schleswig-Holstein	SH	Steinburg
25377	Kollmar	Schleswig-Holstein	SH	Steinburg
25379	Herzhorn	Schleswig-Holstein	SH	Steinburg
25404	Pinneberg	Schleswig-Holstein	SH	Pinneberg
25421	Pinneberg	Schleswig-Holstein	SH	Pinneberg
12529	Berlin	Berlin	BE	Berlin; Stadt
25429	Uetersen	Schleswig-Holstein	SH	Pinneberg
25436	Heidgraben	Schleswig-Holstein	SH	Pinneberg
25436	Moorrege	Schleswig-Holstein	SH	Pinneberg
25436	Tornesch	Schleswig-Holstein	SH	Pinneberg
25436	Groß Nordende	Schleswig-Holstein	SH	Pinneberg
25436	Neuendeich	Schleswig-Holstein	SH	Pinneberg
25436	Uetersen	Schleswig-Holstein	SH	Pinneberg
25437	Tornesch	Schleswig-Holstein	SH	Pinneberg
25451	Quickborn	Schleswig-Holstein	SH	Pinneberg
25462	Rellingen	Schleswig-Holstein	SH	Pinneberg
25469	Halstenbek	Schleswig-Holstein	SH	Pinneberg
25474	Ellerbek	Schleswig-Holstein	SH	Pinneberg
25474	Bönningstedt	Schleswig-Holstein	SH	Pinneberg
25474	Hasloh	Schleswig-Holstein	SH	Pinneberg
25479	Ellerau	Schleswig-Holstein	SH	Segeberg
25482	Appen	Schleswig-Holstein	SH	Pinneberg
25485	Langeln	Schleswig-Holstein	SH	Pinneberg
25485	Hemdingen	Schleswig-Holstein	SH	Pinneberg
25485	Bilsen	Schleswig-Holstein	SH	Pinneberg
25486	Alveslohe	Schleswig-Holstein	SH	Segeberg
25488	Holm	Schleswig-Holstein	SH	Pinneberg
25489	Haseldorf	Schleswig-Holstein	SH	Pinneberg
25489	Haselau	Schleswig-Holstein	SH	Pinneberg
25491	Hetlingen	Schleswig-Holstein	SH	Pinneberg
25492	Heist	Schleswig-Holstein	SH	Pinneberg
25494	Borstel-Hohenraden	Schleswig-Holstein	SH	Pinneberg
25495	Kummerfeld	Schleswig-Holstein	SH	Pinneberg
25497	Prisdorf	Schleswig-Holstein	SH	Pinneberg
25499	Tangstedt	Schleswig-Holstein	SH	Pinneberg
25524	Bekmünde	Schleswig-Holstein	SH	Steinburg
25524	Oelixdorf	Schleswig-Holstein	SH	Steinburg
25524	Itzehoe	Schleswig-Holstein	SH	Steinburg
25524	Heiligenstedtenerkamp	Schleswig-Holstein	SH	Steinburg
25524	Heiligenstedten	Schleswig-Holstein	SH	Steinburg
25524	Kollmoor	Schleswig-Holstein	SH	Steinburg
25524	Breitenburg	Schleswig-Holstein	SH	Steinburg
25541	Brunsbüttel	Schleswig-Holstein	SH	Dithmarschen
25548	Wittenbergen	Schleswig-Holstein	SH	Steinburg
25548	Oeschebüttel	Schleswig-Holstein	SH	Steinburg
25548	Rosdorf	Schleswig-Holstein	SH	Steinburg
25548	Mühlenbarbek	Schleswig-Holstein	SH	Steinburg
25548	Auufer	Schleswig-Holstein	SH	Steinburg
25548	Störkathen	Schleswig-Holstein	SH	Steinburg
25548	Kellinghusen	Schleswig-Holstein	SH	Steinburg
25551	Lockstedt	Schleswig-Holstein	SH	Steinburg
25551	Hohenlockstedt	Schleswig-Holstein	SH	Steinburg
25551	Peissen	Schleswig-Holstein	SH	Steinburg
25551	Lohbarbek	Schleswig-Holstein	SH	Steinburg
25551	Schlotfeld	Schleswig-Holstein	SH	Steinburg
25551	Winseldorf	Schleswig-Holstein	SH	Steinburg
25551	Silzen	Schleswig-Holstein	SH	Steinburg
25554	Neuendorf-Sachsenbande Neuendorf bei Wilster	Schleswig-Holstein	SH	Steinburg
25554	Neuendorf-Sachsenbande	Schleswig-Holstein	SH	Steinburg
25554	Neuendorf-Sachsenbande Sachsenbande	Schleswig-Holstein	SH	Steinburg
25554	Bekdorf	Schleswig-Holstein	SH	Steinburg
25554	Wilster	Schleswig-Holstein	SH	Steinburg
25554	Krummendiek	Schleswig-Holstein	SH	Steinburg
25554	Nortorf	Schleswig-Holstein	SH	Steinburg
25554	Stördorf	Schleswig-Holstein	SH	Steinburg
25554	Dammfleth	Schleswig-Holstein	SH	Steinburg
25554	Moorhusen	Schleswig-Holstein	SH	Steinburg
25554	Landrecht	Schleswig-Holstein	SH	Steinburg
25554	Kleve	Schleswig-Holstein	SH	Steinburg
25557	Gokels	Schleswig-Holstein	SH	Rendsburg-Eckernförde
25557	Hanerau-Hademarschen	Schleswig-Holstein	SH	Rendsburg-Eckernförde
25557	Oldenbüttel	Schleswig-Holstein	SH	Rendsburg-Eckernförde
25557	Seefeld	Schleswig-Holstein	SH	Rendsburg-Eckernförde
25557	Steenfeld	Schleswig-Holstein	SH	Rendsburg-Eckernförde
25557	Thaden	Schleswig-Holstein	SH	Rendsburg-Eckernförde
25557	Beldorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
25557	Bendorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
25560	Puls	Schleswig-Holstein	SH	Steinburg
25560	Oldenborstel	Schleswig-Holstein	SH	Steinburg
25560	Pöschendorf	Schleswig-Holstein	SH	Steinburg
25560	Aasbüttel	Schleswig-Holstein	SH	Steinburg
25560	Hadenfeld	Schleswig-Holstein	SH	Steinburg
25560	Bokhorst	Schleswig-Holstein	SH	Steinburg
25560	Kaisborstel	Schleswig-Holstein	SH	Steinburg
25560	Schenefeld	Schleswig-Holstein	SH	Steinburg
25560	Warringholz	Schleswig-Holstein	SH	Steinburg
25560	Siezbüttel	Schleswig-Holstein	SH	Steinburg
25560	Agethorst	Schleswig-Holstein	SH	Steinburg
25563	Wulfsmoor	Schleswig-Holstein	SH	Steinburg
25563	Wrist	Schleswig-Holstein	SH	Steinburg
25563	Quarnstedt	Schleswig-Holstein	SH	Steinburg
25563	Hingstheide	Schleswig-Holstein	SH	Steinburg
25563	Föhrden-Barl	Schleswig-Holstein	SH	Segeberg
25566	Rethwisch	Schleswig-Holstein	SH	Steinburg
25566	Lägerdorf	Schleswig-Holstein	SH	Steinburg
25569	Bahrenfleth	Schleswig-Holstein	SH	Steinburg
25569	Hodorf	Schleswig-Holstein	SH	Steinburg
25569	Kremperheide	Schleswig-Holstein	SH	Steinburg
25569	Krempermoor	Schleswig-Holstein	SH	Steinburg
25572	Sankt Margarethen	Schleswig-Holstein	SH	Steinburg
25572	Ecklak	Schleswig-Holstein	SH	Steinburg
25572	Aebtissinwisch	Schleswig-Holstein	SH	Steinburg
25572	Kudensee	Schleswig-Holstein	SH	Steinburg
25572	Büttel	Schleswig-Holstein	SH	Steinburg
25572	Landscheide	Schleswig-Holstein	SH	Steinburg
25573	Beidenfleth	Schleswig-Holstein	SH	Steinburg
12555	Berlin	Berlin	BE	Berlin; Stadt
25575	Beringstedt	Schleswig-Holstein	SH	Rendsburg-Eckernförde
25576	Brokdorf	Schleswig-Holstein	SH	Steinburg
25578	Dägeling	Schleswig-Holstein	SH	Steinburg
25578	Neuenbrook	Schleswig-Holstein	SH	Steinburg
25579	Fitzbek	Schleswig-Holstein	SH	Steinburg
25579	Rade	Schleswig-Holstein	SH	Steinburg
25581	Poyenberg	Schleswig-Holstein	SH	Steinburg
25581	Hennstedt	Schleswig-Holstein	SH	Steinburg
25582	Drage	Schleswig-Holstein	SH	Steinburg
25582	Kaaks	Schleswig-Holstein	SH	Steinburg
25582	Hohenaspe	Schleswig-Holstein	SH	Steinburg
25582	Looft	Schleswig-Holstein	SH	Steinburg
25584	Besdorf	Schleswig-Holstein	SH	Steinburg
25584	Holstenniendorf	Schleswig-Holstein	SH	Steinburg
25585	Lütjenwestedt	Schleswig-Holstein	SH	Rendsburg-Eckernförde
25585	Tackesdorf	Schleswig-Holstein	SH	Rendsburg-Eckernförde
25587	Münsterdorf	Schleswig-Holstein	SH	Steinburg
25588	Oldendorf	Schleswig-Holstein	SH	Steinburg
25588	Huje	Schleswig-Holstein	SH	Steinburg
25588	Mehlbek	Schleswig-Holstein	SH	Steinburg
25590	Osterstedt	Schleswig-Holstein	SH	Rendsburg-Eckernförde
25591	Ottenbüttel	Schleswig-Holstein	SH	Steinburg
25593	Christinenthal	Schleswig-Holstein	SH	Steinburg
25593	Reher	Schleswig-Holstein	SH	Steinburg
25594	Vaalermoor	Schleswig-Holstein	SH	Steinburg
25594	Vaale	Schleswig-Holstein	SH	Steinburg
25594	Nutteln	Schleswig-Holstein	SH	Steinburg
25596	Nienbüttel	Schleswig-Holstein	SH	Steinburg
25596	Wacken	Schleswig-Holstein	SH	Steinburg
25596	Gribbohm	Schleswig-Holstein	SH	Steinburg
25596	Bokelrehm	Schleswig-Holstein	SH	Steinburg
25597	Moordiek	Schleswig-Holstein	SH	Steinburg
25597	Breitenberg	Schleswig-Holstein	SH	Steinburg
25597	Westermoor	Schleswig-Holstein	SH	Steinburg
25597	Moordorf	Schleswig-Holstein	SH	Steinburg
25597	Kronsmoor	Schleswig-Holstein	SH	Steinburg
25599	Wewelsfleth	Schleswig-Holstein	SH	Steinburg
25693	Gudendorf	Schleswig-Holstein	SH	Dithmarschen
25693	Sankt Michaelisdonn	Schleswig-Holstein	SH	Dithmarschen
25693	Trennewurth	Schleswig-Holstein	SH	Dithmarschen
25693	Volsemenhusen	Schleswig-Holstein	SH	Dithmarschen
25704	Nordermeldorf	Schleswig-Holstein	SH	Dithmarschen
25704	Wolmersdorf	Schleswig-Holstein	SH	Dithmarschen
25704	Elpersbüttel	Schleswig-Holstein	SH	Dithmarschen
25704	Bargenstedt	Schleswig-Holstein	SH	Dithmarschen
25704	Meldorf	Schleswig-Holstein	SH	Dithmarschen
25704	Epenwöhrden	Schleswig-Holstein	SH	Dithmarschen
25704	Nindorf	Schleswig-Holstein	SH	Dithmarschen
25709	Kronprinzenkoog	Schleswig-Holstein	SH	Dithmarschen
25709	Kaiser-Wilhelm-Koog	Schleswig-Holstein	SH	Dithmarschen
25709	Marnerdeich	Schleswig-Holstein	SH	Dithmarschen
25709	Diekhusen-Fahrstedt	Schleswig-Holstein	SH	Dithmarschen
25709	Helse	Schleswig-Holstein	SH	Dithmarschen
25709	Marne	Schleswig-Holstein	SH	Dithmarschen
25712	Kuden	Schleswig-Holstein	SH	Dithmarschen
25712	Buchholz	Schleswig-Holstein	SH	Dithmarschen
25712	Brickeln	Schleswig-Holstein	SH	Dithmarschen
25712	Hochdonn	Schleswig-Holstein	SH	Dithmarschen
25712	Quickborn	Schleswig-Holstein	SH	Dithmarschen
25712	Großenrade	Schleswig-Holstein	SH	Dithmarschen
25712	Burg (Dithmarschen)	Schleswig-Holstein	SH	Dithmarschen
2829	Markersdorf	Sachsen	SN	Görlitz
25715	Ramhusen	Schleswig-Holstein	SH	Dithmarschen
25715	Averlak	Schleswig-Holstein	SH	Dithmarschen
25715	Dingen	Schleswig-Holstein	SH	Dithmarschen
25715	Eddelak	Schleswig-Holstein	SH	Dithmarschen
25718	Friedrichskoog	Schleswig-Holstein	SH	Dithmarschen
25719	Busenwurth	Schleswig-Holstein	SH	Dithmarschen
25719	Barlt	Schleswig-Holstein	SH	Dithmarschen
25721	Eggstedt	Schleswig-Holstein	SH	Dithmarschen
25724	Neufelderkoog	Schleswig-Holstein	SH	Dithmarschen
25724	Neufeld	Schleswig-Holstein	SH	Dithmarschen
25724	Schmedeswurth	Schleswig-Holstein	SH	Dithmarschen
25725	Bornholt	Schleswig-Holstein	SH	Rendsburg-Eckernförde
25725	Schafstedt	Schleswig-Holstein	SH	Dithmarschen
25727	Süderhastedt	Schleswig-Holstein	SH	Dithmarschen
25727	Krumstedt	Schleswig-Holstein	SH	Dithmarschen
25727	Frestedt	Schleswig-Holstein	SH	Dithmarschen
25729	Windbergen	Schleswig-Holstein	SH	Dithmarschen
25746	Norderwöhrden	Schleswig-Holstein	SH	Dithmarschen
25746	Lohe-Rickelshof	Schleswig-Holstein	SH	Dithmarschen
25746	Ostrohe	Schleswig-Holstein	SH	Dithmarschen
25746	Heide	Schleswig-Holstein	SH	Dithmarschen
25746	Wesseln	Schleswig-Holstein	SH	Dithmarschen
25761	Westerdeichstrich	Schleswig-Holstein	SH	Dithmarschen
25761	Oesterdeichstrich	Schleswig-Holstein	SH	Dithmarschen
25761	Hedwigenkoog	Schleswig-Holstein	SH	Dithmarschen
25761	Büsumer Deichhausen	Schleswig-Holstein	SH	Dithmarschen
25761	Warwerort	Schleswig-Holstein	SH	Dithmarschen
25761	Büsum	Schleswig-Holstein	SH	Dithmarschen
25764	Hillgroven	Schleswig-Holstein	SH	Dithmarschen
25764	Hellschen-Heringsand-Unterschaar	Schleswig-Holstein	SH	Dithmarschen
25764	Wesselburenerkoog	Schleswig-Holstein	SH	Dithmarschen
25764	Wesselburener-Deichhausen	Schleswig-Holstein	SH	Dithmarschen
25764	Norddeich	Schleswig-Holstein	SH	Dithmarschen
25764	Süderdeich	Schleswig-Holstein	SH	Dithmarschen
25764	Friedrichsgabekoog	Schleswig-Holstein	SH	Dithmarschen
25764	Reinsbüttel	Schleswig-Holstein	SH	Dithmarschen
25764	Oesterwurth	Schleswig-Holstein	SH	Dithmarschen
25764	Schülp	Schleswig-Holstein	SH	Dithmarschen
25764	Wesselburen	Schleswig-Holstein	SH	Dithmarschen
25767	Wennbüttel	Schleswig-Holstein	SH	Dithmarschen
25767	Tensbüttel-Röst	Schleswig-Holstein	SH	Dithmarschen
25767	Osterrade	Schleswig-Holstein	SH	Dithmarschen
25767	Bunsoh	Schleswig-Holstein	SH	Dithmarschen
25767	Albersdorf	Schleswig-Holstein	SH	Dithmarschen
25767	Offenbüttel	Schleswig-Holstein	SH	Dithmarschen
25767	Arkebek	Schleswig-Holstein	SH	Dithmarschen
25770	Lieth	Schleswig-Holstein	SH	Dithmarschen
25770	Hemmingstedt	Schleswig-Holstein	SH	Dithmarschen
25774	Lehe	Schleswig-Holstein	SH	Dithmarschen
25774	Lunden	Schleswig-Holstein	SH	Dithmarschen
25774	Krempel	Schleswig-Holstein	SH	Dithmarschen
25774	Hemme	Schleswig-Holstein	SH	Dithmarschen
25774	Groven	Schleswig-Holstein	SH	Dithmarschen
25774	Karolinenkoog	Schleswig-Holstein	SH	Dithmarschen
25776	Schlichting	Schleswig-Holstein	SH	Dithmarschen
25776	Rehm-Flehde-Bargen	Schleswig-Holstein	SH	Dithmarschen
25776	Sankt Annen	Schleswig-Holstein	SH	Dithmarschen
25779	Glüsing	Schleswig-Holstein	SH	Dithmarschen
25779	Hennstedt	Schleswig-Holstein	SH	Dithmarschen
25779	Fedderingen	Schleswig-Holstein	SH	Dithmarschen
25779	Norderheistedt	Schleswig-Holstein	SH	Dithmarschen
25779	Bergewöhrden	Schleswig-Holstein	SH	Dithmarschen
25779	Kleve	Schleswig-Holstein	SH	Dithmarschen
25779	Süderheistedt	Schleswig-Holstein	SH	Dithmarschen
25779	Wiemerstedt	Schleswig-Holstein	SH	Dithmarschen
25779	Hägen	Schleswig-Holstein	SH	Dithmarschen
25782	Hövede	Schleswig-Holstein	SH	Dithmarschen
25782	Tellingstedt	Schleswig-Holstein	SH	Dithmarschen
25782	Westerborstel	Schleswig-Holstein	SH	Dithmarschen
25782	Welmbüttel	Schleswig-Holstein	SH	Dithmarschen
25782	Süderdorf	Schleswig-Holstein	SH	Dithmarschen
25782	Gaushorn	Schleswig-Holstein	SH	Dithmarschen
25782	Schalkholz	Schleswig-Holstein	SH	Dithmarschen
25782	Schrum	Schleswig-Holstein	SH	Dithmarschen
25785	Nordhastedt	Schleswig-Holstein	SH	Dithmarschen
25785	Sarzbüttel	Schleswig-Holstein	SH	Dithmarschen
25785	Odderade	Schleswig-Holstein	SH	Dithmarschen
25786	Dellstedt	Schleswig-Holstein	SH	Dithmarschen
25788	Delve	Schleswig-Holstein	SH	Dithmarschen
25788	Hollingstedt	Schleswig-Holstein	SH	Dithmarschen
25788	Wallen	Schleswig-Holstein	SH	Dithmarschen
25791	Barkenholm	Schleswig-Holstein	SH	Dithmarschen
25791	Linden	Schleswig-Holstein	SH	Dithmarschen
25792	Neuenkirchen	Schleswig-Holstein	SH	Dithmarschen
25792	Strübbel	Schleswig-Holstein	SH	Dithmarschen
25794	Dörpling	Schleswig-Holstein	SH	Dithmarschen
25794	Pahlen	Schleswig-Holstein	SH	Dithmarschen
25794	Tielenhemme	Schleswig-Holstein	SH	Dithmarschen
25795	Weddingstedt	Schleswig-Holstein	SH	Dithmarschen
25795	Stelle-Wittenwurth	Schleswig-Holstein	SH	Dithmarschen
25797	Wöhrden	Schleswig-Holstein	SH	Dithmarschen
25799	Wrohm	Schleswig-Holstein	SH	Dithmarschen
25813	Südermarsch	Schleswig-Holstein	SH	Nordfriesland
25813	Simonsberg	Schleswig-Holstein	SH	Nordfriesland
25813	Schwesing	Schleswig-Holstein	SH	Nordfriesland
25813	Husum	Schleswig-Holstein	SH	Nordfriesland
25821	Bredstedt	Schleswig-Holstein	SH	Nordfriesland
25821	Struckum	Schleswig-Holstein	SH	Nordfriesland
25821	Sönnebüll	Schleswig-Holstein	SH	Nordfriesland
25821	Vollstedt	Schleswig-Holstein	SH	Nordfriesland
25821	Breklum	Schleswig-Holstein	SH	Nordfriesland
25821	Reußenköge	Schleswig-Holstein	SH	Nordfriesland
25821	Almdorf	Schleswig-Holstein	SH	Nordfriesland
25826	Sankt Peter-Ording	Schleswig-Holstein	SH	Nordfriesland
25832	Kotzenbüll	Schleswig-Holstein	SH	Nordfriesland
25832	Tönning	Schleswig-Holstein	SH	Nordfriesland
25836	Grothusenkoog	Schleswig-Holstein	SH	Nordfriesland
25836	Kirchspiel Garding	Schleswig-Holstein	SH	Nordfriesland
25836	Garding	Schleswig-Holstein	SH	Nordfriesland
25836	Katharinenheerd	Schleswig-Holstein	SH	Nordfriesland
25836	Osterhever	Schleswig-Holstein	SH	Nordfriesland
25836	Vollerwiek	Schleswig-Holstein	SH	Nordfriesland
25836	Poppenbüll	Schleswig-Holstein	SH	Nordfriesland
25836	Welt	Schleswig-Holstein	SH	Nordfriesland
25840	Koldenbüttel	Schleswig-Holstein	SH	Nordfriesland
25840	Friedrichstadt	Schleswig-Holstein	SH	Nordfriesland
25842	Lütjenholm	Schleswig-Holstein	SH	Nordfriesland
25842	Langenhorn	Schleswig-Holstein	SH	Nordfriesland
25842	Bargum	Schleswig-Holstein	SH	Nordfriesland
25842	Ockholm	Schleswig-Holstein	SH	Nordfriesland
25845	Nordstrand	Schleswig-Holstein	SH	Nordfriesland
25845	Elisabeth-Sophien-Koog	Schleswig-Holstein	SH	Nordfriesland
25849	Pellworm	Schleswig-Holstein	SH	Nordfriesland
25850	Bondelum	Schleswig-Holstein	SH	Nordfriesland
25850	Behrendorf	Schleswig-Holstein	SH	Nordfriesland
25852	Bordelum	Schleswig-Holstein	SH	Nordfriesland
25853	Drelsdorf	Schleswig-Holstein	SH	Nordfriesland
25853	Bohmstedt	Schleswig-Holstein	SH	Nordfriesland
25853	Ahrenshöft	Schleswig-Holstein	SH	Nordfriesland
25855	Haselund	Schleswig-Holstein	SH	Nordfriesland
25856	Wobbenbüll	Schleswig-Holstein	SH	Nordfriesland
25856	Hattstedtermarsch	Schleswig-Holstein	SH	Nordfriesland
25856	Hattstedt	Schleswig-Holstein	SH	Nordfriesland
25858	Högel	Schleswig-Holstein	SH	Nordfriesland
25859	Hooge	Schleswig-Holstein	SH	Nordfriesland
25860	Olderup	Schleswig-Holstein	SH	Nordfriesland
25860	Horstedt	Schleswig-Holstein	SH	Nordfriesland
25860	Arlewatt	Schleswig-Holstein	SH	Nordfriesland
25862	Joldelund	Schleswig-Holstein	SH	Nordfriesland
25862	Goldebek	Schleswig-Holstein	SH	Nordfriesland
25862	Kolkerheide	Schleswig-Holstein	SH	Nordfriesland
25862	Goldelund	Schleswig-Holstein	SH	Nordfriesland
25863	Langeneß	Schleswig-Holstein	SH	Nordfriesland
25864	Löwenstedt	Schleswig-Holstein	SH	Nordfriesland
25866	Mildstedt	Schleswig-Holstein	SH	Nordfriesland
25868	Norderstapel	Schleswig-Holstein	SH	Schleswig-Flensburg
25869	Gröde	Schleswig-Holstein	SH	Nordfriesland
25870	Norderfriedrichskoog	Schleswig-Holstein	SH	Nordfriesland
25870	Oldenswort	Schleswig-Holstein	SH	Nordfriesland
25872	Ostenfeld	Schleswig-Holstein	SH	Nordfriesland
25872	Wittbek	Schleswig-Holstein	SH	Nordfriesland
25873	Rantrum	Schleswig-Holstein	SH	Nordfriesland
25873	Oldersbek	Schleswig-Holstein	SH	Nordfriesland
25875	Schobüll	Schleswig-Holstein	SH	Nordfriesland
25876	Süderhöft	Schleswig-Holstein	SH	Nordfriesland
25876	Schwabstedt	Schleswig-Holstein	SH	Nordfriesland
25876	Wisch	Schleswig-Holstein	SH	Nordfriesland
25876	Fresendelf	Schleswig-Holstein	SH	Nordfriesland
25876	Ramstedt	Schleswig-Holstein	SH	Nordfriesland
25876	Hude	Schleswig-Holstein	SH	Nordfriesland
25878	Seeth	Schleswig-Holstein	SH	Nordfriesland
25878	Drage	Schleswig-Holstein	SH	Nordfriesland
25879	Süderstapel	Schleswig-Holstein	SH	Schleswig-Flensburg
25881	Westerhever	Schleswig-Holstein	SH	Nordfriesland
25881	Tümlauer Koog	Schleswig-Holstein	SH	Nordfriesland
25881	Augustenkoog	Schleswig-Holstein	SH	Nordfriesland
25881	Tating	Schleswig-Holstein	SH	Nordfriesland
25882	Tetenbüll	Schleswig-Holstein	SH	Nordfriesland
25884	Sollwitt	Schleswig-Holstein	SH	Nordfriesland
25884	Viöl	Schleswig-Holstein	SH	Nordfriesland
25884	Norstedt	Schleswig-Holstein	SH	Nordfriesland
25885	Oster-Ohrstedt	Schleswig-Holstein	SH	Nordfriesland
25885	Ahrenviöl	Schleswig-Holstein	SH	Nordfriesland
25885	Ahrenviölfeld	Schleswig-Holstein	SH	Nordfriesland
25885	Wester-Ohrstedt	Schleswig-Holstein	SH	Nordfriesland
25885	Immenstedt	Schleswig-Holstein	SH	Nordfriesland
25887	Winnert	Schleswig-Holstein	SH	Nordfriesland
25889	Uelvesbüll	Schleswig-Holstein	SH	Nordfriesland
25889	Witzwort	Schleswig-Holstein	SH	Nordfriesland
25899	Dagebüll	Schleswig-Holstein	SH	Nordfriesland
25899	Klixbüll	Schleswig-Holstein	SH	Nordfriesland
25899	Galmsbüll	Schleswig-Holstein	SH	Nordfriesland
25899	Niebüll	Schleswig-Holstein	SH	Nordfriesland
25899	Bosbüll	Schleswig-Holstein	SH	Nordfriesland
25917	Achtrup	Schleswig-Holstein	SH	Nordfriesland
25917	Leck	Schleswig-Holstein	SH	Nordfriesland
25917	Enge-Sande	Schleswig-Holstein	SH	Nordfriesland
25917	Tinningstedt	Schleswig-Holstein	SH	Nordfriesland
25917	Stadum	Schleswig-Holstein	SH	Nordfriesland
25917	Sprakebüll	Schleswig-Holstein	SH	Nordfriesland
25920	Risum-Lindholm	Schleswig-Holstein	SH	Nordfriesland
25920	Stedesand	Schleswig-Holstein	SH	Nordfriesland
25923	Lexgaard	Schleswig-Holstein	SH	Nordfriesland
25923	Ellhöft	Schleswig-Holstein	SH	Nordfriesland
25923	Uphusum	Schleswig-Holstein	SH	Nordfriesland
25923	Humptrup	Schleswig-Holstein	SH	Nordfriesland
25923	Holm	Schleswig-Holstein	SH	Nordfriesland
2829	Königshain	Sachsen	SN	Görlitz
25923	Braderup	Schleswig-Holstein	SH	Nordfriesland
25923	Süderlügum	Schleswig-Holstein	SH	Nordfriesland
25924	Rodenäs	Schleswig-Holstein	SH	Nordfriesland
25924	Klanxbüll	Schleswig-Holstein	SH	Nordfriesland
25924	Emmelsbüll-Horsbüll	Schleswig-Holstein	SH	Nordfriesland
25924	Friedrich-Wilhelm-Lübke-Koog	Schleswig-Holstein	SH	Nordfriesland
25926	Karlum	Schleswig-Holstein	SH	Nordfriesland
25926	Ladelund	Schleswig-Holstein	SH	Nordfriesland
25926	Westre	Schleswig-Holstein	SH	Nordfriesland
25926	Bramstedtlund	Schleswig-Holstein	SH	Nordfriesland
25927	Aventoft	Schleswig-Holstein	SH	Nordfriesland
25927	Neukirchen	Schleswig-Holstein	SH	Nordfriesland
25938	Borgsum	Schleswig-Holstein	SH	Nordfriesland
25938	Nieblum	Schleswig-Holstein	SH	Nordfriesland
25938	Midlum	Schleswig-Holstein	SH	Nordfriesland
25938	Oldsum	Schleswig-Holstein	SH	Nordfriesland
25938	Wyk auf Föhr	Schleswig-Holstein	SH	Nordfriesland
25938	Alkersum	Schleswig-Holstein	SH	Nordfriesland
25938	Wrixum	Schleswig-Holstein	SH	Nordfriesland
25938	Süderende	Schleswig-Holstein	SH	Nordfriesland
25938	Dunsum	Schleswig-Holstein	SH	Nordfriesland
25938	Utersum	Schleswig-Holstein	SH	Nordfriesland
25938	Witsum	Schleswig-Holstein	SH	Nordfriesland
25938	Oevenum	Schleswig-Holstein	SH	Nordfriesland
25946	Norddorf	Schleswig-Holstein	SH	Nordfriesland
25946	Wittdün	Schleswig-Holstein	SH	Nordfriesland
25946	Nebel	Schleswig-Holstein	SH	Nordfriesland
25980	Westerland	Schleswig-Holstein	SH	Nordfriesland
25980	Rantum	Schleswig-Holstein	SH	Nordfriesland
25980	Sylt-Ost	Schleswig-Holstein	SH	Nordfriesland
25992	List	Schleswig-Holstein	SH	Nordfriesland
25996	Wenningstedt	Schleswig-Holstein	SH	Nordfriesland
25997	Hörnum	Schleswig-Holstein	SH	Nordfriesland
25999	Kampen	Schleswig-Holstein	SH	Nordfriesland
27498	Helgoland	Schleswig-Holstein	SH	Pinneberg
66111	Saarbrücken	Saarland	SL	Regionalverband Saarbrücken
66113	Saarbrücken	Saarland	SL	Regionalverband Saarbrücken
66115	Saarbrücken	Saarland	SL	Regionalverband Saarbrücken
66117	Saarbrücken	Saarland	SL	Regionalverband Saarbrücken
66119	Saarbrücken	Saarland	SL	Regionalverband Saarbrücken
66121	Saarbrücken	Saarland	SL	Regionalverband Saarbrücken
66123	Saarbrücken	Saarland	SL	Regionalverband Saarbrücken
66125	Saarbrücken	Saarland	SL	Regionalverband Saarbrücken
66126	Saarbrücken	Saarland	SL	Regionalverband Saarbrücken
66127	Saarbrücken	Saarland	SL	Regionalverband Saarbrücken
66128	Saarbrücken	Saarland	SL	Regionalverband Saarbrücken
66129	Saarbrücken	Saarland	SL	Regionalverband Saarbrücken
66130	Saarbrücken	Saarland	SL	Regionalverband Saarbrücken
66131	Saarbrücken	Saarland	SL	Regionalverband Saarbrücken
66132	Saarbrücken	Saarland	SL	Regionalverband Saarbrücken
66133	Saarbrücken	Saarland	SL	Regionalverband Saarbrücken
66265	Heusweiler	Saarland	SL	Regionalverband Saarbrücken
66271	Kleinblittersdorf	Saarland	SL	Regionalverband Saarbrücken
66280	Sulzbach/Saar	Saarland	SL	Regionalverband Saarbrücken
66287	Quierschied	Saarland	SL	Regionalverband Saarbrücken
66292	Riegelsberg	Saarland	SL	Regionalverband Saarbrücken
66299	Friedrichsthal	Saarland	SL	Regionalverband Saarbrücken
66333	Völklingen	Saarland	SL	Regionalverband Saarbrücken
66346	Püttlingen	Saarland	SL	Regionalverband Saarbrücken
66352	Großrosseln	Saarland	SL	Regionalverband Saarbrücken
66359	Bous	Saarland	SL	Saarlouis
66386	Sankt Ingbert	Saarland	SL	Saarpfalz
66399	Mandelbachtal	Saarland	SL	Saarpfalz
66424	Homburg	Saarland	SL	Saarpfalz
66440	Blieskastel	Saarland	SL	Saarpfalz
66450	Bexbach	Saarland	SL	Saarpfalz
66453	Gersheim	Saarland	SL	Saarpfalz
66459	Kirkel	Saarland	SL	Saarpfalz
66538	Neunkirchen/Saar	Saarland	SL	Neunkirchen
66539	Neunkirchen/Saar	Saarland	SL	Neunkirchen
66540	Neunkirchen/Saar	Saarland	SL	Neunkirchen
66557	Illingen	Saarland	SL	Neunkirchen
66564	Ottweiler	Saarland	SL	Neunkirchen
66571	Eppelborn	Saarland	SL	Neunkirchen
66578	Schiffweiler	Saarland	SL	Neunkirchen
66583	Spiesen-Elversberg	Saarland	SL	Neunkirchen
66589	Merchweiler	Saarland	SL	Neunkirchen
66606	Sankt Wendel	Saarland	SL	St. Wendel
66620	Nonnweiler	Saarland	SL	St. Wendel
66625	Nohfelden	Saarland	SL	St. Wendel
66629	Freisen	Saarland	SL	St. Wendel
66636	Tholey	Saarland	SL	St. Wendel
66640	Namborn	Saarland	SL	St. Wendel
66646	Marpingen	Saarland	SL	St. Wendel
66649	Oberthal	Saarland	SL	St. Wendel
66663	Merzig	Saarland	SL	Merzig-Wadern
66679	Losheim am See	Saarland	SL	Merzig-Wadern
66687	Wadern	Saarland	SL	Merzig-Wadern
66693	Mettlach	Saarland	SL	Merzig-Wadern
66701	Beckingen	Saarland	SL	Merzig-Wadern
66706	Perl	Saarland	SL	Merzig-Wadern
66709	Weiskirchen	Saarland	SL	Merzig-Wadern
66740	Saarlouis	Saarland	SL	Saarlouis
66763	Dillingen	Saarland	SL	Saarlouis
66773	Schwalbach	Saarland	SL	Saarlouis
66780	Rehlingen-Siersburg	Saarland	SL	Saarlouis
66787	Wadgassen	Saarland	SL	Saarlouis
66793	Saarwellingen	Saarland	SL	Saarlouis
66798	Wallerfangen	Saarland	SL	Saarlouis
66802	Überherrn	Saarland	SL	Saarlouis
66806	Ensdorf	Saarland	SL	Saarlouis
66809	Nalbach	Saarland	SL	Saarlouis
66822	Lebach	Saarland	SL	Saarlouis
66839	Schmelz	Saarland	SL	Saarlouis
1067	Dresden Friedrichstadt	Sachsen	SN	Dresden
1067	Dresden Innere Altstadt	Sachsen	SN	Dresden
1067	Dresden	Sachsen	SN	Dresden
1069	Dresden	Sachsen	SN	Dresden
1097	Dresden	Sachsen	SN	Dresden
1099	Dresden	Sachsen	SN	Dresden
1108	Marsdorf	Sachsen	SN	Dresden
1108	Weixdorf	Sachsen	SN	Dresden
1108	Dresden	Sachsen	SN	Dresden
1109	Dresden	Sachsen	SN	Dresden
1109	Wilschdorf	Sachsen	SN	Dresden
1109	Hellerau	Sachsen	SN	Dresden
1109	Klotzsche	Sachsen	SN	Dresden
1127	Dresden	Sachsen	SN	Dresden
1129	Dresden	Sachsen	SN	Dresden
1139	Dresden	Sachsen	SN	Dresden
1156	Dresden Gompitz; Steinbach	Sachsen	SN	Dresden
1156	Dresden Gompitz; Ockerwitz	Sachsen	SN	Dresden
1156	Dresden Altfranken	Sachsen	SN	Dresden
1156	Dresden Gompitz; Unkersdorf	Sachsen	SN	Dresden
1156	Dresden Gompitz; Roitzsch	Sachsen	SN	Dresden
1156	Dresden Gompitz; Pennrich	Sachsen	SN	Dresden
1156	Dresden Gompitz; Zöllmen	Sachsen	SN	Dresden
1156	Dresden Gompitz; Gompitz	Sachsen	SN	Dresden
1156	Dresden	Sachsen	SN	Dresden
1156	Dresden Gompitz	Sachsen	SN	Dresden
1157	Dresden	Sachsen	SN	Dresden
1159	Dresden	Sachsen	SN	Dresden
1169	Dresden	Sachsen	SN	Dresden
1187	Dresden	Sachsen	SN	Dresden
1189	Dresden	Sachsen	SN	Dresden
1217	Dresden	Sachsen	SN	Dresden
1219	Dresden	Sachsen	SN	Dresden
1237	Dresden	Sachsen	SN	Dresden
1239	Dresden	Sachsen	SN	Dresden
1257	Dresden	Sachsen	SN	Dresden
1259	Dresden	Sachsen	SN	Dresden
1277	Dresden	Sachsen	SN	Dresden
1277	Dresden Tolkewitz	Sachsen	SN	Dresden
1277	Dresden Striesen	Sachsen	SN	Dresden
1279	Dresden	Sachsen	SN	Dresden
1279	Dresden Tolkewitz	Sachsen	SN	Dresden
1307	Dresden	Sachsen	SN	Dresden
1309	Dresden	Sachsen	SN	Dresden
1309	Dresden Blasewitz	Sachsen	SN	Dresden
1324	Dresden	Sachsen	SN	Dresden
1326	Dresden	Sachsen	SN	Dresden
1328	Dresden	Sachsen	SN	Dresden
1445	Radebeul	Sachsen	SN	Meißen
1454	Wachau	Sachsen	SN	Bautzen
1454	Radeberg	Sachsen	SN	Bautzen
1458	Ottendorf-Okrilla	Sachsen	SN	Bautzen
1465	Dresden	Sachsen	SN	Dresden
1465	Dresden Langebrück	Sachsen	SN	Dresden
1468	Moritzburg	Sachsen	SN	Meißen
1471	Radeburg	Sachsen	SN	Meißen
1477	Arnsdorf	Sachsen	SN	Bautzen
1558	Großenhain	Sachsen	SN	Meißen
1561	Lampertswalde	Sachsen	SN	Meißen
1561	Schönfeld	Sachsen	SN	Meißen
1561	Weißig am Raschütz	Sachsen	SN	Meißen
1561	Ebersbach	Sachsen	SN	Meißen
1561	Zabeltitz	Sachsen	SN	Meißen
1561	Tauscha	Sachsen	SN	Meißen
1561	Priestewitz	Sachsen	SN	Meißen
1561	Wildenhain	Sachsen	SN	Meißen
1561	Thiendorf	Sachsen	SN	Meißen
1587	Riesa	Sachsen	SN	Meißen
1589	Riesa	Sachsen	SN	Meißen
1591	Riesa	Sachsen	SN	Meißen
1594	Stauchitz	Sachsen	SN	Meißen
1594	Hirschstein	Sachsen	SN	Meißen
1609	Gröditz	Sachsen	SN	Meißen
1609	Nauwalde	Sachsen	SN	Meißen
1609	Wülknitz	Sachsen	SN	Meißen
1612	Diesbar-Seußlitz	Sachsen	SN	Meißen
1612	Nünchritz	Sachsen	SN	Meißen
1612	Glaubitz	Sachsen	SN	Meißen
1616	Strehla	Sachsen	SN	Meißen
1619	Zeithain	Sachsen	SN	Meißen
1619	Röderaue	Sachsen	SN	Meißen
1623	Ketzerbachtal	Sachsen	SN	Meißen
1623	Leuben-Schleinitz	Sachsen	SN	Meißen
1623	Lommatzsch	Sachsen	SN	Meißen
1640	Coswig	Sachsen	SN	Meißen
1662	Meißen	Sachsen	SN	Meißen
1665	Klipphausen	Sachsen	SN	Meißen
1665	Taubenheim	Sachsen	SN	Meißen
1665	Diera-Zehren	Sachsen	SN	Meißen
1665	Triebischtal	Sachsen	SN	Meißen
1665	Käbschütztal	Sachsen	SN	Meißen
1683	Nossen	Sachsen	SN	Meißen
1683	Heynitz	Sachsen	SN	Meißen
1689	Niederau	Sachsen	SN	Meißen
1689	Weinböhla	Sachsen	SN	Meißen
1705	Freital	Sachsen	SN	Sächsische Schweiz
1723	Wilsdruff	Sachsen	SN	Sächsische Schweiz
1728	Bannewitz	Sachsen	SN	Sächsische Schweiz
1731	Kreischa	Sachsen	SN	Sächsische Schweiz
1734	Rabenau	Sachsen	SN	Sächsische Schweiz
1737	Tharandt	Sachsen	SN	Sächsische Schweiz
1738	Dorfhain	Sachsen	SN	Sächsische Schweiz
1744	Dippoldiswalde	Sachsen	SN	Sächsische Schweiz
1762	Schmiedeberg	Sachsen	SN	Sächsische Schweiz
1762	Hartmannsdorf-Reichenau	Sachsen	SN	Sächsische Schweiz
1768	Reinhardtsgrimma	Sachsen	SN	Sächsische Schweiz
1768	Bärenstein	Sachsen	SN	Sächsische Schweiz
1768	Glashütte	Sachsen	SN	Sächsische Schweiz
1773	Altenberg	Sachsen	SN	Sächsische Schweiz
1774	Pretzschendorf	Sachsen	SN	Sächsische Schweiz
1774	Höckendorf	Sachsen	SN	Sächsische Schweiz
1776	Hermsdorf/Erzgebirge	Sachsen	SN	Sächsische Schweiz
1778	Geising	Sachsen	SN	Sächsische Schweiz
1796	Pirna	Sachsen	SN	Sächsische Schweiz
1796	Struppen	Sachsen	SN	Sächsische Schweiz
1796	Dohma	Sachsen	SN	Sächsische Schweiz
1809	Müglitztal	Sachsen	SN	Sächsische Schweiz
1809	Dohna	Sachsen	SN	Sächsische Schweiz
1809	Heidenau	Sachsen	SN	Sächsische Schweiz
1814	Porschdorf	Sachsen	SN	Sächsische Schweiz
1814	Bad Schandau	Sachsen	SN	Sächsische Schweiz
1814	Reinhardtsdorf-Schöna	Sachsen	SN	Sächsische Schweiz
1814	Rathmannsdorf	Sachsen	SN	Sächsische Schweiz
1816	Bad Gottleuba-Berggießhübel	Sachsen	SN	Sächsische Schweiz
1819	Bahretal	Sachsen	SN	Sächsische Schweiz
1824	Königstein/Sächsische Schweiz	Sachsen	SN	Sächsische Schweiz
1824	Gohrisch	Sachsen	SN	Sächsische Schweiz
1824	Rosenthal-Bielatal	Sachsen	SN	Sächsische Schweiz
1824	Rathen	Sachsen	SN	Sächsische Schweiz
1825	Liebstadt	Sachsen	SN	Sächsische Schweiz
1829	Stadt Wehlen	Sachsen	SN	Sächsische Schweiz
1833	Dürrröhrsdorf-Dittersbach	Sachsen	SN	Sächsische Schweiz
1833	Stolpen	Sachsen	SN	Sächsische Schweiz
1844	Neustadt in Sachsen	Sachsen	SN	Sächsische Schweiz
1844	Hohwald	Sachsen	SN	Sächsische Schweiz
1847	Lohmen	Sachsen	SN	Sächsische Schweiz
1848	Hohnstein	Sachsen	SN	Sächsische Schweiz
1855	Kirnitzschtal	Sachsen	SN	Sächsische Schweiz
1855	Sebnitz	Sachsen	SN	Sächsische Schweiz
1877	Demitz-Thumitz	Sachsen	SN	Bautzen
1877	Bischofswerda	Sachsen	SN	Bautzen
1877	Rammenau	Sachsen	SN	Bautzen
1877	Doberschau-Gaußig	Sachsen	SN	Bautzen
1877	Schmölln-Putzkau	Sachsen	SN	Bautzen
1896	Lichtenberg	Sachsen	SN	Bautzen
1896	Pulsnitz	Sachsen	SN	Bautzen
1896	Ohorn	Sachsen	SN	Bautzen
1900	Großröhrsdorf	Sachsen	SN	Bautzen
1900	Bretnig-Hauswalde	Sachsen	SN	Bautzen
1904	Steinigtwolmsdorf	Sachsen	SN	Bautzen
1904	Neukirch/Lausitz	Sachsen	SN	Bautzen
1906	Burkau	Sachsen	SN	Bautzen
1909	Frankenthal	Sachsen	SN	Bautzen
1909	Großharthau	Sachsen	SN	Bautzen
1917	Kamenz	Sachsen	SN	Bautzen
1920	Schönteichen	Sachsen	SN	Bautzen
1920	Haselbachtal	Sachsen	SN	Bautzen
1920	Ralbitz-Rosenthal	Sachsen	SN	Bautzen
1920	Steina	Sachsen	SN	Bautzen
1920	Nebelschütz	Sachsen	SN	Bautzen
1920	Crostwitz	Sachsen	SN	Bautzen
1920	Panschwitz-Kuckau	Sachsen	SN	Bautzen
1920	Oßling	Sachsen	SN	Bautzen
1920	Elstra	Sachsen	SN	Bautzen
1920	Räckelwitz	Sachsen	SN	Bautzen
1936	Königsbrück	Sachsen	SN	Bautzen
1936	Schwepnitz	Sachsen	SN	Bautzen
1936	Laußnitz	Sachsen	SN	Bautzen
1936	Großnaundorf	Sachsen	SN	Bautzen
1936	Oberlichtenau	Sachsen	SN	Bautzen
1936	Neukirch	Sachsen	SN	Bautzen
1936	Straßgräbchen	Sachsen	SN	Bautzen
1936	Haselbachtal	Sachsen	SN	Bautzen
2625	Bautzen	Sachsen	SN	Bautzen
2627	Hochkirch	Sachsen	SN	Bautzen
2627	Kubschütz	Sachsen	SN	Bautzen
2627	Radibor	Sachsen	SN	Bautzen
2627	Weißenberg	Sachsen	SN	Bautzen
2633	Doberschau-Gaußig	Sachsen	SN	Bautzen
2633	Göda	Sachsen	SN	Bautzen
2681	Schirgiswalde	Sachsen	SN	Bautzen
2681	Crostau	Sachsen	SN	Bautzen
2681	Kirschau	Sachsen	SN	Bautzen
2681	Wilthen	Sachsen	SN	Bautzen
2689	Sohland an der Spree	Sachsen	SN	Bautzen
2692	Doberschau-Gaußig	Sachsen	SN	Bautzen
2692	Großpostwitz/Oberlausitz	Sachsen	SN	Bautzen
2692	Obergurig	Sachsen	SN	Bautzen
2692	Eulowitz	Sachsen	SN	Bautzen
2694	Großdubrau	Sachsen	SN	Bautzen
2694	Guttau	Sachsen	SN	Bautzen
2694	Malschwitz	Sachsen	SN	Bautzen
2699	Puschwitz	Sachsen	SN	Bautzen
2699	Königswartha	Sachsen	SN	Bautzen
2699	Neschwitz	Sachsen	SN	Bautzen
2708	Niedercunnersdorf	Sachsen	SN	Görlitz
2708	Großschweidnitz	Sachsen	SN	Görlitz
2708	Löbau	Sachsen	SN	Görlitz
2708	Kittlitz	Sachsen	SN	Görlitz
2708	Dürrhennersdorf	Sachsen	SN	Görlitz
2708	Lawalde	Sachsen	SN	Görlitz
2708	Obercunnersdorf	Sachsen	SN	Görlitz
2708	Schönbach	Sachsen	SN	Görlitz
2708	Rosenbach	Sachsen	SN	Görlitz
2727	Neugersdorf	Sachsen	SN	Görlitz
2730	Ebersbach/Sachsen	Sachsen	SN	Görlitz
2733	Cunewalde	Sachsen	SN	Bautzen
2736	Oppach	Sachsen	SN	Görlitz
2736	Beiersdorf	Sachsen	SN	Görlitz
2739	Eibau	Sachsen	SN	Görlitz
2742	Friedersdorf	Sachsen	SN	Görlitz
2742	Neusalza-Spremberg	Sachsen	SN	Görlitz
2747	Berthelsdorf	Sachsen	SN	Görlitz
2747	Herrnhut	Sachsen	SN	Görlitz
2747	Strahwalde	Sachsen	SN	Görlitz
2747	Großhennersdorf	Sachsen	SN	Görlitz
2748	Bernstadt auf dem Eigen	Sachsen	SN	Görlitz
2763	Mittelherwigsdorf	Sachsen	SN	Görlitz
2763	Zittau	Sachsen	SN	Görlitz
2763	Bertsdorf-Hörnitz	Sachsen	SN	Görlitz
2779	Großschönau	Sachsen	SN	Görlitz
2779	Hainewalde	Sachsen	SN	Görlitz
2782	Seifhennersdorf	Sachsen	SN	Görlitz
2785	Olbersdorf	Sachsen	SN	Görlitz
2788	Hirschfelde	Sachsen	SN	Görlitz
2788	Schlegel	Sachsen	SN	Görlitz
2788	Hirschfelde Dittelsdorf	Sachsen	SN	Görlitz
2791	Oderwitz	Sachsen	SN	Görlitz
2794	Leutersdorf	Sachsen	SN	Görlitz
2796	Jonsdorf	Sachsen	SN	Görlitz
2797	Oybin	Sachsen	SN	Görlitz
2799	Waltersdorf	Sachsen	SN	Görlitz
2894	Reichenbach/Oberlausitz	Sachsen	SN	Görlitz
2894	Vierkirchen	Sachsen	SN	Görlitz
2894	Sohland am Rotstein	Sachsen	SN	Görlitz
2899	Schönau-Berzdorf auf dem Eigen	Sachsen	SN	Görlitz
2899	Ostritz	Sachsen	SN	Görlitz
2906	Mücka	Sachsen	SN	Görlitz
2906	Waldhufen	Sachsen	SN	Görlitz
2906	Kreba-Neudorf	Sachsen	SN	Görlitz
2906	Klitten	Sachsen	SN	Görlitz
2906	Quitzdorf am See	Sachsen	SN	Görlitz
2906	Niesky	Sachsen	SN	Görlitz
2906	Hohendubrau	Sachsen	SN	Görlitz
2923	Hähnichen	Sachsen	SN	Görlitz
2923	Horka	Sachsen	SN	Görlitz
2923	Kodersdorf	Sachsen	SN	Görlitz
2923	Neißeaue	Sachsen	SN	Görlitz
2929	Rothenburg/Oberlausitz	Sachsen	SN	Görlitz
2943	Weißwasser	Sachsen	SN	Görlitz
2943	Boxberg/Oberlausitz	Sachsen	SN	Görlitz
2953	Bad Muskau	Sachsen	SN	Görlitz
2953	Gablenz	Sachsen	SN	Görlitz
2956	Rietschen	Sachsen	SN	Görlitz
2957	Krauschwitz	Sachsen	SN	Görlitz
2957	Weißkeißel	Sachsen	SN	Görlitz
2959	Schleife	Sachsen	SN	Görlitz
2959	Trebendorf	Sachsen	SN	Görlitz
2959	Groß Düben	Sachsen	SN	Görlitz
2977	Hoyerswerda	Sachsen	SN	Bautzen
2979	Spreetal	Sachsen	SN	Bautzen
2979	Elsterheide	Sachsen	SN	Bautzen
2991	Leippe-Torno	Sachsen	SN	Bautzen
2991	Elsterheide	Sachsen	SN	Bautzen
2991	Lauta	Sachsen	SN	Bautzen
2994	Wiednitz	Sachsen	SN	Bautzen
2994	Bernsdorf	Sachsen	SN	Bautzen
2997	Wittichenau	Sachsen	SN	Bautzen
2999	Knappensee	Sachsen	SN	Bautzen
2999	Lohsa	Sachsen	SN	Bautzen
2999	Uhyst	Sachsen	SN	Görlitz
4103	Leipzig	Sachsen	SN	Leipzig
4105	Leipzig	Sachsen	SN	Leipzig
4107	Leipzig	Sachsen	SN	Leipzig
4109	Leipzig	Sachsen	SN	Leipzig
4129	Leipzig	Sachsen	SN	Leipzig
4155	Leipzig	Sachsen	SN	Leipzig
4157	Leipzig	Sachsen	SN	Leipzig
4158	Breitenfeld	Sachsen	SN	Leipzig
4159	Leipzig	Sachsen	SN	Leipzig
4177	Leipzig	Sachsen	SN	Leipzig
4178	Burghausen	Sachsen	SN	Leipzig
4179	Leipzig	Sachsen	SN	Leipzig
4205	Leipzig	Sachsen	SN	Leipzig
4207	Leipzig	Sachsen	SN	Leipzig
4209	Leipzig	Sachsen	SN	Leipzig
4229	Leipzig	Sachsen	SN	Leipzig
4249	Leipzig	Sachsen	SN	Leipzig
4275	Leipzig	Sachsen	SN	Leipzig
4277	Leipzig	Sachsen	SN	Leipzig
4279	Leipzig	Sachsen	SN	Leipzig
4288	Leipzig	Sachsen	SN	Leipzig
4289	Leipzig	Sachsen	SN	Leipzig
4299	Leipzig	Sachsen	SN	Leipzig
4315	Leipzig	Sachsen	SN	Leipzig
4316	Leipzig	Sachsen	SN	Leipzig
4317	Leipzig	Sachsen	SN	Leipzig
4318	Leipzig	Sachsen	SN	Leipzig
4319	Leipzig	Sachsen	SN	Leipzig
4328	Sellerhausen-Stünz	Sachsen	SN	Leipzig
4329	Leipzig	Sachsen	SN	Leipzig
4347	Leipzig	Sachsen	SN	Leipzig
4349	Leipzig	Sachsen	SN	Leipzig
4356	Leipzig	Sachsen	SN	Leipzig
4357	Leipzig	Sachsen	SN	Leipzig
4416	Markkleeberg	Sachsen	SN	Leipzig
4420	Markranstädt	Sachsen	SN	Leipzig
4420	Großlehna	Sachsen	SN	Leipzig
4425	Taucha	Sachsen	SN	Nordsachsen
4435	Schkeuditz	Sachsen	SN	Nordsachsen
4442	Zwenkau	Sachsen	SN	Leipzig
4451	Borsdorf	Sachsen	SN	Leipzig
4460	Kitzen	Sachsen	SN	Leipzig
4463	Großpösna	Sachsen	SN	Leipzig
4509	Zschortau	Sachsen	SN	Nordsachsen
4509	Wiedemar	Sachsen	SN	Nordsachsen
4509	Zwochau	Sachsen	SN	Nordsachsen
4509	Krostitz	Sachsen	SN	Nordsachsen
4509	Schönwölkau	Sachsen	SN	Nordsachsen
4509	Döbernitz	Sachsen	SN	Nordsachsen
4509	Delitzsch	Sachsen	SN	Nordsachsen
4509	Löbnitz	Sachsen	SN	Nordsachsen
4509	Neukyhna	Sachsen	SN	Nordsachsen
4519	Rackwitz	Sachsen	SN	Nordsachsen
4523	Elstertrebnitz	Sachsen	SN	Leipzig
4523	Pegau	Sachsen	SN	Leipzig
4539	Groitzsch	Sachsen	SN	Leipzig
4552	Borna	Sachsen	SN	Leipzig
4552	Lobstädt	Sachsen	SN	Leipzig
4552	Wyhratal	Sachsen	SN	Leipzig
4564	Böhlen	Sachsen	SN	Leipzig
4565	Regis-Breitingen	Sachsen	SN	Leipzig
4567	Kitzscher	Sachsen	SN	Leipzig
4571	Rötha	Sachsen	SN	Leipzig
4574	Heuersdorf	Sachsen	SN	Leipzig
4574	Deutzen	Sachsen	SN	Leipzig
4575	Neukieritzsch	Sachsen	SN	Leipzig
4579	Espenhain	Sachsen	SN	Leipzig
4643	Geithain	Sachsen	SN	Leipzig
4651	Bad Lausick	Sachsen	SN	Leipzig
4651	Eulatal	Sachsen	SN	Leipzig
4654	Frohburg	Sachsen	SN	Leipzig
4655	Kohren-Sahlis	Sachsen	SN	Leipzig
4657	Narsdorf	Sachsen	SN	Leipzig
4668	Parthenstein	Sachsen	SN	Leipzig
4668	Thümmlitzwalde	Sachsen	SN	Leipzig
4668	Großbardau	Sachsen	SN	Leipzig
4668	Großbothen	Sachsen	SN	Leipzig
4668	Otterwisch	Sachsen	SN	Leipzig
4668	Grimma	Sachsen	SN	Leipzig
4680	Colditz	Sachsen	SN	Leipzig
4680	Zschadraß	Sachsen	SN	Leipzig
4683	Naunhof	Sachsen	SN	Leipzig
4683	Belgershain	Sachsen	SN	Leipzig
4685	Nerchau	Sachsen	SN	Leipzig
4687	Trebsen/Mulde	Sachsen	SN	Leipzig
4688	Mutzschen	Sachsen	SN	Leipzig
4703	Bockelwitz	Sachsen	SN	Mittelsachsen
4703	Gersdorf	Sachsen	SN	Mittelsachsen
4703	Leisnig	Sachsen	SN	Mittelsachsen
4720	Zschaitz-Ottewig	Sachsen	SN	Mittelsachsen
4720	Ebersbach	Sachsen	SN	Mittelsachsen
4720	Döbeln	Sachsen	SN	Mittelsachsen
4720	Ziegra-Knobelsdorf	Sachsen	SN	Mittelsachsen
4720	Mochau	Sachsen	SN	Mittelsachsen
4720	Großweitzschen	Sachsen	SN	Mittelsachsen
4736	Waldheim	Sachsen	SN	Mittelsachsen
4741	Roßwein	Sachsen	SN	Mittelsachsen
4741	Niederstriegis	Sachsen	SN	Mittelsachsen
4746	Hartha	Sachsen	SN	Mittelsachsen
4749	Ostrau	Sachsen	SN	Mittelsachsen
4758	Liebschützberg	Sachsen	SN	Nordsachsen
4758	Cavertitz	Sachsen	SN	Nordsachsen
4758	Oschatz	Sachsen	SN	Nordsachsen
4769	Naundorf	Sachsen	SN	Nordsachsen
4769	Mügeln	Sachsen	SN	Nordsachsen
4769	Sornzig-Ablaß	Sachsen	SN	Nordsachsen
4774	Dahlen	Sachsen	SN	Nordsachsen
4779	Wermsdorf	Sachsen	SN	Nordsachsen
4808	Thallwitz	Sachsen	SN	Leipzig
4808	Falkenhain	Sachsen	SN	Leipzig
4808	Wurzen	Sachsen	SN	Leipzig
4808	Hohburg	Sachsen	SN	Leipzig
4808	Kühren-Burkartshain	Sachsen	SN	Leipzig
4821	Brandis	Sachsen	SN	Leipzig
4824	Beucha	Sachsen	SN	Leipzig
4827	Machern	Sachsen	SN	Leipzig
4828	Bennewitz	Sachsen	SN	Leipzig
4838	Jesewitz	Sachsen	SN	Nordsachsen
4838	Laußig	Sachsen	SN	Nordsachsen
4838	Mockrehna	Sachsen	SN	Nordsachsen
4838	Eilenburg	Sachsen	SN	Nordsachsen
4838	Doberschütz	Sachsen	SN	Nordsachsen
4838	Zschepplin	Sachsen	SN	Nordsachsen
4849	Bad Düben	Sachsen	SN	Nordsachsen
4849	Kossa	Sachsen	SN	Nordsachsen
4860	Torgau	Sachsen	SN	Nordsachsen
4860	Zinna	Sachsen	SN	Nordsachsen
4860	Pflückuff	Sachsen	SN	Nordsachsen
4860	Dreiheide	Sachsen	SN	Nordsachsen
4862	Mockrehna	Sachsen	SN	Nordsachsen
4874	Belgern	Sachsen	SN	Nordsachsen
4880	Elsnig	Sachsen	SN	Nordsachsen
4880	Trossin	Sachsen	SN	Nordsachsen
4880	Dommitzsch	Sachsen	SN	Nordsachsen
4886	Beilrode	Sachsen	SN	Nordsachsen
4886	Großtreben-Zwethau	Sachsen	SN	Nordsachsen
4886	Arzberg	Sachsen	SN	Nordsachsen
4889	Schildau	Sachsen	SN	Nordsachsen
7919	Mühltroff	Sachsen	SN	Vogt
7952	Pausa	Sachsen	SN	Vogt
7952	Vogtländisches Oberland	Sachsen	SN	Vogt
7985	Vogtländisches Oberland	Sachsen	SN	Vogt
7985	Elsterberg	Sachsen	SN	Vogt
8056	Zwickau	Sachsen	SN	Zwickau
8058	Zwickau	Sachsen	SN	Zwickau
8060	Zwickau	Sachsen	SN	Zwickau
8062	Zwickau	Sachsen	SN	Zwickau
8064	Zwickau	Sachsen	SN	Zwickau
8066	Zwickau	Sachsen	SN	Zwickau
8107	Hirschfeld	Sachsen	SN	Zwickau
8107	Hartmannsdorf bei Kirchberg	Sachsen	SN	Zwickau
8107	Kirchberg	Sachsen	SN	Zwickau
8112	Wilkau-Haßlau	Sachsen	SN	Zwickau
8115	Lichtentanne	Sachsen	SN	Zwickau
8118	Hartenstein	Sachsen	SN	Zwickau
8118	Hartenstein Hartenstein	Sachsen	SN	Zwickau
8118	Hartenstein Thierfeld	Sachsen	SN	Zwickau
8118	Hartenstein Zschocken	Sachsen	SN	Zwickau
8132	Mülsen Thurm	Sachsen	SN	Zwickau
8132	Mülsen Ortmannsdorf; Neuschönburg	Sachsen	SN	Zwickau
8132	Mülsen Ortmannsdorf; Marienau	Sachsen	SN	Zwickau
8132	Mülsen Mülsen Sankt Micheln	Sachsen	SN	Zwickau
8132	Mülsen Mülsen Sankt Jacob	Sachsen	SN	Zwickau
8132	Mülsen Niedermülsen	Sachsen	SN	Zwickau
8132	Mülsen Ortmannsdorf	Sachsen	SN	Zwickau
8132	Mülsen Wulm; Wulm	Sachsen	SN	Zwickau
8132	Mülsen Ortmannsdorf; Ortmannsdorf	Sachsen	SN	Zwickau
8132	Mülsen	Sachsen	SN	Zwickau
8132	Mülsen Mülsen Sankt Niclas	Sachsen	SN	Zwickau
8132	Mülsen Wulm; Bertelsdorf	Sachsen	SN	Zwickau
8132	Mülsen Stangendorf	Sachsen	SN	Zwickau
8132	Mülsen Wulm	Sachsen	SN	Zwickau
8134	Langenweißbach	Sachsen	SN	Zwickau
8134	Wildenfels	Sachsen	SN	Zwickau
8134	Langenweißbach Langenbach	Sachsen	SN	Zwickau
8134	Langenweißbach Weißbach	Sachsen	SN	Zwickau
8134	Wildenfels Schönau	Sachsen	SN	Zwickau
8134	Wildenfels Härtensdorf	Sachsen	SN	Zwickau
8134	Wildenfels Wildenfels	Sachsen	SN	Zwickau
8134	Wildenfels Wiesenburg	Sachsen	SN	Zwickau
8134	Wildenfels Wiesen	Sachsen	SN	Zwickau
8134	Langenweißbach Grünau	Sachsen	SN	Zwickau
8141	Reinsdorf	Sachsen	SN	Zwickau
8144	Hirschfeld	Sachsen	SN	Zwickau
8147	Crinitzberg	Sachsen	SN	Zwickau
8209	Auerbach/Vogtland	Sachsen	SN	Vogt
8223	Falkenstein/Vogtland	Sachsen	SN	Vogt
8223	Werda	Sachsen	SN	Vogt
8223	Neustadt/Vogtland	Sachsen	SN	Vogt
8223	Grünbach	Sachsen	SN	Vogt
8228	Rodewisch	Sachsen	SN	Vogt
8233	Treuen	Sachsen	SN	Vogt
8236	Ellefeld	Sachsen	SN	Vogt
8237	Steinberg	Sachsen	SN	Vogt
8239	Bergen	Sachsen	SN	Vogt
8248	Klingenthal/Sachsen	Sachsen	SN	Vogt
8258	Markneukirchen	Sachsen	SN	Vogt
8261	Schöneck/Vogtland	Sachsen	SN	Vogt
8262	Tannenbergsthal/Vogtland	Sachsen	SN	Vogt
8262	Morgenröthe-Rautenkranz	Sachsen	SN	Vogt
8265	Erlbach	Sachsen	SN	Vogt
8267	Zwota	Sachsen	SN	Vogt
8269	Hammerbrücke	Sachsen	SN	Vogt
8280	Aue	Sachsen	SN	Erzgebirgskreis
8289	Schneeberg	Sachsen	SN	Erzgebirgskreis
8294	Lößnitz	Sachsen	SN	Erzgebirgskreis
8297	Zwönitz	Sachsen	SN	Erzgebirgskreis
8301	Schlema	Sachsen	SN	Erzgebirgskreis
8304	Schönheide	Sachsen	SN	Erzgebirgskreis
8309	Eibenstock	Sachsen	SN	Erzgebirgskreis
8312	Lauter/Sachsen	Sachsen	SN	Erzgebirgskreis
8315	Bernsbach	Sachsen	SN	Erzgebirgskreis
8318	Hundshübel	Sachsen	SN	Erzgebirgskreis
8321	Zschorlau	Sachsen	SN	Erzgebirgskreis
8324	Bockau	Sachsen	SN	Erzgebirgskreis
8325	Carlsfeld; Erzgebirge	Sachsen	SN	Erzgebirgskreis
8326	Sosa	Sachsen	SN	Erzgebirgskreis
8328	Stützengrün	Sachsen	SN	Erzgebirgskreis
8340	Schwarzenberg/Erzgebirge	Sachsen	SN	Erzgebirgskreis
8340	Beierfeld	Sachsen	SN	Erzgebirgskreis
8344	Grünhain	Sachsen	SN	Erzgebirgskreis
8349	Johanngeorgenstadt	Sachsen	SN	Erzgebirgskreis
8349	Erlabrunn	Sachsen	SN	Erzgebirgskreis
8352	Markersbach	Sachsen	SN	Erzgebirgskreis
8352	Pöhla	Sachsen	SN	Erzgebirgskreis
8352	Raschau	Sachsen	SN	Erzgebirgskreis
8355	Rittersgrün	Sachsen	SN	Erzgebirgskreis
8359	Breitenbrunn/Erzgebirge	Sachsen	SN	Erzgebirgskreis
8371	Glauchau	Sachsen	SN	Zwickau
8373	Remse	Sachsen	SN	Zwickau
8393	Dennheritz	Sachsen	SN	Zwickau
8393	Schönberg	Sachsen	SN	Zwickau
8393	Meerane	Sachsen	SN	Zwickau
8396	Waldenburg	Sachsen	SN	Zwickau
8396	Oberwiera	Sachsen	SN	Zwickau
8412	Leubnitz	Sachsen	SN	Zwickau
8412	Werdau	Sachsen	SN	Zwickau
8427	Fraureuth	Sachsen	SN	Zwickau
8428	Langenbernsdorf	Sachsen	SN	Zwickau
8432	Steinpleis	Sachsen	SN	Zwickau
8439	Langenhessen	Sachsen	SN	Zwickau
8451	Crimmitschau	Sachsen	SN	Zwickau
8459	Neukirchen/Pleiße	Sachsen	SN	Zwickau
8468	Heinsdorfergrund	Sachsen	SN	Vogt
8468	Reichenbach/Vogtland	Sachsen	SN	Vogt
8485	Lengenfeld	Sachsen	SN	Vogt
8491	Netzschkau	Sachsen	SN	Vogt
8491	Limbach	Sachsen	SN	Vogt
8496	Neumark	Sachsen	SN	Vogt
8499	Mylau	Sachsen	SN	Vogt
8523	Plauen	Sachsen	SN	Vogt
8525	Plauen	Sachsen	SN	Vogt
8527	Plauen	Sachsen	SN	Vogt
8529	Plauen	Sachsen	SN	Vogt
8538	Reuth	Sachsen	SN	Vogt
8538	Burgstein	Sachsen	SN	Vogt
8538	Weischlitz	Sachsen	SN	Vogt
8539	Mehltheuer	Sachsen	SN	Vogt
8541	Theuma	Sachsen	SN	Vogt
8541	Neuensalz	Sachsen	SN	Vogt
8543	Pöhl	Sachsen	SN	Vogt
8547	Jößnitz	Sachsen	SN	Vogt
8548	Syrau	Sachsen	SN	Vogt
8606	Bösenbrunn	Sachsen	SN	Vogt
8606	Triebel/Vogtland	Sachsen	SN	Vogt
8606	Mühlental	Sachsen	SN	Vogt
8606	Oelsnitz	Sachsen	SN	Vogt
8606	Tirpersdorf	Sachsen	SN	Vogt
8626	Eichigt	Sachsen	SN	Vogt
8626	Adorf	Sachsen	SN	Vogt
8645	Bad Elster	Sachsen	SN	Vogt
8648	Bad Brambach	Sachsen	SN	Vogt
9028	Chemnitz; Sachsen	Sachsen	SN	Chemnitz; Stadt
9030	Chemnitz; Sachsen	Sachsen	SN	Chemnitz; Stadt
9111	Chemnitz	Sachsen	SN	Chemnitz; Stadt
9112	Chemnitz	Sachsen	SN	Chemnitz; Stadt
9113	Chemnitz	Sachsen	SN	Chemnitz; Stadt
9114	Chemnitz	Sachsen	SN	Chemnitz; Stadt
9116	Chemnitz	Sachsen	SN	Chemnitz; Stadt
9117	Chemnitz	Sachsen	SN	Chemnitz; Stadt
9119	Chemnitz	Sachsen	SN	Chemnitz; Stadt
9120	Chemnitz	Sachsen	SN	Chemnitz; Stadt
9122	Chemnitz	Sachsen	SN	Chemnitz; Stadt
9123	Chemnitz	Sachsen	SN	Chemnitz; Stadt
9125	Chemnitz	Sachsen	SN	Chemnitz; Stadt
9126	Chemnitz	Sachsen	SN	Chemnitz; Stadt
9127	Chemnitz	Sachsen	SN	Chemnitz; Stadt
9128	Chemnitz; Sachsen	Sachsen	SN	Chemnitz; Stadt
9130	Chemnitz	Sachsen	SN	Chemnitz; Stadt
9131	Chemnitz	Sachsen	SN	Chemnitz; Stadt
9212	Kändler	Sachsen	SN	Zwickau
9212	Pleißa	Sachsen	SN	Zwickau
9212	Limbach-Oberfrohna	Sachsen	SN	Zwickau
9217	Burgstädt	Sachsen	SN	Mittelsachsen
9221	Neukirchen/Erzgebirge	Sachsen	SN	Erzgebirgskreis
9224	Mittelbach bei Chemnitz	Sachsen	SN	Chemnitz; Stadt
9227	Einsiedel bei Chemnitz	Sachsen	SN	Chemnitz; Stadt
9228	Wittgensdorf	Sachsen	SN	Chemnitz; Stadt
9232	Hartmannsdorf	Sachsen	SN	Mittelsachsen
9235	Burkhardtsdorf	Sachsen	SN	Erzgebirgskreis
9236	Claußnitz	Sachsen	SN	Mittelsachsen
9241	Mühlau	Sachsen	SN	Mittelsachsen
9243	Niederfrohna	Sachsen	SN	Zwickau
9244	Lichtenau	Sachsen	SN	Mittelsachsen
9247	Röhrsdorf	Sachsen	SN	Chemnitz; Stadt
9249	Taura	Sachsen	SN	Mittelsachsen
9306	Wechselburg	Sachsen	SN	Mittelsachsen
9306	Erlau	Sachsen	SN	Mittelsachsen
9306	Königshain-Wiederau	Sachsen	SN	Mittelsachsen
9306	Rochlitz	Sachsen	SN	Mittelsachsen
9306	Zettlitz	Sachsen	SN	Mittelsachsen
9306	Königsfeld	Sachsen	SN	Mittelsachsen
9306	Seelitz	Sachsen	SN	Mittelsachsen
9322	Penig	Sachsen	SN	Mittelsachsen
9326	Geringswalde	Sachsen	SN	Mittelsachsen
9328	Lunzenau	Sachsen	SN	Mittelsachsen
9337	Hohenstein-Ernstthal	Sachsen	SN	Zwickau
9337	Callenberg	Sachsen	SN	Zwickau
9337	Bernsdorf	Sachsen	SN	Zwickau
9350	Lichtenstein/Sachsen	Sachsen	SN	Zwickau
9353	Oberlungwitz	Sachsen	SN	Zwickau
9355	Gersdorf	Sachsen	SN	Zwickau
9356	Sankt Egidien	Sachsen	SN	Zwickau
9366	Niederdorf	Sachsen	SN	Erzgebirgskreis
9366	Stollberg/Erzgebirge	Sachsen	SN	Erzgebirgskreis
9376	Oelsnitz/Erzgebirge	Sachsen	SN	Erzgebirgskreis
9380	Thalheim / Erzgebirge	Sachsen	SN	Erzgebirgskreis
9385	Lugau/Erzgebirge	Sachsen	SN	Erzgebirgskreis
9385	Erlbach-Kirchberg	Sachsen	SN	Erzgebirgskreis
9387	Jahnsdorf/Erzgebirge	Sachsen	SN	Erzgebirgskreis
9390	Gornsdorf	Sachsen	SN	Erzgebirgskreis
9392	Auerbach	Sachsen	SN	Erzgebirgskreis
9394	Hohndorf	Sachsen	SN	Erzgebirgskreis
9395	Hormersdorf	Sachsen	SN	Erzgebirgskreis
9399	Niederwürschnitz	Sachsen	SN	Erzgebirgskreis
9405	Zschopau	Sachsen	SN	Erzgebirgskreis
9405	Gornau/Erzgebirge	Sachsen	SN	Erzgebirgskreis
9419	Thum	Sachsen	SN	Erzgebirgskreis
9423	Gelenau/Erzgebirge	Sachsen	SN	Erzgebirgskreis
9427	Ehrenfriedersdorf	Sachsen	SN	Erzgebirgskreis
9429	Wolkenstein	Sachsen	SN	Erzgebirgskreis
9430	Drebach	Sachsen	SN	Erzgebirgskreis
9430	Venusberg	Sachsen	SN	Erzgebirgskreis
9432	Großolbersdorf	Sachsen	SN	Erzgebirgskreis
9435	Scharfenstein	Sachsen	SN	Erzgebirgskreis
9437	Börnichen/Erzgebirge	Sachsen	SN	Erzgebirgskreis
9437	Waldkirchen/Erzgebirge	Sachsen	SN	Erzgebirgskreis
9439	Amtsberg	Sachsen	SN	Erzgebirgskreis
9456	Mildenau	Sachsen	SN	Erzgebirgskreis
9456	Annaberg-Buchholz	Sachsen	SN	Erzgebirgskreis
9465	Sehmatal	Sachsen	SN	Erzgebirgskreis
9468	Geyer	Sachsen	SN	Erzgebirgskreis
9468	Tannenberg	Sachsen	SN	Erzgebirgskreis
9471	Bärenstein	Sachsen	SN	Erzgebirgskreis
9471	Königswalde	Sachsen	SN	Erzgebirgskreis
9474	Crottendorf	Sachsen	SN	Erzgebirgskreis
9477	Jöhstadt	Sachsen	SN	Erzgebirgskreis
9481	Elterlein	Sachsen	SN	Erzgebirgskreis
9481	Scheibenberg	Sachsen	SN	Erzgebirgskreis
9484	Oberwiesenthal	Sachsen	SN	Erzgebirgskreis
9487	Schlettau	Sachsen	SN	Erzgebirgskreis
9488	Wiesa	Sachsen	SN	Erzgebirgskreis
9496	Marienberg	Sachsen	SN	Erzgebirgskreis
9496	Pobershau	Sachsen	SN	Erzgebirgskreis
9509	Pockau	Sachsen	SN	Erzgebirgskreis
9514	Lengefeld	Sachsen	SN	Erzgebirgskreis
9517	Zöblitz	Sachsen	SN	Erzgebirgskreis
9518	Großrückerswalde	Sachsen	SN	Erzgebirgskreis
9526	Pfaffroda	Sachsen	SN	Erzgebirgskreis
9526	Heidersdorf	Sachsen	SN	Erzgebirgskreis
9526	Olbernhau	Sachsen	SN	Erzgebirgskreis
9544	Neuhausen/Erzgebirge	Sachsen	SN	Mittelsachsen
9548	Deutschneudorf	Sachsen	SN	Erzgebirgskreis
9548	Seiffen/Erzgebirge	Sachsen	SN	Erzgebirgskreis
9557	Flöha	Sachsen	SN	Mittelsachsen
9569	Gahlenz	Sachsen	SN	Mittelsachsen
9569	Frankenstein	Sachsen	SN	Mittelsachsen
9569	Falkenau	Sachsen	SN	Mittelsachsen
9569	Oederan	Sachsen	SN	Mittelsachsen
9573	Augustusburg	Sachsen	SN	Mittelsachsen
9573	Leubsdorf	Sachsen	SN	Mittelsachsen
9575	Eppendorf	Sachsen	SN	Mittelsachsen
9577	Niederwiesa	Sachsen	SN	Mittelsachsen
9579	Borstendorf	Sachsen	SN	Erzgebirgskreis
9579	Grünhainichen	Sachsen	SN	Erzgebirgskreis
9599	Freiberg	Sachsen	SN	Mittelsachsen
9600	Weißenborn/Erzgebirge	Sachsen	SN	Mittelsachsen
9600	Niederschöna	Sachsen	SN	Mittelsachsen
9600	Oberschöna	Sachsen	SN	Mittelsachsen
9603	Großschirma	Sachsen	SN	Mittelsachsen
9618	Großhartmannsdorf	Sachsen	SN	Mittelsachsen
9618	Brand-Erbisdorf	Sachsen	SN	Mittelsachsen
9619	Dorfchemnitz bei Sayda	Sachsen	SN	Mittelsachsen
9619	Sayda	Sachsen	SN	Mittelsachsen
9619	Mulda/Sachsen	Sachsen	SN	Mittelsachsen
9623	Frauenstein	Sachsen	SN	Mittelsachsen
9623	Rechenberg-Bienenmühle	Sachsen	SN	Mittelsachsen
9627	Bobritzsch	Sachsen	SN	Mittelsachsen
9627	Hilbersdorf	Sachsen	SN	Mittelsachsen
9629	Reinsberg	Sachsen	SN	Mittelsachsen
9633	Halsbrücke	Sachsen	SN	Mittelsachsen
9634	Siebenlehn	Sachsen	SN	Mittelsachsen
9638	Lichtenberg/Erzgebirge	Sachsen	SN	Mittelsachsen
9648	Altmittweida	Sachsen	SN	Mittelsachsen
9648	Mittweida	Sachsen	SN	Mittelsachsen
9648	Kriebstein	Sachsen	SN	Mittelsachsen
9661	Hainichen	Sachsen	SN	Mittelsachsen
9661	Striegistal	Sachsen	SN	Mittelsachsen
9661	Tiefenbach	Sachsen	SN	Mittelsachsen
9661	Rossau	Sachsen	SN	Mittelsachsen
9669	Frankenberg/Sachsen	Sachsen	SN	Mittelsachsen
6108	Halle	Sachsen-Anhalt	ST	Halle
6110	Halle	Sachsen-Anhalt	ST	Halle
6112	Halle	Sachsen-Anhalt	ST	Halle
6114	Halle	Sachsen-Anhalt	ST	Halle
6116	Halle	Sachsen-Anhalt	ST	Halle
6118	Halle	Sachsen-Anhalt	ST	Halle
6120	Halle	Sachsen-Anhalt	ST	Halle
6120	Lieskau	Sachsen-Anhalt	ST	Saalekreis
6122	Halle	Sachsen-Anhalt	ST	Halle
6124	Halle	Sachsen-Anhalt	ST	Halle
6126	Halle	Sachsen-Anhalt	ST	Halle
6128	Halle	Sachsen-Anhalt	ST	Halle
6130	Halle	Sachsen-Anhalt	ST	Halle
6132	Halle	Sachsen-Anhalt	ST	Halle
6179	Langenbogen	Sachsen-Anhalt	ST	Saalekreis
6179	Schkopau Hohenweiden	Sachsen-Anhalt	ST	Saalekreis
6179	Zscherben	Sachsen-Anhalt	ST	Saalekreis
6179	Höhnstedt	Sachsen-Anhalt	ST	Saalekreis
6179	Schkopau	Sachsen-Anhalt	ST	Saalekreis
6179	Bennstedt	Sachsen-Anhalt	ST	Saalekreis
6179	Holleben	Sachsen-Anhalt	ST	Saalekreis
6179	Zappendorf	Sachsen-Anhalt	ST	Saalekreis
6179	Schochwitz	Sachsen-Anhalt	ST	Saalekreis
6179	Dornstedt	Sachsen-Anhalt	ST	Saalekreis
6179	Teutschenthal	Sachsen-Anhalt	ST	Saalekreis
6179	Angersdorf	Sachsen-Anhalt	ST	Saalekreis
6179	Steuden	Sachsen-Anhalt	ST	Saalekreis
6184	Gröbers	Sachsen-Anhalt	ST	Saalekreis
6184	Dölbau	Sachsen-Anhalt	ST	Saalekreis
6184	Schkopau Lochau	Sachsen-Anhalt	ST	Saalekreis
6184	Schkopau	Sachsen-Anhalt	ST	Saalekreis
6184	Dieskau	Sachsen-Anhalt	ST	Saalekreis
6184	Schkopau Döllnitz	Sachsen-Anhalt	ST	Saalekreis
6184	Schkopau Ermlitz	Sachsen-Anhalt	ST	Saalekreis
6184	Großkugel	Sachsen-Anhalt	ST	Saalekreis
6184	Schkopau Röglitz	Sachsen-Anhalt	ST	Saalekreis
6184	Schkopau Raßnitz	Sachsen-Anhalt	ST	Saalekreis
6184	Schkopau Burgliebenau	Sachsen-Anhalt	ST	Saalekreis
6188	Brachstedt	Sachsen-Anhalt	ST	Saalekreis
6188	Peißen	Sachsen-Anhalt	ST	Saalekreis
6188	Schwerz	Sachsen-Anhalt	ST	Saalekreis
6188	Spickendorf	Sachsen-Anhalt	ST	Saalekreis
6188	Oppin	Sachsen-Anhalt	ST	Saalekreis
6188	Hohenthurm	Sachsen-Anhalt	ST	Saalekreis
6188	Braschwitz	Sachsen-Anhalt	ST	Saalekreis
6188	Sietzsch	Sachsen-Anhalt	ST	Saalekreis
6188	Reußen	Sachsen-Anhalt	ST	Saalekreis
6188	Queis	Sachsen-Anhalt	ST	Saalekreis
6188	Niemberg	Sachsen-Anhalt	ST	Saalekreis
6188	Landsberg	Sachsen-Anhalt	ST	Saalekreis
6193	Löbejün	Sachsen-Anhalt	ST	Saalekreis
6193	Gutenberg	Sachsen-Anhalt	ST	Saalekreis
6193	Petersberg	Sachsen-Anhalt	ST	Saalekreis
6193	Plötz	Sachsen-Anhalt	ST	Saalekreis
6193	Ostrau	Sachsen-Anhalt	ST	Saalekreis
6193	Teicha	Sachsen-Anhalt	ST	Saalekreis
6193	Nauendorf	Sachsen-Anhalt	ST	Saalekreis
6193	Morl	Sachsen-Anhalt	ST	Saalekreis
6193	Kütten	Sachsen-Anhalt	ST	Saalekreis
6193	Nehlitz	Sachsen-Anhalt	ST	Saalekreis
6193	Sennewitz	Sachsen-Anhalt	ST	Saalekreis
6193	Wallwitz	Sachsen-Anhalt	ST	Saalekreis
6193	Krosigk	Sachsen-Anhalt	ST	Saalekreis
6193	Mösthinsdorf	Sachsen-Anhalt	ST	Saalekreis
6198	Gimritz	Sachsen-Anhalt	ST	Saalekreis
6198	Dößel	Sachsen-Anhalt	ST	Saalekreis
6198	Brachwitz	Sachsen-Anhalt	ST	Saalekreis
6198	Salzmünde	Sachsen-Anhalt	ST	Saalekreis
6198	Fienstedt	Sachsen-Anhalt	ST	Saalekreis
6198	Wettin	Sachsen-Anhalt	ST	Saalekreis
6198	Beesenstedt	Sachsen-Anhalt	ST	Saalekreis
6198	Neutz-Lettewitz	Sachsen-Anhalt	ST	Saalekreis
6198	Kloschwitz	Sachsen-Anhalt	ST	Saalekreis
6198	Döblitz	Sachsen-Anhalt	ST	Saalekreis
6217	Geusa	Sachsen-Anhalt	ST	Saalekreis
6217	Beuna	Sachsen-Anhalt	ST	Saalekreis
6217	Merseburg	Sachsen-Anhalt	ST	Saalekreis
6231	Tollwitz	Sachsen-Anhalt	ST	Saalekreis
6231	Kötzschau	Sachsen-Anhalt	ST	Saalekreis
6231	Oebles-Schlechtewitz	Sachsen-Anhalt	ST	Saalekreis
6231	Kreypau	Sachsen-Anhalt	ST	Saalekreis
6231	Nempitz	Sachsen-Anhalt	ST	Saalekreis
6231	Rodden	Sachsen-Anhalt	ST	Saalekreis
6231	Bad Dürrenberg	Sachsen-Anhalt	ST	Saalekreis
6237	Spergau	Sachsen-Anhalt	ST	Saalekreis
6237	Leuna	Sachsen-Anhalt	ST	Saalekreis
6242	Krumpa	Sachsen-Anhalt	ST	Saalekreis
6242	Roßbach	Sachsen-Anhalt	ST	Saalekreis
6242	Braunsbedra	Sachsen-Anhalt	ST	Saalekreis
6242	Großkayna	Sachsen-Anhalt	ST	Saalekreis
6246	Milzau	Sachsen-Anhalt	ST	Saalekreis
6246	Delitz am Berge	Sachsen-Anhalt	ST	Saalekreis
6246	Klobikau	Sachsen-Anhalt	ST	Saalekreis
6246	Knapendorf	Sachsen-Anhalt	ST	Saalekreis
6246	Bad Lauchstädt	Sachsen-Anhalt	ST	Saalekreis
6249	Mücheln (Geiseltal)	Sachsen-Anhalt	ST	Saalekreis
6254	Günthersdorf	Sachsen-Anhalt	ST	Saalekreis
6254	Kötschlitz	Sachsen-Anhalt	ST	Saalekreis
6254	Wallendorf	Sachsen-Anhalt	ST	Saalekreis
6254	Zweimen	Sachsen-Anhalt	ST	Saalekreis
6254	Zöschen	Sachsen-Anhalt	ST	Saalekreis
6254	Friedensdorf	Sachsen-Anhalt	ST	Saalekreis
6254	Horburg-Maßlau	Sachsen-Anhalt	ST	Saalekreis
6254	Luppenau	Sachsen-Anhalt	ST	Saalekreis
6255	Wünsch	Sachsen-Anhalt	ST	Saalekreis
6255	Schafstädt	Sachsen-Anhalt	ST	Saalekreis
6258	Schkopau Schkopau	Sachsen-Anhalt	ST	Saalekreis
6258	Schkopau Korbetha	Sachsen-Anhalt	ST	Saalekreis
6258	Schkopau	Sachsen-Anhalt	ST	Saalekreis
6259	Frankleben	Sachsen-Anhalt	ST	Saalekreis
6268	Weißenschirmbach	Sachsen-Anhalt	ST	Saalekreis
6268	Nemsdorf-Göhrendorf	Sachsen-Anhalt	ST	Saalekreis
6268	Steigra	Sachsen-Anhalt	ST	Saalekreis
6268	Albersroda	Sachsen-Anhalt	ST	Saalekreis
6268	Langeneichstädt	Sachsen-Anhalt	ST	Saalekreis
6268	Schmon	Sachsen-Anhalt	ST	Saalekreis
6268	Obhausen	Sachsen-Anhalt	ST	Saalekreis
6268	Leimbach	Sachsen-Anhalt	ST	Saalekreis
6268	Vitzenburg	Sachsen-Anhalt	ST	Saalekreis
6268	Querfurt	Sachsen-Anhalt	ST	Saalekreis
6268	Grockstädt	Sachsen-Anhalt	ST	Saalekreis
6268	Ziegelroda	Sachsen-Anhalt	ST	Saalekreis
6268	Barnstädt	Sachsen-Anhalt	ST	Saalekreis
6268	Oechlitz	Sachsen-Anhalt	ST	Saalekreis
6279	Farnstädt	Sachsen-Anhalt	ST	Saalekreis
6279	Schraplau	Sachsen-Anhalt	ST	Saalekreis
6279	Alberstedt	Sachsen-Anhalt	ST	Saalekreis
6279	Esperstedt	Sachsen-Anhalt	ST	Saalekreis
6295	Wolferode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6295	Rothenschirmbach	Sachsen-Anhalt	ST	Mansfeld-Südharz
6295	Dederstedt	Sachsen-Anhalt	ST	Mansfeld-Südharz
6295	Polleben	Sachsen-Anhalt	ST	Mansfeld-Südharz
6295	Neehausen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6295	Hornburg	Sachsen-Anhalt	ST	Mansfeld-Südharz
6295	Bischofrode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6295	Schmalzerode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6295	Volkstedt	Sachsen-Anhalt	ST	Mansfeld-Südharz
6295	Unterrißdorf	Sachsen-Anhalt	ST	Mansfeld-Südharz
6295	Rottelsdorf	Sachsen-Anhalt	ST	Mansfeld-Südharz
6295	Burgsdorf	Sachsen-Anhalt	ST	Mansfeld-Südharz
6295	Hedersleben	Sachsen-Anhalt	ST	Mansfeld-Südharz
6295	Bornstedt	Sachsen-Anhalt	ST	Mansfeld-Südharz
6295	Lutherstadt Eisleben	Sachsen-Anhalt	ST	Mansfeld-Südharz
6295	Osterhausen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6308	Klostermansfeld	Sachsen-Anhalt	ST	Mansfeld-Südharz
6308	Annarode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6308	Hübitz	Sachsen-Anhalt	ST	Mansfeld-Südharz
6308	Benndorf	Sachsen-Anhalt	ST	Mansfeld-Südharz
6308	Augsdorf	Sachsen-Anhalt	ST	Mansfeld-Südharz
6308	Siersleben	Sachsen-Anhalt	ST	Mansfeld-Südharz
6308	Siebigerode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6311	Helbra	Sachsen-Anhalt	ST	Mansfeld-Südharz
6313	Hergisdorf	Sachsen-Anhalt	ST	Mansfeld-Südharz
6313	Ahlsdorf	Sachsen-Anhalt	ST	Mansfeld-Südharz
6313	Wimmelburg	Sachsen-Anhalt	ST	Mansfeld-Südharz
6317	Aseleben	Sachsen-Anhalt	ST	Mansfeld-Südharz
6317	Stedten	Sachsen-Anhalt	ST	Mansfeld-Südharz
6317	Seeburg	Sachsen-Anhalt	ST	Mansfeld-Südharz
6317	Lüttchendorf	Sachsen-Anhalt	ST	Mansfeld-Südharz
6317	Erdeborn	Sachsen-Anhalt	ST	Mansfeld-Südharz
6317	Röblingen am See	Sachsen-Anhalt	ST	Mansfeld-Südharz
6317	Amsdorf	Sachsen-Anhalt	ST	Mansfeld-Südharz
6318	Wansleben am See	Sachsen-Anhalt	ST	Mansfeld-Südharz
6333	Welbsleben	Sachsen-Anhalt	ST	Mansfeld-Südharz
6333	Endorf	Sachsen-Anhalt	ST	Harz
6333	Quenstedt	Sachsen-Anhalt	ST	Mansfeld-Südharz
6333	Wiederstedt	Sachsen-Anhalt	ST	Mansfeld-Südharz
6333	Greifenhagen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6333	Welfesholz	Sachsen-Anhalt	ST	Mansfeld-Südharz
6333	Bräunrode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6333	Neuplatendorf	Sachsen-Anhalt	ST	Harz
6333	Ritterode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6333	Hettstedt	Sachsen-Anhalt	ST	Mansfeld-Südharz
6333	Sylda	Sachsen-Anhalt	ST	Mansfeld-Südharz
6333	Walbeck	Sachsen-Anhalt	ST	Mansfeld-Südharz
6333	Arnstedt	Sachsen-Anhalt	ST	Mansfeld-Südharz
6333	Harkerode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6343	Möllendorf	Sachsen-Anhalt	ST	Mansfeld-Südharz
6343	Mansfeld	Sachsen-Anhalt	ST	Mansfeld-Südharz
6343	Piskaborn	Sachsen-Anhalt	ST	Mansfeld-Südharz
6343	Gorenzen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6343	Vatterode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6343	Biesenrode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6347	Freist	Sachsen-Anhalt	ST	Mansfeld-Südharz
6347	Heiligenthal	Sachsen-Anhalt	ST	Mansfeld-Südharz
6347	Ihlewitz	Sachsen-Anhalt	ST	Mansfeld-Südharz
6347	Friedeburg	Sachsen-Anhalt	ST	Mansfeld-Südharz
6347	Friedeburgerhütte	Sachsen-Anhalt	ST	Mansfeld-Südharz
6347	Gerbstedt	Sachsen-Anhalt	ST	Mansfeld-Südharz
6347	Zabenstedt	Sachsen-Anhalt	ST	Mansfeld-Südharz
6348	Großörner	Sachsen-Anhalt	ST	Mansfeld-Südharz
6366	Köthen	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Prosigk	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Dohndorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Großbadegast	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Weißandt-Gölzau	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Drosa	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Wörbzig	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Riesdorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Löbnitz an der Linde	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Trebbichau an der Fuhne	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Wülknitz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Arensdorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Zabitz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Glauzig	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Dornbock	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Trinum	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Görzig	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Reupzig	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Großpaschleben	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Schortewitz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Wulfen	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Cösitz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Zehbitz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Diebzig	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Cosa	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6369	Radegast	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6385	Aken	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6386	Chörau	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6386	Meilendorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6386	Hinsdorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6386	Reppichau	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6386	Quellendorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6386	Scheuder	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6386	Osternienburg	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6386	Fraßdorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6386	Libbesdorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6386	Elsnigk	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6386	Micheln	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6388	Gröbzig	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6388	Baasdorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6388	Wieskau	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6388	Edderitz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6388	Maasdorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6388	Piethen	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6406	Bernburg	Sachsen-Anhalt	ST	Salz
6408	Ilberstedt	Sachsen-Anhalt	ST	Salz
6408	Biendorf	Sachsen-Anhalt	ST	Salz
6408	Cörmigk	Sachsen-Anhalt	ST	Salz
6408	Aderstedt	Sachsen-Anhalt	ST	Salz
6408	Gröna	Sachsen-Anhalt	ST	Salz
6408	Poley	Sachsen-Anhalt	ST	Salz
6408	Preußlitz	Sachsen-Anhalt	ST	Salz
6408	Peißen	Sachsen-Anhalt	ST	Salz
6408	Baalberge	Sachsen-Anhalt	ST	Salz
6408	Wohlsdorf	Sachsen-Anhalt	ST	Salz
6408	Latdorf	Sachsen-Anhalt	ST	Salz
6420	Edlau	Sachsen-Anhalt	ST	Salz
6420	Gerlebogk	Sachsen-Anhalt	ST	Salz
6420	Domnitz	Sachsen-Anhalt	ST	Saalekreis
6420	Rothenburg	Sachsen-Anhalt	ST	Saalekreis
6420	Könnern	Sachsen-Anhalt	ST	Salz
6420	Lebendorf	Sachsen-Anhalt	ST	Salz
6420	Wiendorf	Sachsen-Anhalt	ST	Salz
6420	Golbitz	Sachsen-Anhalt	ST	Salz
6420	Zickeritz	Sachsen-Anhalt	ST	Salz
6425	Beesenlaublingen	Sachsen-Anhalt	ST	Salz
6425	Plötzkau	Sachsen-Anhalt	ST	Salz
6425	Belleben	Sachsen-Anhalt	ST	Salz
6425	Alsleben (Saale)	Sachsen-Anhalt	ST	Salz
6425	Schackstedt	Sachsen-Anhalt	ST	Salz
6425	Strenznaundorf	Sachsen-Anhalt	ST	Salz
6429	Pobzig	Sachsen-Anhalt	ST	Salz
6429	Nienburg (Saale)	Sachsen-Anhalt	ST	Salz
6429	Wedlitz	Sachsen-Anhalt	ST	Salz
6429	Gerbitz	Sachsen-Anhalt	ST	Salz
6429	Neugattersleben	Sachsen-Anhalt	ST	Salz
12557	Berlin	Berlin	BE	Berlin; Stadt
6449	Schadeleben	Sachsen-Anhalt	ST	Salz
6449	Cochstedt	Sachsen-Anhalt	ST	Salz
6449	Aschersleben Aschersleben	Sachsen-Anhalt	ST	Salz
6449	Schackenthal	Sachsen-Anhalt	ST	Salz
6449	Aschersleben Klein Schierstedt	Sachsen-Anhalt	ST	Salz
6449	Wilsleben	Sachsen-Anhalt	ST	Salz
6449	Westdorf	Sachsen-Anhalt	ST	Salz
6449	Groß Schierstedt	Sachsen-Anhalt	ST	Salz
6449	Aschersleben	Sachsen-Anhalt	ST	Salz
6449	Neu Königsaue	Sachsen-Anhalt	ST	Salz
6449	Friedrichsaue	Sachsen-Anhalt	ST	Salz
6449	Aschersleben Winningen	Sachsen-Anhalt	ST	Salz
6449	Giersleben	Sachsen-Anhalt	ST	Salz
6456	Mehringen	Sachsen-Anhalt	ST	Salz
6456	Drohndorf	Sachsen-Anhalt	ST	Salz
6456	Sandersleben	Sachsen-Anhalt	ST	Mansfeld-Südharz
6456	Freckleben	Sachsen-Anhalt	ST	Salz
6458	Wedderstedt	Sachsen-Anhalt	ST	Harz
6458	Hausneindorf	Sachsen-Anhalt	ST	Harz
6458	Heteborn	Sachsen-Anhalt	ST	Harz
6458	Hedersleben	Sachsen-Anhalt	ST	Harz
6463	Radisleben	Sachsen-Anhalt	ST	Harz
6463	Reinstedt	Sachsen-Anhalt	ST	Harz
6463	Ermsleben	Sachsen-Anhalt	ST	Harz
6463	Meisdorf	Sachsen-Anhalt	ST	Harz
6464	Frose	Sachsen-Anhalt	ST	Salz
6466	Gatersleben	Sachsen-Anhalt	ST	Salz
6467	Hoym	Sachsen-Anhalt	ST	Salz
6469	Nachterstedt	Sachsen-Anhalt	ST	Salz
6484	Westerhausen	Sachsen-Anhalt	ST	Harz
6484	Ditfurt	Sachsen-Anhalt	ST	Harz
6484	Quedlinburg	Sachsen-Anhalt	ST	Harz
6493	Straßberg	Sachsen-Anhalt	ST	Harz
6493	Harzgerode	Sachsen-Anhalt	ST	Harz
6493	Schielo	Sachsen-Anhalt	ST	Harz
6493	Königerode	Sachsen-Anhalt	ST	Harz
6493	Neudorf	Sachsen-Anhalt	ST	Harz
6493	Ballenstedt	Sachsen-Anhalt	ST	Harz
6493	Dankerode	Sachsen-Anhalt	ST	Harz
6502	Neinstedt	Sachsen-Anhalt	ST	Harz
6502	Weddersleben	Sachsen-Anhalt	ST	Harz
6502	Thale	Sachsen-Anhalt	ST	Harz
6502	Warnstedt	Sachsen-Anhalt	ST	Harz
6507	Güntersberge	Sachsen-Anhalt	ST	Harz
6507	Stecklenberg	Sachsen-Anhalt	ST	Harz
6507	Rieder	Sachsen-Anhalt	ST	Harz
6507	Timmenrode	Sachsen-Anhalt	ST	Harz
6507	Bad Suderode	Sachsen-Anhalt	ST	Harz
6507	Gernrode	Sachsen-Anhalt	ST	Harz
6507	Allrode	Sachsen-Anhalt	ST	Harz
6507	Siptenfelde	Sachsen-Anhalt	ST	Harz
6507	Friedrichsbrunn	Sachsen-Anhalt	ST	Harz
6526	Sangerhausen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6526	Wippra	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Holdenstedt	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Wallhausen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Oberröblingen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Morungen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Brücken	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Blankenheim	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Riestedt	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Sotterhausen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Breitenbach	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Riethnordhausen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Pölsfeld	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Drebsdorf	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Obersdorf	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Rotha	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Grillenberg	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Großleinungen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Beyernaumburg	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Hainrode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Emseloh	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Hackpfüffel	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Horla	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Martinsrieth	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Kleinleinungen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Liedersdorf	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Gonna	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Lengefeld	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Edersleben	Sachsen-Anhalt	ST	Mansfeld-Südharz
6528	Wettelrode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6536	Wolfsberg	Sachsen-Anhalt	ST	Mansfeld-Südharz
6536	Questenberg	Sachsen-Anhalt	ST	Mansfeld-Südharz
6536	Breitungen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6536	Dietersdorf	Sachsen-Anhalt	ST	Mansfeld-Südharz
6536	Berga	Sachsen-Anhalt	ST	Mansfeld-Südharz
6536	Wickerode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6536	Rottleberode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6536	Hayn	Sachsen-Anhalt	ST	Mansfeld-Südharz
6536	Bennungen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6536	Roßla	Sachsen-Anhalt	ST	Mansfeld-Südharz
6536	Uftrungen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6537	Tilleda	Sachsen-Anhalt	ST	Mansfeld-Südharz
6537	Kelbra	Sachsen-Anhalt	ST	Mansfeld-Südharz
6542	Niederröblingen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6542	Katharinenrieth	Sachsen-Anhalt	ST	Mansfeld-Südharz
6542	Wolferstedt	Sachsen-Anhalt	ST	Mansfeld-Südharz
6542	Allstedt	Sachsen-Anhalt	ST	Mansfeld-Südharz
6542	Winkel	Sachsen-Anhalt	ST	Mansfeld-Südharz
6542	Nienstedt	Sachsen-Anhalt	ST	Mansfeld-Südharz
6542	Mittelhausen	Sachsen-Anhalt	ST	Mansfeld-Südharz
6543	Friesdorf	Sachsen-Anhalt	ST	Mansfeld-Südharz
6543	Hermerode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6543	Wieserode	Sachsen-Anhalt	ST	Harz
6543	Molmerswende	Sachsen-Anhalt	ST	Mansfeld-Südharz
6543	Pansfelde	Sachsen-Anhalt	ST	Harz
6543	Alterode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6543	Abberode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6543	Ulzigerode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6543	Braunschwende	Sachsen-Anhalt	ST	Mansfeld-Südharz
6543	Ritzgerode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6543	Stangerode	Sachsen-Anhalt	ST	Mansfeld-Südharz
6547	Breitenstein	Sachsen-Anhalt	ST	Mansfeld-Südharz
6547	Schwenda	Sachsen-Anhalt	ST	Mansfeld-Südharz
6547	Stolberg (Harz)	Sachsen-Anhalt	ST	Mansfeld-Südharz
6618	Utenbach	Sachsen-Anhalt	ST	Burgen
6618	Leislau	Sachsen-Anhalt	ST	Burgen
6618	Löbitz	Sachsen-Anhalt	ST	Burgen
6618	Mertendorf	Sachsen-Anhalt	ST	Burgen
6618	Naumburg	Sachsen-Anhalt	ST	Burgen
6618	Casekirchen	Sachsen-Anhalt	ST	Burgen
6618	Janisroda	Sachsen-Anhalt	ST	Burgen
6618	Prießnitz	Sachsen-Anhalt	ST	Burgen
6618	Wethau	Sachsen-Anhalt	ST	Burgen
6618	Molau	Sachsen-Anhalt	ST	Burgen
6618	Pödelist	Sachsen-Anhalt	ST	Burgen
6618	Gieckau	Sachsen-Anhalt	ST	Burgen
6618	Görschen	Sachsen-Anhalt	ST	Burgen
6618	Schönburg	Sachsen-Anhalt	ST	Burgen
6628	Abtlöbnitz	Sachsen-Anhalt	ST	Burgen
6628	Möllern	Sachsen-Anhalt	ST	Burgen
6628	Bad Kösen	Sachsen-Anhalt	ST	Burgen
6628	Taugwitz Spielberg	Sachsen-Anhalt	ST	Burgen
6628	Crölpa-Löbschütz	Sachsen-Anhalt	ST	Burgen
6628	Taugwitz Taugwitz	Sachsen-Anhalt	ST	Burgen
6628	Taugwitz	Sachsen-Anhalt	ST	Burgen
6632	Branderoda	Sachsen-Anhalt	ST	Burgen
6632	Freyburg	Sachsen-Anhalt	ST	Burgen
6632	Ebersroda	Sachsen-Anhalt	ST	Burgen
6632	Größnitz	Sachsen-Anhalt	ST	Burgen
6632	Balgstädt	Sachsen-Anhalt	ST	Burgen
6632	Baumersroda	Sachsen-Anhalt	ST	Burgen
6632	Gröst	Sachsen-Anhalt	ST	Saalekreis
6632	Zeuchfeld	Sachsen-Anhalt	ST	Burgen
6632	Gleina	Sachsen-Anhalt	ST	Burgen
6632	Schleberoda	Sachsen-Anhalt	ST	Burgen
6636	Kirchscheidungen	Sachsen-Anhalt	ST	Burgen
6636	Burgscheidungen	Sachsen-Anhalt	ST	Burgen
6636	Golzen	Sachsen-Anhalt	ST	Burgen
6636	Laucha	Sachsen-Anhalt	ST	Burgen
6636	Hirschroda	Sachsen-Anhalt	ST	Burgen
6636	Weischütz	Sachsen-Anhalt	ST	Burgen
6638	Karsdorf	Sachsen-Anhalt	ST	Burgen
6642	Reinsdorf	Sachsen-Anhalt	ST	Burgen
6642	Nebra	Sachsen-Anhalt	ST	Burgen
6642	Altenroda	Sachsen-Anhalt	ST	Burgen
6642	Wohlmirstedt	Sachsen-Anhalt	ST	Burgen
6642	Bucha	Sachsen-Anhalt	ST	Burgen
6642	Wangen	Sachsen-Anhalt	ST	Burgen
6642	Memleben	Sachsen-Anhalt	ST	Burgen
6647	Burkersroda	Sachsen-Anhalt	ST	Burgen
6647	Saubach	Sachsen-Anhalt	ST	Burgen
6647	Billroda	Sachsen-Anhalt	ST	Burgen
6647	Steinburg	Sachsen-Anhalt	ST	Burgen
6647	Bad Bibra	Sachsen-Anhalt	ST	Burgen
6647	Wischroda	Sachsen-Anhalt	ST	Burgen
6647	Klosterhäseler	Sachsen-Anhalt	ST	Burgen
6647	Thalwinkel	Sachsen-Anhalt	ST	Burgen
6647	Kahlwinkel	Sachsen-Anhalt	ST	Burgen
6647	Lossa	Sachsen-Anhalt	ST	Burgen
6648	Burgholzhausen	Sachsen-Anhalt	ST	Burgen
6648	Tromsdorf	Sachsen-Anhalt	ST	Burgen
6648	Eckartsberga	Sachsen-Anhalt	ST	Burgen
6648	Herrengosserstedt	Sachsen-Anhalt	ST	Burgen
6667	Uichteritz	Sachsen-Anhalt	ST	Burgen
6667	Markwerben	Sachsen-Anhalt	ST	Burgen
6667	Goseck	Sachsen-Anhalt	ST	Burgen
6667	Langendorf	Sachsen-Anhalt	ST	Burgen
6667	Burgwerben	Sachsen-Anhalt	ST	Burgen
6667	Reichardtswerben	Sachsen-Anhalt	ST	Burgen
6667	Leißling	Sachsen-Anhalt	ST	Burgen
6667	Pretzsch	Sachsen-Anhalt	ST	Burgen
6667	Stößen	Sachsen-Anhalt	ST	Burgen
6667	Weißenfels	Sachsen-Anhalt	ST	Burgen
6667	Prittitz	Sachsen-Anhalt	ST	Burgen
6667	Gröbitz	Sachsen-Anhalt	ST	Burgen
6667	Storkau	Sachsen-Anhalt	ST	Burgen
6667	Tagewerben	Sachsen-Anhalt	ST	Burgen
6679	Taucha	Sachsen-Anhalt	ST	Burgen
6679	Muschwitz	Sachsen-Anhalt	ST	Burgen
6679	Webau	Sachsen-Anhalt	ST	Burgen
6679	Hohenmölsen	Sachsen-Anhalt	ST	Burgen
6679	Zorbau	Sachsen-Anhalt	ST	Burgen
6679	Granschütz	Sachsen-Anhalt	ST	Burgen
6682	Schelkau	Sachsen-Anhalt	ST	Burgen
6682	Krauschwitz	Sachsen-Anhalt	ST	Burgen
6682	Deuben	Sachsen-Anhalt	ST	Burgen
6682	Gröben	Sachsen-Anhalt	ST	Burgen
6682	Trebnitz	Sachsen-Anhalt	ST	Burgen
6682	Teuchern	Sachsen-Anhalt	ST	Burgen
6682	Nessa	Sachsen-Anhalt	ST	Burgen
6682	Werschen	Sachsen-Anhalt	ST	Burgen
6686	Dehlitz	Sachsen-Anhalt	ST	Burgen
6686	Großgörschen	Sachsen-Anhalt	ST	Burgen
6686	Rippach	Sachsen-Anhalt	ST	Burgen
6686	Lützen	Sachsen-Anhalt	ST	Burgen
6686	Röcken	Sachsen-Anhalt	ST	Burgen
6686	Starsiedel	Sachsen-Anhalt	ST	Burgen
6686	Sössen	Sachsen-Anhalt	ST	Burgen
6686	Poserna	Sachsen-Anhalt	ST	Burgen
6688	Großkorbetha	Sachsen-Anhalt	ST	Burgen
6688	Wengelsdorf	Sachsen-Anhalt	ST	Burgen
6688	Schkortleben	Sachsen-Anhalt	ST	Burgen
6712	Grana	Sachsen-Anhalt	ST	Burgen
6712	Kretzschau	Sachsen-Anhalt	ST	Burgen
6712	Geußnitz	Sachsen-Anhalt	ST	Burgen
6712	Breitenbach	Sachsen-Anhalt	ST	Burgen
6712	Würchwitz	Sachsen-Anhalt	ST	Burgen
6712	Draschwitz	Sachsen-Anhalt	ST	Burgen
6712	Droßdorf	Sachsen-Anhalt	ST	Burgen
6712	Haynsburg	Sachsen-Anhalt	ST	Burgen
6712	Könderitz	Sachsen-Anhalt	ST	Burgen
6712	Bornitz	Sachsen-Anhalt	ST	Burgen
6712	Göbitz	Sachsen-Anhalt	ST	Burgen
6712	Schellbach	Sachsen-Anhalt	ST	Burgen
6712	Bergisdorf	Sachsen-Anhalt	ST	Burgen
6712	Heuckewalde	Sachsen-Anhalt	ST	Burgen
6712	Zeitz	Sachsen-Anhalt	ST	Burgen
6712	Wittgendorf	Sachsen-Anhalt	ST	Burgen
6712	Döschwitz	Sachsen-Anhalt	ST	Burgen
6721	Osterfeld	Sachsen-Anhalt	ST	Burgen
6721	Goldschau	Sachsen-Anhalt	ST	Burgen
6721	Unterkaka	Sachsen-Anhalt	ST	Burgen
6721	Meineweh	Sachsen-Anhalt	ST	Burgen
6721	Waldau	Sachsen-Anhalt	ST	Burgen
6722	Weickelsdorf	Sachsen-Anhalt	ST	Burgen
6722	Wetterzeube	Sachsen-Anhalt	ST	Burgen
6722	Kleinhelmsdorf	Sachsen-Anhalt	ST	Burgen
6722	Droyßig	Sachsen-Anhalt	ST	Burgen
6724	Bröckau	Sachsen-Anhalt	ST	Burgen
6724	Spora	Sachsen-Anhalt	ST	Burgen
6724	Kayna	Sachsen-Anhalt	ST	Burgen
6724	Weißenborn	Sachsen-Anhalt	ST	Burgen
6725	Reuden	Sachsen-Anhalt	ST	Burgen
6725	Profen	Sachsen-Anhalt	ST	Burgen
6727	Nonnewitz	Sachsen-Anhalt	ST	Burgen
6727	Theißen	Sachsen-Anhalt	ST	Burgen
6727	Luckenau	Sachsen-Anhalt	ST	Burgen
6727	Döbris	Sachsen-Anhalt	ST	Burgen
6729	Rehmsdorf	Sachsen-Anhalt	ST	Burgen
6729	Tröglitz	Sachsen-Anhalt	ST	Burgen
6729	Langendorf	Sachsen-Anhalt	ST	Burgen
6731	Bitterfeld-Wolfen	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6749	Friedersdorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6749	Bitterfeld	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6766	Bobbau	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6766	Wolfen	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6766	Thalheim	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6766	Rödgen	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6773	Gräfenhainichen	Sachsen-Anhalt	ST	Wittenberg
6773	Rotta	Sachsen-Anhalt	ST	Wittenberg
6773	Kemberg Klitzschena	Sachsen-Anhalt	ST	Wittenberg
6773	Schköna	Sachsen-Anhalt	ST	Wittenberg
6773	Kemberg Bergwitz	Sachsen-Anhalt	ST	Wittenberg
6773	Jüdenberg	Sachsen-Anhalt	ST	Wittenberg
6773	Kemberg	Sachsen-Anhalt	ST	Wittenberg
6773	Radis	Sachsen-Anhalt	ST	Wittenberg
6773	Gossa	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6773	Selbitz	Sachsen-Anhalt	ST	Wittenberg
6773	Gröbern	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6773	Uthausen	Sachsen-Anhalt	ST	Wittenberg
6774	Schlaitz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6774	Mühlbeck	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6774	Pouch	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6774	Krina	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6774	Söllichau	Sachsen-Anhalt	ST	Wittenberg
6774	Rösa	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6774	Tornau	Sachsen-Anhalt	ST	Wittenberg
6774	Plodda	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6774	Schwemsal	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6779	Tornau	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6779	Marke	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6779	Raguhn	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6779	Schierau	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6779	Thurland	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6779	Retzau	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6779	Salzfurtkapelle	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6780	Stumsdorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6780	Quetzdölsdorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6780	Göttnitz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6780	Großzöberitz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6780	Löberitz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6780	Sandersdorf Heideloh	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6780	Spören	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6780	Schrenz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6780	Zörbig	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6780	Sandersdorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6785	Schleesen	Sachsen-Anhalt	ST	Wittenberg
6785	Kakau	Sachsen-Anhalt	ST	Wittenberg
6785	Oranienbaum	Sachsen-Anhalt	ST	Wittenberg
6785	Brandhorst	Sachsen-Anhalt	ST	Wittenberg
6785	Horstdorf	Sachsen-Anhalt	ST	Wittenberg
6786	Gohrau	Sachsen-Anhalt	ST	Wittenberg
6786	Riesigk	Sachsen-Anhalt	ST	Wittenberg
6786	Griesen	Sachsen-Anhalt	ST	Wittenberg
6786	Vockerode	Sachsen-Anhalt	ST	Wittenberg
6786	Wörlitz	Sachsen-Anhalt	ST	Wittenberg
6786	Rehsen	Sachsen-Anhalt	ST	Wittenberg
6791	Zschornewitz	Sachsen-Anhalt	ST	Wittenberg
6791	Möhlau	Sachsen-Anhalt	ST	Wittenberg
6792	Sandersdorf Sandersdorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6792	Sandersdorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6794	Sandersdorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6794	Glebitzsch	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6794	Sandersdorf Renneritz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6794	Sandersdorf Ramsin	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6794	Sandersdorf Zscherndorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6796	Brehna	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6800	Altjeßnitz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6800	Jeßnitz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6803	Greppin	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6804	Muldenstein	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6804	Burgkemnitz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6808	Holzweißig	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
12559	Berlin	Berlin	BE	Berlin; Stadt
6809	Roitzsch	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6809	Petersroda	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
6842	Dessau	Sachsen-Anhalt	ST	Dessau-Roßlau
6844	Dessau	Sachsen-Anhalt	ST	Dessau-Roßlau
6846	Dessau	Sachsen-Anhalt	ST	Dessau-Roßlau
6847	Dessau	Sachsen-Anhalt	ST	Dessau-Roßlau
6849	Dessau	Sachsen-Anhalt	ST	Dessau-Roßlau
6861	Dessau-Roßlau	Sachsen-Anhalt	ST	Dessau-Roßlau
6862	Rodleben	Sachsen-Anhalt	ST	Dessau-Roßlau
6862	Brambach	Sachsen-Anhalt	ST	Dessau-Roßlau
6862	Roßlau	Sachsen-Anhalt	ST	Dessau-Roßlau
6868	Jeber-Bergfrieden	Sachsen-Anhalt	ST	Wittenberg
6868	Ragösen	Sachsen-Anhalt	ST	Wittenberg
6868	Stackelitz	Sachsen-Anhalt	ST	Wittenberg
6868	Hundeluft	Sachsen-Anhalt	ST	Wittenberg
6868	Bräsen	Sachsen-Anhalt	ST	Wittenberg
6868	Serno	Sachsen-Anhalt	ST	Wittenberg
6868	Thießen	Sachsen-Anhalt	ST	Wittenberg
6869	Griebo	Sachsen-Anhalt	ST	Wittenberg
6869	Buko	Sachsen-Anhalt	ST	Wittenberg
6869	Coswig	Sachsen-Anhalt	ST	Wittenberg
6869	Klieken	Sachsen-Anhalt	ST	Wittenberg
6869	Wörpen	Sachsen-Anhalt	ST	Wittenberg
6869	Cobbelsdorf	Sachsen-Anhalt	ST	Wittenberg
6869	Zieko	Sachsen-Anhalt	ST	Wittenberg
6869	Düben	Sachsen-Anhalt	ST	Wittenberg
6869	Möllensdorf	Sachsen-Anhalt	ST	Wittenberg
6869	Senst	Sachsen-Anhalt	ST	Wittenberg
6869	Köselitz	Sachsen-Anhalt	ST	Wittenberg
6886	Lutherstadt Wittenberg	Sachsen-Anhalt	ST	Wittenberg
6888	Zörnigall	Sachsen-Anhalt	ST	Wittenberg
6888	Dietrichsdorf	Sachsen-Anhalt	ST	Wittenberg
6888	Mochau	Sachsen-Anhalt	ST	Wittenberg
6888	Abtsdorf	Sachsen-Anhalt	ST	Wittenberg
6888	Dabrun	Sachsen-Anhalt	ST	Wittenberg
6888	Mühlanger	Sachsen-Anhalt	ST	Wittenberg
6888	Eutzsch	Sachsen-Anhalt	ST	Wittenberg
6889	Lutherstadt Wittenberg	Sachsen-Anhalt	ST	Wittenberg
6895	Boßdorf	Sachsen-Anhalt	ST	Wittenberg
6895	Zahna	Sachsen-Anhalt	ST	Wittenberg
6895	Kropstädt	Sachsen-Anhalt	ST	Wittenberg
6895	Rahnsdorf	Sachsen-Anhalt	ST	Wittenberg
6895	Bülzig	Sachsen-Anhalt	ST	Wittenberg
6895	Leetza	Sachsen-Anhalt	ST	Wittenberg
6896	Straach	Sachsen-Anhalt	ST	Wittenberg
6896	Schmilkendorf	Sachsen-Anhalt	ST	Wittenberg
6896	Nudersdorf	Sachsen-Anhalt	ST	Wittenberg
6901	Schnellin	Sachsen-Anhalt	ST	Wittenberg
6901	Dorna	Sachsen-Anhalt	ST	Wittenberg
6901	Rackith	Sachsen-Anhalt	ST	Wittenberg
6901	Kemberg	Sachsen-Anhalt	ST	Wittenberg
6901	Wartenburg	Sachsen-Anhalt	ST	Wittenberg
6901	Globig-Bleddin	Sachsen-Anhalt	ST	Wittenberg
6901	Kemberg Kemberg	Sachsen-Anhalt	ST	Wittenberg
6901	Ateritz	Sachsen-Anhalt	ST	Wittenberg
6905	Korgau	Sachsen-Anhalt	ST	Wittenberg
6905	Bad Schmiedeberg	Sachsen-Anhalt	ST	Wittenberg
6905	Meuro	Sachsen-Anhalt	ST	Wittenberg
6909	Trebitz	Sachsen-Anhalt	ST	Wittenberg
6909	Pretzsch/Elbe	Sachsen-Anhalt	ST	Wittenberg
6909	Priesitz	Sachsen-Anhalt	ST	Wittenberg
6917	Klöden	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Morxdorf	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Buschkuhnsdorf	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Kleinkorga	Sachsen-Anhalt	ST	Wittenberg
6917	Schützberg	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Lindwerder	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Großkorga	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Neuerstadt	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Linda	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Schweinitz	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Mönchenhöfe	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Mellnitz	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Battin	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Ruhlsdorf	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Lüttchenseyda	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Reicho	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Kremitz	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Klossa	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Düßnitz	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Grabo	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Jessen (Elster)	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Mark Zwuschen	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Mügeln	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Leipa	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Gerbisbach	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Schöneicho	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Steinsdorf	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster)	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Gentha	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Gorsdorf-Hemsendorf	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Kleindröben	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Rade	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Arnsdorf	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Dixförda	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Holzdorf	Sachsen-Anhalt	ST	Wittenberg
6917	Jessen (Elster) Schadewalde	Sachsen-Anhalt	ST	Wittenberg
6918	Elster/Elbe	Sachsen-Anhalt	ST	Wittenberg
6918	Gentha	Sachsen-Anhalt	ST	Wittenberg
6918	Zemnick	Sachsen-Anhalt	ST	Wittenberg
6918	Naundorf bei Seyda	Sachsen-Anhalt	ST	Wittenberg
6918	Mellnitz	Sachsen-Anhalt	ST	Wittenberg
6918	Gadegast	Sachsen-Anhalt	ST	Wittenberg
6918	Listerfehrda	Sachsen-Anhalt	ST	Wittenberg
6918	Jessen (Elster) Seyda	Sachsen-Anhalt	ST	Wittenberg
6918	Morxdorf	Sachsen-Anhalt	ST	Wittenberg
6922	Axien	Sachsen-Anhalt	ST	Wittenberg
6922	Plossig	Sachsen-Anhalt	ST	Wittenberg
6922	Labrun	Sachsen-Anhalt	ST	Wittenberg
6922	Prettin	Sachsen-Anhalt	ST	Wittenberg
6922	Lebien	Sachsen-Anhalt	ST	Wittenberg
6925	Purzien	Sachsen-Anhalt	ST	Wittenberg
6925	Bethau	Sachsen-Anhalt	ST	Wittenberg
6925	Groß Naundorf	Sachsen-Anhalt	ST	Wittenberg
6925	Annaburg	Sachsen-Anhalt	ST	Wittenberg
6925	Löben	Sachsen-Anhalt	ST	Wittenberg
6926	Kleinkorga	Sachsen-Anhalt	ST	Wittenberg
6926	Buschkuhnsdorf	Sachsen-Anhalt	ST	Wittenberg
6926	Neuerstadt	Sachsen-Anhalt	ST	Wittenberg
6926	Premsendorf	Sachsen-Anhalt	ST	Wittenberg
6926	Holzdorf	Sachsen-Anhalt	ST	Wittenberg
6926	Mönchenhöfe	Sachsen-Anhalt	ST	Wittenberg
6926	Reicho	Sachsen-Anhalt	ST	Wittenberg
6928	Linda (Elster)	Sachsen-Anhalt	ST	Wittenberg
14715	Schollene	Sachsen-Anhalt	ST	Stendal
29410	Chüden	Sachsen-Anhalt	ST	AltmarkSalzwedel
29410	Salzwedel	Sachsen-Anhalt	ST	AltmarkSalzwedel
29413	Tylsen	Sachsen-Anhalt	ST	AltmarkSalzwedel
29413	Lagendorf	Sachsen-Anhalt	ST	AltmarkSalzwedel
29413	Ellenberg	Sachsen-Anhalt	ST	AltmarkSalzwedel
29413	Wallstawe	Sachsen-Anhalt	ST	AltmarkSalzwedel
29413	Henningen	Sachsen-Anhalt	ST	AltmarkSalzwedel
29413	Bornsen	Sachsen-Anhalt	ST	AltmarkSalzwedel
29413	Langenapel	Sachsen-Anhalt	ST	AltmarkSalzwedel
29413	Osterwohle	Sachsen-Anhalt	ST	AltmarkSalzwedel
29413	Dähre	Sachsen-Anhalt	ST	AltmarkSalzwedel
29413	Gieseritz	Sachsen-Anhalt	ST	AltmarkSalzwedel
29413	Flecken Diesdorf	Sachsen-Anhalt	ST	AltmarkSalzwedel
29413	Neuekrug	Sachsen-Anhalt	ST	AltmarkSalzwedel
29413	Mehmke	Sachsen-Anhalt	ST	AltmarkSalzwedel
29413	Bonese	Sachsen-Anhalt	ST	AltmarkSalzwedel
29413	Seebenau	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Beetzendorf Gischau	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Kerkau	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Altensalzwedel	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Pretzier	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Kaulitz	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Bierstedt	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Chüden	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Kuhfelde	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Liesten	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Klein Gartz	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Binde	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Jeggeleben	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Fleetmark	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Steinitz	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Wieblitz-Eversdorf	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Siedenlangenbeck	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Püggen	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Winterfeld	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Mechau	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Valfitz	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Riebau	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Rademin	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Benkendorf	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Vissum	Sachsen-Anhalt	ST	AltmarkSalzwedel
29416	Salzwedel Stappenbeck	Sachsen-Anhalt	ST	AltmarkSalzwedel
38486	Kusey	Sachsen-Anhalt	ST	AltmarkSalzwedel
38486	Klötze	Sachsen-Anhalt	ST	AltmarkSalzwedel
38486	Neuferchau	Sachsen-Anhalt	ST	AltmarkSalzwedel
38486	Kunrau	Sachsen-Anhalt	ST	AltmarkSalzwedel
38486	Steimke	Sachsen-Anhalt	ST	AltmarkSalzwedel
38486	Ristedt	Sachsen-Anhalt	ST	AltmarkSalzwedel
38486	Bandau	Sachsen-Anhalt	ST	AltmarkSalzwedel
38486	Jahrstedt	Sachsen-Anhalt	ST	AltmarkSalzwedel
38486	Flecken Apenburg	Sachsen-Anhalt	ST	AltmarkSalzwedel
38486	Neuendorf	Sachsen-Anhalt	ST	AltmarkSalzwedel
38486	Wenze	Sachsen-Anhalt	ST	AltmarkSalzwedel
38486	Dönitz	Sachsen-Anhalt	ST	AltmarkSalzwedel
38486	Immekath	Sachsen-Anhalt	ST	AltmarkSalzwedel
38489	Hohentramm	Sachsen-Anhalt	ST	AltmarkSalzwedel
38489	Jübar	Sachsen-Anhalt	ST	AltmarkSalzwedel
38489	Nettgau	Sachsen-Anhalt	ST	AltmarkSalzwedel
38489	Jeeben	Sachsen-Anhalt	ST	AltmarkSalzwedel
38489	Tangeln	Sachsen-Anhalt	ST	AltmarkSalzwedel
38489	Rohrberg	Sachsen-Anhalt	ST	AltmarkSalzwedel
38489	Ahlum	Sachsen-Anhalt	ST	AltmarkSalzwedel
38489	Hanum	Sachsen-Anhalt	ST	AltmarkSalzwedel
38489	Lüdelsen	Sachsen-Anhalt	ST	AltmarkSalzwedel
38489	Mellin	Sachsen-Anhalt	ST	AltmarkSalzwedel
38489	Beetzendorf	Sachsen-Anhalt	ST	AltmarkSalzwedel
38820	Halberstadt	Sachsen-Anhalt	ST	Harz
38822	Athenstedt	Sachsen-Anhalt	ST	Harz
38822	Aspenstedt	Sachsen-Anhalt	ST	Harz
38822	Sargstedt	Sachsen-Anhalt	ST	Harz
38822	Ströbeck	Sachsen-Anhalt	ST	Harz
38822	Groß Quenstedt	Sachsen-Anhalt	ST	Harz
38828	Wegeleben	Sachsen-Anhalt	ST	Harz
38829	Harsleben	Sachsen-Anhalt	ST	Harz
38835	Wülperode	Sachsen-Anhalt	ST	Harz
38835	Osterode	Sachsen-Anhalt	ST	Harz
38835	Bühne	Sachsen-Anhalt	ST	Harz
38835	Schauen	Sachsen-Anhalt	ST	Harz
38835	Veltheim	Sachsen-Anhalt	ST	Harz
38835	Rhoden	Sachsen-Anhalt	ST	Harz
38835	Zilly	Sachsen-Anhalt	ST	Harz
38835	Osterwieck	Sachsen-Anhalt	ST	Harz
38835	Berßel	Sachsen-Anhalt	ST	Harz
38835	Deersheim	Sachsen-Anhalt	ST	Harz
38835	Hessen	Sachsen-Anhalt	ST	Harz
38835	Lüttgenrode	Sachsen-Anhalt	ST	Harz
38836	Rohrsheim	Sachsen-Anhalt	ST	Harz
38836	Dardesheim	Sachsen-Anhalt	ST	Harz
38836	Pabstorf	Sachsen-Anhalt	ST	Harz
38836	Badersleben	Sachsen-Anhalt	ST	Harz
38836	Huy-Neinstedt	Sachsen-Anhalt	ST	Harz
38836	Anderbeck	Sachsen-Anhalt	ST	Harz
38836	Vogelsdorf	Sachsen-Anhalt	ST	Harz
38836	Dedeleben	Sachsen-Anhalt	ST	Harz
38838	Aderstedt	Sachsen-Anhalt	ST	Harz
38838	Schlanstedt	Sachsen-Anhalt	ST	Harz
38838	Eilenstedt	Sachsen-Anhalt	ST	Harz
38838	Eilsdorf	Sachsen-Anhalt	ST	Harz
38838	Dingelstedt	Sachsen-Anhalt	ST	Harz
38855	Reddeber	Sachsen-Anhalt	ST	Harz
38855	Heudeber	Sachsen-Anhalt	ST	Harz
38855	Wernigerode	Sachsen-Anhalt	ST	Harz
38855	Schmatzfeld	Sachsen-Anhalt	ST	Harz
38855	Danstedt	Sachsen-Anhalt	ST	Harz
38871	Drübeck	Sachsen-Anhalt	ST	Harz
38871	Stapelburg	Sachsen-Anhalt	ST	Harz
38871	Langeln	Sachsen-Anhalt	ST	Harz
38871	Darlingerode	Sachsen-Anhalt	ST	Harz
38871	Veckenstedt	Sachsen-Anhalt	ST	Harz
38871	Wasserleben	Sachsen-Anhalt	ST	Harz
38871	Abbenrode	Sachsen-Anhalt	ST	Harz
38871	Ilsenburg	Sachsen-Anhalt	ST	Harz
38875	Sorge	Sachsen-Anhalt	ST	Harz
38875	Tanne	Sachsen-Anhalt	ST	Harz
38875	Königshütte	Sachsen-Anhalt	ST	Harz
38875	Elend	Sachsen-Anhalt	ST	Harz
38875	Elbingerode	Sachsen-Anhalt	ST	Harz
38877	Benneckenstein	Sachsen-Anhalt	ST	Harz
38879	Schierke	Sachsen-Anhalt	ST	Harz
38889	Hüttenrode	Sachsen-Anhalt	ST	Harz
38889	Wienrode	Sachsen-Anhalt	ST	Harz
38889	Heimburg	Sachsen-Anhalt	ST	Harz
38889	Rübeland	Sachsen-Anhalt	ST	Harz
38889	Altenbrak	Sachsen-Anhalt	ST	Harz
38889	Treseburg	Sachsen-Anhalt	ST	Harz
38889	Cattenstedt	Sachsen-Anhalt	ST	Harz
38889	Blankenburg	Sachsen-Anhalt	ST	Harz
38895	Langenstein	Sachsen-Anhalt	ST	Harz
38895	Derenburg	Sachsen-Anhalt	ST	Harz
38899	Hasselfelde	Sachsen-Anhalt	ST	Harz
38899	Trautenstein	Sachsen-Anhalt	ST	Harz
38899	Stiege	Sachsen-Anhalt	ST	Harz
39014	Magdeburg	Sachsen-Anhalt	ST	Magdeburg
39104	Magdeburg	Sachsen-Anhalt	ST	Magdeburg
39106	Magdeburg	Sachsen-Anhalt	ST	Magdeburg
39108	Magdeburg	Sachsen-Anhalt	ST	Magdeburg
39110	Magdeburg	Sachsen-Anhalt	ST	Magdeburg
39112	Magdeburg	Sachsen-Anhalt	ST	Magdeburg
39114	Magdeburg	Sachsen-Anhalt	ST	Magdeburg
39116	Magdeburg	Sachsen-Anhalt	ST	Magdeburg
39118	Magdeburg	Sachsen-Anhalt	ST	Magdeburg
39120	Magdeburg	Sachsen-Anhalt	ST	Magdeburg
39122	Magdeburg	Sachsen-Anhalt	ST	Magdeburg
39124	Magdeburg	Sachsen-Anhalt	ST	Magdeburg
39126	Magdeburg	Sachsen-Anhalt	ST	Magdeburg
39128	Magdeburg	Sachsen-Anhalt	ST	Magdeburg
39130	Magdeburg	Sachsen-Anhalt	ST	Magdeburg
39164	Bottmersdorf	Sachsen-Anhalt	ST	Börde
39164	Domersleben	Sachsen-Anhalt	ST	Börde
39164	Wanzleben	Sachsen-Anhalt	ST	Börde
39164	Klein Wanzleben	Sachsen-Anhalt	ST	Börde
39167	Ochtmersleben	Sachsen-Anhalt	ST	Börde
39167	Groß Rodensleben	Sachsen-Anhalt	ST	Börde
39167	Niederndodeleben	Sachsen-Anhalt	ST	Börde
39167	Irxleben	Sachsen-Anhalt	ST	Börde
39167	Klein Rodensleben	Sachsen-Anhalt	ST	Börde
39167	Hohendodeleben	Sachsen-Anhalt	ST	Börde
39167	Eichenbarleben	Sachsen-Anhalt	ST	Börde
39167	Wellen	Sachsen-Anhalt	ST	Börde
39171	Sülzetal	Sachsen-Anhalt	ST	Börde
39175	Gerwisch	Sachsen-Anhalt	ST	Jerichower Land
39175	Gübs	Sachsen-Anhalt	ST	Jerichower Land
39175	Biederitz	Sachsen-Anhalt	ST	Jerichower Land
39175	Menz	Sachsen-Anhalt	ST	Jerichower Land
39175	Königsborn	Sachsen-Anhalt	ST	Jerichower Land
39175	Körbelitz	Sachsen-Anhalt	ST	Jerichower Land
39175	Woltersdorf	Sachsen-Anhalt	ST	Jerichower Land
39175	Wahlitz	Sachsen-Anhalt	ST	Jerichower Land
39179	Barleben Ebendorf	Sachsen-Anhalt	ST	Börde
39179	Barleben Barleben	Sachsen-Anhalt	ST	Börde
39179	Barleben	Sachsen-Anhalt	ST	Börde
39217	Schönebeck (Elbe)	Sachsen-Anhalt	ST	Salz
39218	Schönebeck (Elbe)	Sachsen-Anhalt	ST	Salz
39221	Eickendorf	Sachsen-Anhalt	ST	Salz
39221	Welsleben	Sachsen-Anhalt	ST	Salz
39221	Eggersdorf	Sachsen-Anhalt	ST	Salz
39221	Biere	Sachsen-Anhalt	ST	Salz
39221	Ranies	Sachsen-Anhalt	ST	Salz
39221	Zens	Sachsen-Anhalt	ST	Salz
39221	Kleinmühlingen	Sachsen-Anhalt	ST	Salz
39221	Großmühlingen	Sachsen-Anhalt	ST	Salz
39240	Groß Rosenburg	Sachsen-Anhalt	ST	Salz
39240	Calbe	Sachsen-Anhalt	ST	Salz
39240	Sachsendorf	Sachsen-Anhalt	ST	Salz
39240	Glöthe	Sachsen-Anhalt	ST	Salz
39240	Brumby	Sachsen-Anhalt	ST	Salz
39240	Zuchau	Sachsen-Anhalt	ST	Salz
39240	Breitenhagen	Sachsen-Anhalt	ST	Salz
39240	Lödderitz	Sachsen-Anhalt	ST	Salz
39245	Gommern	Sachsen-Anhalt	ST	Jerichower Land
39245	Pretzien	Sachsen-Anhalt	ST	Salz
39245	Dannigkow	Sachsen-Anhalt	ST	Jerichower Land
39245	Plötzky	Sachsen-Anhalt	ST	Salz
39249	Barby	Sachsen-Anhalt	ST	Salz
39249	Gnadau	Sachsen-Anhalt	ST	Salz
39249	Wespen	Sachsen-Anhalt	ST	Salz
39249	Tornitz	Sachsen-Anhalt	ST	Salz
39249	Pömmelte	Sachsen-Anhalt	ST	Salz
39249	Glinde	Sachsen-Anhalt	ST	Salz
39261	Zerbst	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Prödel	Sachsen-Anhalt	ST	Jerichower Land
39264	Reuden	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Bias	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Leps	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Polenzko	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Luso	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Nutha	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Jütrichau	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Gödnitz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Moritz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Grimme	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Dornburg	Sachsen-Anhalt	ST	Jerichower Land
39264	Dobritz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Güterglück	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Straguth	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Bornum	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Walternienburg	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Lübs	Sachsen-Anhalt	ST	Jerichower Land
39264	Lindau	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Zernitz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Hohenlepte	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Buhlendorf	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Deetz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Gehrden	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Nedlitz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39264	Steutz	Sachsen-Anhalt	ST	Anhalt-Bitterfeld
39279	Hobeck	Sachsen-Anhalt	ST	Jerichower Land
39279	Zeppernick	Sachsen-Anhalt	ST	Jerichower Land
39279	Rosian	Sachsen-Anhalt	ST	Jerichower Land
39279	Leitzkau	Sachsen-Anhalt	ST	Jerichower Land
39279	Schweinitz	Sachsen-Anhalt	ST	Jerichower Land
39279	Ladeburg	Sachsen-Anhalt	ST	Jerichower Land
39279	Loburg	Sachsen-Anhalt	ST	Jerichower Land
39288	Burg	Sachsen-Anhalt	ST	Jerichower Land
39291	Rietzel	Sachsen-Anhalt	ST	Jerichower Land
39291	Detershagen	Sachsen-Anhalt	ST	Jerichower Land
39291	Friedensau	Sachsen-Anhalt	ST	Jerichower Land
39291	Theeßen	Sachsen-Anhalt	ST	Jerichower Land
39291	Schartau	Sachsen-Anhalt	ST	Jerichower Land
39291	Stresow	Sachsen-Anhalt	ST	Jerichower Land
39291	Möser	Sachsen-Anhalt	ST	Jerichower Land
39291	Lübars	Sachsen-Anhalt	ST	Jerichower Land
39291	Krüssau	Sachsen-Anhalt	ST	Jerichower Land
39291	Hohenwarthe	Sachsen-Anhalt	ST	Jerichower Land
39291	Wüstenjerichow	Sachsen-Anhalt	ST	Jerichower Land
39291	Reesen	Sachsen-Anhalt	ST	Jerichower Land
39291	Magdeburgerforth	Sachsen-Anhalt	ST	Jerichower Land
39291	Ziepel	Sachsen-Anhalt	ST	Jerichower Land
39291	Stegelitz	Sachsen-Anhalt	ST	Jerichower Land
39291	Büden	Sachsen-Anhalt	ST	Jerichower Land
39291	Schermen	Sachsen-Anhalt	ST	Jerichower Land
39291	Lostau	Sachsen-Anhalt	ST	Jerichower Land
39291	Niegripp	Sachsen-Anhalt	ST	Jerichower Land
39291	Parchau	Sachsen-Anhalt	ST	Jerichower Land
39291	Dörnitz	Sachsen-Anhalt	ST	Jerichower Land
39291	Pietzpuhl	Sachsen-Anhalt	ST	Jerichower Land
39291	Zeddenick	Sachsen-Anhalt	ST	Jerichower Land
39291	Vehlitz	Sachsen-Anhalt	ST	Jerichower Land
39291	Möckern	Sachsen-Anhalt	ST	Jerichower Land
39291	Grabow	Sachsen-Anhalt	ST	Jerichower Land
39291	Tryppehna	Sachsen-Anhalt	ST	Jerichower Land
39291	Karith	Sachsen-Anhalt	ST	Jerichower Land
39291	Ihleburg	Sachsen-Anhalt	ST	Jerichower Land
39291	Wallwitz	Sachsen-Anhalt	ST	Jerichower Land
39291	Drewitz	Sachsen-Anhalt	ST	Jerichower Land
39291	Wörmlitz	Sachsen-Anhalt	ST	Jerichower Land
39291	Reesdorf	Sachsen-Anhalt	ST	Jerichower Land
39291	Schopsdorf	Sachsen-Anhalt	ST	Jerichower Land
39291	Küsel	Sachsen-Anhalt	ST	Jerichower Land
39291	Nedlitz	Sachsen-Anhalt	ST	Jerichower Land
39291	Hohenziatz	Sachsen-Anhalt	ST	Jerichower Land
39307	Klitsche	Sachsen-Anhalt	ST	Jerichower Land
39307	Parchen	Sachsen-Anhalt	ST	Jerichower Land
39307	Brettin	Sachsen-Anhalt	ST	Jerichower Land
39307	Mützel	Sachsen-Anhalt	ST	Jerichower Land
39307	Genthin	Sachsen-Anhalt	ST	Jerichower Land
39307	Tucheim	Sachsen-Anhalt	ST	Jerichower Land
39307	Paplitz	Sachsen-Anhalt	ST	Jerichower Land
39307	Kade	Sachsen-Anhalt	ST	Jerichower Land
39307	Schlagenthin	Sachsen-Anhalt	ST	Jerichower Land
39307	Zabakuck	Sachsen-Anhalt	ST	Jerichower Land
39307	Karow	Sachsen-Anhalt	ST	Jerichower Land
39307	Elbe-Parey	Sachsen-Anhalt	ST	Jerichower Land
39307	Roßdorf	Sachsen-Anhalt	ST	Jerichower Land
39307	Gladau	Sachsen-Anhalt	ST	Jerichower Land
39307	Demsin	Sachsen-Anhalt	ST	Jerichower Land
39317	Elbe-Parey	Sachsen-Anhalt	ST	Jerichower Land
39319	Redekin	Sachsen-Anhalt	ST	Jerichower Land
39319	Wulkow	Sachsen-Anhalt	ST	Jerichower Land
39319	Jerichow	Sachsen-Anhalt	ST	Jerichower Land
39319	Nielebock	Sachsen-Anhalt	ST	Jerichower Land
39326	Klein Ammensleben	Sachsen-Anhalt	ST	Börde
39326	Samswegen	Sachsen-Anhalt	ST	Börde
39326	Groß Ammensleben	Sachsen-Anhalt	ST	Börde
39326	Glindenberg	Sachsen-Anhalt	ST	Börde
39326	Loitsche	Sachsen-Anhalt	ST	Börde
39326	Colbitz	Sachsen-Anhalt	ST	Börde
39326	Barleben Meitzendorf	Sachsen-Anhalt	ST	Börde
39326	Wolmirstedt	Sachsen-Anhalt	ST	Börde
39326	Rogätz	Sachsen-Anhalt	ST	Börde
39326	Hohenwarsleben	Sachsen-Anhalt	ST	Börde
39326	Dahlenwarsleben	Sachsen-Anhalt	ST	Börde
39326	Jersleben	Sachsen-Anhalt	ST	Börde
39326	Zielitz	Sachsen-Anhalt	ST	Börde
39326	Angern	Sachsen-Anhalt	ST	Börde
39326	Gutenswegen	Sachsen-Anhalt	ST	Börde
39326	Barleben	Sachsen-Anhalt	ST	Börde
39326	Hermsdorf	Sachsen-Anhalt	ST	Börde
39326	Heinrichsberg	Sachsen-Anhalt	ST	Börde
39326	Farsleben	Sachsen-Anhalt	ST	Börde
39326	Meseberg	Sachsen-Anhalt	ST	Börde
39340	Haldensleben	Sachsen-Anhalt	ST	Börde
39343	Alleringersleben	Sachsen-Anhalt	ST	Börde
39343	Süplingen	Sachsen-Anhalt	ST	Börde
39343	Nordgermersleben	Sachsen-Anhalt	ST	Börde
39343	Altenhausen	Sachsen-Anhalt	ST	Börde
39343	Bebertal	Sachsen-Anhalt	ST	Börde
39343	Morsleben	Sachsen-Anhalt	ST	Börde
39343	Erxleben	Sachsen-Anhalt	ST	Börde
39343	Hillersleben	Sachsen-Anhalt	ST	Börde
39343	Ostingersleben	Sachsen-Anhalt	ST	Börde
39343	Bartensleben	Sachsen-Anhalt	ST	Börde
39343	Rottmersleben	Sachsen-Anhalt	ST	Börde
39343	Groß Santersleben	Sachsen-Anhalt	ST	Börde
39343	Uhrsleben	Sachsen-Anhalt	ST	Börde
39343	Ackendorf	Sachsen-Anhalt	ST	Börde
39343	Bornstedt	Sachsen-Anhalt	ST	Börde
39343	Hakenstedt	Sachsen-Anhalt	ST	Börde
39343	Emden	Sachsen-Anhalt	ST	Börde
39343	Eimersleben	Sachsen-Anhalt	ST	Börde
39343	Schackensleben	Sachsen-Anhalt	ST	Börde
39343	Bregenstedt	Sachsen-Anhalt	ST	Börde
39343	Ivenrode	Sachsen-Anhalt	ST	Börde
39343	Schwanefeld	Sachsen-Anhalt	ST	Börde
39343	Beendorf	Sachsen-Anhalt	ST	Börde
39345	Neuenhofe	Sachsen-Anhalt	ST	Börde
39345	Flechtingen	Sachsen-Anhalt	ST	Börde
39345	Wieglitz	Sachsen-Anhalt	ST	Börde
39345	Bülstringen	Sachsen-Anhalt	ST	Börde
39345	Born	Sachsen-Anhalt	ST	Börde
39345	Vahldorf	Sachsen-Anhalt	ST	Börde
39356	Siestedt	Sachsen-Anhalt	ST	Börde
39356	Hörsingen	Sachsen-Anhalt	ST	Börde
39356	Hödingen	Sachsen-Anhalt	ST	Börde
39356	Eschenrode	Sachsen-Anhalt	ST	Börde
39356	Walbeck	Sachsen-Anhalt	ST	Börde
39356	Behnsdorf	Sachsen-Anhalt	ST	Börde
39356	Seggerde	Sachsen-Anhalt	ST	Börde
39356	Döhren	Sachsen-Anhalt	ST	Börde
39356	Belsdorf	Sachsen-Anhalt	ST	Börde
39356	Weferlingen	Sachsen-Anhalt	ST	Börde
39359	Grauingen	Sachsen-Anhalt	ST	Börde
39359	Kathendorf	Sachsen-Anhalt	ST	Börde
39359	Rätzlingen	Sachsen-Anhalt	ST	Börde
39359	Everingen	Sachsen-Anhalt	ST	Börde
39359	Velsdorf	Sachsen-Anhalt	ST	Börde
39359	Böddensell	Sachsen-Anhalt	ST	Börde
39359	Eickendorf	Sachsen-Anhalt	ST	Börde
39359	Bösdorf	Sachsen-Anhalt	ST	Börde
39359	Wegenstedt	Sachsen-Anhalt	ST	Börde
39359	Calvörde	Sachsen-Anhalt	ST	Börde
39359	Etingen	Sachsen-Anhalt	ST	Börde
39359	Mannhausen	Sachsen-Anhalt	ST	Börde
39365	Wefensleben	Sachsen-Anhalt	ST	Börde
39365	Ummendorf	Sachsen-Anhalt	ST	Börde
39365	Sommersdorf	Sachsen-Anhalt	ST	Börde
39365	Seehausen	Sachsen-Anhalt	ST	Börde
39365	Dreileben	Sachsen-Anhalt	ST	Börde
39365	Wormsdorf	Sachsen-Anhalt	ST	Börde
39365	Marienborn	Sachsen-Anhalt	ST	Börde
39365	Druxberge	Sachsen-Anhalt	ST	Börde
39365	Harbke	Sachsen-Anhalt	ST	Börde
39365	Drackenstedt	Sachsen-Anhalt	ST	Börde
39365	Eilsleben	Sachsen-Anhalt	ST	Börde
39365	Ovelgünne	Sachsen-Anhalt	ST	Börde
39365	Eggenstedt	Sachsen-Anhalt	ST	Börde
39387	Ampfurth	Sachsen-Anhalt	ST	Börde
39387	Wulferstedt	Sachsen-Anhalt	ST	Börde
39387	Hornhausen	Sachsen-Anhalt	ST	Börde
39387	Oschersleben	Sachsen-Anhalt	ST	Börde
39387	Am Großen Bruch Neuwegersleben	Sachsen-Anhalt	ST	Börde
39387	Am Großen Bruch	Sachsen-Anhalt	ST	Börde
39387	Schermcke	Sachsen-Anhalt	ST	Börde
39387	Altbrandsleben	Sachsen-Anhalt	ST	Börde
39393	Völpke	Sachsen-Anhalt	ST	Börde
39393	Hötensleben	Sachsen-Anhalt	ST	Börde
39393	Am Großen Bruch Hamersleben	Sachsen-Anhalt	ST	Börde
39393	Am Großen Bruch	Sachsen-Anhalt	ST	Börde
39393	Ausleben	Sachsen-Anhalt	ST	Börde
39393	Wackersleben	Sachsen-Anhalt	ST	Börde
39393	Barneberg	Sachsen-Anhalt	ST	Börde
39393	Ohrsleben	Sachsen-Anhalt	ST	Börde
39393	Am Großen Bruch Gunsleben	Sachsen-Anhalt	ST	Börde
39397	Schwanebeck	Sachsen-Anhalt	ST	Harz
39397	Nienhagen	Sachsen-Anhalt	ST	Harz
39397	Gröningen	Sachsen-Anhalt	ST	Börde
39397	Kroppenstedt	Sachsen-Anhalt	ST	Börde
39398	Peseckendorf	Sachsen-Anhalt	ST	Börde
39398	Groß Germersleben	Sachsen-Anhalt	ST	Börde
39398	Hadmersleben	Sachsen-Anhalt	ST	Börde
39398	Klein Oschersleben	Sachsen-Anhalt	ST	Börde
39398	Alikendorf	Sachsen-Anhalt	ST	Börde
39418	Neundorf (Anhalt)	Sachsen-Anhalt	ST	Salz
39418	Staßfurt	Sachsen-Anhalt	ST	Salz
39434	Hecklingen bei Staßfurt	Sachsen-Anhalt	ST	Salz
39435	Groß Börnecke	Sachsen-Anhalt	ST	Salz
39435	Tarthun	Sachsen-Anhalt	ST	Salz
39435	Borne	Sachsen-Anhalt	ST	Salz
39435	Wolmirsleben	Sachsen-Anhalt	ST	Salz
39435	Unseburg	Sachsen-Anhalt	ST	Salz
39435	Egeln	Sachsen-Anhalt	ST	Salz
39435	Schneidlingen	Sachsen-Anhalt	ST	Salz
39439	Rathmannsdorf	Sachsen-Anhalt	ST	Salz
39439	Güsten	Sachsen-Anhalt	ST	Salz
39439	Amesdorf	Sachsen-Anhalt	ST	Salz
39443	Hohenerxleben	Sachsen-Anhalt	ST	Salz
39443	Löbnitz	Sachsen-Anhalt	ST	Salz
39443	Förderstedt	Sachsen-Anhalt	ST	Salz
39443	Atzendorf	Sachsen-Anhalt	ST	Salz
39444	Hecklingen	Sachsen-Anhalt	ST	Salz
39446	Löderburg	Sachsen-Anhalt	ST	Salz
39448	Westeregeln	Sachsen-Anhalt	ST	Salz
39448	Hakeborn	Sachsen-Anhalt	ST	Salz
39448	Etgersleben	Sachsen-Anhalt	ST	Salz
39517	Tangerhütte	Sachsen-Anhalt	ST	Stendal
39517	Cröchern	Sachsen-Anhalt	ST	Börde
39517	Bittkau	Sachsen-Anhalt	ST	Stendal
39517	Uchtdorf	Sachsen-Anhalt	ST	Stendal
39517	Schelldorf	Sachsen-Anhalt	ST	Stendal
39517	Schönwalde (Altmark)	Sachsen-Anhalt	ST	Stendal
39517	Uetz	Sachsen-Anhalt	ST	Stendal
39517	Grieben	Sachsen-Anhalt	ST	Stendal
39517	Lüderitz	Sachsen-Anhalt	ST	Stendal
39517	Bertingen	Sachsen-Anhalt	ST	Börde
39517	Birkholz	Sachsen-Anhalt	ST	Stendal
39517	Wenddorf	Sachsen-Anhalt	ST	Börde
39517	Kehnert	Sachsen-Anhalt	ST	Stendal
39517	Mahlwinkel	Sachsen-Anhalt	ST	Börde
39517	Dolle	Sachsen-Anhalt	ST	Börde
39517	Ringfurth	Sachsen-Anhalt	ST	Stendal
39517	Buch	Sachsen-Anhalt	ST	Stendal
39517	Schernebeck	Sachsen-Anhalt	ST	Stendal
39517	Burgstall	Sachsen-Anhalt	ST	Börde
39517	Jerchel	Sachsen-Anhalt	ST	Stendal
39517	Bölsdorf	Sachsen-Anhalt	ST	Stendal
39517	Cobbel	Sachsen-Anhalt	ST	Stendal
39517	Sandbeiendorf	Sachsen-Anhalt	ST	Börde
39517	Weißewarte	Sachsen-Anhalt	ST	Stendal
39524	Hohengöhren	Sachsen-Anhalt	ST	Stendal
39524	Warnau	Sachsen-Anhalt	ST	Stendal
39524	Wust	Sachsen-Anhalt	ST	Stendal
39524	Mangelsdorf	Sachsen-Anhalt	ST	Jerichower Land
39524	Kamern	Sachsen-Anhalt	ST	Stendal
39524	Fischbeck (Elbe)	Sachsen-Anhalt	ST	Stendal
39524	Wulkau	Sachsen-Anhalt	ST	Stendal
39524	Sandau (Elbe)	Sachsen-Anhalt	ST	Stendal
39524	Garz	Sachsen-Anhalt	ST	Stendal
39524	Schönfeld	Sachsen-Anhalt	ST	Stendal
39524	Schönhausen (Elbe)	Sachsen-Anhalt	ST	Stendal
39524	Kuhlhausen	Sachsen-Anhalt	ST	Stendal
39524	Klietz	Sachsen-Anhalt	ST	Stendal
39524	Neuermark-Lübars	Sachsen-Anhalt	ST	Stendal
39539	Havelberg	Sachsen-Anhalt	ST	Stendal
39576	Stendal	Sachsen-Anhalt	ST	Stendal
39579	Querstedt	Sachsen-Anhalt	ST	Stendal
39579	Bellingen	Sachsen-Anhalt	ST	Stendal
39579	Schäplitz	Sachsen-Anhalt	ST	Stendal
39579	Rochau	Sachsen-Anhalt	ST	Stendal
39579	Grassau	Sachsen-Anhalt	ST	Stendal
39579	Windberge	Sachsen-Anhalt	ST	Stendal
39579	Garlipp	Sachsen-Anhalt	ST	Stendal
39579	Uenglingen	Sachsen-Anhalt	ST	Stendal
39579	Wittenmoor	Sachsen-Anhalt	ST	Stendal
39579	Hüselitz	Sachsen-Anhalt	ST	Stendal
39579	Kläden	Sachsen-Anhalt	ST	Stendal
39579	Dahlen	Sachsen-Anhalt	ST	Stendal
39579	Groß Schwechten	Sachsen-Anhalt	ST	Stendal
39579	Buchholz	Sachsen-Anhalt	ST	Stendal
39579	Schinne	Sachsen-Anhalt	ST	Stendal
39579	Klein Schwechten	Sachsen-Anhalt	ST	Stendal
39579	Demker	Sachsen-Anhalt	ST	Stendal
39579	Badingen	Sachsen-Anhalt	ST	Stendal
39579	Grobleben	Sachsen-Anhalt	ST	Stendal
39579	Schernikau	Sachsen-Anhalt	ST	Stendal
39590	Hämerten	Sachsen-Anhalt	ST	Stendal
39590	Tangermünde	Sachsen-Anhalt	ST	Stendal
39590	Storkau (Elbe)	Sachsen-Anhalt	ST	Stendal
39590	Langensalzwedel	Sachsen-Anhalt	ST	Stendal
39590	Heeren	Sachsen-Anhalt	ST	Stendal
39590	Miltern	Sachsen-Anhalt	ST	Stendal
39596	Hassel	Sachsen-Anhalt	ST	Stendal
39596	Arneburg	Sachsen-Anhalt	ST	Stendal
39596	Jarchau	Sachsen-Anhalt	ST	Stendal
39596	Schwarzholz	Sachsen-Anhalt	ST	Stendal
39596	Baben	Sachsen-Anhalt	ST	Stendal
39596	Beelitz	Sachsen-Anhalt	ST	Stendal
39596	Lindtorf	Sachsen-Anhalt	ST	Stendal
39596	Altenzaun	Sachsen-Anhalt	ST	Stendal
39596	Goldbeck	Sachsen-Anhalt	ST	Stendal
39596	Bertkow	Sachsen-Anhalt	ST	Stendal
39596	Hindenburg	Sachsen-Anhalt	ST	Stendal
39596	Hohenberg-Krusemark	Sachsen-Anhalt	ST	Stendal
39596	Sanne	Sachsen-Anhalt	ST	Stendal
39596	Eichstedt (Altmark)	Sachsen-Anhalt	ST	Stendal
39599	Käthen	Sachsen-Anhalt	ST	Stendal
39599	Möringen	Sachsen-Anhalt	ST	Stendal
39599	Volgfelde	Sachsen-Anhalt	ST	Stendal
39599	Insel	Sachsen-Anhalt	ST	Stendal
39599	Staats	Sachsen-Anhalt	ST	Stendal
39599	Steinfeld (Altmark)	Sachsen-Anhalt	ST	Stendal
39599	Uchtspringe	Sachsen-Anhalt	ST	Stendal
39599	Vinzelberg	Sachsen-Anhalt	ST	Stendal
39599	Nahrstedt	Sachsen-Anhalt	ST	Stendal
39606	Kossebau	Sachsen-Anhalt	ST	Stendal
39606	Heiligenfelde	Sachsen-Anhalt	ST	Stendal
39606	Düsedau	Sachsen-Anhalt	ST	Stendal
39606	Lückstedt	Sachsen-Anhalt	ST	Stendal
39606	Walsleben	Sachsen-Anhalt	ST	Stendal
39606	Hohenwulsch	Sachsen-Anhalt	ST	Stendal
39606	Sanne-Kerkuhn	Sachsen-Anhalt	ST	Stendal
39606	Kleinau	Sachsen-Anhalt	ST	AltmarkSalzwedel
39606	Osterburg	Sachsen-Anhalt	ST	Stendal
39606	Rossau	Sachsen-Anhalt	ST	Stendal
39606	Behrendorf	Sachsen-Anhalt	ST	Stendal
39606	Boock	Sachsen-Anhalt	ST	Stendal
39606	Schorstedt	Sachsen-Anhalt	ST	Stendal
39606	Ballerstedt	Sachsen-Anhalt	ST	Stendal
39606	Gagel	Sachsen-Anhalt	ST	Stendal
39606	Gladigau	Sachsen-Anhalt	ST	Stendal
39606	Bretsch	Sachsen-Anhalt	ST	Stendal
39606	Krevese	Sachsen-Anhalt	ST	Stendal
39606	Meseberg	Sachsen-Anhalt	ST	Stendal
39606	Erxleben	Sachsen-Anhalt	ST	Stendal
39606	Königsmark	Sachsen-Anhalt	ST	Stendal
39606	Iden	Sachsen-Anhalt	ST	Stendal
39606	Sandauerholz	Sachsen-Anhalt	ST	Stendal
39606	Flessau	Sachsen-Anhalt	ST	Stendal
39606	Dobberkau	Sachsen-Anhalt	ST	Stendal
39615	Losenrade	Sachsen-Anhalt	ST	Stendal
39615	Beuster	Sachsen-Anhalt	ST	Stendal
39615	Geestgottberg	Sachsen-Anhalt	ST	Stendal
39615	Aulosen	Sachsen-Anhalt	ST	Stendal
39615	Wendemark	Sachsen-Anhalt	ST	Stendal
39615	Falkenberg	Sachsen-Anhalt	ST	Stendal
39615	Seehausen	Sachsen-Anhalt	ST	Stendal
39615	Neulingen	Sachsen-Anhalt	ST	AltmarkSalzwedel
39615	Höwisch	Sachsen-Anhalt	ST	AltmarkSalzwedel
39615	Werben (Elbe)	Sachsen-Anhalt	ST	Stendal
39615	Neukirchen (Altmark)	Sachsen-Anhalt	ST	Stendal
39615	Leppin	Sachsen-Anhalt	ST	AltmarkSalzwedel
39615	Krüden	Sachsen-Anhalt	ST	Stendal
39615	Groß Garz	Sachsen-Anhalt	ST	Stendal
39615	Wahrenberg	Sachsen-Anhalt	ST	Stendal
39615	Wanzer	Sachsen-Anhalt	ST	Stendal
39615	Gollensdorf	Sachsen-Anhalt	ST	Stendal
39615	Schönberg	Sachsen-Anhalt	ST	Stendal
39615	Lichterfelde	Sachsen-Anhalt	ST	Stendal
39615	Losse	Sachsen-Anhalt	ST	Stendal
39615	Pollitz	Sachsen-Anhalt	ST	Stendal
39619	Schrampe	Sachsen-Anhalt	ST	AltmarkSalzwedel
39619	Thielbeer	Sachsen-Anhalt	ST	AltmarkSalzwedel
39619	Arendsee	Sachsen-Anhalt	ST	AltmarkSalzwedel
39619	Ziemendorf	Sachsen-Anhalt	ST	AltmarkSalzwedel
39619	Kläden	Sachsen-Anhalt	ST	AltmarkSalzwedel
39624	Badel	Sachsen-Anhalt	ST	AltmarkSalzwedel
39624	Güssefeld	Sachsen-Anhalt	ST	AltmarkSalzwedel
39624	Berkau	Sachsen-Anhalt	ST	Stendal
39624	Kakerbeck	Sachsen-Anhalt	ST	AltmarkSalzwedel
39624	Packebusch	Sachsen-Anhalt	ST	AltmarkSalzwedel
39624	Büste	Sachsen-Anhalt	ST	Stendal
39624	Zethlingen	Sachsen-Anhalt	ST	AltmarkSalzwedel
39624	Wernstedt	Sachsen-Anhalt	ST	AltmarkSalzwedel
39624	Neuendorf am Damm	Sachsen-Anhalt	ST	AltmarkSalzwedel
39624	Vienau	Sachsen-Anhalt	ST	AltmarkSalzwedel
39624	Kremkau	Sachsen-Anhalt	ST	Stendal
39624	Jeetze	Sachsen-Anhalt	ST	AltmarkSalzwedel
39624	Kahrstedt	Sachsen-Anhalt	ST	AltmarkSalzwedel
39624	Brunau	Sachsen-Anhalt	ST	AltmarkSalzwedel
39624	Meßdorf	Sachsen-Anhalt	ST	Stendal
39624	Altmersleben	Sachsen-Anhalt	ST	AltmarkSalzwedel
39624	Winkelstedt	Sachsen-Anhalt	ST	AltmarkSalzwedel
39624	Kalbe (Milde)	Sachsen-Anhalt	ST	AltmarkSalzwedel
39629	Bismark (Altmark)	Sachsen-Anhalt	ST	Stendal
39629	Könnigde	Sachsen-Anhalt	ST	Stendal
39629	Holzhausen	Sachsen-Anhalt	ST	Stendal
39638	Roxförde	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Letzlingen	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Schwiesau	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Klüden	Sachsen-Anhalt	ST	Börde
39638	Berge	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Jeseritz	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Wiepke	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Kassieck	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Jävenitz	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Solpke	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Algenstedt	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Zobbenitz	Sachsen-Anhalt	ST	Börde
39638	Schenkenhorst	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Zichtau	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Dorst	Sachsen-Anhalt	ST	Börde
39638	Kloster Neuendorf	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Hemstedt	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Breitenfeld	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Lindstedt	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Engersen	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Wannefeld	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Hottendorf	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Potzehne	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Estedt	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Berenbrock	Sachsen-Anhalt	ST	Börde
39638	Gardelegen	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Seethen	Sachsen-Anhalt	ST	AltmarkSalzwedel
39638	Jerchel	Sachsen-Anhalt	ST	AltmarkSalzwedel
39646	Oebisfelde	Sachsen-Anhalt	ST	Börde
39649	Sachau	Sachsen-Anhalt	ST	AltmarkSalzwedel
39649	Sichau	Sachsen-Anhalt	ST	AltmarkSalzwedel
39649	Miesterhorst	Sachsen-Anhalt	ST	AltmarkSalzwedel
39649	Dannefeld	Sachsen-Anhalt	ST	AltmarkSalzwedel
39649	Peckfitz	Sachsen-Anhalt	ST	AltmarkSalzwedel
39649	Köckte	Sachsen-Anhalt	ST	AltmarkSalzwedel
39649	Jeggau	Sachsen-Anhalt	ST	AltmarkSalzwedel
39649	Mieste	Sachsen-Anhalt	ST	AltmarkSalzwedel
4600	Altenburg	Thüringen	TH	Altenburger Land
4603	Windischleuba	Thüringen	TH	Altenburger Land
4603	Nobitz	Thüringen	TH	Altenburger Land
4603	Göhren	Thüringen	TH	Altenburger Land
4603	Saara	Thüringen	TH	Altenburger Land
4610	Meuselwitz	Thüringen	TH	Altenburger Land
4610	Wintersdorf	Thüringen	TH	Altenburger Land
4613	Lucka	Thüringen	TH	Altenburger Land
4617	Tegkwitz	Thüringen	TH	Altenburger Land
4617	Treben	Thüringen	TH	Altenburger Land
4617	Rositz	Thüringen	TH	Altenburger Land
4617	Kriebitzsch	Thüringen	TH	Altenburger Land
4617	Fockendorf	Thüringen	TH	Altenburger Land
12587	Berlin	Berlin	BE	Berlin; Stadt
4617	Haselbach	Thüringen	TH	Altenburger Land
4617	Großröda	Thüringen	TH	Altenburger Land
4617	Starkenberg	Thüringen	TH	Altenburger Land
4617	Monstab	Thüringen	TH	Altenburger Land
4617	Naundorf	Thüringen	TH	Altenburger Land
4617	Lödla	Thüringen	TH	Altenburger Land
4617	Gerstenberg	Thüringen	TH	Altenburger Land
4618	Langenleuba-Niederhain	Thüringen	TH	Altenburger Land
4618	Göpfersdorf	Thüringen	TH	Altenburger Land
4618	Frohnsdorf	Thüringen	TH	Altenburger Land
4618	Jückelberg	Thüringen	TH	Altenburger Land
4618	Ziegelheim	Thüringen	TH	Altenburger Land
4626	Jonaswalde	Thüringen	TH	Altenburger Land
4626	Drogen	Thüringen	TH	Altenburger Land
4626	Löbichau	Thüringen	TH	Altenburger Land
4626	Heukewalde	Thüringen	TH	Altenburger Land
4626	Posterstein	Thüringen	TH	Altenburger Land
4626	Dobitschen	Thüringen	TH	Altenburger Land
4626	Vollmershain	Thüringen	TH	Altenburger Land
4626	Altkirchen	Thüringen	TH	Altenburger Land
4626	Göllnitz	Thüringen	TH	Altenburger Land
4626	Lumpzig	Thüringen	TH	Altenburger Land
4626	Thonhausen	Thüringen	TH	Altenburger Land
4626	Mehna	Thüringen	TH	Altenburger Land
4626	Wildenbörten	Thüringen	TH	Altenburger Land
4626	Schmölln	Thüringen	TH	Altenburger Land
4626	Nöbdenitz	Thüringen	TH	Altenburger Land
4639	Gößnitz	Thüringen	TH	Altenburger Land
6556	Artern	Thüringen	TH	Kyffhäuserkreis
6556	Kalbsrieth	Thüringen	TH	Kyffhäuserkreis
6556	Ichstedt	Thüringen	TH	Kyffhäuserkreis
6556	Reinsdorf	Thüringen	TH	Kyffhäuserkreis
6556	Mönchpfiffel-Nikolausrieth	Thüringen	TH	Kyffhäuserkreis
6556	Schönewerda	Thüringen	TH	Kyffhäuserkreis
6556	Heygendorf	Thüringen	TH	Kyffhäuserkreis
6556	Ringleben	Thüringen	TH	Kyffhäuserkreis
6556	Voigtstedt	Thüringen	TH	Kyffhäuserkreis
6556	Borxleben	Thüringen	TH	Kyffhäuserkreis
6556	Bretleben	Thüringen	TH	Kyffhäuserkreis
6567	Bad Frankenhausen	Thüringen	TH	Kyffhäuserkreis
6567	Esperstedt	Thüringen	TH	Kyffhäuserkreis
6571	Roßleben	Thüringen	TH	Kyffhäuserkreis
6571	Nausitz	Thüringen	TH	Kyffhäuserkreis
6571	Wiehe	Thüringen	TH	Kyffhäuserkreis
6571	Donndorf	Thüringen	TH	Kyffhäuserkreis
6571	Gehofen	Thüringen	TH	Kyffhäuserkreis
6577	Etzleben	Thüringen	TH	Kyffhäuserkreis
6577	Gorsleben	Thüringen	TH	Kyffhäuserkreis
6577	Oberheldrungen	Thüringen	TH	Kyffhäuserkreis
6577	Heldrungen	Thüringen	TH	Kyffhäuserkreis
6577	Hemleben	Thüringen	TH	Kyffhäuserkreis
6577	Hauteroda	Thüringen	TH	Kyffhäuserkreis
6578	Oldisleben	Thüringen	TH	Kyffhäuserkreis
6578	Kannawurf	Thüringen	TH	Sömmerda
6578	Bilzingsleben	Thüringen	TH	Sömmerda
7318	Arnsgereuth	Thüringen	TH	Saalfeld-Rudolstadt
7318	Wittgendorf	Thüringen	TH	Saalfeld-Rudolstadt
7318	Saalfeld/Saale	Thüringen	TH	Saalfeld-Rudolstadt
7330	Probstzella	Thüringen	TH	Saalfeld-Rudolstadt
7330	Marktgölitz	Thüringen	TH	Saalfeld-Rudolstadt
7333	Unterwellenborn	Thüringen	TH	Saalfeld-Rudolstadt
7334	Kamsdorf	Thüringen	TH	Saalfeld-Rudolstadt
7334	Goßwitz	Thüringen	TH	Saalfeld-Rudolstadt
7336	Könitz	Thüringen	TH	Saalfeld-Rudolstadt
7336	Birkigt	Thüringen	TH	Saalfeld-Rudolstadt
7338	Leutenberg	Thüringen	TH	Saalfeld-Rudolstadt
7338	Hohenwarte	Thüringen	TH	Saalfeld-Rudolstadt
7338	Drognitz	Thüringen	TH	Saalfeld-Rudolstadt
7338	Kaulsdorf	Thüringen	TH	Saalfeld-Rudolstadt
7338	Altenbeuthen	Thüringen	TH	Saalfeld-Rudolstadt
7343	Wurzbach	Thüringen	TH	Saale-Orla
7349	Lehesten	Thüringen	TH	Saalfeld-Rudolstadt
7356	Lobenstein	Thüringen	TH	Saale-Orla
7356	Neundorf (bei Lobenstein)	Thüringen	TH	Saale-Orla
7366	Birkenhügel	Thüringen	TH	Saale-Orla
7366	Schlegel	Thüringen	TH	Saale-Orla
7366	Pottiga	Thüringen	TH	Saale-Orla
7366	Blankenstein	Thüringen	TH	Saale-Orla
7366	Harra	Thüringen	TH	Saale-Orla
7366	Blankenberg	Thüringen	TH	Saale-Orla
7368	Remptendorf	Thüringen	TH	Saale-Orla
7368	Saalburg-Ebersdorf	Thüringen	TH	Saale-Orla
7381	Langenorla	Thüringen	TH	Saale-Orla
7381	Oberoppurg	Thüringen	TH	Saale-Orla
7381	Moxa	Thüringen	TH	Saale-Orla
7381	Pößneck	Thüringen	TH	Saale-Orla
7381	Döbritz	Thüringen	TH	Saale-Orla
7381	Bodelwitz	Thüringen	TH	Saale-Orla
7381	Oppurg	Thüringen	TH	Saale-Orla
7381	Solkwitz	Thüringen	TH	Saale-Orla
7381	Paska	Thüringen	TH	Saale-Orla
7381	Wernburg	Thüringen	TH	Saale-Orla
7381	Nimritz	Thüringen	TH	Saale-Orla
7387	Krölpa	Thüringen	TH	Saale-Orla
7387	Lausnitz bei Pößneck	Thüringen	TH	Saale-Orla
7389	Wilhelmsdorf	Thüringen	TH	Saale-Orla
7389	Gössitz	Thüringen	TH	Saale-Orla
7389	Peuschen	Thüringen	TH	Saale-Orla
7389	Ranis	Thüringen	TH	Saale-Orla
7389	Gertewitz	Thüringen	TH	Saale-Orla
7389	Schmorda	Thüringen	TH	Saale-Orla
7389	Knau	Thüringen	TH	Saale-Orla
7389	Keila	Thüringen	TH	Saale-Orla
7389	Seisla	Thüringen	TH	Saale-Orla
7389	Bucha	Thüringen	TH	Saale-Orla
7389	Grobengereuth	Thüringen	TH	Saale-Orla
12589	Berlin	Berlin	BE	Berlin; Stadt
7389	Quaschwitz	Thüringen	TH	Saale-Orla
7407	Rudolstadt	Thüringen	TH	Saalfeld-Rudolstadt
7407	Heilingen	Thüringen	TH	Saalfeld-Rudolstadt
7407	Remda-Teichel	Thüringen	TH	Saalfeld-Rudolstadt
7407	Uhlstädt-Kirchhasel	Thüringen	TH	Saalfeld-Rudolstadt
7407	Großkochberg	Thüringen	TH	Saalfeld-Rudolstadt
7422	Rottenbach	Thüringen	TH	Saalfeld-Rudolstadt
7422	Bad Blankenburg	Thüringen	TH	Saalfeld-Rudolstadt
7422	Saalfelder Höhe	Thüringen	TH	Saalfeld-Rudolstadt
7426	Allendorf	Thüringen	TH	Saalfeld-Rudolstadt
7426	Königsee	Thüringen	TH	Saalfeld-Rudolstadt
7426	Oberhain	Thüringen	TH	Saalfeld-Rudolstadt
7426	Bechstedt	Thüringen	TH	Saalfeld-Rudolstadt
7426	Dröbischau	Thüringen	TH	Saalfeld-Rudolstadt
7427	Schwarzburg	Thüringen	TH	Saalfeld-Rudolstadt
7429	Döschnitz	Thüringen	TH	Saalfeld-Rudolstadt
7429	Sitzendorf	Thüringen	TH	Saalfeld-Rudolstadt
7429	Rohrbach	Thüringen	TH	Saalfeld-Rudolstadt
7545	Gera	Thüringen	TH	Gera; Stadt
7546	Gera	Thüringen	TH	Gera; Stadt
7548	Gera	Thüringen	TH	Gera; Stadt
7549	Gera	Thüringen	TH	Gera; Stadt
7551	Gera	Thüringen	TH	Gera; Stadt
7552	Gera	Thüringen	TH	Gera; Stadt
7554	Hirschfeld	Thüringen	TH	Greiz
7554	Schwaara	Thüringen	TH	Greiz
7554	Pölzig	Thüringen	TH	Greiz
7554	Brahmenau	Thüringen	TH	Greiz
7554	Korbußen	Thüringen	TH	Greiz
7554	Kauern	Thüringen	TH	Greiz
7554	Bethenhausen	Thüringen	TH	Greiz
7557	Hundhaupten	Thüringen	TH	Greiz
7557	Zedlitz	Thüringen	TH	Greiz
7557	Harth-Pöllnitz	Thüringen	TH	Greiz
7557	Harth-Pöllnitz Köckritz	Thüringen	TH	Greiz
7557	Harth-Pöllnitz Köfeln	Thüringen	TH	Greiz
7557	Bocka	Thüringen	TH	Greiz
7557	Crimla	Thüringen	TH	Greiz
7570	Harth-Pöllnitz Neundorf	Thüringen	TH	Greiz
7570	Harth-Pöllnitz Birkigt	Thüringen	TH	Greiz
7570	Hohenölsen	Thüringen	TH	Greiz
7570	Wünschendorf	Thüringen	TH	Greiz
7570	Harth-Pöllnitz	Thüringen	TH	Greiz
7570	Schömberg	Thüringen	TH	Greiz
7570	Endschütz	Thüringen	TH	Greiz
7570	Harth-Pöllnitz Nonnendorf	Thüringen	TH	Greiz
7570	Harth-Pöllnitz Burkersdorf	Thüringen	TH	Greiz
7570	Harth-Pöllnitz Frießnitz	Thüringen	TH	Greiz
7570	Harth-Pöllnitz Wetzdorf	Thüringen	TH	Greiz
7570	Harth-Pöllnitz Niederpöllnitz	Thüringen	TH	Greiz
7570	Harth-Pöllnitz Forstwolfersdorf	Thüringen	TH	Greiz
7570	Harth-Pöllnitz Grochwitz	Thüringen	TH	Greiz
7570	Harth-Pöllnitz Rohna	Thüringen	TH	Greiz
7570	Harth-Pöllnitz Uhlersdorf	Thüringen	TH	Greiz
7570	Steinsdorf	Thüringen	TH	Greiz
7570	Weida	Thüringen	TH	Greiz
7570	Teichwitz	Thüringen	TH	Greiz
7580	Großenstein	Thüringen	TH	Greiz
7580	Reichstädt	Thüringen	TH	Greiz
7580	Seelingstädt	Thüringen	TH	Greiz
7580	Ronneburg	Thüringen	TH	Greiz
7580	Linda bei Weida	Thüringen	TH	Greiz
7580	Paitzdorf	Thüringen	TH	Greiz
7580	Braunichswalde	Thüringen	TH	Greiz
7580	Rückersdorf	Thüringen	TH	Greiz
7580	Gauern	Thüringen	TH	Greiz
7580	Hilbersdorf	Thüringen	TH	Greiz
7586	Bad Köstritz	Thüringen	TH	Greiz
7586	Hartmannsdorf	Thüringen	TH	Greiz
7586	Caaschwitz	Thüringen	TH	Greiz
7586	Kraftsdorf	Thüringen	TH	Greiz
7589	Harth-Pöllnitz Birkhausen	Thüringen	TH	Greiz
7589	Saara	Thüringen	TH	Greiz
7589	Harth-Pöllnitz	Thüringen	TH	Greiz
7589	Lederhose	Thüringen	TH	Greiz
7589	Harth-Pöllnitz Großebersdorf	Thüringen	TH	Greiz
7589	Harth-Pöllnitz Struth	Thüringen	TH	Greiz
7589	Münchenbernsdorf	Thüringen	TH	Greiz
7589	Schwarzbach	Thüringen	TH	Greiz
7589	Lindenkreuz	Thüringen	TH	Greiz
7607	Eisenberg	Thüringen	TH	Saale-Holzland
7607	Hainspitz	Thüringen	TH	Saale-Holzland
7607	Heideland	Thüringen	TH	Saale-Holzland
7607	Gösen	Thüringen	TH	Saale-Holzland
7613	Seifartsdorf	Thüringen	TH	Saale-Holzland
7613	Crossen an der Elster	Thüringen	TH	Saale-Holzland
7613	Silbitz	Thüringen	TH	Saale-Holzland
7613	Rauda	Thüringen	TH	Saale-Holzland
7613	Walpernhain	Thüringen	TH	Saale-Holzland
7613	Hartmannsdorf	Thüringen	TH	Saale-Holzland
7616	Poxdorf	Thüringen	TH	Saale-Holzland
7616	Bürgel	Thüringen	TH	Saale-Holzland
7616	Petersberg	Thüringen	TH	Saale-Holzland
7616	Graitschen bei Bürgel	Thüringen	TH	Saale-Holzland
7616	Serba	Thüringen	TH	Saale-Holzland
7616	Nausnitz	Thüringen	TH	Saale-Holzland
7616	Rauschwitz	Thüringen	TH	Saale-Holzland
7619	Mertendorf	Thüringen	TH	Saale-Holzland
7619	Schkölen	Thüringen	TH	Saale-Holzland
7629	Hermsdorf	Thüringen	TH	Saale-Holzland
7629	Sankt Gangloff	Thüringen	TH	Saale-Holzland
7629	Reichenbach	Thüringen	TH	Saale-Holzland
7629	Schleifreisen	Thüringen	TH	Saale-Holzland
7639	Bad Klosterlausnitz	Thüringen	TH	Saale-Holzland
7639	Weißenborn	Thüringen	TH	Saale-Holzland
7639	Tautenhain	Thüringen	TH	Saale-Holzland
7646	Stadtroda	Thüringen	TH	Saale-Holzland
7646	Unterbodnitz	Thüringen	TH	Saale-Holzland
7646	Weißbach	Thüringen	TH	Saale-Holzland
7646	Lippersdorf-Erdmannsdorf	Thüringen	TH	Saale-Holzland
7646	Tissa	Thüringen	TH	Saale-Holzland
7646	Tautendorf	Thüringen	TH	Saale-Holzland
7646	Oberbodnitz	Thüringen	TH	Saale-Holzland
7646	Rattelsdorf	Thüringen	TH	Saale-Holzland
7646	Rausdorf	Thüringen	TH	Saale-Holzland
7646	Quirla	Thüringen	TH	Saale-Holzland
7646	Albersdorf	Thüringen	TH	Saale-Holzland
7646	Tröbnitz	Thüringen	TH	Saale-Holzland
7646	Großbockedra	Thüringen	TH	Saale-Holzland
7646	Meusebach	Thüringen	TH	Saale-Holzland
7646	Kleinbockedra	Thüringen	TH	Saale-Holzland
7646	Scheiditz	Thüringen	TH	Saale-Holzland
7646	Möckern	Thüringen	TH	Saale-Holzland
7646	Mörsdorf	Thüringen	TH	Saale-Holzland
7646	Waltersdorf	Thüringen	TH	Saale-Holzland
7646	Ruttersdorf-Lotschen	Thüringen	TH	Saale-Holzland
7646	Schlöben	Thüringen	TH	Saale-Holzland
7646	Ottendorf	Thüringen	TH	Saale-Holzland
7646	Laasdorf	Thüringen	TH	Saale-Holzland
7646	Karlsdorf	Thüringen	TH	Saale-Holzland
7646	Trockenborn-Wolfersdorf	Thüringen	TH	Saale-Holzland
7646	Schöngleina	Thüringen	TH	Saale-Holzland
7646	Bollberg	Thüringen	TH	Saale-Holzland
7646	Gneus	Thüringen	TH	Saale-Holzland
7646	Bremsnitz	Thüringen	TH	Saale-Holzland
7646	Geisenhain	Thüringen	TH	Saale-Holzland
7646	Waldeck	Thüringen	TH	Saale-Holzland
7646	Kleinebersdorf	Thüringen	TH	Saale-Holzland
7646	Renthendorf	Thüringen	TH	Saale-Holzland
7646	Bobeck	Thüringen	TH	Saale-Holzland
7646	Eineborn	Thüringen	TH	Saale-Holzland
7743	Jena	Thüringen	TH	Jena; Stadt
7745	Jena	Thüringen	TH	Jena; Stadt
7747	Jena	Thüringen	TH	Jena; Stadt
7749	Jena	Thüringen	TH	Jena; Stadt
7751	Jenalöbnitz	Thüringen	TH	Saale-Holzland
7751	Löberschütz	Thüringen	TH	Saale-Holzland
7751	Rothenstein	Thüringen	TH	Saale-Holzland
7751	Sulza	Thüringen	TH	Saale-Holzland
7751	Zöllnitz	Thüringen	TH	Saale-Holzland
7751	Bucha	Thüringen	TH	Saale-Holzland
7751	Golmsdorf	Thüringen	TH	Saale-Holzland
7751	Großlöbichau	Thüringen	TH	Saale-Holzland
7751	Großpürschütz	Thüringen	TH	Saale-Holzland
7751	Milda	Thüringen	TH	Saale-Holzland
7768	Hummelshain	Thüringen	TH	Saale-Holzland
7768	Kleineutersdorf	Thüringen	TH	Saale-Holzland
7768	Seitenroda	Thüringen	TH	Saale-Holzland
7768	Eichenberg	Thüringen	TH	Saale-Holzland
7768	Gumperda	Thüringen	TH	Saale-Holzland
7768	Altenberga	Thüringen	TH	Saale-Holzland
7768	Großeutersdorf	Thüringen	TH	Saale-Holzland
7768	Freienorla	Thüringen	TH	Saale-Holzland
7768	Kahla	Thüringen	TH	Saale-Holzland
7768	Orlamünde	Thüringen	TH	Saale-Holzland
7768	Reinstädt	Thüringen	TH	Saale-Holzland
7768	Lindig	Thüringen	TH	Saale-Holzland
7768	Bibra	Thüringen	TH	Saale-Holzland
7768	Schöps	Thüringen	TH	Saale-Holzland
7774	Camburg	Thüringen	TH	Saale-Holzland
7774	Thierschneck	Thüringen	TH	Saale-Holzland
7774	Frauenprießnitz	Thüringen	TH	Saale-Holzland
7774	Wichmar	Thüringen	TH	Saale-Holzland
7778	Lehesten	Thüringen	TH	Saale-Holzland
7778	Dornburg	Thüringen	TH	Saale-Holzland
7778	Tautenburg	Thüringen	TH	Saale-Holzland
7778	Zimmern	Thüringen	TH	Saale-Holzland
7778	Hainichen	Thüringen	TH	Saale-Holzland
7778	Dorndorf-Steudnitz	Thüringen	TH	Saale-Holzland
7778	Neuengönna	Thüringen	TH	Saale-Holzland
7806	Neustadt an der Orla	Thüringen	TH	Saale-Orla
7806	Weira	Thüringen	TH	Saale-Orla
7806	Lausnitz bei Neustadt an der Orla	Thüringen	TH	Saale-Orla
7806	Dreba	Thüringen	TH	Saale-Orla
7819	Dreitzsch	Thüringen	TH	Saale-Orla
7819	Schmieritz	Thüringen	TH	Saale-Orla
7819	Pillingsdorf	Thüringen	TH	Saale-Orla
7819	Geroda	Thüringen	TH	Saale-Orla
7819	Triptis	Thüringen	TH	Saale-Orla
7819	Lemnitz	Thüringen	TH	Saale-Orla
7819	Tömmelsdorf	Thüringen	TH	Saale-Orla
7819	Linda bei Neustadt an der Orla	Thüringen	TH	Saale-Orla
7819	Rosendorf	Thüringen	TH	Saale-Orla
7819	Miesitz	Thüringen	TH	Saale-Orla
7819	Mittelpöllnitz	Thüringen	TH	Saale-Orla
7907	Görkwitz	Thüringen	TH	Saale-Orla
7907	Göschitz	Thüringen	TH	Saale-Orla
7907	Tegau	Thüringen	TH	Saale-Orla
7907	Dittersdorf	Thüringen	TH	Saale-Orla
7907	Löhma	Thüringen	TH	Saale-Orla
7907	Dragensdorf	Thüringen	TH	Saale-Orla
7907	Plothen	Thüringen	TH	Saale-Orla
7907	Schleiz	Thüringen	TH	Saale-Orla
7907	Pörmitz	Thüringen	TH	Saale-Orla
7907	Oettersdorf	Thüringen	TH	Saale-Orla
7919	Kirschkau	Thüringen	TH	Saale-Orla
7922	Tanna	Thüringen	TH	Saale-Orla
7924	Crispendorf	Thüringen	TH	Saale-Orla
7924	Neundorf (bei Schleiz)	Thüringen	TH	Saale-Orla
7924	Eßbach	Thüringen	TH	Saale-Orla
7924	Schöndorf	Thüringen	TH	Saale-Orla
7924	Ziegenrück	Thüringen	TH	Saale-Orla
7924	Volkmannsdorf	Thüringen	TH	Saale-Orla
7926	Gefell	Thüringen	TH	Saale-Orla
7927	Hirschberg	Thüringen	TH	Saale-Orla
7929	Saalburg-Ebersdorf	Thüringen	TH	Saale-Orla
7937	Zeulenroda	Thüringen	TH	Greiz
7937	Zadelsdorf	Thüringen	TH	Greiz
7937	Langenwolschendorf	Thüringen	TH	Greiz
7937	Vogtländisches Oberland	Thüringen	TH	Greiz
7937	Silberfeld	Thüringen	TH	Greiz
7950	Göhren-Döhlen	Thüringen	TH	Greiz
7950	Wiebelsdorf	Thüringen	TH	Greiz
7950	Weißendorf	Thüringen	TH	Greiz
7950	Staitz	Thüringen	TH	Greiz
7950	Merkendorf	Thüringen	TH	Greiz
7950	Triebes	Thüringen	TH	Greiz
7955	Auma	Thüringen	TH	Greiz
7955	Braunsdorf	Thüringen	TH	Greiz
7957	Hain	Thüringen	TH	Greiz
7957	Langenwetzendorf	Thüringen	TH	Greiz
7958	Hohenleuben	Thüringen	TH	Greiz
7973	Greiz	Thüringen	TH	Greiz
7980	Neugernsdorf	Thüringen	TH	Greiz
7980	Lunzig	Thüringen	TH	Greiz
7980	Berga/Elster	Thüringen	TH	Greiz
7980	Kühdorf	Thüringen	TH	Greiz
7980	Wildetaube	Thüringen	TH	Greiz
7980	Neumühle	Thüringen	TH	Greiz
7987	Mohlsdorf	Thüringen	TH	Greiz
7989	Teichwolframsdorf	Thüringen	TH	Greiz
36404	Martinroda	Thüringen	TH	Wartburgkreis
36404	Vacha	Thüringen	TH	Wartburgkreis
36404	Völkershausen	Thüringen	TH	Wartburgkreis
36404	Oechsen	Thüringen	TH	Wartburgkreis
36404	Wölferbütt	Thüringen	TH	Wartburgkreis
36414	Unterbreizbach	Thüringen	TH	Wartburgkreis
36419	Geisa	Thüringen	TH	Wartburgkreis
36419	Schleid	Thüringen	TH	Wartburgkreis
36419	Gerstengrund	Thüringen	TH	Wartburgkreis
36419	Rockenstuhl	Thüringen	TH	Wartburgkreis
36419	Buttlar	Thüringen	TH	Wartburgkreis
36433	Leimbach	Thüringen	TH	Wartburgkreis
36433	Bad Salzungen	Thüringen	TH	Wartburgkreis
36433	Immelborn	Thüringen	TH	Wartburgkreis
36433	Moorgrund	Thüringen	TH	Wartburgkreis
36448	Schweina	Thüringen	TH	Wartburgkreis
36448	Steinbach	Thüringen	TH	Wartburgkreis
36448	Bad Liebenstein	Thüringen	TH	Wartburgkreis
36452	Klings	Thüringen	TH	Schmalkalden-Meiningen
36452	Zella	Thüringen	TH	Wartburgkreis
36452	Neidhartshausen	Thüringen	TH	Wartburgkreis
36452	Andenhausen	Thüringen	TH	Schmalkalden-Meiningen
36452	Diedorf	Thüringen	TH	Wartburgkreis
36452	Fischbach/Rhön	Thüringen	TH	Wartburgkreis
36452	Brunnhartshausen	Thüringen	TH	Wartburgkreis
36452	Kaltenlengsfeld	Thüringen	TH	Schmalkalden-Meiningen
36452	Kaltennordheim	Thüringen	TH	Schmalkalden-Meiningen
36452	Empfertshausen	Thüringen	TH	Wartburgkreis
36456	Barchfeld	Thüringen	TH	Wartburgkreis
36457	Weilar	Thüringen	TH	Wartburgkreis
36457	Stadtlengsfeld	Thüringen	TH	Wartburgkreis
36457	Urnshausen	Thüringen	TH	Wartburgkreis
36460	Frauensee	Thüringen	TH	Wartburgkreis
36460	Merkers-Kieselbach	Thüringen	TH	Wartburgkreis
36460	Dorndorf	Thüringen	TH	Wartburgkreis
36466	Wiesenthal	Thüringen	TH	Wartburgkreis
36466	Dermbach	Thüringen	TH	Wartburgkreis
36469	Tiefenort	Thüringen	TH	Wartburgkreis
37308	Pfaffschwende	Thüringen	TH	Eichsfeld
37308	Sickerode	Thüringen	TH	Eichsfeld
37308	Steinbach	Thüringen	TH	Eichsfeld
37308	Krombach	Thüringen	TH	Eichsfeld
37308	Volkerode	Thüringen	TH	Eichsfeld
37308	Kella	Thüringen	TH	Eichsfeld
37308	Wingerode	Thüringen	TH	Eichsfeld
37308	Hohes Kreuz	Thüringen	TH	Eichsfeld
37308	Bodenrode-Westhausen	Thüringen	TH	Eichsfeld
37308	Heuthen	Thüringen	TH	Eichsfeld
37308	Schimberg	Thüringen	TH	Eichsfeld
37308	Reinholterode	Thüringen	TH	Eichsfeld
37308	Heilbad Heiligenstadt	Thüringen	TH	Eichsfeld
37308	Wiesenfeld	Thüringen	TH	Eichsfeld
37308	Geismar	Thüringen	TH	Eichsfeld
37308	Geisleden	Thüringen	TH	Eichsfeld
37308	Glasehausen	Thüringen	TH	Eichsfeld
37318	Dieterode	Thüringen	TH	Eichsfeld
37318	Schwobfeld	Thüringen	TH	Eichsfeld
37318	Schachtebich	Thüringen	TH	Eichsfeld
37318	Birkenfelde	Thüringen	TH	Eichsfeld
37318	Steinheuterode	Thüringen	TH	Eichsfeld
37318	Lindewerra	Thüringen	TH	Eichsfeld
37318	Hohengandern	Thüringen	TH	Eichsfeld
37318	Kirchgandern	Thüringen	TH	Eichsfeld
37318	Rohrberg	Thüringen	TH	Eichsfeld
37318	Burgwalde	Thüringen	TH	Eichsfeld
37318	Eichstruth	Thüringen	TH	Eichsfeld
37318	Mackenrode	Thüringen	TH	Eichsfeld
37318	Arenshausen	Thüringen	TH	Eichsfeld
37318	Fretterode	Thüringen	TH	Eichsfeld
37318	Wüstheuterode	Thüringen	TH	Eichsfeld
37318	Lenterode	Thüringen	TH	Eichsfeld
37318	Lutter	Thüringen	TH	Eichsfeld
37318	Uder	Thüringen	TH	Eichsfeld
37318	Röhrig	Thüringen	TH	Eichsfeld
37318	Schönhagen	Thüringen	TH	Eichsfeld
37318	Bornhagen	Thüringen	TH	Eichsfeld
37318	Thalwenden	Thüringen	TH	Eichsfeld
37318	Gerbershausen	Thüringen	TH	Eichsfeld
37318	Dietzenrode-Vatterode	Thüringen	TH	Eichsfeld
37318	Asbach-Sickenberg	Thüringen	TH	Eichsfeld
37318	Wahlhausen	Thüringen	TH	Eichsfeld
37318	Bernterode (bei Heilbad Heiligenstadt)	Thüringen	TH	Eichsfeld
37318	Marth	Thüringen	TH	Eichsfeld
37318	Rustenfelde	Thüringen	TH	Eichsfeld
37318	Freienhagen	Thüringen	TH	Eichsfeld
37327	Breitenbach	Thüringen	TH	Eichsfeld
37327	Kallmerode	Thüringen	TH	Eichsfeld
37327	Leinefelde	Thüringen	TH	Eichsfeld
37327	Hausen	Thüringen	TH	Eichsfeld
37339	Brehme	Thüringen	TH	Eichsfeld
37339	Wehnde	Thüringen	TH	Eichsfeld
37339	Ecklingerode	Thüringen	TH	Eichsfeld
37339	Buhla	Thüringen	TH	Eichsfeld
37339	Breitenworbis	Thüringen	TH	Eichsfeld
37339	Worbis	Thüringen	TH	Eichsfeld
37339	Wintzingerode	Thüringen	TH	Eichsfeld
37339	Teistungen	Thüringen	TH	Eichsfeld
37339	Tastungen	Thüringen	TH	Eichsfeld
37339	Berlingerode	Thüringen	TH	Eichsfeld
37339	Haynrode	Thüringen	TH	Eichsfeld
37339	Hundeshagen	Thüringen	TH	Eichsfeld
37339	Ferna	Thüringen	TH	Eichsfeld
37339	Kirchworbis	Thüringen	TH	Eichsfeld
37339	Gernrode	Thüringen	TH	Eichsfeld
37345	Weißenborn-Lüderode	Thüringen	TH	Eichsfeld
37345	Großbodungen	Thüringen	TH	Eichsfeld
37345	Jützenbach	Thüringen	TH	Eichsfeld
37345	Stöckey	Thüringen	TH	Eichsfeld
37345	Holungen	Thüringen	TH	Eichsfeld
37345	Neustadt	Thüringen	TH	Eichsfeld
37345	Bischofferode	Thüringen	TH	Eichsfeld
37345	Silkerode	Thüringen	TH	Eichsfeld
37345	Bockelnhagen	Thüringen	TH	Eichsfeld
37345	Zwinge	Thüringen	TH	Eichsfeld
37345	Steinrode	Thüringen	TH	Eichsfeld
37351	Silberhausen	Thüringen	TH	Eichsfeld
37351	Kefferhausen	Thüringen	TH	Eichsfeld
37351	Dingelstädt	Thüringen	TH	Eichsfeld
37351	Kreuzebra	Thüringen	TH	Eichsfeld
37351	Helmsdorf	Thüringen	TH	Eichsfeld
37355	Niederorschel	Thüringen	TH	Eichsfeld
37355	Bernterode; Untereichsfeld	Thüringen	TH	Eichsfeld
37355	Gerterode	Thüringen	TH	Eichsfeld
37355	Vollenborn	Thüringen	TH	Kyffhäuserkreis
37355	Kleinbartloff	Thüringen	TH	Eichsfeld
37355	Deuna	Thüringen	TH	Eichsfeld
37359	Wachstedt	Thüringen	TH	Eichsfeld
37359	Küllstedt	Thüringen	TH	Eichsfeld
37359	Büttstedt	Thüringen	TH	Eichsfeld
37359	Großbartloff	Thüringen	TH	Eichsfeld
37359	Effelder	Thüringen	TH	Eichsfeld
96515	Sonneberg	Thüringen	TH	Sonneberg
96523	Oberland am Rennsteig	Thüringen	TH	Sonneberg
96523	Steinach	Thüringen	TH	Sonneberg
96524	Judenbach	Thüringen	TH	Sonneberg
96524	Neuhaus-Schierschnitz	Thüringen	TH	Sonneberg
96524	Föritz	Thüringen	TH	Sonneberg
96528	Frankenblick	Thüringen	TH	Sonneberg
96528	Bachfeld	Thüringen	TH	Sonneberg
96528	Schalkau	Thüringen	TH	Sonneberg
98527	Suhl	Thüringen	TH	Suhl
98528	Suhl	Thüringen	TH	Suhl
98529	Suhl	Thüringen	TH	Suhl
98530	Dillstädt	Thüringen	TH	Schmalkalden-Meiningen
98530	Schmeheim	Thüringen	TH	Hildburghausen
98530	Oberstadt	Thüringen	TH	Hildburghausen
98530	Marisfeld	Thüringen	TH	Hildburghausen
98530	Rohr	Thüringen	TH	Schmalkalden-Meiningen
98544	Zella-Mehlis	Thüringen	TH	Schmalkalden-Meiningen
98547	Schwarza	Thüringen	TH	Schmalkalden-Meiningen
98547	Christes	Thüringen	TH	Schmalkalden-Meiningen
98547	Kühndorf	Thüringen	TH	Schmalkalden-Meiningen
98547	Viernau	Thüringen	TH	Schmalkalden-Meiningen
98553	Nahetal-Waldau	Thüringen	TH	Hildburghausen
98553	Ahlstädt	Thüringen	TH	Hildburghausen
98553	Bischofrod	Thüringen	TH	Hildburghausen
98553	Schleusingen	Thüringen	TH	Hildburghausen
98553	Eichenberg	Thüringen	TH	Hildburghausen
99425	Weimar	Thüringen	TH	Weimar; Stadt
98553	Sankt Kilian	Thüringen	TH	Hildburghausen
98554	Benshausen	Thüringen	TH	Schmalkalden-Meiningen
98559	Gehlberg	Thüringen	TH	Suhl
98559	Oberhof	Thüringen	TH	Schmalkalden-Meiningen
98574	Schmalkalden	Thüringen	TH	Schmalkalden-Meiningen
98587	Altersbach	Thüringen	TH	Schmalkalden-Meiningen
98587	Steinbach-Hallenberg	Thüringen	TH	Schmalkalden-Meiningen
98587	Oberschönau	Thüringen	TH	Schmalkalden-Meiningen
98587	Bermbach	Thüringen	TH	Schmalkalden-Meiningen
98587	Rotterode	Thüringen	TH	Schmalkalden-Meiningen
98587	Springstille	Thüringen	TH	Schmalkalden-Meiningen
98587	Unterschönau	Thüringen	TH	Schmalkalden-Meiningen
98590	Roßdorf	Thüringen	TH	Schmalkalden-Meiningen
98590	Rosa	Thüringen	TH	Schmalkalden-Meiningen
98590	Schwallungen	Thüringen	TH	Schmalkalden-Meiningen
98590	Wernshausen	Thüringen	TH	Schmalkalden-Meiningen
98593	Floh-Seligenthal	Thüringen	TH	Schmalkalden-Meiningen
98593	Kleinschmalkalden	Thüringen	TH	Schmalkalden-Meiningen
98596	Trusetal	Thüringen	TH	Schmalkalden-Meiningen
98597	Breitungen	Thüringen	TH	Schmalkalden-Meiningen
98597	Heßles	Thüringen	TH	Schmalkalden-Meiningen
98597	Fambach	Thüringen	TH	Schmalkalden-Meiningen
98599	Brotterode	Thüringen	TH	Schmalkalden-Meiningen
98617	Henneberg	Thüringen	TH	Schmalkalden-Meiningen
98617	Stepfershausen	Thüringen	TH	Schmalkalden-Meiningen
98617	Meiningen	Thüringen	TH	Schmalkalden-Meiningen
98617	Obermaßfeld-Grimmenthal	Thüringen	TH	Schmalkalden-Meiningen
98617	Belrieth	Thüringen	TH	Schmalkalden-Meiningen
98617	Wölfershausen	Thüringen	TH	Schmalkalden-Meiningen
98617	Ellingshausen	Thüringen	TH	Schmalkalden-Meiningen
98617	Bauerbach	Thüringen	TH	Schmalkalden-Meiningen
98617	Leutersdorf	Thüringen	TH	Schmalkalden-Meiningen
98617	Einhausen	Thüringen	TH	Schmalkalden-Meiningen
98617	Neubrunn	Thüringen	TH	Schmalkalden-Meiningen
98617	Vachdorf	Thüringen	TH	Schmalkalden-Meiningen
98617	Ritschenhausen	Thüringen	TH	Schmalkalden-Meiningen
98617	Utendorf	Thüringen	TH	Schmalkalden-Meiningen
98617	Herpf	Thüringen	TH	Schmalkalden-Meiningen
98617	Sülzfeld	Thüringen	TH	Schmalkalden-Meiningen
98617	Rhönblick	Thüringen	TH	Schmalkalden-Meiningen
98617	Untermaßfeld	Thüringen	TH	Schmalkalden-Meiningen
98630	Römhild	Thüringen	TH	Hildburghausen
98630	Milz	Thüringen	TH	Hildburghausen
98630	Mendhausen	Thüringen	TH	Hildburghausen
98630	Westenfeld	Thüringen	TH	Hildburghausen
98631	Wolfmannshausen	Thüringen	TH	Schmalkalden-Meiningen
98631	Behrungen	Thüringen	TH	Schmalkalden-Meiningen
98631	Jüchsen	Thüringen	TH	Schmalkalden-Meiningen
98631	Bibra	Thüringen	TH	Schmalkalden-Meiningen
98631	Rentwertshausen	Thüringen	TH	Schmalkalden-Meiningen
98631	Nordheim	Thüringen	TH	Schmalkalden-Meiningen
98631	Schwickershausen	Thüringen	TH	Schmalkalden-Meiningen
98631	Berkach	Thüringen	TH	Schmalkalden-Meiningen
98631	Queienfeld	Thüringen	TH	Schmalkalden-Meiningen
98631	Exdorf	Thüringen	TH	Schmalkalden-Meiningen
98634	Wasungen	Thüringen	TH	Schmalkalden-Meiningen
98634	Unterweid	Thüringen	TH	Schmalkalden-Meiningen
98634	Wahns	Thüringen	TH	Schmalkalden-Meiningen
98634	Aschenhausen	Thüringen	TH	Schmalkalden-Meiningen
98634	Frankenheim	Thüringen	TH	Schmalkalden-Meiningen
98634	Oepfershausen	Thüringen	TH	Schmalkalden-Meiningen
98634	Hümpfershausen	Thüringen	TH	Schmalkalden-Meiningen
98634	Erbenhausen	Thüringen	TH	Schmalkalden-Meiningen
98634	Unterkatz	Thüringen	TH	Schmalkalden-Meiningen
98634	Friedelshausen	Thüringen	TH	Schmalkalden-Meiningen
98634	Mehmels	Thüringen	TH	Schmalkalden-Meiningen
98634	Birx	Thüringen	TH	Schmalkalden-Meiningen
98634	Kaltenwestheim	Thüringen	TH	Schmalkalden-Meiningen
98634	Kaltensundheim	Thüringen	TH	Schmalkalden-Meiningen
98634	Oberweid	Thüringen	TH	Schmalkalden-Meiningen
98634	Oberkatz	Thüringen	TH	Schmalkalden-Meiningen
98634	Melpers	Thüringen	TH	Schmalkalden-Meiningen
98639	Rippershausen	Thüringen	TH	Schmalkalden-Meiningen
98639	Wallbach	Thüringen	TH	Schmalkalden-Meiningen
98639	Walldorf	Thüringen	TH	Schmalkalden-Meiningen
98639	Metzels	Thüringen	TH	Schmalkalden-Meiningen
98646	Gleichamberg	Thüringen	TH	Hildburghausen
98646	Straufhain	Thüringen	TH	Hildburghausen
98646	Hildburghausen	Thüringen	TH	Hildburghausen
98646	Trostadt	Thüringen	TH	Hildburghausen
98646	Siegritz	Thüringen	TH	Hildburghausen
98646	Reurieth	Thüringen	TH	Hildburghausen
98646	Dingsleben	Thüringen	TH	Hildburghausen
98660	Ehrenberg	Thüringen	TH	Hildburghausen
98660	Henfstädt	Thüringen	TH	Hildburghausen
98660	Themar	Thüringen	TH	Hildburghausen
98660	Kloster Veßra	Thüringen	TH	Hildburghausen
98660	Beinerstadt	Thüringen	TH	Hildburghausen
98660	Lengfeld	Thüringen	TH	Hildburghausen
98660	Grimmelshausen	Thüringen	TH	Hildburghausen
98660	Sankt Bernhard	Thüringen	TH	Hildburghausen
98663	Schweickershausen	Thüringen	TH	Hildburghausen
98663	Ummerstadt	Thüringen	TH	Hildburghausen
98663	Westhausen	Thüringen	TH	Hildburghausen
98663	Gompertshausen	Thüringen	TH	Hildburghausen
98663	Hellingen	Thüringen	TH	Hildburghausen
98663	Bad Colberg-Heldburg	Thüringen	TH	Hildburghausen
98666	Masserberg	Thüringen	TH	Hildburghausen
98667	Schleusegrund	Thüringen	TH	Hildburghausen
98669	Schlechtsart	Thüringen	TH	Hildburghausen
98669	Veilsdorf	Thüringen	TH	Hildburghausen
98673	Auengrund	Thüringen	TH	Hildburghausen
98673	Brünn	Thüringen	TH	Hildburghausen
98673	Eisfeld	Thüringen	TH	Hildburghausen
98678	Sachsenbrunn	Thüringen	TH	Hildburghausen
98693	Ilmenau	Thüringen	TH	Ilm
98693	Martinroda	Thüringen	TH	Ilm
98701	Herschdorf	Thüringen	TH	Ilm
98701	Gillersdorf	Thüringen	TH	Ilm
98701	Großbreitenbach	Thüringen	TH	Ilm
98701	Altenfeld	Thüringen	TH	Ilm
98701	Neustadt am Rennsteig	Thüringen	TH	Ilm
98701	Wildenspring	Thüringen	TH	Ilm
98701	Böhlen	Thüringen	TH	Ilm
98701	Friedersdorf	Thüringen	TH	Ilm
98704	Wolfsberg	Thüringen	TH	Ilm
98704	Langewiesen	Thüringen	TH	Ilm
98708	Gehren	Thüringen	TH	Ilm
98708	Pennewitz	Thüringen	TH	Ilm
98708	Möhrenbach	Thüringen	TH	Ilm
98711	Frauenwald	Thüringen	TH	Ilm
98711	Schmiedefeld am Rennsteig	Thüringen	TH	Suhl
98714	Stützerbach	Thüringen	TH	Ilm
98716	Elgersburg	Thüringen	TH	Ilm
98716	Geraberg	Thüringen	TH	Ilm
98716	Geschwenda	Thüringen	TH	Ilm
98724	Lauscha	Thüringen	TH	Sonneberg
98724	Neuhaus am Rennweg	Thüringen	TH	Sonneberg
98739	Lichte	Thüringen	TH	Sonneberg
98739	Piesau	Thüringen	TH	Sonneberg
98739	Reichmannsdorf	Thüringen	TH	Saalfeld-Rudolstadt
98739	Schmiedefeld	Thüringen	TH	Saalfeld-Rudolstadt
98743	Gräfenthal	Thüringen	TH	Saalfeld-Rudolstadt
98744	Deesbach	Thüringen	TH	Saalfeld-Rudolstadt
98744	Oberweißbach	Thüringen	TH	Saalfeld-Rudolstadt
98744	Unterweißbach	Thüringen	TH	Saalfeld-Rudolstadt
98744	Lichtenhain/Bergbahn	Thüringen	TH	Saalfeld-Rudolstadt
98744	Meura	Thüringen	TH	Saalfeld-Rudolstadt
98744	Cursdorf	Thüringen	TH	Saalfeld-Rudolstadt
98746	Mellenbach-Glasbach	Thüringen	TH	Saalfeld-Rudolstadt
98746	Katzhütte	Thüringen	TH	Saalfeld-Rudolstadt
98746	Meuselbach-Schwarzmühle	Thüringen	TH	Saalfeld-Rudolstadt
98746	Goldisthal	Thüringen	TH	Sonneberg
98749	Siegmundsburg	Thüringen	TH	Sonneberg
98749	Scheibe-Alsbach	Thüringen	TH	Sonneberg
98749	Steinheid	Thüringen	TH	Sonneberg
99084	Erfurt	Thüringen	TH	Erfurt; Stadt
99085	Erfurt	Thüringen	TH	Erfurt; Stadt
99086	Erfurt	Thüringen	TH	Erfurt; Stadt
99087	Erfurt	Thüringen	TH	Erfurt; Stadt
99089	Erfurt	Thüringen	TH	Erfurt; Stadt
99091	Erfurt	Thüringen	TH	Erfurt; Stadt
99092	Erfurt	Thüringen	TH	Erfurt; Stadt
99094	Erfurt	Thüringen	TH	Erfurt; Stadt
99096	Erfurt	Thüringen	TH	Erfurt; Stadt
99097	Erfurt	Thüringen	TH	Erfurt; Stadt
99098	Erfurt	Thüringen	TH	Erfurt; Stadt
99099	Erfurt	Thüringen	TH	Erfurt; Stadt
99100	Döllstädt	Thüringen	TH	Gotha
99100	Zimmernsupra	Thüringen	TH	Gotha
99100	Großfahner	Thüringen	TH	Gotha
99100	Bienstädt	Thüringen	TH	Gotha
99100	Gierstädt/Kleinfahner	Thüringen	TH	Gotha
99100	Dachwig	Thüringen	TH	Gotha
99102	Klettbach	Thüringen	TH	Weimarer Land
99102	Rockhausen	Thüringen	TH	Ilm
99130	Marlishausen	Thüringen	TH	Ilm
99189	Elxleben	Thüringen	TH	Sömmerda
99189	Gebesee	Thüringen	TH	Sömmerda
99189	Andisleben	Thüringen	TH	Sömmerda
99189	Walschleben	Thüringen	TH	Sömmerda
99189	Witterda	Thüringen	TH	Sömmerda
99189	Ringleben	Thüringen	TH	Sömmerda
99189	Haßleben	Thüringen	TH	Sömmerda
99192	Ingersleben	Thüringen	TH	Gotha
99192	Neudietendorf	Thüringen	TH	Gotha
99192	Nottleben	Thüringen	TH	Gotha
99192	Apfelstädt	Thüringen	TH	Gotha
99192	Gamstädt	Thüringen	TH	Gotha
99195	Großrudestedt	Thüringen	TH	Sömmerda
99195	Eckstedt	Thüringen	TH	Sömmerda
99195	Alperstedt	Thüringen	TH	Sömmerda
99195	Riethnordhausen	Thüringen	TH	Sömmerda
99195	Markvippach	Thüringen	TH	Sömmerda
99195	Schloßvippach	Thüringen	TH	Sömmerda
99195	Nöda	Thüringen	TH	Sömmerda
99198	Großmölsen	Thüringen	TH	Sömmerda
99198	Kleinmölsen	Thüringen	TH	Sömmerda
99198	Ollendorf	Thüringen	TH	Sömmerda
99198	Udestedt	Thüringen	TH	Sömmerda
99198	Mönchenholzhausen	Thüringen	TH	Weimarer Land
99310	Dornheim	Thüringen	TH	Ilm
99310	Wipfratal	Thüringen	TH	Ilm
99310	Wachsenburggemeinde	Thüringen	TH	Ilm
99310	Arnstadt	Thüringen	TH	Ilm
99310	Witzleben	Thüringen	TH	Ilm
99310	Osthausen-Wülfershausen	Thüringen	TH	Ilm
99310	Alkersleben	Thüringen	TH	Ilm
99310	Bösleben-Wüllersleben	Thüringen	TH	Ilm
99326	Ilmtal	Thüringen	TH	Ilm
99326	Stadtilm	Thüringen	TH	Ilm
99330	Liebenstein	Thüringen	TH	Ilm
99330	Gräfenroda	Thüringen	TH	Ilm
99330	Frankenhain	Thüringen	TH	Ilm
99330	Crawinkel	Thüringen	TH	Gotha
99334	Kirchheim	Thüringen	TH	Ilm
99334	Ichtershausen	Thüringen	TH	Ilm
99334	Elxleben	Thüringen	TH	Ilm
99334	Elleben	Thüringen	TH	Ilm
99338	Gossel	Thüringen	TH	Ilm
99338	Plaue	Thüringen	TH	Ilm
99338	Angelroda	Thüringen	TH	Ilm
99338	Neusiß	Thüringen	TH	Ilm
99423	Weimar	Thüringen	TH	Weimar; Stadt
99428	Daasdorf am Berge	Thüringen	TH	Weimarer Land
99428	Utzberg	Thüringen	TH	Weimarer Land
99428	Nohra	Thüringen	TH	Weimarer Land
99428	Hopfgarten	Thüringen	TH	Weimarer Land
99428	Bechstedtstraß	Thüringen	TH	Weimarer Land
99428	Ottstedt am Berge	Thüringen	TH	Weimarer Land
99428	Isseroda	Thüringen	TH	Weimarer Land
99428	Niederzimmern	Thüringen	TH	Weimarer Land
99438	Troistedt	Thüringen	TH	Weimarer Land
99438	Tonndorf	Thüringen	TH	Weimarer Land
99438	Buchfart	Thüringen	TH	Weimarer Land
99438	Vollersroda	Thüringen	TH	Weimarer Land
99438	Gutendorf	Thüringen	TH	Weimarer Land
99438	Bad Berka	Thüringen	TH	Weimarer Land
99438	Hetschburg	Thüringen	TH	Weimarer Land
99438	Oettern	Thüringen	TH	Weimarer Land
99439	Leutenthal	Thüringen	TH	Weimarer Land
99439	Sachsenhausen	Thüringen	TH	Weimarer Land
99439	Ballstedt	Thüringen	TH	Weimarer Land
99439	Krautheim	Thüringen	TH	Weimarer Land
99439	Schwerstedt	Thüringen	TH	Weimarer Land
99439	Ramsla	Thüringen	TH	Weimarer Land
99439	Kleinobringen	Thüringen	TH	Weimarer Land
99439	Buttelstedt	Thüringen	TH	Weimarer Land
99439	Rohrbach	Thüringen	TH	Weimarer Land
99439	Berlstedt	Thüringen	TH	Weimarer Land
99439	Ettersburg	Thüringen	TH	Weimarer Land
99439	Neumark	Thüringen	TH	Weimarer Land
99439	Wohlsborn	Thüringen	TH	Weimarer Land
99439	Heichelheim	Thüringen	TH	Weimarer Land
99439	Vippachedelhausen	Thüringen	TH	Weimarer Land
99439	Großobringen	Thüringen	TH	Weimarer Land
99439	Hottelstedt	Thüringen	TH	Weimarer Land
99441	Frankendorf	Thüringen	TH	Weimarer Land
99441	Lehnstedt	Thüringen	TH	Weimarer Land
99441	Kromsdorf	Thüringen	TH	Weimarer Land
99441	Döbritschen	Thüringen	TH	Weimarer Land
99441	Magdala	Thüringen	TH	Weimarer Land
99441	Kiliansroda	Thüringen	TH	Weimarer Land
99441	Umpferstedt	Thüringen	TH	Weimarer Land
99441	Mechelroda	Thüringen	TH	Weimarer Land
99441	Hammerstedt	Thüringen	TH	Weimarer Land
12619	Berlin	Berlin	BE	Berlin; Stadt
99441	Kleinschwabhausen	Thüringen	TH	Weimarer Land
99441	Hohlstedt	Thüringen	TH	Weimarer Land
99441	Mellingen	Thüringen	TH	Weimarer Land
99441	Großschwabhausen	Thüringen	TH	Weimarer Land
99444	Blankenhain	Thüringen	TH	Weimarer Land
99448	Kranichfeld	Thüringen	TH	Weimarer Land
99448	Nauendorf	Thüringen	TH	Weimarer Land
99448	Rittersdorf	Thüringen	TH	Weimarer Land
99448	Hohenfelden	Thüringen	TH	Weimarer Land
99510	Flurstedt	Thüringen	TH	Weimarer Land
99510	Kapellendorf	Thüringen	TH	Weimarer Land
99510	Mattstedt	Thüringen	TH	Weimarer Land
99510	Oßmannstedt	Thüringen	TH	Weimarer Land
99510	Willerstedt	Thüringen	TH	Weimarer Land
99510	Obertrebra	Thüringen	TH	Weimarer Land
99510	Apolda	Thüringen	TH	Weimarer Land
99510	Liebstedt	Thüringen	TH	Weimarer Land
99510	Gebstedt	Thüringen	TH	Weimarer Land
99510	Saaleplatte	Thüringen	TH	Weimarer Land
99510	Oberreißen	Thüringen	TH	Weimarer Land
99510	Wickerstedt	Thüringen	TH	Weimarer Land
99510	Niederroßla	Thüringen	TH	Weimarer Land
99510	Pfiffelbach	Thüringen	TH	Weimarer Land
99510	Wiegendorf	Thüringen	TH	Weimarer Land
99510	Nirmsdorf	Thüringen	TH	Weimarer Land
99510	Niederreißen	Thüringen	TH	Weimarer Land
99518	Großheringen	Thüringen	TH	Weimarer Land
99518	Niedertrebra	Thüringen	TH	Weimarer Land
99518	Reisdorf	Thüringen	TH	Weimarer Land
99518	Eberstedt	Thüringen	TH	Weimarer Land
99518	Auerstedt	Thüringen	TH	Weimarer Land
99518	Bad Sulza	Thüringen	TH	Weimarer Land
99518	Ködderitzsch	Thüringen	TH	Weimarer Land
99518	Rannstedt	Thüringen	TH	Weimarer Land
99518	Schmiedehausen	Thüringen	TH	Weimarer Land
99610	Wundersleben	Thüringen	TH	Sömmerda
99610	Großbrembach	Thüringen	TH	Sömmerda
99610	Sprötau	Thüringen	TH	Sömmerda
99610	Vogelsberg	Thüringen	TH	Sömmerda
99610	Kleinbrembach	Thüringen	TH	Sömmerda
99610	Sömmerda	Thüringen	TH	Sömmerda
99625	Schillingstedt	Thüringen	TH	Sömmerda
99625	Kleinneuhausen	Thüringen	TH	Sömmerda
99625	Kölleda	Thüringen	TH	Sömmerda
99625	Großmonra	Thüringen	TH	Sömmerda
99625	Großneuhausen	Thüringen	TH	Sömmerda
99625	Beichlingen	Thüringen	TH	Sömmerda
99628	Eßleben-Teutleben	Thüringen	TH	Sömmerda
99628	Rudersdorf	Thüringen	TH	Sömmerda
99628	Guthmannshausen	Thüringen	TH	Sömmerda
99628	Mannstedt	Thüringen	TH	Sömmerda
99628	Olbersleben	Thüringen	TH	Sömmerda
99628	Buttstädt	Thüringen	TH	Sömmerda
99628	Ellersleben	Thüringen	TH	Sömmerda
99628	Hardisleben	Thüringen	TH	Sömmerda
99631	Weißensee	Thüringen	TH	Sömmerda
99631	Herrnschwende	Thüringen	TH	Sömmerda
99631	Günstedt	Thüringen	TH	Sömmerda
99634	Schwerstedt	Thüringen	TH	Sömmerda
99634	Werningshausen	Thüringen	TH	Sömmerda
99634	Gangloffsömmern	Thüringen	TH	Sömmerda
99634	Straußfurt	Thüringen	TH	Sömmerda
99634	Henschleben	Thüringen	TH	Sömmerda
99636	Ostramondra	Thüringen	TH	Sömmerda
99636	Rastenberg	Thüringen	TH	Sömmerda
99638	Kindelbrück	Thüringen	TH	Sömmerda
99638	Griefstedt	Thüringen	TH	Sömmerda
99638	Riethgen	Thüringen	TH	Sömmerda
99638	Büchel	Thüringen	TH	Sömmerda
99638	Frömmstedt	Thüringen	TH	Sömmerda
99706	Sondershausen	Thüringen	TH	Kyffhäuserkreis
99707	Bendeleben	Thüringen	TH	Kyffhäuserkreis
99707	Günserode	Thüringen	TH	Kyffhäuserkreis
99707	Hachelbich	Thüringen	TH	Kyffhäuserkreis
99707	Rottleben	Thüringen	TH	Kyffhäuserkreis
99707	Badra	Thüringen	TH	Kyffhäuserkreis
99707	Steinthaleben	Thüringen	TH	Kyffhäuserkreis
99707	Seega	Thüringen	TH	Kyffhäuserkreis
99707	Göllingen	Thüringen	TH	Kyffhäuserkreis
99713	Freienbessingen	Thüringen	TH	Kyffhäuserkreis
99713	Bellstedt	Thüringen	TH	Kyffhäuserkreis
99713	Thüringenhausen	Thüringen	TH	Kyffhäuserkreis
99713	Helbedündorf	Thüringen	TH	Kyffhäuserkreis
99713	Rockstedt	Thüringen	TH	Kyffhäuserkreis
99713	Ebeleben	Thüringen	TH	Kyffhäuserkreis
99713	Abtsbessingen	Thüringen	TH	Kyffhäuserkreis
99713	Schernberg	Thüringen	TH	Kyffhäuserkreis
99713	Wolferschwenda	Thüringen	TH	Kyffhäuserkreis
99713	Holzsußra	Thüringen	TH	Kyffhäuserkreis
99718	Wasserthaleben	Thüringen	TH	Kyffhäuserkreis
99718	Topfstedt	Thüringen	TH	Kyffhäuserkreis
99718	Greußen	Thüringen	TH	Kyffhäuserkreis
99718	Großenehrich	Thüringen	TH	Kyffhäuserkreis
99718	Trebra	Thüringen	TH	Kyffhäuserkreis
99718	Oberbösa	Thüringen	TH	Kyffhäuserkreis
99718	Niederbösa	Thüringen	TH	Kyffhäuserkreis
99718	Westgreußen	Thüringen	TH	Kyffhäuserkreis
99718	Clingen	Thüringen	TH	Kyffhäuserkreis
99734	Nordhausen	Thüringen	TH	Nordhausen
99735	Friedrichsthal	Thüringen	TH	Nordhausen
99735	Etzelsrode	Thüringen	TH	Nordhausen
99735	Kleinfurra	Thüringen	TH	Nordhausen
99735	Petersdorf	Thüringen	TH	Nordhausen
99735	Wolkramshausen	Thüringen	TH	Nordhausen
99735	Hohenstein	Thüringen	TH	Nordhausen
99735	Nohra	Thüringen	TH	Nordhausen
99735	Hainrode	Thüringen	TH	Nordhausen
99735	Werther	Thüringen	TH	Nordhausen
99752	Kleinbodungen	Thüringen	TH	Nordhausen
99752	Wipperdorf	Thüringen	TH	Nordhausen
99752	Lipprechterode	Thüringen	TH	Nordhausen
99752	Kehmstedt	Thüringen	TH	Nordhausen
99752	Kraja	Thüringen	TH	Nordhausen
99755	Hohenstein	Thüringen	TH	Nordhausen
99755	Ellrich	Thüringen	TH	Nordhausen
99759	Großlohra	Thüringen	TH	Nordhausen
99759	Rehungen	Thüringen	TH	Nordhausen
99759	Obergebra	Thüringen	TH	Nordhausen
99759	Niedergebra	Thüringen	TH	Nordhausen
99762	Buchholz	Thüringen	TH	Nordhausen
99762	Rodishain	Thüringen	TH	Nordhausen
99762	Stempeda	Thüringen	TH	Nordhausen
99762	Neustadt/Harz	Thüringen	TH	Nordhausen
99762	Harzungen	Thüringen	TH	Nordhausen
99762	Herrmannsacker	Thüringen	TH	Nordhausen
99762	Niedersachswerfen	Thüringen	TH	Nordhausen
99765	Hamma	Thüringen	TH	Nordhausen
99765	Auleben	Thüringen	TH	Nordhausen
99765	Heringen/Helme	Thüringen	TH	Nordhausen
99765	Görsbach	Thüringen	TH	Nordhausen
99765	Windehausen	Thüringen	TH	Nordhausen
99765	Uthleben	Thüringen	TH	Nordhausen
99765	Urbach	Thüringen	TH	Nordhausen
99768	Ilfeld	Thüringen	TH	Nordhausen
99817	Eisenach	Thüringen	TH	Eisenach; Stadt
99819	Wolfsburg-Unkeroda	Thüringen	TH	Wartburgkreis
99819	Marksuhl	Thüringen	TH	Wartburgkreis
99819	Hörselberg	Thüringen	TH	Wartburgkreis
99819	Ettenhausen an der Suhl	Thüringen	TH	Wartburgkreis
99819	Krauthausen	Thüringen	TH	Wartburgkreis
99820	Behringen	Thüringen	TH	Wartburgkreis
99826	Nazza	Thüringen	TH	Wartburgkreis
99826	Mihla	Thüringen	TH	Wartburgkreis
99826	Lauterbach	Thüringen	TH	Wartburgkreis
99826	Bischofroda	Thüringen	TH	Wartburgkreis
99826	Berka vor der Hainich	Thüringen	TH	Wartburgkreis
99826	Frankenroda	Thüringen	TH	Wartburgkreis
99826	Hallungen	Thüringen	TH	Wartburgkreis
99826	Ebenshausen	Thüringen	TH	Wartburgkreis
99830	Treffurt	Thüringen	TH	Wartburgkreis
99831	Creuzburg	Thüringen	TH	Wartburgkreis
99831	Ifta	Thüringen	TH	Wartburgkreis
99834	Lauchröden	Thüringen	TH	Wartburgkreis
99834	Gerstungen	Thüringen	TH	Wartburgkreis
99834	Unterellen	Thüringen	TH	Wartburgkreis
99834	Oberellen	Thüringen	TH	Wartburgkreis
99837	Dankmarshausen	Thüringen	TH	Wartburgkreis
99837	Berka/Werra	Thüringen	TH	Wartburgkreis
99837	Großensee	Thüringen	TH	Wartburgkreis
99837	Dippach	Thüringen	TH	Wartburgkreis
99842	Ruhla	Thüringen	TH	Wartburgkreis
99846	Seebach	Thüringen	TH	Wartburgkreis
99848	Wutha-Farnroda	Thüringen	TH	Wartburgkreis
99848	Hörselberg	Thüringen	TH	Wartburgkreis
99867	Gotha	Thüringen	TH	Gotha
99869	Hochheim	Thüringen	TH	Gotha
99869	Seebergen	Thüringen	TH	Gotha
99869	Bufleben	Thüringen	TH	Gotha
99869	Günthersleben	Thüringen	TH	Gotha
99869	Tröchtelborn	Thüringen	TH	Gotha
99869	Ebenheim	Thüringen	TH	Gotha
99869	Pferdingsleben	Thüringen	TH	Gotha
99869	Tüttleben	Thüringen	TH	Gotha
99869	Wangenheim	Thüringen	TH	Gotha
99869	Warza	Thüringen	TH	Gotha
99880	Hörselgau	Thüringen	TH	Gotha
99880	Metebach	Thüringen	TH	Gotha
99880	Fröttstädt	Thüringen	TH	Gotha
99880	Teutleben	Thüringen	TH	Gotha
99880	Trügleben	Thüringen	TH	Gotha
99885	Luisenthal	Thüringen	TH	Gotha
99885	Wölfis	Thüringen	TH	Gotha
99885	Ohrdruf	Thüringen	TH	Gotha
99887	Georgenthal	Thüringen	TH	Gotha
99887	Petriroda	Thüringen	TH	Gotha
99887	Gräfenhain	Thüringen	TH	Gotha
99887	Herrenhof	Thüringen	TH	Gotha
99887	Hohenkirchen	Thüringen	TH	Gotha
99891	Tabarz	Thüringen	TH	Gotha
99891	Emsetal	Thüringen	TH	Gotha
99894	Friedrichroda	Thüringen	TH	Gotha
99894	Finsterbergen	Thüringen	TH	Gotha
99894	Ernstroda	Thüringen	TH	Gotha
99897	Tambach-Dietharz	Thüringen	TH	Gotha
99947	Mülverstedt	Thüringen	TH	Unstrut-Hainich
99947	Sundhausen	Thüringen	TH	Unstrut-Hainich
99947	Tottleben	Thüringen	TH	Unstrut-Hainich
99947	Kleinwelsbach	Thüringen	TH	Unstrut-Hainich
99947	Schönstedt	Thüringen	TH	Unstrut-Hainich
99947	Neunheilingen	Thüringen	TH	Unstrut-Hainich
99947	Weberstedt	Thüringen	TH	Unstrut-Hainich
99947	Bad Langensalza	Thüringen	TH	Unstrut-Hainich
99947	Bothenheilingen	Thüringen	TH	Unstrut-Hainich
99947	Issersheilingen	Thüringen	TH	Unstrut-Hainich
99947	Kirchheilingen	Thüringen	TH	Unstrut-Hainich
99955	Kutzleben	Thüringen	TH	Unstrut-Hainich
99955	Haussömmern	Thüringen	TH	Unstrut-Hainich
99955	Bad Tennstedt	Thüringen	TH	Unstrut-Hainich
99955	Herbsleben	Thüringen	TH	Unstrut-Hainich
99955	Bruchstedt	Thüringen	TH	Unstrut-Hainich
99955	Hornsömmern	Thüringen	TH	Unstrut-Hainich
99955	Mittelsömmern	Thüringen	TH	Unstrut-Hainich
99955	Urleben	Thüringen	TH	Unstrut-Hainich
99955	Ballhausen	Thüringen	TH	Unstrut-Hainich
99955	Blankenburg	Thüringen	TH	Unstrut-Hainich
99955	Klettstedt	Thüringen	TH	Unstrut-Hainich
99958	Tonna	Thüringen	TH	Gotha
99958	Großvargula	Thüringen	TH	Unstrut-Hainich
99974	Unstruttal	Thüringen	TH	Unstrut-Hainich
99974	Mühlhausen	Thüringen	TH	Unstrut-Hainich
12621	Berlin	Berlin	BE	Berlin; Stadt
99976	Anrode	Thüringen	TH	Unstrut-Hainich
99976	Hildebrandshausen	Thüringen	TH	Unstrut-Hainich
99976	Unstruttal	Thüringen	TH	Unstrut-Hainich
99976	Rodeberg	Thüringen	TH	Unstrut-Hainich
99976	Dünwald	Thüringen	TH	Unstrut-Hainich
99976	Lengenfeld unterm Stein	Thüringen	TH	Unstrut-Hainich
99986	Langula	Thüringen	TH	Unstrut-Hainich
99986	Oberdorla	Thüringen	TH	Unstrut-Hainich
99986	Oppershausen	Thüringen	TH	Unstrut-Hainich
99986	Kammerforst	Thüringen	TH	Unstrut-Hainich
99986	Flarchheim	Thüringen	TH	Unstrut-Hainich
99986	Niederdorla	Thüringen	TH	Unstrut-Hainich
99988	Heyerode	Thüringen	TH	Unstrut-Hainich
99988	Katharinenberg	Thüringen	TH	Unstrut-Hainich
99991	Großengottern	Thüringen	TH	Unstrut-Hainich
99991	Altengottern	Thüringen	TH	Unstrut-Hainich
99991	Heroldishausen	Thüringen	TH	Unstrut-Hainich
99994	Marolterode	Thüringen	TH	Unstrut-Hainich
99994	Schlotheim	Thüringen	TH	Unstrut-Hainich
99996	Menteroda	Thüringen	TH	Unstrut-Hainich
99996	Obermehler	Thüringen	TH	Unstrut-Hainich
99998	Körner	Thüringen	TH	Unstrut-Hainich
99998	Mühlhausen/Thüringen	Thüringen	TH	Unstrut-Hainich
12623	Berlin	Berlin	BE	Berlin; Stadt
1945	Guteborn	Brandenburg	BB	Oberspreewald-Lausitz
1945	Kroppen	Brandenburg	BB	Oberspreewald-Lausitz
1945	Tettau	Brandenburg	BB	Oberspreewald-Lausitz
1945	Ruhland	Brandenburg	BB	Oberspreewald-Lausitz
1945	Schwarzbach	Brandenburg	BB	Oberspreewald-Lausitz
1945	Hohenbocka	Brandenburg	BB	Oberspreewald-Lausitz
1945	Hermsdorf	Brandenburg	BB	Oberspreewald-Lausitz
1945	Grünewald	Brandenburg	BB	Oberspreewald-Lausitz
1945	Lindenau	Brandenburg	BB	Oberspreewald-Lausitz
1968	Senftenberg	Brandenburg	BB	Oberspreewald-Lausitz
1968	Schipkau Hörlitz	Brandenburg	BB	Oberspreewald-Lausitz
1968	Schipkau	Brandenburg	BB	Oberspreewald-Lausitz
1979	Lauchhammer	Brandenburg	BB	Oberspreewald-Lausitz
1983	Neu-Seeland	Brandenburg	BB	Oberspreewald-Lausitz
1983	Großräschen	Brandenburg	BB	Oberspreewald-Lausitz
1987	Schwarzheide	Brandenburg	BB	Oberspreewald-Lausitz
1990	Ortrand	Brandenburg	BB	Oberspreewald-Lausitz
1990	Großkmehlen	Brandenburg	BB	Oberspreewald-Lausitz
1990	Frauendorf	Brandenburg	BB	Oberspreewald-Lausitz
1993	Schipkau	Brandenburg	BB	Oberspreewald-Lausitz
1993	Schipkau Schipkau	Brandenburg	BB	Oberspreewald-Lausitz
1994	Schipkau	Brandenburg	BB	Oberspreewald-Lausitz
1994	Schipkau Meuro	Brandenburg	BB	Oberspreewald-Lausitz
1994	Schipkau Drochow	Brandenburg	BB	Oberspreewald-Lausitz
1994	Schipkau Annahütte; Annahütte-Siedlung	Brandenburg	BB	Oberspreewald-Lausitz
1994	Schipkau Annahütte; Annahütte	Brandenburg	BB	Oberspreewald-Lausitz
1994	Schipkau Annahütte; Herrnnmühle	Brandenburg	BB	Oberspreewald-Lausitz
1994	Schipkau Annahütte	Brandenburg	BB	Oberspreewald-Lausitz
1994	Schipkau Annahütte; Karl-Marx-Siedlung	Brandenburg	BB	Oberspreewald-Lausitz
1996	Hosena	Brandenburg	BB	Oberspreewald-Lausitz
1998	Schipkau Klettwitz	Brandenburg	BB	Oberspreewald-Lausitz
1998	Schipkau Meuro	Brandenburg	BB	Oberspreewald-Lausitz
1998	Schipkau	Brandenburg	BB	Oberspreewald-Lausitz
3042	Cottbus	Brandenburg	BB	Cottbus
3044	Cottbus	Brandenburg	BB	Cottbus
3046	Cottbus	Brandenburg	BB	Cottbus
3048	Cottbus	Brandenburg	BB	Cottbus
3050	Cottbus	Brandenburg	BB	Cottbus
3051	Cottbus	Brandenburg	BB	Cottbus
3052	Cottbus	Brandenburg	BB	Cottbus
3053	Cottbus	Brandenburg	BB	Cottbus
3054	Cottbus	Brandenburg	BB	Cottbus
3055	Cottbus	Brandenburg	BB	Cottbus
3058	Groß Döbbern	Brandenburg	BB	Spree-Neiße
3058	Sergen	Brandenburg	BB	Spree-Neiße
3058	Neuhausen	Brandenburg	BB	Spree-Neiße
3058	Haasow	Brandenburg	BB	Spree-Neiße
3058	Klein Döbbern	Brandenburg	BB	Spree-Neiße
79280	Au	Baden-Württemberg	BW	83
99427	Weimar	Thüringen	TH	Weimar; Stadt
99869	Friedrichswerth	Thüringen	TH	Gotha
99869	Wechmar	Thüringen	TH	Gotha
99869	Grabsleben	Thüringen	TH	Gotha
99869	Mühlberg	Thüringen	TH	Gotha
99869	Sonneborn	Thüringen	TH	Gotha
99869	Weingarten	Thüringen	TH	Gotha
99869	Goldbach	Thüringen	TH	Gotha
99869	Remstädt	Thüringen	TH	Gotha
99869	Emleben	Thüringen	TH	Gotha
99869	Brüheim	Thüringen	TH	Gotha
99869	Friemar	Thüringen	TH	Gotha
99869	Molschleben	Thüringen	TH	Gotha
99869	Westhausen	Thüringen	TH	Gotha
99869	Ballstädt	Thüringen	TH	Gotha
99869	Wandersleben	Thüringen	TH	Gotha
99869	Eschenbergen	Thüringen	TH	Gotha
99869	Schwabhausen	Thüringen	TH	Gotha
99869	Haina	Thüringen	TH	Gotha
99880	Mechterstädt	Thüringen	TH	Gotha
99880	Laucha	Thüringen	TH	Gotha
99880	Leinatal	Thüringen	TH	Gotha
99880	Waltershausen	Thüringen	TH	Gotha
99880	Aspach	Thüringen	TH	Gotha
\.


--
-- PostgreSQL database dump complete
--

